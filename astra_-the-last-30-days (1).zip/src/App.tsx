/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { MissionState, DifficultyLevel, DecisionChoice, EmergencyOption, OutpostModuleAction, CrewMember, RocketId } from './types/mission';
import { DAILY_DECISIONS } from './data/missionContent';
import { MOON_SPOTS, MoonSpot, getRocketSpec } from './data/rocketCatalog';
import { simulationEngine } from './services/simulationEngine';
import { storageService } from './services/storageService';
import { soundEngine } from './services/soundEngine';

import { TopBar } from './components/TopBar';
import { LandingPage } from './components/LandingPage';
import { OpeningRocketPromo3D } from './components/OpeningRocketPromo3D';
import { MoonGlobeFlight3D } from './components/MoonGlobeFlight3D';
import { CinematicIntro } from './components/CinematicIntro';
import { MissionBriefing } from './components/MissionBriefing';
import { CrewIntroView } from './components/CrewIntroView';
import { RocketSelectStep } from './components/RocketSelectStep';
import { InstructionsStep } from './components/InstructionsStep';
import { MainGameScreen } from './components/MainGameScreen';
import { DashboardView } from './components/DashboardView';
import { DailyDecisionModal } from './components/DailyDecisionModal';
import { EmergencyModal } from './components/EmergencyModal';
import { FinalReportView } from './components/FinalReportView';
import { AnimatedTutorial } from './components/AnimatedTutorial';
import { ScienceModal } from './components/ScienceModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { DeepSpaceBackground } from './components/DeepSpaceBackground';
import { RocketLaunchCelebration } from './components/RocketLaunchCelebration';
import { AstronautGuide } from './components/AstronautGuide';
import { DiscoveryModal } from './components/DiscoveryModal';
import { DiscoveryLogModal } from './components/DiscoveryLogModal';
import { NASA_DISCOVERIES, DiscoveryFact } from './data/discoveriesData';
import { LUNAR_BADGES, BadgeDefinition } from './data/badgeData';
import { BadgeCeremonyModal } from './components/BadgeCeremonyModal';
import { BadgeCollectionModal } from './components/BadgeCollectionModal';
import { RestartConfirmationModal } from './components/RestartConfirmationModal';
import { MissionInitialisedModal } from './components/MissionInitialisedModal';

export default function App() {
  // Initialize mission state from localStorage if available, or create initial
  const [missionState, setMissionState] = useState<MissionState>(() => {
    const saved = storageService.loadMission();
    if (saved) return saved;
    return simulationEngine.createInitialMission('beginner');
  });

  const [activeView, setActiveView] = useState<'game' | 'telemetry'>('game');
  const [selectedDifficulty, setSelectedDifficulty] = useState<DifficultyLevel>(missionState.difficulty || 'beginner');

  // Modals state
  const [isDecisionOpen, setIsDecisionOpen] = useState(false);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);
  const [isTutorialOpen, setIsTutorialOpen] = useState(false);
  const [isScienceOpen, setIsScienceOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [isMissionInitialisedOpen, setIsMissionInitialisedOpen] = useState(false);
  const [isResetProcessing, setIsResetProcessing] = useState(false);
  const [newMissionNotification, setNewMissionNotification] = useState<string | null>(null);
  const [isBadgesCollectionOpen, setIsBadgesCollectionOpen] = useState(false);
  const [activeAwardBadge, setActiveAwardBadge] = useState<BadgeDefinition | null>(null);

  // Discovery & Rocket Launch state
  const [showOpeningPromo, setShowOpeningPromo] = useState(true);
  const [launchSetupAfterPromo, setLaunchSetupAfterPromo] = useState(false);
  const [pendingMoonHop, setPendingMoonHop] = useState<{
    fromSpot: MoonSpot;
    toSpot: MoonSpot;
    rocketId: RocketId;
    headline: string;
    subtext: string;
    badgeText: string;
    ctaLabel: string;
    autoCompleteDelayMs?: number;
    nextAction: () => void;
  } | null>(null);
  const [isRocketLaunchActive, setIsRocketLaunchActive] = useState(false);
  const [isDiscoveryOpen, setIsDiscoveryOpen] = useState(false);
  const [selectedDiscovery, setSelectedDiscovery] = useState<DiscoveryFact | null>(null);
  const [isDiscoveryLogOpen, setIsDiscoveryLogOpen] = useState(false);
  const [novaCustomSpeech, setNovaCustomSpeech] = useState<string | null>(null);
  const [pendingPostCeremonyDiscovery, setPendingPostCeremonyDiscovery] = useState<DiscoveryFact | null>(null);

  const missionStateRef = useRef<MissionState>(missionState);
  missionStateRef.current = missionState;
  const isAdvancingDayRef = useRef<boolean>(false);
  const toastTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (toastTimerRef.current !== null) clearTimeout(toastTimerRef.current);
    };
  }, []);

  // Load user audio preferences independently of mission save
  useEffect(() => {
    const prefs = storageService.loadPreferences();
    soundEngine.setMuted(!prefs.soundEnabled);
    setMissionState((prev) => ({ ...prev, soundEnabled: prefs.soundEnabled }));
  }, []);

  // Auto-save whenever mission state changes across active gameplay and preparation phases
  useEffect(() => {
    if (
      missionState.phase === 'active' ||
      missionState.phase === 'victory' ||
      missionState.phase === 'failed' ||
      missionState.phase === 'crew-intro' ||
      missionState.phase === 'briefing' ||
      missionState.phase === 'setup-crew' ||
      missionState.phase === 'setup-rocket' ||
      missionState.phase === 'setup-briefing'
    ) {
      storageService.saveMission(missionState);
    }
  }, [missionState]);

  // Audio start ambient drone on first user interaction
  useEffect(() => {
    const startAudio = () => {
      soundEngine.startAmbientDrone();
      window.removeEventListener('click', startAudio);
      window.removeEventListener('keydown', startAudio);
    };
    window.addEventListener('click', startAudio);
    window.addEventListener('keydown', startAudio);
    return () => {
      window.removeEventListener('click', startAudio);
      window.removeEventListener('keydown', startAudio);
    };
  }, []);

  // Compute daily baseline deltas
  const dailyDeltas = useMemo(() => {
    return simulationEngine.calculateDailyBaselineDeltas(missionState);
  }, [missionState]);

  const triggerMoonHop = useCallback((config: {
    fromSpot: MoonSpot;
    toSpot: MoonSpot;
    rocketId: RocketId;
    headline: string;
    subtext: string;
    badgeText: string;
    ctaLabel: string;
    autoCompleteDelayMs?: number;
    nextAction: () => void;
  }) => {
    soundEngine.playDayAdvance();
    setPendingMoonHop(config);
  }, []);

  // Navigation handlers
  const handleStartMissionSetup = useCallback(() => {
    // If an existing campaign is saved or active, prompt player with the confirmation modal
    if (storageService.hasSave() || (missionState.phase === 'active' && missionState.day > 1)) {
      soundEngine.playWarning();
      setIsResetConfirmOpen(true);
      return;
    }
    // No previous save: fly 3D rocket onto Tranquility Crew Pad for Step 1 (Pick Crew)
    soundEngine.playConfirm();
    const freshMission = simulationEngine.createInitialMission(selectedDifficulty);
    freshMission.phase = 'setup-crew';
    freshMission.selectedRocketId = 'nova-mk1';
    storageService.saveMission(freshMission);
    setMissionState(freshMission);
    setActiveView('game');

    triggerMoonHop({
      fromSpot: MOON_SPOTS.orbitEntry,
      toSpot: MOON_SPOTS.crewPad,
      rocketId: 'nova-mk1',
      badgeText: 'STEP 1 APPROACH',
      headline: `Landing at ${MOON_SPOTS.crewPad.name}`,
      subtext: 'First stop: pick the 4 astronauts joining your Moon expedition!',
      ctaLabel: 'Pick Crew',
      autoCompleteDelayMs: 900,
      nextAction: () => {
        setPendingMoonHop(null);
      },
    });
  }, [selectedDifficulty, missionState, triggerMoonHop]);

  const handleCinematicComplete = useCallback(() => {
    soundEngine.playConfirm();
    setMissionState((prev) => ({
      ...prev,
      phase: 'briefing',
    }));
  }, []);

  const handleResumeSavedMission = useCallback(() => {
    const saved = storageService.loadMission();
    if (saved) {
      soundEngine.playConfirm();
      const targetState = {
        ...saved,
        selectedRocketId: saved.selectedRocketId || 'nova-mk1',
        phase: (saved.phase === 'landing' || saved.phase === 'cinematic') ? ('active' as const) : saved.phase,
      };
      setMissionState(targetState);
      setSelectedDifficulty(saved.difficulty || 'beginner');
      setActiveView('game');
    }
  }, []);

  const handleBriefingProceed = useCallback(() => {
    soundEngine.playConfirm();
    setMissionState((prev) => ({
      ...prev,
      phase: 'setup-crew',
    }));
  }, []);

  const handleCrewIntroProceedToTutorial = useCallback(() => {
    soundEngine.playConfirm();
    setIsTutorialOpen(true);
  }, []);

  const handleProceedToCrewAssembly = useCallback(() => {
    soundEngine.playConfirm();
    setIsMissionInitialisedOpen(false);
    setMissionState((prev) => {
      const updated = {
        ...prev,
        phase: 'setup-crew' as const,
      };
      storageService.saveMission(updated);
      return updated;
    });
  }, []);

  // Step 1 -> Step 2 (Crew Pad -> Tycho Rocket Shipyard)
  const handleCrewSelectedNextToRocket = useCallback((customizedCrew: CrewMember[], crewName: string) => {
    const rocketId = missionStateRef.current.selectedRocketId || 'nova-mk1';
    setMissionState((prev) => {
      const updated: MissionState = {
        ...prev,
        crew: customizedCrew,
        crewName,
      };
      storageService.saveMission(updated);
      return updated;
    });

    triggerMoonHop({
      fromSpot: MOON_SPOTS.crewPad,
      toSpot: MOON_SPOTS.shipyard,
      rocketId,
      badgeText: 'STEP 1 COMPLETE',
      headline: `Flying to ${MOON_SPOTS.shipyard.name}`,
      subtext: `Team ${crewName} is aboard! Next stop: pick your custom Moon rocket.`,
      ctaLabel: 'Choose Rocket',
      autoCompleteDelayMs: 900,
      nextAction: () => {
        setPendingMoonHop(null);
        setMissionState((prev) => ({ ...prev, phase: 'setup-rocket' }));
      },
    });
  }, [triggerMoonHop]);

  // Step 2 -> Step 3 (Tycho Shipyard -> Shackleton Control using the SELECTED rocket!)
  const handleRocketSelectedNextToBriefing = useCallback(() => {
    const rocketId = missionStateRef.current.selectedRocketId || 'nova-mk1';
    const spec = getRocketSpec(rocketId);

    triggerMoonHop({
      fromSpot: MOON_SPOTS.shipyard,
      toSpot: MOON_SPOTS.missionControl,
      rocketId,
      badgeText: 'STEP 2 COMPLETE',
      headline: `${spec.name} Lifting Off!`,
      subtext: `Flying your new ${spec.name} to ${MOON_SPOTS.missionControl.name} for final rules.`,
      ctaLabel: 'View Rules',
      autoCompleteDelayMs: 900,
      nextAction: () => {
        setPendingMoonHop(null);
        setMissionState((prev) => ({ ...prev, phase: 'setup-briefing' }));
      },
    });
  }, [triggerMoonHop]);

  // Step 3 -> Day 1 Gameplay (Shackleton Control -> Moon Base Alpha using the SELECTED rocket!)
  const handleLaunchDay1FromSetup = useCallback(() => {
    const current = missionStateRef.current;
    const diff = selectedDifficulty;
    const rocketId = current.selectedRocketId || 'nova-mk1';
    const spec = getRocketSpec(rocketId);

    const freshMission = simulationEngine.createInitialMission(diff);
    freshMission.crew = current.crew.length === 4 ? current.crew : freshMission.crew;
    freshMission.crewName = current.crewName || 'Astra Vanguard';
    freshMission.selectedRocketId = rocketId;
    freshMission.tutorialCompleted = current.tutorialCompleted;
    freshMission.soundEnabled = current.soundEnabled;
    freshMission.logs[0].message = `${freshMission.crewName} landed aboard ${spec.name}! Mode: ${diff === 'beginner' ? 'CADET (EASY)' : diff.toUpperCase()}.`;
    freshMission.phase = 'setup-briefing';
    storageService.saveMission(freshMission);
    setMissionState(freshMission);

    triggerMoonHop({
      fromSpot: MOON_SPOTS.missionControl,
      toSpot: MOON_SPOTS.moonBaseAlpha,
      rocketId,
      badgeText: 'FINAL APPROACH · DAY 1',
      headline: `Touching Down at ${MOON_SPOTS.moonBaseAlpha.name}`,
      subtext: `${freshMission.crewName} & ${spec.name} are descending to your 3D Moon Base!`,
      ctaLabel: 'Enter Day 1 Base',
      autoCompleteDelayMs: 950,
      nextAction: () => {
        setPendingMoonHop(null);
        setMissionState((prev) => {
          const started = { ...prev, phase: 'active' as const };
          storageService.saveMission(started);
          return started;
        });
        setActiveView('game');
        const r = freshMission.resources;
        setNewMissionNotification(
          `DAY 1 READY — ${r.oxygenKg}kg Air, ${r.waterLiters}L Water, ${r.foodPacks} Food, ${r.powerKwh}kWh Power.`
        );
        if (toastTimerRef.current !== null) clearTimeout(toastTimerRef.current);
        toastTimerRef.current = window.setTimeout(() => setNewMissionNotification(null), 4500);
      },
    });
  }, [selectedDifficulty, triggerMoonHop]);

  const handleSkipToOutpost = useCallback((customizedCrew?: CrewMember[], crewName?: string) => {
    soundEngine.playConfirm();
    const freshMission = simulationEngine.createInitialMission(selectedDifficulty);
    if (customizedCrew && customizedCrew.length === 4) {
      freshMission.crew = customizedCrew;
    }
    freshMission.selectedRocketId = missionStateRef.current.selectedRocketId || 'nova-mk1';
    if (crewName) {
      freshMission.crewName = crewName;
      freshMission.logs[0].message = `Team ${crewName.toUpperCase()} landed on the Moon! Mode: ${selectedDifficulty === 'beginner' ? 'CADET (EASY)' : selectedDifficulty.toUpperCase()}. All base systems ready.`;
    }
    freshMission.phase = 'active';
    storageService.saveMission(freshMission);
    setMissionState(freshMission);
    setActiveView('game');
  }, [selectedDifficulty]);

  const handleTutorialComplete = useCallback(() => {
    soundEngine.playConfirm();
    setIsTutorialOpen(false);
    if (missionState.phase === 'setup-briefing' || missionState.phase === 'setup-crew' || missionState.phase === 'setup-rocket') {
      setMissionState((prev) => ({ ...prev, tutorialCompleted: true }));
    } else if (missionState.phase !== 'active') {
      const freshMission = simulationEngine.createInitialMission(selectedDifficulty);
      freshMission.phase = 'active';
      freshMission.tutorialCompleted = true;
      setMissionState(freshMission);
      setActiveView('game');
    } else {
      setMissionState((prev) => ({ ...prev, tutorialCompleted: true }));
    }
  }, [selectedDifficulty, missionState.phase]);

  const handleAdvanceDay = useCallback(() => {
    if (missionState.activeEmergency) {
      soundEngine.playWarning();
      setIsEmergencyOpen(true);
      return;
    }
    if (missionState.activeDecision) {
      soundEngine.playTelemetryClick();
      setIsDecisionOpen(true);
      return;
    }

    isAdvancingDayRef.current = false;
    soundEngine.playDayAdvance();
    setIsRocketLaunchActive(true);
  }, [missionState]);

  const handleRocketLaunchComplete = useCallback(() => {
    if (isAdvancingDayRef.current) return;
    isAdvancingDayRef.current = true;
    soundEngine.playConfirm();
    setIsRocketLaunchActive(false);

    const prev = missionStateRef.current;
    const next = simulationEngine.advanceDay(prev);
    setMissionState(next);

    // Check if a badge was earned at this milestone that hasn't had its ceremony shown
    const newlyEarnedBadgeId = next.unlockedBadges?.find(
      (bId) => !prev.unlockedBadges?.includes(bId) && !prev.viewedBadgeCeremonies?.includes(bId)
    );

    const nextDayDisc =
      next.phase === 'active'
        ? NASA_DISCOVERIES.find((d) => d.day === next.day) || null
        : null;

    if (newlyEarnedBadgeId) {
      const badgeDef = LUNAR_BADGES.find((b) => b.id === newlyEarnedBadgeId);
      if (badgeDef) {
        setActiveAwardBadge(badgeDef);
        if (nextDayDisc) {
          setPendingPostCeremonyDiscovery(nextDayDisc);
        }
        return;
      }
    }

    if (nextDayDisc) {
      setSelectedDiscovery(nextDayDisc);
      setIsDiscoveryOpen(true);
    }
  }, []);

  const handleBadgeCeremonyAddToCollection = useCallback((badgeId: string) => {
    setMissionState((prev) => {
      const viewed = prev.viewedBadgeCeremonies || [];
      const updatedViewed = viewed.includes(badgeId) ? viewed : [...viewed, badgeId];
      const unlocked = prev.unlockedBadges || [];
      const updatedUnlocked = unlocked.includes(badgeId) ? unlocked : [...unlocked, badgeId];
      return {
        ...prev,
        viewedBadgeCeremonies: updatedViewed,
        unlockedBadges: updatedUnlocked,
      };
    });
  }, []);

  const handleBadgeCeremonyContinue = useCallback(() => {
    if (activeAwardBadge) {
      const badgeId = activeAwardBadge.id;
      setMissionState((prev) => {
        const viewed = prev.viewedBadgeCeremonies || [];
        const updatedViewed = viewed.includes(badgeId) ? viewed : [...viewed, badgeId];
        return {
          ...prev,
          viewedBadgeCeremonies: updatedViewed,
        };
      });
    }
    setActiveAwardBadge(null);

    // If there was a daily discovery waiting for the badge ceremony to finish, show it now!
    if (pendingPostCeremonyDiscovery) {
      setSelectedDiscovery(pendingPostCeremonyDiscovery);
      setIsDiscoveryOpen(true);
      setPendingPostCeremonyDiscovery(null);
    }
  }, [activeAwardBadge, pendingPostCeremonyDiscovery]);

  const handleReplayCeremony = useCallback((badge: BadgeDefinition) => {
    setIsBadgesCollectionOpen(false);
    setActiveAwardBadge(badge);
  }, []);

  const handleCollectDiscovery = useCallback((discovery: DiscoveryFact) => {
    soundEngine.playConfirm();
    setMissionState((prev) => {
      const existing = prev.unlockedDiscoveries || [1];
      if (existing.includes(discovery.day)) {
        return prev;
      }
      const updated = [...existing, discovery.day];
      return {
        ...prev,
        unlockedDiscoveries: updated,
        stats: {
          ...prev.stats,
          scienceDiscoveries: Math.max(prev.stats.scienceDiscoveries, updated.length),
          finalScore: prev.stats.finalScore + 50,
        },
        logs: [
          {
            id: `log-disc-${Date.now()}`,
            day: prev.day,
            timestamp: '12:00 UTC',
            message: `Space Quiz completed: ${discovery.factTitle} (+50 Pts)!`,
            type: 'success',
          },
          ...prev.logs,
        ],
      };
    });
    setIsDiscoveryOpen(false);
  }, []);

  const handleRequestHint = useCallback(() => {
    soundEngine.playTelemetryClick();
    if (missionState.activeEmergency) {
      setNovaCustomSpeech(`Alert! ${missionState.activeEmergency.title}. Pick the safest fix that fits our supplies!`);
    } else if (missionState.activeDecision) {
      setNovaCustomSpeech(`Nova's Tip: ${missionState.activeDecision.plainHint || missionState.activeDecision.context}`);
    } else {
      setNovaCustomSpeech(`You're doing awesome! Everything is ready — check your Air, Water, Food & Power meters, then launch to the next day!`);
    }
  }, [missionState]);

  const handleConfirmChoice = useCallback((choice: DecisionChoice) => {
    soundEngine.playConfirm();
    setMissionState((prev) => simulationEngine.applyChoiceToState(prev, choice));
    setIsDecisionOpen(false);
  }, []);

  const handleResolveEmergency = useCallback((option: EmergencyOption) => {
    soundEngine.playConfirm();
    setMissionState((prev) => simulationEngine.applyEmergencyResolution(prev, option));
    setIsEmergencyOpen(false);
  }, []);

  const handleExecuteModuleAction = useCallback((moduleId: string, action: OutpostModuleAction) => {
    soundEngine.playConfirm();
    setMissionState((prev) => simulationEngine.applyModuleAction(prev, moduleId, action));
  }, []);

  const handleToggleSound = useCallback(() => {
    const nextMuted = soundEngine.toggleMute();
    storageService.savePreferences({ soundEnabled: !nextMuted });
    setMissionState((prev) => ({ ...prev, soundEnabled: !nextMuted }));
  }, []);

  // Safe and complete restart: wipes previous mission, resets state, replays 3D opening promo, then enters Step 1 Moon-Hop Setup
  const handleConfirmRestart = useCallback(() => {
    setIsResetProcessing(true);
    soundEngine.playConfirm();

    // 1. Clear previous saved campaign data from persistence
    storageService.clearMission();

    // 2. Generate fresh setup state starting at Step 1
    const freshMission = simulationEngine.createInitialMission(selectedDifficulty);
    freshMission.phase = 'setup-crew';
    freshMission.selectedRocketId = 'nova-mk1';
    freshMission.soundEnabled = !soundEngine.getMuted();

    // 3. Store immediately in localStorage
    storageService.saveMission(freshMission);

    // 4. Update authoritative application state & reset open transient modals
    setMissionState(freshMission);
    setNovaCustomSpeech(null);
    setActiveAwardBadge(null);
    setPendingPostCeremonyDiscovery(null);
    setPendingMoonHop(null);
    setIsResetConfirmOpen(false);
    setIsResetProcessing(false);
    setActiveView('game');

    // 5. Replay 3D opening rocket promo on every restart, then launch Step 1 Moon-Hop
    setIsMissionInitialisedOpen(false);
    setLaunchSetupAfterPromo(true);
    setShowOpeningPromo(true);
  }, [selectedDifficulty]);

  const handleCancelRestart = useCallback(() => {
    soundEngine.playTelemetryClick();
    setIsResetConfirmOpen(false);
  }, []);

  // Global Keyboard Shortcuts (Space to advance/launch, Esc to close modals, 1/2 view switcher, M mute, B badges, D discoveries, H handbook)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (showOpeningPromo || pendingMoonHop) return;
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      if (e.key === 'Escape') {
        if (activeAwardBadge) {
          handleBadgeCeremonyContinue();
        } else if (isMissionInitialisedOpen) {
          setIsMissionInitialisedOpen(false);
        } else if (isDecisionOpen) {
          setIsDecisionOpen(false);
        } else if (isEmergencyOpen) {
          setIsEmergencyOpen(false);
        } else if (isDiscoveryOpen) {
          setIsDiscoveryOpen(false);
        } else if (isDiscoveryLogOpen) {
          setIsDiscoveryLogOpen(false);
        } else if (isBadgesCollectionOpen) {
          setIsBadgesCollectionOpen(false);
        } else if (isTutorialOpen) {
          setIsTutorialOpen(false);
        } else if (isScienceOpen) {
          setIsScienceOpen(false);
        } else if (isHelpOpen) {
          setIsHelpOpen(false);
        } else if (isResetConfirmOpen) {
          setIsResetConfirmOpen(false);
        }
        return;
      }

      if (e.code === 'Space') {
        if (isRocketLaunchActive) {
          e.preventDefault();
          handleRocketLaunchComplete();
          return;
        }
        if (
          missionState.phase === 'active' &&
          !isDecisionOpen &&
          !isEmergencyOpen &&
          !isDiscoveryOpen &&
          !isDiscoveryLogOpen &&
          !isMissionInitialisedOpen &&
          !isBadgesCollectionOpen &&
          !activeAwardBadge &&
          !isTutorialOpen &&
          !isScienceOpen &&
          !isHelpOpen &&
          !isResetConfirmOpen
        ) {
          e.preventDefault();
          handleAdvanceDay();
        }
        return;
      }

      if (missionState.phase === 'active') {
        if (e.key === '1') {
          setActiveView('game');
        } else if (e.key === '2') {
          setActiveView('telemetry');
        } else if (e.key === 'b' || e.key === 'B') {
          setIsBadgesCollectionOpen((prev) => !prev);
        } else if (e.key === 'd' || e.key === 'D') {
          setIsDiscoveryLogOpen((prev) => !prev);
        }
      }

      if (e.key === 'm' || e.key === 'M') {
        handleToggleSound();
      }
      if (e.key === 'h' || e.key === 'H') {
        setIsHelpOpen((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    showOpeningPromo,
    pendingMoonHop,
    missionState.phase,
    isRocketLaunchActive,
    isDecisionOpen,
    isEmergencyOpen,
    isDiscoveryOpen,
    isDiscoveryLogOpen,
    isMissionInitialisedOpen,
    isBadgesCollectionOpen,
    activeAwardBadge,
    isTutorialOpen,
    isScienceOpen,
    isHelpOpen,
    isResetConfirmOpen,
    handleRocketLaunchComplete,
    handleAdvanceDay,
    handleBadgeCeremonyContinue,
    handleToggleSound,
  ]);

  return (
    <div className="min-h-screen bg-[#030611] text-slate-100 flex flex-col antialiased selection:bg-cyan-500 selection:text-slate-950 overflow-x-hidden relative">
      {/* Opening 3D Rocket Takeoff Promo */}
      {showOpeningPromo && (
        <OpeningRocketPromo3D
          onComplete={() => {
            setShowOpeningPromo(false);
            soundEngine.startAmbientDrone();
            if (launchSetupAfterPromo) {
              setLaunchSetupAfterPromo(false);
              triggerMoonHop({
                fromSpot: MOON_SPOTS.orbitEntry,
                toSpot: MOON_SPOTS.crewPad,
                rocketId: 'nova-mk1',
                badgeText: 'STEP 1 APPROACH',
                headline: `Landing at ${MOON_SPOTS.crewPad.name}`,
                subtext: 'First stop: pick the 4 astronauts joining your Moon expedition!',
                ctaLabel: 'Pick Crew',
                autoCompleteDelayMs: 900,
                nextAction: () => {
                  setPendingMoonHop(null);
                },
              });
            }
          }}
        />
      )}

      {/* Step-by-Step 3D Moon Globe Rocket Transit */}
      {pendingMoonHop && !showOpeningPromo && (
        <MoonGlobeFlight3D
          rocketId={pendingMoonHop.rocketId}
          fromSpot={pendingMoonHop.fromSpot}
          toSpot={pendingMoonHop.toSpot}
          badgeText={pendingMoonHop.badgeText}
          headline={pendingMoonHop.headline}
          subtext={pendingMoonHop.subtext}
          ctaLabel={pendingMoonHop.ctaLabel}
          autoCompleteDelayMs={pendingMoonHop.autoCompleteDelayMs}
          onComplete={pendingMoonHop.nextAction}
        />
      )}

      {/* Immersive Deep-Space Background with Stars & Cosmic Nebulae */}
      <DeepSpaceBackground
        variant={
          missionState.phase === 'cinematic' || missionState.phase === 'landing'
            ? 'cinematic'
            : activeView === 'telemetry'
            ? 'telemetry'
            : 'game'
        }
      />

      {/* Top Application Bar */}
      {missionState.phase !== 'cinematic' && (
        <TopBar
          day={missionState.day}
          phase={missionState.phase}
          solarAngleDeg={missionState.solarAngleDeg}
          isLunarNight={missionState.isLunarNight}
          soundEnabled={missionState.soundEnabled}
          onToggleSound={handleToggleSound}
          onOpenScience={() => setIsScienceOpen(true)}
          onOpenHelp={() => setIsHelpOpen(true)}
          onOpenTutorial={() => setIsTutorialOpen(true)}
          onOpenDiscoveryLog={() => setIsDiscoveryLogOpen(true)}
          discoveryCount={missionState.unlockedDiscoveries?.length || 1}
          onOpenBadges={() => setIsBadgesCollectionOpen(true)}
          badgeCount={missionState.unlockedBadges?.length || 0}
          onResetMission={() => setIsResetConfirmOpen(true)}
          activeEmergencyCount={missionState.activeEmergency ? 1 : 0}
          activeView={activeView}
          onChangeView={setActiveView}
        />
      )}

      {/* Main View Router */}
      <main className="flex-1 w-full flex flex-col justify-center overflow-x-hidden">
        {/* Phase 0: Opening Cinematic Sequence */}
        {missionState.phase === 'cinematic' && (
          <CinematicIntro onComplete={handleCinematicComplete} />
        )}

        {/* Phase 1: Landing Screen */}
        {missionState.phase === 'landing' && (
          <LandingPage
            onStartMission={handleStartMissionSetup}
            onResumeMission={storageService.hasSave() ? handleResumeSavedMission : undefined}
            hasSavedGame={storageService.hasSave()}
            onOpenHowToPlay={() => setIsHelpOpen(true)}
            onOpenScience={() => setIsScienceOpen(true)}
            onOpenBadges={() => setIsBadgesCollectionOpen(true)}
            badgeCount={missionState.unlockedBadges?.length || 0}
          />
        )}

        {/* Phase 2: Mission Briefing */}
        {missionState.phase === 'briefing' && (
          <MissionBriefing
            crew={missionState.crew}
            resources={missionState.resources}
            selectedDifficulty={selectedDifficulty}
            onChangeDifficulty={(diff) => {
              setSelectedDifficulty(diff);
              const preview = simulationEngine.createInitialMission(diff);
              setMissionState((prev) => ({
                ...prev,
                difficulty: diff,
                resources: preview.resources,
              }));
            }}
            onBeginMission={handleBriefingProceed}
            onBackToLanding={() => setMissionState((prev) => ({ ...prev, phase: 'landing' }))}
            onStartTutorial={() => setIsTutorialOpen(true)}
          />
        )}

        {/* Step 1 / Crew Introduction (Tranquility Crew Pad) */}
        {(missionState.phase === 'setup-crew' || missionState.phase === 'crew-intro') && (
          <CrewIntroView
            crew={missionState.crew}
            initialCrewName={missionState.crewName}
            selectedDifficulty={selectedDifficulty}
            onChangeDifficulty={(diff) => {
              setSelectedDifficulty(diff);
              const preview = simulationEngine.createInitialMission(diff);
              setMissionState((prev) => ({
                ...prev,
                difficulty: diff,
                resources: preview.resources,
              }));
            }}
            isStepMode={missionState.phase === 'setup-crew'}
            onNextToRocket={handleCrewSelectedNextToRocket}
            onProceedToTutorial={handleCrewIntroProceedToTutorial}
            onDeployToOutpost={handleSkipToOutpost}
            onBackToLanding={() => setMissionState((prev) => ({ ...prev, phase: 'landing' }))}
          />
        )}

        {/* Step 2: Pick Your Rocket (Tycho Rocket Shipyard) */}
        {missionState.phase === 'setup-rocket' && (
          <RocketSelectStep
            selectedRocketId={missionState.selectedRocketId || 'nova-mk1'}
            onSelectRocket={(id) => {
              setMissionState((prev) => ({ ...prev, selectedRocketId: id }));
            }}
            onBackToCrew={() => setMissionState((prev) => ({ ...prev, phase: 'setup-crew' }))}
            onNextStep={handleRocketSelectedNextToBriefing}
          />
        )}

        {/* Step 3: Mission Rules & Mode (Shackleton Base Control) */}
        {missionState.phase === 'setup-briefing' && (
          <InstructionsStep
            crew={missionState.crew}
            crewName={missionState.crewName}
            selectedRocketId={missionState.selectedRocketId || 'nova-mk1'}
            resources={missionState.resources}
            selectedDifficulty={selectedDifficulty}
            onChangeDifficulty={(diff) => {
              setSelectedDifficulty(diff);
              const preview = simulationEngine.createInitialMission(diff);
              setMissionState((prev) => ({
                ...prev,
                difficulty: diff,
                resources: preview.resources,
              }));
            }}
            onOpenInteractiveTour={() => setIsTutorialOpen(true)}
            onBackToRocket={() => setMissionState((prev) => ({ ...prev, phase: 'setup-rocket' }))}
            onLaunchDay1={handleLaunchDay1FromSetup}
          />
        )}

        {/* Phase 4: Active Gameplay */}
        {missionState.phase === 'active' && (
          <>
            {activeView === 'game' ? (
              <MainGameScreen
                state={missionState}
                deltas={dailyDeltas}
                onAdvanceDay={handleAdvanceDay}
                onOpenDecision={() => setIsDecisionOpen(true)}
                onOpenEmergency={() => setIsEmergencyOpen(true)}
                onExecuteModuleAction={handleExecuteModuleAction}
                onSwitchToTelemetry={() => setActiveView('telemetry')}
                onOpenDiscovery={() => {
                  const disc = NASA_DISCOVERIES.find((d) => d.day === missionState.day) || NASA_DISCOVERIES[0];
                  setSelectedDiscovery(disc);
                  setIsDiscoveryOpen(true);
                }}
                onOpenBadges={() => setIsBadgesCollectionOpen(true)}
              />
            ) : (
              <DashboardView
                state={missionState}
                dailyDeltas={dailyDeltas}
                onAdvanceDay={handleAdvanceDay}
                onOpenDecision={() => setIsDecisionOpen(true)}
                onOpenEmergency={() => setIsEmergencyOpen(true)}
                onOpen3DView={() => setActiveView('game')}
                onOpenDiscovery={() => {
                  const disc = NASA_DISCOVERIES.find((d) => d.day === missionState.day) || NASA_DISCOVERIES[0];
                  setSelectedDiscovery(disc);
                  setIsDiscoveryOpen(true);
                }}
                onOpenBadges={() => setIsBadgesCollectionOpen(true)}
              />
            )}
          </>
        )}

        {/* Phase 5: Mission Debrief Report */}
        {(missionState.phase === 'victory' || missionState.phase === 'failed') && (
          <FinalReportView
            state={missionState}
            onRestartMission={() => setIsResetConfirmOpen(true)}
            onOpenScience={() => setIsScienceOpen(true)}
          />
        )}
      </main>

      {/* Floating Mission Reset Notification Toast */}
      {newMissionNotification && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 animate-bounce pointer-events-none">
          <div className="px-4 py-2 rounded-xl bg-cyan-950/95 border border-cyan-400 text-cyan-200 text-xs font-mono font-bold shadow-2xl flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span>{newMissionNotification}</span>
          </div>
        </div>
      )}

      {/* Floating Astronaut Guide (Specialist Nova) */}
      {missionState.phase === 'active' && !isRocketLaunchActive && (
        <AstronautGuide
          headline={`Coach Nova · Day ${missionState.day}`}
          message={
            novaCustomSpeech ||
            (missionState.activeEmergency
              ? 'Heads up! A base alert popped up. Open it to pick a quick fix!'
              : missionState.activeDecision
              ? (missionState.activeDecision.plainHint || 'You have a new mission choice for today!')
              : (NASA_DISCOVERIES.find((d) => d.day === missionState.day)?.novaQuote ||
                 'Base looks great! Ready to launch into the next day!'))
          }
          mood={missionState.activeEmergency ? 'warning' : missionState.activeDecision ? 'hint' : 'neutral'}
          onRequestHint={handleRequestHint}
          onOpenDiscovery={() => {
            const disc = NASA_DISCOVERIES.find((d) => d.day === missionState.day) || NASA_DISCOVERIES[0];
            setSelectedDiscovery(disc);
            setIsDiscoveryOpen(true);
          }}
        />
      )}

      {/* Cinematic 3D Moon-Globe Rocket Hop Celebration on Level Advancement */}
      {isRocketLaunchActive && (
        <RocketLaunchCelebration
          completedDay={missionState.day}
          nextDay={Math.min(30, missionState.day + 1)}
          scoreGained={100}
          rocketId={missionState.selectedRocketId}
          unlockedDiscoveryTitle={NASA_DISCOVERIES.find((d) => d.day === Math.min(30, missionState.day + 1))?.factTitle}
          isFinalMissionComplete={missionState.day >= 30}
          onContinue={handleRocketLaunchComplete}
        />
      )}

      {/* NASA Scientific Discovery Interactive Modal */}
      {isDiscoveryOpen && selectedDiscovery && (
        <DiscoveryModal
          discovery={selectedDiscovery}
          isOpen={isDiscoveryOpen}
          onClose={() => setIsDiscoveryOpen(false)}
          onCollect={handleCollectDiscovery}
          isAlreadyCollected={missionState.unlockedDiscoveries?.includes(selectedDiscovery.day)}
        />
      )}

      {/* Personal NASA Discovery Log */}
      <DiscoveryLogModal
        isOpen={isDiscoveryLogOpen}
        onClose={() => setIsDiscoveryLogOpen(false)}
        unlockedDays={missionState.unlockedDiscoveries || [1]}
        onSelectDiscovery={(disc) => {
          setSelectedDiscovery(disc);
          setIsDiscoveryOpen(true);
        }}
      />

      {/* Professional Restart & Data Reset Warning Modal (Part 3 & 7) */}
      <RestartConfirmationModal
        isOpen={isResetConfirmOpen}
        currentMission={missionState}
        onCancel={handleCancelRestart}
        onConfirmRestart={handleConfirmRestart}
        isProcessing={isResetProcessing}
      />

      {/* Fresh Mission Initialised Confirmation Modal (Part 6) */}
      <MissionInitialisedModal
        isOpen={isMissionInitialisedOpen}
        state={missionState}
        onEnterOutpost={() => setIsMissionInitialisedOpen(false)}
        onProceedToCrewAssembly={handleProceedToCrewAssembly}
      />

      {/* Daily Decision Modal */}
      {missionState.activeDecision && (
        <DailyDecisionModal
          key={`decision-day-${missionState.activeDecision.day}`}
          decision={missionState.activeDecision}
          isOpen={isDecisionOpen}
          onConfirmChoice={handleConfirmChoice}
          onClose={() => setIsDecisionOpen(false)}
          showHints={missionState.difficulty === 'beginner'}
        />
      )}

      {/* Emergency Event Modal */}
      {missionState.activeEmergency && (
        <EmergencyModal
          key={missionState.activeEmergency.id}
          emergency={missionState.activeEmergency}
          isOpen={isEmergencyOpen}
          onResolve={handleResolveEmergency}
          onClose={() => setIsEmergencyOpen(false)}
        />
      )}

      {/* Animated 5-Scene Interactive Tutorial Modal */}
      <AnimatedTutorial
        isOpen={isTutorialOpen}
        onClose={() => setIsTutorialOpen(false)}
        onComplete={handleTutorialComplete}
      />

      {/* NASA Scientific Sources Modal */}
      <ScienceModal isOpen={isScienceOpen} onClose={() => setIsScienceOpen(false)} />

      {/* Astronaut Survival Handbook Modal */}
      <HowToPlayModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
        onStartTutorial={() => setIsTutorialOpen(true)}
      />

      {/* NASA-Inspired Training Badge Award Ceremony Modal */}
      {activeAwardBadge && (
        <BadgeCeremonyModal
          badge={activeAwardBadge}
          completedDay={activeAwardBadge.requiredDay}
          onAddToCollection={handleBadgeCeremonyAddToCollection}
          onContinue={handleBadgeCeremonyContinue}
        />
      )}

      {/* ASTRA Training Badges & Insignia Collection Modal */}
      {isBadgesCollectionOpen && (
        <BadgeCollectionModal
          unlockedBadgeIds={missionState.unlockedBadges || []}
          currentDay={missionState.day}
          onClose={() => setIsBadgesCollectionOpen(false)}
          onReplayCeremony={handleReplayCeremony}
        />
      )}
    </div>
  );
}
