/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type MissionPhase =
  | 'cinematic'
  | 'landing'
  | 'setup-crew'
  | 'setup-rocket'
  | 'setup-briefing'
  | 'briefing'
  | 'crew-intro'
  | 'active'
  | 'victory'
  | 'failed';

export type RocketId = 'nova-mk1' | 'falcon-cyan' | 'apollo-gold' | 'comet-emerald';

export type DifficultyLevel = 'beginner' | 'commander' | 'expert';

export type SubsystemStatus = 'nominal' | 'degraded' | 'critical' | 'offline';

export type CrewHealthStatus = 'nominal' | 'fatigued' | 'injured' | 'critical';

export interface CrewMember {
  id: string;
  name: string;
  callsign: string;
  role: string;
  specialty: string;
  avatarSeed: string;
  personality: string;
  color: string;
  quote: string;
  health: number;      // 0 - 100%
  morale: number;      // 0 - 100%
  fatigue: number;     // 0 - 100%
  status: CrewHealthStatus;
  assignedModule: string;
}

export interface OutpostModuleAction {
  id: string;
  label: string;
  effectDesc: string;
  powerCostKw: number;
  cooldownDays: number;
  lastUsedDay?: number;
}

export interface OutpostModule {
  id: string;
  name: string;
  shortName: string;
  category: 'habitation' | 'power' | 'eclss' | 'bioculture' | 'science' | 'communications';
  status: SubsystemStatus;
  efficiency: number;   // 0 - 100%
  powerDrawKw: number;
  description: string;
  purpose: string;
  plainLanguageExplanation?: string;
  potentialRisks: string[];
  scientificPrinciple: string;
  actions: OutpostModuleAction[];
}

export interface ResourceTelemetry {
  oxygenKg: number;         // Max ~200 kg
  waterLiters: number;      // Max ~250 L
  foodPacks: number;        // Max ~200 packs
  powerKwh: number;         // Max 300 kWh
  maxPowerKwh: number;
  powerGenKw: number;       // Current generation rate
  powerLoadKw: number;      // Current consumption rate
  baseIntegrity: number;    // 0 - 100%
  eclssWaterRecycleRate: number; // e.g. 0.85 (85%)
  eclssOxygenRecycleRate: number;// e.g. 0.60 (60%)
}

export interface DailyResourceDeltas {
  netOxygen: number;
  netWater: number;
  netFood: number;
  netPower: number;
  netIntegrity: number;
  crewHealthDelta: number;
  crewMoraleDelta: number;
}

export interface DecisionChoice {
  id: string;
  title: string;
  description: string;
  impactDesc: string;
  plainAdvice?: string;
  deltas: Partial<DailyResourceDeltas>;
  affectedModuleId?: string;
  affectedCrewId?: string;
  riskProbability?: number; // 0 - 1
  riskConsequence?: string;
}

export interface DailyDecision {
  day: number;
  title: string;
  context: string;
  educationalNote: string;
  plainHint?: string;
  choices: DecisionChoice[];
}

export interface EmergencyOption {
  id: string;
  label: string;
  description: string;
  plainExplanation?: string;
  riskLevel: 'Low' | 'Moderate' | 'High';
  successRatePercent: number;
  resourceCost: Partial<DailyResourceDeltas>;
  successOutcome: string;
  failureOutcome: string;
}

export interface EmergencyIncident {
  id: string;
  title: string;
  subsystemId: string;
  severity: 'warning' | 'critical' | 'severe';
  briefing: string;
  plainExplanation?: string;
  scientificContext: string;
  options: EmergencyOption[];
}

export interface MissionLog {
  id: string;
  day: number;
  timestamp: string;
  message: string;
  type: 'info' | 'warn' | 'crit' | 'success';
}

export interface DailySnapshot {
  day: number;
  oxygen: number;
  water: number;
  food: number;
  power: number;
  crewHealthAvg: number;
  crewMoraleAvg: number;
  baseIntegrity: number;
  solarEfficiency: number;
}

export interface MissionStats {
  emergenciesFaced: number;
  emergenciesResolved: number;
  decisionsMade: number;
  scienceDiscoveries: number;
  peakPowerDeficit: number;
  totalWaterRecycled: number;
  totalOxygenRecovered: number;
  finalScore: number;
}

export interface MissionState {
  day: number;                    // 1 - 30
  phase: MissionPhase;
  difficulty: DifficultyLevel;
  failureReason?: string;
  
  // Lunar illumination & environmental conditions
  solarAngleDeg: number;          // 0 to 90 degrees
  solarEfficiency: number;        // 0.1 to 1.15
  isLunarNight: boolean;
  surfaceTempC: number;           // -170°C to +120°C
  
  resources: ResourceTelemetry;
  crew: CrewMember[];
  crewName?: string;
  selectedRocketId?: RocketId;
  modules: OutpostModule[];
  history: DailySnapshot[];
  logs: MissionLog[];
  
  activeDecision?: DailyDecision;
  activeEmergency?: EmergencyIncident;
  
  stats: MissionStats;
  soundEnabled: boolean;
  tutorialCompleted: boolean;
  unlockedDiscoveries?: number[];
  unlockedBadges?: string[];
  viewedBadgeCeremonies?: string[];
}

export interface ScienceReference {
  title: string;
  category: 'ECLSS' | 'Solar Dynamics' | 'Radiation Protection' | 'Lunar Regolith' | 'Artemis Architecture';
  summary: string;
  nasaSourceUrl: string;
  citation: string;
}

export interface ScientificGlossaryTerm {
  term: string;
  plainDefinition: string;
  detailedContext: string;
}
