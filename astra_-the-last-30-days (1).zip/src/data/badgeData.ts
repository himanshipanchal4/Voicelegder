/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface BadgeDefinition {
  id: string;
  level: 1 | 2 | 3 | 4 | 5 | 6;
  romanNumeral: 'I' | 'II' | 'III' | 'IV' | 'V' | 'VI';
  title: string;
  subtitle: string;
  requiredDay: number; // 5, 10, 15, 20, 25, 30
  dayRange: string;    // "Days 1–5", etc.
  description: string;
  lore: string;
  educationalInsight: string;
  mentorQuote: string;
  starsCount: number;
  palette: {
    primary: string;
    secondary: string;
    accent: string;
    glow: string;
    border: string;
    rimGrad: [string, string, string];
    bgGrad: [string, string];
  };
}

export const LUNAR_BADGES: BadgeDefinition[] = [
  {
    id: 'badge-level-1',
    level: 1,
    romanNumeral: 'I',
    title: 'LUNAR CADET',
    subtitle: 'Foundation & Polar Acclimatization',
    requiredDay: 5,
    dayRange: 'Days 1–5',
    description: 'You have completed your first five days of lunar survival training.',
    lore: 'Conferred upon expedition commanders who establish operational stability across the primary life-support loop, calibrate closed-loop recycling, and survive the initial polar regolith thermal shock.',
    educationalInsight: 'The Moon has no atmosphere to buffer solar radiation or moderate surface temperature, which swings from +120°C in sunlight to -170°C in shadow. Early polar mission days focus on securing sealed habitability margins.',
    mentorQuote: 'Outstanding work, Commander! You’ve established life-support equilibrium and proven your crew can withstand the harsh realities of Shackleton Rim. Your first mission insignia is officially yours in ASTRA.',
    starsCount: 3,
    palette: {
      primary: '#1e3a5f',
      secondary: '#94a3b8',
      accent: '#38bdf8',
      glow: 'rgba(56, 189, 248, 0.45)',
      border: '#cbd5e1',
      rimGrad: ['#f8fafc', '#94a3b8', '#475569'],
      bgGrad: ['#0f172a', '#020617'],
    },
  },
  {
    id: 'badge-level-2',
    level: 2,
    romanNumeral: 'II',
    title: 'ORBITAL EXPLORER',
    subtitle: 'Trajectory & Orbital Sync',
    requiredDay: 10,
    dayRange: 'Days 6–10',
    description: 'You have advanced your mission knowledge and strengthened your understanding of lunar exploration.',
    lore: 'Recognizes precision rendezvous planning, successful trans-lunar communication relay alignment, and surface exploration traverses beyond the immediate habitat perimeter.',
    educationalInsight: 'Polar lunar orbits experience non-uniform gravitational perturbations from "mascons" (dense subsurface mass concentrations). Maintaining communication relays requires synchronized orbital halo trajectories.',
    mentorQuote: 'Spectacular trajectory, Commander! Ten days in, and your orbital tracking and surface navigational maneuvers are rock solid. Level II Orbital Explorer insignia awarded!',
    starsCount: 4,
    palette: {
      primary: '#1e40af',
      secondary: '#60a5fa',
      accent: '#93c5fd',
      glow: 'rgba(96, 165, 250, 0.5)',
      border: '#93c5fd',
      rimGrad: ['#bfdbfe', '#3b82f6', '#1d4ed8'],
      bgGrad: ['#172554', '#030712'],
    },
  },
  {
    id: 'badge-level-3',
    level: 3,
    romanNumeral: 'III',
    title: 'LUNAR SPECIALIST',
    subtitle: 'Scientific Field Investigation',
    requiredDay: 15,
    dayRange: 'Days 11–15',
    description: 'You have demonstrated growing scientific knowledge and lunar survival expertise.',
    lore: 'Awarded for exceptional mass spectrometry analysis, prospecting volatile water-ice cold traps inside permanently shadowed craters, and advancing in-situ resource utilization protocols.',
    educationalInsight: 'Permanently Shadowed Regions (PSRs) at the lunar South Pole maintain temperatures below 40 Kelvin (-233°C), preserving billions of years of volatile water-ice delivered by ancient cometary impacts.',
    mentorQuote: 'Halfway through the 30-day endurance, Commander! You’ve unlocked deep scientific insights and pioneered volatiles prospecting. Wear the Level III Lunar Specialist insignia with pride.',
    starsCount: 5,
    palette: {
      primary: '#0891b2',
      secondary: '#22d3ee',
      accent: '#67e8f9',
      glow: 'rgba(34, 211, 238, 0.55)',
      border: '#67e8f9',
      rimGrad: ['#cffafe', '#06b6d4', '#0e7490'],
      bgGrad: ['#083344', '#020617'],
    },
  },
  {
    id: 'badge-level-4',
    level: 4,
    romanNumeral: 'IV',
    title: 'MISSION ENGINEER',
    subtitle: 'Subsystem Mastery & Closed-Loop Control',
    requiredDay: 20,
    dayRange: 'Days 16–20',
    description: 'You have advanced your ability to manage the systems that keep a lunar outpost operational.',
    lore: 'Decorates engineering excellence in power grid balancing during mountain occultations, micro-machining replacement valve seals, and operating the Sabatier methane/water conversion cycle under strain.',
    educationalInsight: 'The Sabatier catalytic methanation reactor combines exhaled carbon dioxide with hydrogen at 400°C to recover up to 50% of oxygen locked in metabolic CO2, vital for closed-loop self-sufficiency.',
    mentorQuote: 'Exceptional engineering discipline! Surviving 20 days on the Moon demands absolute mastery over micro-mechanical systems and power storage. Level IV Mission Engineer insignia conferred!',
    starsCount: 6,
    palette: {
      primary: '#0f172a',
      secondary: '#d97706',
      accent: '#fbbf24',
      glow: 'rgba(251, 191, 36, 0.5)',
      border: '#fde68a',
      rimGrad: ['#fef08a', '#d97706', '#78350f'],
      bgGrad: ['#1e1b4b', '#030712'],
    },
  },
  {
    id: 'badge-level-5',
    level: 5,
    romanNumeral: 'V',
    title: 'ARTEMIS VANGUARD',
    subtitle: 'Advanced Expedition Readiness',
    requiredDay: 25,
    dayRange: 'Days 21–25',
    description: 'You have reached an advanced stage of lunar mission training.',
    lore: 'Bestowed on elite commanders who maintain high crew morale through prolonged isolation, mitigate acute cosmic radiation flux, and execute advanced lunar logistics readiness protocols.',
    educationalInsight: 'Galactic Cosmic Rays (GCR) and Solar Particle Events (SPE) deliver significant radiation doses without Earth’s magnetosphere. Sintered lunar regolith shielding provides essential passive radiation defense.',
    mentorQuote: 'Remarkable endurance, Commander! 25 days on the lunar frontier puts you among the most capable explorers in human history. The golden Level V Artemis Vanguard insignia is yours.',
    starsCount: 6,
    palette: {
      primary: '#78350f',
      secondary: '#f59e0b',
      accent: '#fef08a',
      glow: 'rgba(245, 158, 11, 0.65)',
      border: '#fef08a',
      rimGrad: ['#fffbeb', '#f59e0b', '#b45309'],
      bgGrad: ['#2e1065', '#020617'],
    },
  },
  {
    id: 'badge-level-6',
    level: 6,
    romanNumeral: 'VI',
    title: 'LUNAR PIONEER ELITE',
    subtitle: 'Supreme Expeditionary Triumph',
    requiredDay: 30,
    dayRange: 'Days 26–30',
    description: 'You have completed the full 30-day ASTRA lunar survival campaign.',
    lore: 'The supreme military and scientific honor in the ASTRA expedition program. Conferred only upon leaders who bring all crew members through a complete lunar diurnal cycle and establish humanity’s permanent outpost on the Moon.',
    educationalInsight: 'Completing 30 consecutive days encompasses an entire lunar day-night cycle (29.5 Earth days), verifying that human life-support, bi-facial solar tracking, and thermal management can sustain long-duration lunar presence indefinitely.',
    mentorQuote: 'Triumph, Commander! You have conquered the full 30-day ASTRA lunar survival campaign! All six insignia shine in your record. Shackleton Rim is now a permanent home for humanity!',
    starsCount: 6,
    palette: {
      primary: '#09090b',
      secondary: '#e2e8f0',
      accent: '#38bdf8',
      glow: 'rgba(255, 255, 255, 0.75)',
      border: '#f8fafc',
      rimGrad: ['#ffffff', '#cbd5e1', '#e2e8f0'],
      bgGrad: ['#030712', '#000000'],
    },
  },
];

/**
 * Returns the next upcoming badge for a given mission day
 */
export function getNextUpcomingBadge(currentDay: number): {
  badge: BadgeDefinition | null;
  daysRemaining: number;
  progressPercent: number;
} {
  const next = LUNAR_BADGES.find((b) => currentDay < b.requiredDay) || null;
  if (!next) {
    return { badge: null, daysRemaining: 0, progressPercent: 100 };
  }

  const prevMilestone = next.requiredDay - 5;
  const daysInBlock = Math.max(0, currentDay - prevMilestone);
  const progressPercent = Math.min(100, Math.round((daysInBlock / 5) * 100));
  const daysRemaining = Math.max(0, next.requiredDay - currentDay);

  return { badge: next, daysRemaining, progressPercent };
}
