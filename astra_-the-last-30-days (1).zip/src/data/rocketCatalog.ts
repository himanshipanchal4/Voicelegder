/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { RocketId } from '../types/mission';

export interface RocketSpec {
  id: RocketId;
  name: string;
  nickname: string;
  tagline: string;
  badge: string;
  hullColorHex: number;
  noseColorHex: number;
  finColorHex: number;
  accentColorHex: number;
  flamePrimaryHex: number;
  flameSecondaryHex: number;
  uiGradient: string;
  uiBorder: string;
  uiText: string;
  stats: {
    thrust: string;
    shield: string;
    style: string;
  };
}

export const ROCKET_CATALOG: RocketSpec[] = [
  {
    id: 'nova-mk1',
    name: 'ASTRA Nova MK-I',
    nickname: 'Red Comet',
    tagline: 'Classic NASA-style twin-booster Moon explorer with bold red fins.',
    badge: 'BALANCED HERO',
    hullColorHex: 0xffffff,
    noseColorHex: 0xef4444,
    finColorHex: 0xef4444,
    accentColorHex: 0xfbbf24,
    flamePrimaryHex: 0xfbbf24,
    flameSecondaryHex: 0xf97316,
    uiGradient: 'from-rose-500/20 to-amber-500/20',
    uiBorder: 'border-rose-400/60',
    uiText: 'text-rose-300',
    stats: {
      thrust: '95%',
      shield: '90%',
      style: 'Twin Boosters',
    },
  },
  {
    id: 'falcon-cyan',
    name: 'Orion Bolt X-9',
    nickname: 'Blue Spark',
    tagline: 'Sleek electric-cyan cruiser with neon plasma wings and ion pods.',
    badge: 'PLASMA SPEED',
    hullColorHex: 0x0f172a,
    noseColorHex: 0x06b6d4,
    finColorHex: 0x38bdf8,
    accentColorHex: 0x22d3ee,
    flamePrimaryHex: 0x67e8f9,
    flameSecondaryHex: 0x3b82f6,
    uiGradient: 'from-cyan-500/20 to-blue-500/20',
    uiBorder: 'border-cyan-400/60',
    uiText: 'text-cyan-300',
    stats: {
      thrust: '99%',
      shield: '86%',
      style: 'Ion Wing Pods',
    },
  },
  {
    id: 'apollo-gold',
    name: 'Apollo Horizon',
    nickname: 'Golden Shield',
    tagline: 'Armored royal-gold Moon lander built for tough crater landings.',
    badge: 'HEAVY ARMOR',
    hullColorHex: 0xf59e0b,
    noseColorHex: 0x1e293b,
    finColorHex: 0xd97706,
    accentColorHex: 0xfef08a,
    flamePrimaryHex: 0xfef08a,
    flameSecondaryHex: 0xf59e0b,
    uiGradient: 'from-amber-500/20 to-yellow-500/20',
    uiBorder: 'border-amber-400/60',
    uiText: 'text-amber-300',
    stats: {
      thrust: '90%',
      shield: '99%',
      style: 'Gold Heat Foil',
    },
  },
  {
    id: 'comet-emerald',
    name: 'Bio-Comet Star',
    nickname: 'Emerald Glow',
    tagline: 'Science-grade emerald & violet rocket with a glowing green plasma trail.',
    badge: 'SCIENCE CRUISER',
    hullColorHex: 0x1e1b4b,
    noseColorHex: 0x10b981,
    finColorHex: 0xa855f7,
    accentColorHex: 0x34d399,
    flamePrimaryHex: 0x6ee7b7,
    flameSecondaryHex: 0x10b981,
    uiGradient: 'from-emerald-500/20 to-violet-500/20',
    uiBorder: 'border-emerald-400/60',
    uiText: 'text-emerald-300',
    stats: {
      thrust: '94%',
      shield: '94%',
      style: 'Bio-Glow Thrusters',
    },
  },
];

export function getRocketSpec(rocketId?: RocketId): RocketSpec {
  return ROCKET_CATALOG.find((r) => r.id === rocketId) || ROCKET_CATALOG[0];
}

export interface MoonSpot {
  id: string;
  name: string;
  subtitle: string;
  terrainType?: string;
  latDeg: number; // -85 to +85
  lonDeg: number; // -180 to +180
}

export const MOON_SPOTS: Record<string, MoonSpot> = {
  orbitEntry: {
    id: 'orbit-entry',
    name: 'Lunar Polar Approach',
    subtitle: 'Entering Moon Orbit',
    terrainType: 'Highland Limb',
    latDeg: 58,
    lonDeg: -105,
  },
  crewPad: {
    id: 'crew-pad',
    name: 'Mare Tranquillitatis',
    subtitle: 'Step 1: Pick Your 4 Astronauts',
    terrainType: 'Dark Basalt Sea',
    latDeg: 8,
    lonDeg: 31,
  },
  shipyard: {
    id: 'shipyard',
    name: 'Tycho Bright Highlands',
    subtitle: 'Step 2: Choose Your Rocket',
    terrainType: 'Rayed Crater Rim',
    latDeg: -43,
    lonDeg: -11,
  },
  missionControl: {
    id: 'mission-control',
    name: 'Oceanus Procellarum',
    subtitle: 'Step 3: Mission Rules & Mode',
    terrainType: 'Western Volcanic Plain',
    latDeg: 18,
    lonDeg: -57,
  },
  moonBaseAlpha: {
    id: 'moon-base-alpha',
    name: 'Shackleton South Pole',
    subtitle: 'Day 1 Landing Zone',
    terrainType: 'Polar Ice Crater',
    latDeg: -82,
    lonDeg: 18,
  },
};

const DAY_SECTORS: Array<{ name: string; terrainType: string; latDeg: number; lonDeg: number }> = [
  { name: 'Shackleton South Pole', terrainType: 'Polar Ice Crater', latDeg: -82, lonDeg: 18 },
  { name: 'Mare Tranquillitatis', terrainType: 'Dark Basalt Sea', latDeg: 8, lonDeg: 31 },
  { name: 'Copernicus Crater', terrainType: 'Terraced Ray Crater', latDeg: 10, lonDeg: -20 },
  { name: 'Mare Crisium', terrainType: 'Eastern Oval Basin', latDeg: 17, lonDeg: 59 },
  { name: 'Tycho Bright Rim', terrainType: 'Bright Ejecta Highlands', latDeg: -43, lonDeg: -11 },
  { name: 'Plato Dark Floor', terrainType: 'Lava-Flooded Crater', latDeg: 51, lonDeg: -9 },
  { name: 'Aristarchus Plateau', terrainType: 'Bright Volcanic Dome', latDeg: 24, lonDeg: -47 },
  { name: 'Mare Serenitatis', terrainType: 'Northern Basalt Sea', latDeg: 28, lonDeg: 18 },
  { name: 'Mare Moscoviense', terrainType: 'Far-Side Lunar Sea', latDeg: 27, lonDeg: 147 },
  { name: 'Clavius Walled Plain', terrainType: 'Giant Southern Crater', latDeg: -58, lonDeg: -14 },
  { name: 'Oceanus Procellarum', terrainType: 'Western Lava Ocean', latDeg: 18, lonDeg: -57 },
  { name: 'Apennine Mountains', terrainType: 'Towering Rim Peaks', latDeg: 20, lonDeg: -3 },
  { name: 'Mare Orientale', terrainType: 'Bullseye Ring Basin', latDeg: -19, lonDeg: -93 },
  { name: 'Kepler Ray Crater', terrainType: 'Bright Regolith Rays', latDeg: 8, lonDeg: -38 },
  { name: 'North Pole Peary Rim', terrainType: 'Sunlit Polar Ridge', latDeg: 78, lonDeg: 33 },
  { name: 'Mare Fecunditatis', terrainType: 'Eastern Basalt Basin', latDeg: -7, lonDeg: 51 },
  { name: 'Tsiolkovskiy Crater', terrainType: 'Far-Side Dark Floor', latDeg: -20, lonDeg: 129 },
  { name: 'Mare Imbrium', terrainType: 'Vast Lava Plain', latDeg: 33, lonDeg: -16 },
  { name: 'Grimaldi Dark Basin', terrainType: 'Deep Western Rim', latDeg: -5, lonDeg: -68 },
  { name: 'Taurus-Littrow Valley', terrainType: 'Ancient Highland Rift', latDeg: 20, lonDeg: 31 },
  { name: 'Hertzsprung Basin', terrainType: 'Far-Side Highlands', latDeg: 2, lonDeg: -129 },
  { name: 'Mare Nectaris', terrainType: 'Southern Basalt Sea', latDeg: -15, lonDeg: 35 },
  { name: 'Sinus Iridum', terrainType: 'Bay of Rainbows', latDeg: 44, lonDeg: -32 },
  { name: 'Bailly Giant Basin', terrainType: 'Polar Highland Rim', latDeg: -66, lonDeg: -69 },
  { name: 'Korolev Multi-Ring', terrainType: 'Far-Side Ice Crater', latDeg: -4, lonDeg: -157 },
  { name: 'Petavius Rille Crater', terrainType: 'Fractured Floor Basin', latDeg: -25, lonDeg: 60 },
  { name: 'Mare Humorum', terrainType: 'Circular Lava Sea', latDeg: -24, lonDeg: -39 },
  { name: 'Apollo Far Basin', terrainType: 'South Pole-Aitken', latDeg: -36, lonDeg: -151 },
  { name: 'Archimedes Rim', terrainType: 'Imbrium Plains Edge', latDeg: 30, lonDeg: -4 },
  { name: 'Artemis Summit Alpha', terrainType: 'Lunar South Ridge', latDeg: -84, lonDeg: -28 },
];

export function getMoonDaySector(day: number): MoonSpot {
  const safeIdx = Math.max(0, day - 1) % DAY_SECTORS.length;
  const s = DAY_SECTORS[safeIdx];
  return {
    id: `day-sector-${day}`,
    name: s.name,
    subtitle: `Mission Day ${day}`,
    terrainType: s.terrainType,
    latDeg: s.latDeg,
    lonDeg: s.lonDeg,
  };
}

