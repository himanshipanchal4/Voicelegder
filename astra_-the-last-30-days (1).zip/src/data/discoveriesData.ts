/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface DiscoveryChallengeOption {
  id: string;
  label: string;
  isCorrect: boolean;
  feedback: string;
}

export interface DiscoveryChallenge {
  type: 'shadow-map' | 'solar-align' | 'eclss-pipe' | 'rover-route' | 'radiation-shield' | 'spectroscopy' | 'quick-quiz';
  prompt: string;
  instructions: string;
  targetValue?: number;
  options?: DiscoveryChallengeOption[];
}

export interface DiscoveryFact {
  id: string;
  day: number;
  category: 'water-ice' | 'solar-power' | 'eclss' | 'geology' | 'radiation' | 'navigation';
  factTitle: string;
  factType: 'observation' | 'scientific interpretation' | 'future possibility';
  conciseExplanation: string;
  whyInteresting: string;
  sourceOrg: string;
  sourceTitle: string;
  sourceUrl: string;
  novaQuote: string;
  badge: {
    title: string;
    icon: string;
    description: string;
  };
  challenge: DiscoveryChallenge;
}

export const NASA_DISCOVERIES: DiscoveryFact[] = [
  {
    id: 'disc-1',
    day: 1,
    category: 'water-ice',
    factTitle: 'Dark Polar Craters Hide Frozen Water Ice',
    factType: 'observation',
    conciseExplanation:
      'Because the Moon barely tilts as it spins, sunlight skims sideways at the poles. Deep crater bottoms near the South Pole haven’t seen the Sun for billions of years and stay colder than -230°C.',
    whyInteresting:
      'Astronauts can melt Moon ice into drinking water, split it into oxygen to breathe, and even turn it into rocket fuel!',
    sourceOrg: 'NASA Goddard Space Flight Center / LRO Mission',
    sourceTitle: 'Diviner Lunar Radiometer Experiment & Mini-RF Polar Ice Observations',
    sourceUrl: 'https://science.nasa.gov/mission/lro/',
    novaQuote: 'Look at those pitch-black shadows inside Shackleton Crater! Our sensors just spotted frozen water trapped in the freezing dust.',
    badge: {
      title: 'Ice Hunter',
      icon: '❄️',
      description: 'Found hidden water ice in dark Moon craters.',
    },
    challenge: {
      type: 'shadow-map',
      prompt: 'Where is the best spot to find frozen water ice at Shackleton Crater?',
      instructions: 'Pick the coldest spot where sunlight never melts the ice.',
      options: [
        { id: 'opt-rim', label: 'Sunny top rim of the crater', isCorrect: false, feedback: 'Sunlight hits the crater rim and turns any ice into gas.' },
        { id: 'opt-psr', label: 'Deep, dark bottom of the crater', isCorrect: true, feedback: 'Nice! It stays super freezing down there, so water ice lasts for billions of years.' },
        { id: 'opt-exterior', label: 'Sunny outside slopes', isCorrect: false, feedback: 'The sunny outside slopes can heat up past 100°C—way too hot for ice!' },
      ],
    },
  },
  {
    id: 'disc-2',
    day: 2,
    category: 'solar-power',
    factTitle: 'Tall Crater Peaks Catch Sunlight Almost Non-Stop',
    factType: 'observation',
    conciseExplanation:
      'High ridges along Shackleton and Malapert craters rise so tall that the low polar Sun shines on them for nearly 90% of the year.',
    whyInteresting:
      'Most places on the Moon have 14 straight days of pitch-black night, so polar mountain ridges are the best spot for solar-powered Moon bases.',
    sourceOrg: 'NASA Lunar Reconnaissance Orbiter (LRO)',
    sourceTitle: 'Illumination Conditions at the Lunar Poles',
    sourceUrl: 'https://www.nasa.gov/mission_pages/LRO/news/polar-illumination.html',
    novaQuote: 'At the South Pole, the Sun sits right on the horizon like a permanent sunset—that’s why our solar panels stand up tall!',
    badge: {
      title: 'Sun Chaser',
      icon: '☀️',
      description: 'Pointed solar panels to catch low polar sunlight.',
    },
    challenge: {
      type: 'solar-align',
      prompt: 'At the Moon’s South Pole, the Sun stays super low near the horizon. How should we aim our solar panels?',
      instructions: 'Choose the best angle to catch sideways sunlight.',
      targetValue: 88,
      options: [
        { id: 'flat', label: 'Lay them flat on the ground', isCorrect: false, feedback: 'Flat panels miss most of the light when the Sun is right on the horizon.' },
        { id: 'vertical', label: 'Stand them up tall facing the horizon', isCorrect: true, feedback: 'You got it! Vertical solar towers spin to face the sideways Sun and make steady power.' },
        { id: 'inverted', label: 'Point them down into the dark crater', isCorrect: false, feedback: 'Pointing them into the dark crater means zero sunlight!' },
      ],
    },
  },
  {
    id: 'disc-3',
    day: 3,
    category: 'eclss',
    factTitle: 'Space Machines Recycle Astronaut Breath Back Into Air',
    factType: 'scientific interpretation',
    conciseExplanation:
      'Astronauts breathe in oxygen and breathe out carbon dioxide (CO2). Special life-support machines capture that CO2 and turn it back into water and fresh oxygen.',
    whyInteresting:
      'Without recycling air and water, rockets from Earth would have to bring over 1,000 kg of oxygen every year for a 4-person crew!',
    sourceOrg: 'NASA ECLSS Engineering Directorate',
    sourceTitle: 'International Space Station Life Support & Advanced Exploration ECLSS',
    sourceUrl: 'https://www.nasa.gov/humans-in-space/commercial-space/environmental-control-and-life-support-system/',
    novaQuote: 'Nothing goes to waste on our Moon base! Even the air we breathe out gets recycled into fresh oxygen.',
    badge: {
      title: 'Air Recycler',
      icon: '🔄',
      description: 'Recycled carbon dioxide back into breathable oxygen.',
    },
    challenge: {
      type: 'eclss-pipe',
      prompt: 'Our air recycler just turned crew CO2 gas into pure water. What should we do with that water next to get fresh Oxygen?',
      instructions: 'Pick the next step in the Moon base air loop.',
      options: [
        { id: 'vent', label: 'Dump it outside into space', isCorrect: false, feedback: 'No way! Venting water into space wastes air and water we need to survive.' },
        { id: 'electrolysis', label: 'Use electricity to split it into Oxygen gas for breathing', isCorrect: true, feedback: 'Spot on! Splitting water with electricity makes fresh breathable oxygen!' },
        { id: 'coolant', label: 'Mix it with Moon dust', isCorrect: false, feedback: 'Mixing it with Moon dust would ruin our clean water supply!' },
      ],
    },
  },
  {
    id: 'disc-4',
    day: 4,
    category: 'geology',
    factTitle: 'Microwaves Can Melt Moon Dust Into Solid Bricks',
    factType: 'future possibility',
    conciseExplanation:
      'Moon dust contains tiny bits of natural iron. Just like food heats up in a kitchen microwave, Moon dust heats up fast under microwave beams and melts into rock-hard tiles.',
    whyInteresting:
      'Shipping bricks from Earth costs tens of thousands of dollars per kilogram, so rovers can 3D-print landing pads and roads straight out of Moon dirt!',
    sourceOrg: 'NASA Marshall Space Flight Center',
    sourceTitle: 'Microwave Sintering of Lunar Regolith for Additive Construction',
    sourceUrl: 'https://ntrs.nasa.gov/citations/20180006277',
    novaQuote: 'Why pack heavy bricks on a rocket when our rovers can microwave Moon dust into solid roads and landing pads?',
    badge: {
      title: 'Moon Builder',
      icon: '🧱',
      description: 'Turned loose Moon dust into tough building tiles.',
    },
    challenge: {
      type: 'rover-route',
      prompt: 'We want to build a dust-free landing pad without hauling bricks from Earth. How can a rover harden Moon dust?',
      instructions: 'Pick the best way to fuse Moon dust together.',
      options: [
        { id: '2450', label: 'Heat the iron-rich dust with microwave beams until it melts into tile', isCorrect: true, feedback: 'Awesome! Microwaves heat the tiny iron grains in Moon dust and fuse them into solid bricks.' },
        { id: 'sound', label: 'Blast loud music speakers at the ground', isCorrect: false, feedback: 'There is no air on the Moon, so sound waves can’t even travel outside!' },
        { id: 'water', label: 'Mix tons of drinking water with the dust', isCorrect: false, feedback: 'That wastes way too much of our crew’s precious drinking water!' },
      ],
    },
  },
  {
    id: 'disc-5',
    day: 5,
    category: 'radiation',
    factTitle: 'A Thick Blanket of Moon Dirt Blocks Space Radiation',
    factType: 'observation',
    conciseExplanation:
      'Earth’s air and magnetic field shield us from cosmic rays and solar storms. The Moon has no sky or shield, so space radiation hits the ground directly.',
    whyInteresting:
      'Piling about 2.5 meters (8 feet) of Moon soil over base domes protects astronauts just as well as Earth’s atmosphere!',
    sourceOrg: 'NASA Johnson Space Center / Space Radiation Program',
    sourceTitle: 'Radiation Measurements on the Lunar Surface by Chang’e-4 and LRO CRaTER',
    sourceUrl: 'https://science.nasa.gov/moon/radiation/',
    novaQuote: 'Moon dirt is our best armor! Covering our base roof with packed soil blocks dangerous solar flares.',
    badge: {
      title: 'Cosmic Shield',
      icon: '🛡️',
      description: 'Protected the crew from solar storms using Moon soil.',
    },
    challenge: {
      type: 'radiation-shield',
      prompt: 'A solar storm is coming! How much Moon dirt should we pile over our habitat roof to keep the crew safe?',
      instructions: 'Choose the safest protective layer thickness.',
      targetValue: 2.5,
      options: [
        { id: 'thin', label: 'A thin sprinkle of dust (10 cm)', isCorrect: false, feedback: 'Too thin! Strong space rays punch right through a thin layer.' },
        { id: 'safe', label: 'A thick 2.5-meter (8-foot) blanket of packed Moon soil', isCorrect: true, feedback: 'Safe! That thick dirt blanket blocks harmful solar storm particles.' },
        { id: 'sheet', label: 'One sheet of kitchen aluminum foil', isCorrect: false, feedback: 'Space radiation zips straight through thin foil!' },
      ],
    },
  },
  {
    id: 'disc-6',
    day: 6,
    category: 'geology',
    factTitle: 'Sunlight Gives Moon Dust Static Electricity So It Floats',
    factType: 'observation',
    conciseExplanation:
      'Sunlight zaps tiny electrons off Moon dust, giving grains a static charge like a rubbed balloon. Near shadow lines, dust actually floats off the ground!',
    whyInteresting:
      'Floating Moon dust is jagged like tiny glass and clings to spacesuits, visors, and airlocks.',
    sourceOrg: 'NASA Ames Research Center',
    sourceTitle: 'LADEE: Lunar Atmosphere and Dust Environment Explorer',
    sourceUrl: 'https://www.nasa.gov/mission_pages/ladee/main/index.html',
    novaQuote: 'Static electricity makes Moon dust stick to everything like glitter—and it’s sharp like tiny glass!',
    badge: {
      title: 'Dust Buster',
      icon: '✨',
      description: 'Stopped static Moon dust from sticking to airlocks.',
    },
    challenge: {
      type: 'rover-route',
      prompt: 'Sharp, static-charged Moon dust is sticking to our airlock doors. What is the smartest way to shake it off?',
      instructions: 'Choose NASA’s real dust-cleaning solution.',
      options: [
        { id: 'water-hose', label: 'Spray the outside door with a water hose', isCorrect: false, feedback: 'In space vacuum, sprayed water boils and freezes instantly!' },
        { id: 'eds', label: 'Use electric pulses (Dust Shield) to bounce grains off', isCorrect: true, feedback: 'Cool tech! Electric waves literally lift and toss the charged dust right off!' },
        { id: 'wipe', label: 'Rub it hard with a dry towel', isCorrect: false, feedback: 'Rubbing adds even more static charge and scratches the door seals!' },
      ],
    },
  },
  {
    id: 'disc-7',
    day: 7,
    category: 'eclss',
    factTitle: 'Spinning Water Purifiers Recycle 98% of Every Drop',
    factType: 'scientific interpretation',
    conciseExplanation:
      'Space stations use spinning vacuum distillers to boil wastewater at low temperature and collect pure clean steam, recovering up to 98% of every drop.',
    whyInteresting:
      'Astronauts recycle sweat, shower steam, and even urine into water cleaner than most city tap water on Earth!',
    sourceOrg: 'NASA Marshall Space Flight Center',
    sourceTitle: 'Urine Processor Assembly (UPA) & Water Processor Assembly Innovations',
    sourceUrl: 'https://www.nasa.gov/humans-in-space/commercial-space/environmental-control-and-life-support-system/',
    novaQuote: 'Every drop counts on the Moon! Our spinning water purifier turns yesterday’s sweat back into super-clean drinking water.',
    badge: {
      title: 'Water Saver',
      icon: '💧',
      description: 'Recycled 98% of base water with a spinning purifier.',
    },
    challenge: {
      type: 'eclss-pipe',
      prompt: 'In the Moon’s weak gravity, bubbles don’t rise well when boiling dirty water. Why do NASA water purifiers spin like a washing machine?',
      instructions: 'Pick why spinning helps clean water in space.',
      options: [
        { id: 'spin', label: 'Spinning pushes heavier waste outward so pure steam separates cleanly', isCorrect: true, feedback: 'Bingo! Spinning makes artificial gravity to separate clean steam from leftover gunk.' },
        { id: 'boil-100', label: 'It cools the machine down like a ceiling fan', isCorrect: false, feedback: 'Actually, it spins to use centrifugal force—not for cooling!' },
        { id: 'freeze', label: 'It freezes the pipes solid into ice', isCorrect: false, feedback: 'Frozen pipes would crack and stop the water flow!' },
      ],
    },
  },
  {
    id: 'disc-8',
    day: 8,
    category: 'navigation',
    factTitle: 'Orbiting Laser Scanners Mapped 10 Billion Points on the Moon',
    factType: 'observation',
    conciseExplanation:
      'NASA’s Moon orbiter fired laser pulses 28 times every second to time how far away hills and craters were, building an ultra-detailed 3D map of the entire Moon.',
    whyInteresting:
      'Because of these laser maps, Moon rovers can spot steep cliffs and giant boulders before driving anywhere near them!',
    sourceOrg: 'NASA Goddard / LOLA Science Team',
    sourceTitle: 'LOLA: Lunar Orbiter Laser Altimeter Global Topography Grid',
    sourceUrl: 'https://lola.gsfc.nasa.gov/',
    novaQuote: 'Spacecraft lasers already mapped every hill and crater rim—so our rovers know the safest road before turning a wheel!',
    badge: {
      title: 'Rover Navigator',
      icon: '📐',
      description: 'Used 3D laser maps to pick a safe rover trail.',
    },
    challenge: {
      type: 'rover-route',
      prompt: 'Our rover needs to climb out of a crater. Using our 3D laser map, which path should we drive?',
      instructions: 'Pick the safest slope for loose Moon dirt.',
      options: [
        { id: 'steep', label: 'Drive straight up a super steep 35° cliff wall', isCorrect: false, feedback: 'Too steep! Wheels will spin in the loose dust and the rover could tip.' },
        { id: 'gentle', label: 'Zigzag up a gentle 8° ramp shown on the laser map', isCorrect: true, feedback: 'Smart driving! Gentle switchbacks keep all wheels gripped safely.' },
        { id: 'blind', label: 'Drive fast through a dark field full of boulders', isCorrect: false, feedback: 'Driving blind into boulders could break a rover wheel!' },
      ],
    },
  },
  {
    id: 'disc-9',
    day: 9,
    category: 'solar-power',
    factTitle: 'Mini Space Reactors Keep Bases Warm During Freezing Nights',
    factType: 'future possibility',
    conciseExplanation:
      'NASA tested compact fission power units called Kilopower that can run steadily for over 10 years without needing sunlight.',
    whyInteresting:
      'When crater shadows hide the Sun and temperatures plunge below -130°C, backup reactors keep heaters and oxygen machines humming.',
    sourceOrg: 'NASA Glenn Research Center & Los Alamos National Lab',
    sourceTitle: 'Kilopower Project: Fission Surface Power for Moon and Mars',
    sourceUrl: 'https://www.nasa.gov/technology/power-systems/fission-surface-power/',
    novaQuote: 'When the Sun dips behind the crater ridge, backup power keeps our lights bright and heaters cozy!',
    badge: {
      title: 'Power Keeper',
      icon: '⚛️',
      description: 'Managed heat radiators for backup Moon power.',
    },
    challenge: {
      type: 'solar-align',
      prompt: 'A backup power generator makes extra heat that must escape so it doesn’t overheat. Where should we aim its radiator fins?',
      instructions: 'Pick the best way to cool down a Moon generator.',
      options: [
        { id: 'space', label: 'Aim the fins out toward freezing deep space', isCorrect: true, feedback: 'Smart! Cold outer space acts like a giant natural heat sink.' },
        { id: 'ground', label: 'Bury the hot fins underneath the crew bedrooms', isCorrect: false, feedback: 'That would overheat the floor and bake the habitat!' },
        { id: 'core', label: 'Wrap the radiator fins in thick winter blankets', isCorrect: false, feedback: 'Trapping heat inside would make the generator overheat and shut down!' },
      ],
    },
  },
  {
    id: 'disc-10',
    day: 10,
    category: 'water-ice',
    factTitle: 'The Sun’s Wind Helps Make Water Molecules in Moon Dirt',
    factType: 'scientific interpretation',
    conciseExplanation:
      'The Sun shoots tiny charged hydrogen particles across space at 400 km/s. When they hit oxygen-rich rocks on the Moon, they team up to form tiny bits of water!',
    whyInteresting:
      'Even sunlit Moon soil isn’t 100% bone-dry—space weather itself creates microscopic water across the lunar surface.',
    sourceOrg: 'NASA Goddard / Solar System Exploration Research Virtual Institute (SSERVI)',
    sourceTitle: 'Solar Wind Synthesis of Water on the Lunar Surface',
    sourceUrl: 'https://sservi.nasa.gov/articles/solar-wind-water-formation/',
    novaQuote: 'Believe it or not, fast particles flying from the Sun bump into Moon rocks and build tiny water molecules!',
    badge: {
      title: 'Solar Chemist',
      icon: '🧪',
      description: 'Discovered how sunlight particles create water on Moon rocks.',
    },
    challenge: {
      type: 'spectroscopy',
      prompt: 'How do NASA scientists spot tiny hidden water molecules in Moon dirt from orbit without landing?',
      instructions: 'Pick the tool that reads light bouncing off Moon rocks.',
      options: [
        { id: '3um', label: 'Infrared light sensors that detect water’s special heat-light fingerprint', isCorrect: true, feedback: 'Awesome! Water absorbs specific infrared light wavelengths like a barcode!' },
        { id: 'green', label: 'A regular green magnifying glass', isCorrect: false, feedback: 'Human eyes and regular glass can’t spot microscopic water molecules from orbit.' },
        { id: 'radio', label: 'Playing FM radio stations at the Moon', isCorrect: false, feedback: 'FM radio passes right through without measuring water molecules.' },
      ],
    },
  },
  {
    id: 'disc-11',
    day: 11,
    category: 'geology',
    factTitle: 'Giant Underground Lava Caves Could Hold Entire Moon Cities',
    factType: 'observation',
    conciseExplanation:
      'Billions of years ago, rivers of molten lava carved huge hollow tunnels under the Moon’s surface. Some caves are hundreds of meters wide!',
    whyInteresting:
      'Inside a Moon lava cave, the temperature stays steady and thick rock ceilings block meteorites and space radiation.',
    sourceOrg: 'NASA Jet Propulsion Laboratory / GRAIL Mission',
    sourceTitle: 'Gravity Recovery and Interior Laboratory (GRAIL) Subsurface Cavities',
    sourceUrl: 'https://science.nasa.gov/mission/grail/',
    novaQuote: 'Hidden beneath the craters are giant ancient lava caves—natural underground shelters built billions of years ago!',
    badge: {
      title: 'Cave Explorer',
      icon: '🕳️',
      description: 'Explored underground Moon caves with laser drones.',
    },
    challenge: {
      type: 'rover-route',
      prompt: 'We want to send a flying scout drone down into a dark Moon lava cave. Why won’t a normal helicopter drone work there?',
      instructions: 'Think about what helicopters need to fly!',
      options: [
        { id: 'lidar', label: 'There is no air on the Moon, so it needs gas thrusters and laser scanners', isCorrect: true, feedback: 'Yes! Spinning blades need air to push against—on the Moon, thruster jets and laser eyes work best!' },
        { id: 'parachute', label: 'It should drop on a giant parachute instead', isCorrect: false, feedback: 'Parachutes need air to slow down! On the Moon it would drop like a rock.' },
        { id: 'anemometer', label: 'Underground cave winds would blow propellers backward', isCorrect: false, feedback: 'There’s no wind at all on the airless Moon!' },
      ],
    },
  },
  {
    id: 'disc-12',
    day: 12,
    category: 'eclss',
    factTitle: 'Low Gravity Weakens Astronaut Bones Without Daily Workouts',
    factType: 'observation',
    conciseExplanation:
      'Moon gravity is only one-sixth as strong as Earth’s. Because muscles and bones don’t work as hard to walk around, astronauts lose strength fast unless they exercise.',
    whyInteresting:
      'Space gyms use vacuum resistance bands instead of heavy iron weights so astronauts can lift, squat, and keep their hearts strong!',
    sourceOrg: 'NASA Human Research Program (HRP)',
    sourceTitle: 'Musculoskeletal Adaptation in Reduced Gravity & Artemis Exercise Countermeasures',
    sourceUrl: 'https://www.nasa.gov/hrp/',
    novaQuote: 'Bouncing around in one-sixth gravity feels super fun—but without daily workouts, astronauts’ bones get weak!',
    badge: {
      title: 'Space Athlete',
      icon: '🏋️',
      description: 'Kept astronaut bones and hearts strong in low gravity.',
    },
    challenge: {
      type: 'quick-quiz',
      prompt: 'Why can’t astronauts skip workouts on the Moon, even when they feel super light and bouncy?',
      instructions: 'Pick what keeps space crews healthy.',
      options: [
        { id: 'bed', label: 'Staying in bed all day saves food and makes bones stronger', isCorrect: false, feedback: 'Resting too much actually weakens muscles and bones super fast!' },
        { id: 'ared', label: 'Heavy resistance workouts + biking keep bones dense and hearts fit', isCorrect: true, feedback: 'Nailed it! Pulling against resistance machines reminds bones to stay strong!' },
        { id: 'floating', label: 'Light stretching for 5 minutes is enough', isCorrect: false, feedback: 'Quick stretching feels nice, but bones need real resistance force to stay tough.' },
      ],
    },
  },
  {
    id: 'disc-13',
    day: 13,
    category: 'water-ice',
    factTitle: 'NASA Crashed a Rocket Into a Crater to Prove Water Ice Was There',
    factType: 'observation',
    conciseExplanation:
      'In 2009, NASA aimed a spent rocket stage into a dark South Pole crater. A second spacecraft flew through the dust splash and measured real frozen water vapor!',
    whyInteresting:
      'That giant splash proved polar craters aren’t just dry gray rocks—there’s enough frozen water down there to supply future bases!',
    sourceOrg: 'NASA Ames Research Center / LCROSS Mission',
    sourceTitle: 'Detection of Water in the LCROSS Ejecta Plume',
    sourceUrl: 'https://www.nasa.gov/mission_pages/LCROSS/main/index.html',
    novaQuote: 'In 2009, NASA made a giant dust splash inside a dark Moon crater—and spotted real water ice flying out!',
    badge: {
      title: 'Crater Detective',
      icon: '💥',
      description: 'Learned how NASA proved water ice hides in dark craters.',
    },
    challenge: {
      type: 'spectroscopy',
      prompt: 'How did NASA’s LCROSS mission look inside a pitch-black crater to prove ice was hiding underneath the dirt?',
      instructions: 'Pick the clever experiment NASA used.',
      options: [
        { id: 'methane-so2', label: 'Crashed an empty rocket to kick up a sunlit cloud and scanned it for water', isCorrect: true, feedback: 'Boom—science! Sunlight lit up the flying dust cloud so sensors spotted real water!' },
        { id: 'chlorine-gas', label: 'Sent human divers swimming into underground lakes', isCorrect: false, feedback: 'Way too cold for liquid lakes—it’s frozen solid at -230°C!' },
        { id: 'petroleum', label: 'Used giant flashlights from Earth telescopes', isCorrect: false, feedback: 'Flashlights from Earth couldn’t see underground ice inside deep craters!' },
      ],
    },
  },
  {
    id: 'disc-14',
    day: 14,
    category: 'solar-power',
    factTitle: 'Water Can Work Like a Giant Rechargeable Space Battery',
    factType: 'future possibility',
    conciseExplanation:
      'During sunny hours, extra solar power splits water into hydrogen and oxygen gases. At night, a fuel cell puts them back together to make electricity, heat, and water!',
    whyInteresting:
      'Fuel cells store far more energy than regular batteries of the same weight, helping Moon bases survive long freezing shadows.',
    sourceOrg: 'NASA Glenn Research Center',
    sourceTitle: 'Regenerative Fuel Cell Systems for Lunar Surface Missions',
    sourceUrl: 'https://www.nasa.gov/glenn-research-center/technology/energy-storage/',
    novaQuote: 'Water is basically our rechargeable battery! Split it with sunlight by day, recombine it for power and warmth at night!',
    badge: {
      title: 'Battery Genius',
      icon: '🔋',
      description: 'Used hydrogen fuel cells to power the base through Moon shadows.',
    },
    challenge: {
      type: 'eclss-pipe',
      prompt: 'A big mountain shadow just blocked the Sun! What two stored gases combine inside a fuel cell to make electricity and clean water?',
      instructions: 'Pick the fuel-cell power pair.',
      options: [
        { id: 'h2-o2', label: 'Hydrogen + Oxygen gases', isCorrect: true, feedback: 'You got it! Combining Hydrogen and Oxygen creates electricity, heat, and pure H2O!' },
        { id: 'diesel', label: 'Gasoline + outer space vacuum', isCorrect: false, feedback: 'Engines can’t burn gasoline without air outside!' },
        { id: 'steam', label: 'Ice cubes + Moon sand', isCorrect: false, feedback: 'Ice and sand won’t make a fuel-cell reaction!' },
      ],
    },
  },
  {
    id: 'disc-15',
    day: 15,
    category: 'navigation',
    factTitle: 'Laser Beams Can Stream 4K Video Back From Deep Space',
    factType: 'observation',
    conciseExplanation:
      'Instead of only using radio waves, NASA’s optical laser comms shoot super-fast pulses of invisible laser light across space.',
    whyInteresting:
      'Lasers carry 10 to 100 times more data than older radio dishes—enough to beam crisp HD video from the Moon straight to Earth!',
    sourceOrg: 'NASA Jet Propulsion Laboratory / DSOC Mission',
    sourceTitle: 'Deep Space Optical Communications (DSOC) Technology Demonstration',
    sourceUrl: 'https://www.nasa.gov/technology/deep-space-optical-communications-dsoc/',
    novaQuote: 'Goodbye laggy space calls! Infrared lasers let us stream crystal-clear video from the Moon to classrooms on Earth!',
    badge: {
      title: 'Laser Messenger',
      icon: '📡',
      description: 'Sent high-speed data across space using laser beams.',
    },
    challenge: {
      type: 'solar-align',
      prompt: 'Light takes about 1.3 seconds to travel from the Moon to Earth, and Earth is spinning fast! How do we aim a laser dish accurately?',
      instructions: 'Think like a quarterback throwing to a moving target.',
      options: [
        { id: 'point-ahead', label: 'Aim slightly ahead of where Earth’s receiver dish is moving', isCorrect: true, feedback: 'Bullseye! Aiming ahead ensures the laser hits the dish right as it arrives 1.3 seconds later.' },
        { id: 'look-now', label: 'Aim straight where the dish was a few minutes ago', isCorrect: false, feedback: 'Wait—Earth moves fast in space, so the laser beam would miss!' },
        { id: 'wide-beam', label: 'Shake the dish randomly in every direction', isCorrect: false, feedback: 'Shaking scatters the signal so Earth telescopes can’t read it!' },
      ],
    },
  },
  {
    id: 'disc-16',
    day: 16,
    category: 'geology',
    factTitle: 'The Young Moon Was Once a Giant Ocean of Glowing Lava',
    factType: 'observation',
    conciseExplanation:
      'Apollo 15 astronauts brought back a bright white rock over 4.4 billion years old. Lighter white minerals floated to the top of a Moon-wide magma ocean as it cooled!',
    whyInteresting:
      'That’s why the bright Moon highlands you see from your backyard are like frozen foam on top of an ancient lava sea!',
    sourceOrg: 'NASA Johnson Space Center / Astromaterials Research',
    sourceTitle: 'Apollo 15 Lunar Sample 15415: The Genesis Rock & Magma Ocean Hypothesis',
    sourceUrl: 'https://curator.jsc.nasa.gov/lunar/samplecatalog/sample.cfm?sample=15415',
    novaQuote: 'When you look at the Moon from Earth, those bright white highlands are cooled rocks that once floated on a glowing lava sea!',
    badge: {
      title: 'Rock Scientist',
      icon: '🌋',
      description: 'Discovered how the Moon’s bright crust formed from magma.',
    },
    challenge: {
      type: 'quick-quiz',
      prompt: 'Why are the Moon’s bright white rocks found near the surface instead of deep underground?',
      instructions: 'Think about what happens when light and heavy things are melted together.',
      options: [
        { id: 'feldspar', label: 'Lighter white rock crystals floated to the top of the ancient lava ocean', isCorrect: true, feedback: 'Exact science! Light minerals floated upward and cooled into the bright crust we see today.' },
        { id: 'iron', label: 'Heavy metal iron floated up like balloons', isCorrect: false, feedback: 'Heavy iron sank toward the center core of the Moon!' },
        { id: 'coal', label: 'Ancient Moon trees turned into white coal', isCorrect: false, feedback: 'No trees or forests ever grew on the Moon.' },
      ],
    },
  },
  {
    id: 'disc-17',
    day: 17,
    category: 'eclss',
    factTitle: 'Moon Rocks Actually Have Breathable Oxygen Locked Inside',
    factType: 'scientific interpretation',
    conciseExplanation:
      'Over 40% of Moon dirt’s weight is oxygen atoms chemically bonded inside minerals. Heating melted Moon soil with electricity frees pure oxygen gas!',
    whyInteresting:
      'One cubic meter of Moon dirt holds enough oxygen to keep an astronaut breathing for over two years!',
    sourceOrg: 'NASA Kennedy Space Center / ISRU Project',
    sourceTitle: 'Molten Regolith Electrolysis for In-Situ Oxygen Production',
    sourceUrl: 'https://www.nasa.gov/isru/',
    novaQuote: 'Mind-blowing fact: more than 40% of ordinary gray Moon dirt is actually oxygen locked inside rock!',
    badge: {
      title: 'Oxygen Miner',
      icon: '🌬️',
      description: 'Extracted breathable oxygen straight out of melted Moon soil.',
    },
    challenge: {
      type: 'eclss-pipe',
      prompt: 'Nearly half the weight of Moon dirt is oxygen locked inside rock. How can astronauts pull that oxygen out to breathe?',
      instructions: 'Choose the real NASA rock-to-oxygen method.',
      options: [
        { id: 'electrolysis-o2', label: 'Melt the Moon dirt super hot and zap it with electricity to bubble out oxygen gas', isCorrect: true, feedback: 'Amazing! Electric current splits oxygen atoms free from melted rock so we can breathe it!' },
        { id: 'freeze-crush', label: 'Freeze the rocks and smash them with a hammer', isCorrect: false, feedback: 'Smashing rocks just makes smaller dust—the chemical bonds stay locked.' },
        { id: 'soap', label: 'Wash the Moon dirt in warm soapy water', isCorrect: false, feedback: 'Soap doesn’t pull oxygen atoms out of stone!' },
      ],
    },
  },
  {
    id: 'disc-18',
    day: 18,
    category: 'geology',
    factTitle: 'A Giant Ancient Asteroid Dug Into the Moon’s Deep Inside',
    factType: 'observation',
    conciseExplanation:
      'The South Pole-Aitken Basin is one of the largest craters in the entire solar system—2,500 km wide! That mega-crash blasted deep rocks right onto the surface.',
    whyInteresting:
      'Instead of drilling miles down, astronauts can pick up rocks right off the ground to study what the Moon’s deep inside is made of!',
    sourceOrg: 'NASA Science Mission Directorate',
    sourceTitle: 'South Pole-Aitken Basin: The Deepest Window into the Moon',
    sourceUrl: 'https://science.nasa.gov/moon/facts/',
    novaQuote: 'Our outpost sits near one of the biggest craters in the solar system—a cosmic crash dug up rocks from miles underground!',
    badge: {
      title: 'Deep Crater Scout',
      icon: '🪐',
      description: 'Learned how giant impacts expose deep Moon rocks.',
    },
    challenge: {
      type: 'spectroscopy',
      prompt: 'Why are scientists so excited to pick up rocks near the giant South Pole-Aitken crater?',
      instructions: 'Think about what a giant asteroid impact digs up.',
      options: [
        { id: 'pyroxene', label: 'The giant crash blasted up rare iron-rich rocks from deep inside the Moon', isCorrect: true, feedback: 'Correct! We get to study deep interior Moon rocks without needing a mile-deep drill!' },
        { id: 'granite', label: 'Because ancient ocean fish fossils wash up on crater walls', isCorrect: false, feedback: 'The Moon has never had oceans or fish!' },
        { id: 'limestone', label: 'Because shiny gold coins formed inside craters', isCorrect: false, feedback: 'No gold coins—just super valuable deep planetary rocks for science!' },
      ],
    },
  },
  {
    id: 'disc-19',
    day: 19,
    category: 'geology',
    factTitle: 'Moon Dust Is Jagged Like Microscopic Glass',
    factType: 'observation',
    conciseExplanation:
      'On Earth, wind and rain smooth sand grains round. On the airless Moon, tiny space pebbles smash rocks into razor-sharp, jagged dust shards.',
    whyInteresting:
      'During Apollo missions, sharp dust wore away spacesuit gloves and clogged zippers—so modern bases keep dirty suits outside!',
    sourceOrg: 'NASA Toxicological Advisory Group',
    sourceTitle: 'Lunar Dust Toxicity and Mitigation Assessment',
    sourceUrl: 'https://www.nasa.gov/humans-in-space/lunar-dust-hazard/',
    novaQuote: 'Careful after moonwalks! Moon dust isn’t soft like beach sand—under a microscope it looks like tiny sharp glass needles!',
    badge: {
      title: 'Suit Safety Pro',
      icon: '🧹',
      description: 'Kept sharp Moon dust outside the living quarters.',
    },
    challenge: {
      type: 'quick-quiz',
      prompt: 'Because Moon dust is super sharp and bad to breathe, how do modern Moon bases keep suits out of the bedrooms?',
      instructions: 'Pick the cleanest spacesuit design.',
      options: [
        { id: 'suitport', label: 'Attach spacesuits to the outside wall so astronauts step inside from the back', isCorrect: true, feedback: 'Genius design! The dusty suit stays outdoors while astronauts climb straight into a clean room!' },
        { id: 'walk-in', label: 'Wear dusty boots straight to the dining table', isCorrect: false, feedback: 'Tracking sharp glass-like dust inside hurts crew lungs and clogs air filters!' },
        { id: 'blow-dry', label: 'Blast dusty suits with a leaf blower inside the kitchen', isCorrect: false, feedback: 'That would fill the whole base air with floating sharp dust!' },
      ],
    },
  },
  {
    id: 'disc-20',
    day: 20,
    category: 'water-ice',
    factTitle: 'Moon Rovers Drill Underground to Hunt Hidden Permafrost',
    factType: 'observation',
    conciseExplanation:
      'Even when the very top centimeter of Moon dust looks dry, frozen sheets of water ice can hide 10 to 50 centimeters underground under a blanket of soil.',
    whyInteresting:
      'NASA drills underground in short gentle bites so heat doesn’t accidentally melt and vaporize the ice before sensors measure it!',
    sourceOrg: 'NASA Ames Research Center / VIPER Mission',
    sourceTitle: 'Volatiles Investigating Polar Exploration Rover Science Payload',
    sourceUrl: 'https://www.nasa.gov/viper/',
    novaQuote: 'Even if the surface dust looks dry, drilling just a foot underground can strike frozen permafrost ice!',
    badge: {
      title: 'Ice Driller',
      icon: '⛏️',
      description: 'Drilled carefully for underground Moon ice without melting it.',
    },
    challenge: {
      type: 'rover-route',
      prompt: 'When a Moon rover drills into frozen dirt, spinning too fast makes friction heat that melts the ice into steam. How should we drill?',
      instructions: 'Keep the ice sample cold while drilling.',
      options: [
        { id: 'pulse-bite', label: 'Take short, gentle drill bites with cool-down pauses', isCorrect: true, feedback: 'Smart engineering! Short bites keep the drill bit cool so the ice stays frozen to study.' },
        { id: 'high-speed', label: 'Spin at full speed non-stop until the drill glows red hot', isCorrect: false, feedback: 'Way too hot—the ice turns to steam and disappears into space!' },
        { id: 'oil-lube', label: 'Pour thick car motor oil down the hole', isCorrect: false, feedback: 'Oil ruins the science sample and freezes solid in the cold!' },
      ],
    },
  },
  {
    id: 'disc-21',
    day: 21,
    category: 'solar-power',
    factTitle: 'Moon Temperatures Swing Over 250 Degrees From Sun to Shade',
    factType: 'scientific interpretation',
    conciseExplanation:
      'With no air blanket to hold warmth, sunny Moon ground heats past +120°C, while shady craters freeze below -130°C!',
    whyInteresting:
      'Moon bases use special cooling loops (with liquids that don’t freeze easily) to balance scorching daylight and freezing shadows.',
    sourceOrg: 'NASA Glenn Research Center',
    sourceTitle: 'Thermal Energy Storage for Lunar Surface Exploration',
    sourceUrl: 'https://www.nasa.gov/glenn-research-center/technology/thermal-energy-storage/',
    novaQuote: 'One side of your spacesuit in the Sun can bake hotter than boiling water while the shady side freezes like Antarctica!',
    badge: {
      title: 'Temp Master',
      icon: '🌡️',
      description: 'Balanced extreme Moon hot and cold temperatures.',
    },
    challenge: {
      type: 'solar-align',
      prompt: 'In -130°C Moon shadows, why can’t astronauts run ordinary tap water through outside cooling pipes?',
      instructions: 'Think about what happens to water below 0°C!',
      options: [
        { id: 'ammonia', label: 'Water freezes into solid ice and cracks pipes—so NASA uses special non-freezing coolants', isCorrect: true, feedback: 'Right on! Space cooling loops use fluids like ammonia that stay liquid far below freezing.' },
        { id: 'pure-water', label: 'Actually, tap water never freezes on the Moon', isCorrect: false, feedback: 'Tap water freezes rock-solid below 0°C—just like in an Earth freezer!' },
        { id: 'mercury', label: 'Because space aliens drink tap water from outside pipes', isCorrect: false, feedback: 'Haha, no—it’s pure physics: frozen ice expands and bursts metal tubes!' },
      ],
    },
  },
  {
    id: 'disc-22',
    day: 22,
    category: 'radiation',
    factTitle: 'Earth’s Magnetic Tail Shields the Moon 5 Days Every Month',
    factType: 'observation',
    conciseExplanation:
      'Earth’s magnetic field stretches behind us like a giant windsock away from the Sun. Every Full Moon, the Moon sails right inside Earth’s protective tail for 4–5 days!',
    whyInteresting:
      'During those Full Moon days, Earth blocks over 95% of incoming solar wind—making it the safest window for big outdoor moonwalks!',
    sourceOrg: 'NASA Goddard / ARTEMIS',
    sourceTitle: 'ARTEMIS Spacecraft Mapping of Earth’s Magnetotail Interaction with the Moon',
    sourceUrl: 'https://www.nasa.gov/mission_pages/artemis-lunar/',
    novaQuote: 'Teamwork across space! Once a month during Full Moon, Earth’s invisible magnetic shield sweeps right over us!',
    badge: {
      title: 'Shield Surfer',
      icon: '🧲',
      description: 'Timed outdoor moonwalks during Earth’s magnetic shield window.',
    },
    challenge: {
      type: 'radiation-shield',
      prompt: 'Earth’s magnetic tail stretches away from the Sun, right behind Earth. Which Moon phase puts the Moon safely inside that shield?',
      instructions: 'Imagine Sun -> Earth -> Moon lined up in a row.',
      options: [
        { id: 'full-moon', label: 'Full Moon (when the Moon is behind Earth, away from the Sun)', isCorrect: true, feedback: 'You got it! During Full Moon, Earth stands between the Sun and Moon, shielding us!' },
        { id: 'new-moon', label: 'New Moon (when the Moon sits right in front of the Sun)', isCorrect: false, feedback: 'At New Moon, the Moon sits in front of Earth and gets full blast solar wind!' },
        { id: 'quarter', label: 'Half Moon off to the side', isCorrect: false, feedback: 'Off to the side, the Moon sits outside Earth’s magnetic shadow tail.' },
      ],
    },
  },
  {
    id: 'disc-23',
    day: 23,
    category: 'navigation',
    factTitle: 'Smart Spacecraft Cameras Spot Boulders and Land Safely',
    factType: 'scientific interpretation',
    conciseExplanation:
      'Modern Moon landers use fast cameras and computer vision to scan craters during descent and steer themselves clear of steep rocks and cliffs!',
    whyInteresting:
      'Apollo astronauts had to dodge boulders by hand, whereas Artemis landers pinpoint safe flat spots within 100 meters automatically!',
    sourceOrg: 'NASA Jet Propulsion Laboratory',
    sourceTitle: 'Terrain-Relative Navigation for Precision Lunar and Mars Landings',
    sourceUrl: 'https://www.nasa.gov/technology/terrain-relative-navigation/',
    novaQuote: 'Our lander’s onboard cameras scanned craters like a video game map and dodged every boulder automatically!',
    badge: {
      title: 'Autopilot Ace',
      icon: '🎯',
      description: 'Guided a lander safely away from dangerous crater boulders.',
    },
    challenge: {
      type: 'rover-route',
      prompt: 'Your supply rocket is 30 seconds from landing and its camera spots a giant jagged boulder right below! What should the autopilot do?',
      instructions: 'Choose the smartest landing safety maneuver.',
      options: [
        { id: 'divert', label: 'Fire side thrusters to slide sideways 50 meters to a smooth flat patch', isCorrect: true, feedback: 'Touchdown! Sliding sideways onto flat ground saves the rocket and cargo!' },
        { id: 'cut-engine', label: 'Turn off all engines in mid-air', isCorrect: false, feedback: 'Shutting engines off in mid-air causes a crash!' },
        { id: 'full-throttle', label: 'Land right on top of the boulder anyway', isCorrect: false, feedback: 'Landing on a jagged boulder would tip the rocket right over!' },
      ],
    },
  },
  {
    id: 'disc-24',
    day: 24,
    category: 'eclss',
    factTitle: 'Scientists Really Grew Green Plants in Real Moon Dirt!',
    factType: 'observation',
    conciseExplanation:
      'In 2022, NASA scientists planted tiny seeds in actual Moon soil brought back by Apollo astronauts—and green leaves sprouted for the first time ever!',
    whyInteresting:
      'Proving plants can grow in Moon soil means future lunar greenhouses can make fresh salad, boost crew moods, and scrub carbon dioxide!',
    sourceOrg: 'NASA Biological & Physical Sciences (BPS) Division',
    sourceTitle: 'Plants Grown in Apollo Lunar Regolith for the First Time',
    sourceUrl: 'https://science.nasa.gov/biological-physical/features/plants-grown-in-lunar-soil/',
    novaQuote: 'Real green sprouts grew in Apollo Moon rocks back on Earth! Plants are tiny green astronauts helping us survive!',
    badge: {
      title: 'Moon Gardener',
      icon: '🌱',
      description: 'Helped space plants sprout in real Moon soil.',
    },
    challenge: {
      type: 'quick-quiz',
      prompt: 'Raw Moon soil is harsh and salty for seedlings. What helps greenhouse sprouts grow strong and green inside our dome?',
      instructions: 'Pick what plants actually need to thrive.',
      options: [
        { id: 'hydro-leach', label: 'Rinse the soil with clean water, add plant nutrients, and use LED grow lights', isCorrect: true, feedback: 'Green thumb in space! Water, nutrients, and grow lights give astronauts fresh veggies!' },
        { id: 'bleach', label: 'Water the seedlings with swimming-pool bleach', isCorrect: false, feedback: 'Yikes—bleach kills green plants immediately!' },
        { id: 'darkness', label: 'Lock the greenhouse in pitch darkness forever', isCorrect: false, feedback: 'Plants need light energy for photosynthesis to grow and make oxygen!' },
      ],
    },
  },
  {
    id: 'disc-25',
    day: 25,
    category: 'geology',
    factTitle: 'Moonquakes Make the Moon Ring Like a Giant Bell!',
    factType: 'observation',
    conciseExplanation:
      'On Earth, earthquakes usually end in under a minute. Because the Moon’s rocks are super dry and stiff, big moonquakes echo and shake for over 10 minutes!',
    whyInteresting:
      'Engineers build flexible shock-absorber pads under Moon base legs so long vibrations never crack the habitat walls.',
    sourceOrg: 'NASA Marshall Space Flight Center / Apollo Passive Seismic Experiment',
    sourceTitle: 'Lunar Seismology and the Internal Structure of the Moon',
    sourceUrl: 'https://science.nasa.gov/moon/moonquakes/',
    novaQuote: 'Did you know the Moon actually has moonquakes? And without water in the rock to quiet them down, it rings like a bell!',
    badge: {
      title: 'Quake Engineer',
      icon: '🔔',
      description: 'Protected the Moon base from 10-minute moonquakes.',
    },
    challenge: {
      type: 'quick-quiz',
      prompt: 'A moonquake shakes our base for 10 whole minutes! What keeps our habitat dome from cracking?',
      instructions: 'Think how earthquake-proof buildings work.',
      options: [
        { id: 'dampers', label: 'Flexible shock-absorber pads under the base legs', isCorrect: true, feedback: 'Solid engineering! Shock pads absorb vibrations so the dome bends safely without cracking.' },
        { id: 'brittle-glass', label: 'Glue the dome tightly onto stiff brittle glass rods', isCorrect: false, feedback: 'Brittle glass rods snap right away under shaking!' },
        { id: 'hover', label: 'Hover the whole Moon base in the air with rockets for 10 minutes', isCorrect: false, feedback: 'That would burn all our emergency rocket fuel!' },
      ],
    },
  },
  {
    id: 'disc-26',
    day: 26,
    category: 'water-ice',
    factTitle: 'Apollo 17 Astronauts Found Bright Orange Volcanic Soil on the Moon',
    factType: 'observation',
    conciseExplanation:
      'Geologist astronaut Harrison Schmitt spotted glowing orange dirt! Under a microscope, it turned out to be tiny volcanic glass beads from ancient lunar eruptions.',
    whyInteresting:
      'Trapped inside those tiny orange glass beads, scientists discovered traces of ancient water from deep inside the Moon!',
    sourceOrg: 'NASA Johnson Space Center / Apollo 17 Science',
    sourceTitle: 'Volatile-Rich Pyroclastic Glass Deposits on the Moon',
    sourceUrl: 'https://curator.jsc.nasa.gov/lunar/samplecatalog/sample.cfm?sample=74220',
    novaQuote: 'Not everything on the Moon is gray! Apollo 17 discovered bright orange volcanic soil full of tiny glass beads!',
    badge: {
      title: 'Orange Glass Hunter',
      icon: '🟠',
      description: 'Studied ancient volcanic glass beads found on the Moon.',
    },
    challenge: {
      type: 'spectroscopy',
      prompt: 'How did the famous bright orange soil at Apollo 17’s Shorty Crater form 3.6 billion years ago?',
      instructions: 'Pick what made those tiny colored glass beads.',
      options: [
        { id: 'sulfur-fluorine', label: 'Explosive ancient Moon volcanoes sprayed lava droplets that froze into glass beads', isCorrect: true, feedback: 'Awesome volcano fact! Fire-fountains sprayed glowing lava droplets that cooled in space!' },
        { id: 'liquid-gasoline', label: 'Someone spilled giant buckets of orange paint before Apollo 17', isCorrect: false, feedback: 'Haha, definitely not paint—real ancient volcanic glass!' },
        { id: 'ammonite-fossils', label: 'Crushed orange seashells from an ocean', isCorrect: false, feedback: 'No oceans or seashells ever existed on the Moon.' },
      ],
    },
  },
  {
    id: 'disc-27',
    day: 27,
    category: 'radiation',
    factTitle: 'Super Magnets Could Build Invisible Force Fields Around Ships',
    factType: 'future possibility',
    conciseExplanation:
      'NASA scientists are studying lightweight superconducting magnets that create a real magnetic bubble around spaceships to bend charged solar particles away!',
    whyInteresting:
      'Just like Earth’s magnetic field protects us every day, a magnetic force field can shield astronauts on long deep-space trips!',
    sourceOrg: 'NASA Innovative Advanced Concepts (NIAC)',
    sourceTitle: 'Active Superconducting Magnetic Shielding for Deep Space Missions',
    sourceUrl: 'https://www.nasa.gov/directorates/stmd/niac-programs/active-radiation-shielding/',
    novaQuote: 'It sounds straight out of sci-fi, but super-cold magnets really can bend dangerous space radiation around a ship!',
    badge: {
      title: 'Force Field Tech',
      icon: '⚡',
      description: 'Learned how superconducting magnets deflect space radiation.',
    },
    challenge: {
      type: 'radiation-shield',
      prompt: 'Superconducting magnets carry huge electric current with almost zero lost power—what temperature do they need to work?',
      instructions: 'Pick whether superconductors love extreme cold or scorching heat.',
      options: [
        { id: 'cryo-77k', label: 'Super freezing cold (-196°C) using shady deep-space cooling', isCorrect: true, feedback: 'Yes! Superconductors only lose electrical resistance when kept super freezing cold!' },
        { id: 'boiling-300c', label: 'Super hot (+300°C) inside a giant oven', isCorrect: false, feedback: 'Too hot! Heat destroys the superconducting effect completely.' },
        { id: 'salt-water', label: 'Dunked in warm salty ocean water', isCorrect: false, feedback: 'Salt water would short-circuit all the wires!' },
      ],
    },
  },
  {
    id: 'disc-28',
    day: 28,
    category: 'water-ice',
    factTitle: 'Roasting Frozen Dirt Under a Tent Catches Pure Steam',
    factType: 'future possibility',
    conciseExplanation:
      'Instead of digging heavy frozen rock with giant bulldozers, a rover beams microwaves under a sealed tent to turn underground ice straight into vapor, then freezes it onto cold plates!',
    whyInteresting:
      'Using gentle heat instead of heavy digging blades saves tons of rover weight and keeps parts from wearing out in sharp dust!',
    sourceOrg: 'NASA Marshall Space Flight Center',
    sourceTitle: 'In-Situ Microwave Volatiles Extraction from Cryogenic Regolith',
    sourceUrl: 'https://www.nasa.gov/isru/',
    novaQuote: 'Why break shovel blades on rock-hard Moon ice when you can warm it under a tent and catch pure steam?',
    badge: {
      title: 'Steam Catcher',
      icon: '💨',
      description: 'Harvested clean water vapor from frozen Moon dirt.',
    },
    challenge: {
      type: 'eclss-pipe',
      prompt: 'When steam rises out of warmed Moon dirt inside our collector tent, how should we trap it as pure ice?',
      instructions: 'Remember how morning dew or frost forms on cold surfaces.',
      options: [
        { id: 'cold-minus-50', label: 'Chill collector plates to -50°C so water vapor freezes onto them as clean ice', isCorrect: true, feedback: 'Clean harvest! Water vapor instantly freezes onto the icy collector plates for drinking water.' },
        { id: 'boiling-150', label: 'Blast the collector plates at +150°C', isCorrect: false, feedback: 'Hot plates can’t condense steam—it stays gas and escapes!' },
        { id: 'leave-open', label: 'Open the tent flaps wide to outer space', isCorrect: false, feedback: 'All our precious water vapor would escape straight into space!' },
      ],
    },
  },
  {
    id: 'disc-29',
    day: 29,
    category: 'navigation',
    factTitle: 'The Gateway Space Station Will Orbit Over the Moon Like a Relay Hub',
    factType: 'observation',
    conciseExplanation:
      'NASA’s Gateway space station will loop around the Moon in a tall oval orbit, staying in clear radio view of South Pole bases for 6 out of every 7 days!',
    whyInteresting:
      'Gateway acts like an orbiting pit stop between Earth and the Moon—relays our messages and lets landers dock before trips to Mars!',
    sourceOrg: 'NASA Johnson Space Center / Gateway Program',
    sourceTitle: 'Gateway Mission Design: Near-Rectilinear Halo Orbit Architecture',
    sourceUrl: 'https://www.nasa.gov/mission_pages/gateway/overview/index.html',
    novaQuote: 'Wave up at the sky! The Lunar Gateway station loops high overhead, linking our Moon base smoothly back to Earth!',
    badge: {
      title: 'Space Relay Pro',
      icon: '🛰️',
      description: 'Linked our Moon base with the orbiting Gateway station.',
    },
    challenge: {
      type: 'rover-route',
      prompt: 'Why is NASA building the Gateway space station in orbit around the Moon before sending astronauts to Mars?',
      instructions: 'Pick how Gateway helps future explorers.',
      options: [
        { id: 'north-perilune', label: 'It acts as a space pit-stop for communications, supplies, and docking shuttles', isCorrect: true, feedback: 'Exact match! Gateway lets astronauts refuel, dock, and relay signals cleanly!' },
        { id: 'crash-crater', label: 'So astronauts can crash it into a crater at the end of Week 1', isCorrect: false, feedback: 'No way—Gateway is built to stay in orbit for years of missions!' },
        { id: 'earth-burn', label: 'So rockets can park there while heading straight past Jupiter', isCorrect: false, feedback: 'Next stop after the Moon is Mars—not Jupiter!' },
      ],
    },
  },
  {
    id: 'disc-30',
    day: 30,
    category: 'eclss',
    factTitle: 'Surviving on the Moon Trains Astronauts for Mars!',
    factType: 'future possibility',
    conciseExplanation:
      'A real Moon Base Camp combines habitats, pressurized rovers, solar grids, and air/water recyclers that astronauts can use for weeks at a time.',
    whyInteresting:
      'Everything you mastered across 30 days on the Moon—saving air, recycling water, blocking radiation—is the exact training needed for humanity’s first trip to Mars!',
    sourceOrg: 'NASA Headquarters / Artemis Plan',
    sourceTitle: 'NASA’s Plan for Sustained Lunar Exploration and Development',
    sourceUrl: 'https://www.nasa.gov/artemis/manifest/',
    novaQuote: 'You made it all 30 days, Commander! Everything your squad proved on the Moon unlocks our giant leap toward Mars!',
    badge: {
      title: 'Moon Legend',
      icon: '🏆',
      description: 'Mastered all 30 days of Moon survival and space science!',
    },
    challenge: {
      type: 'quick-quiz',
      prompt: 'Congratulations on reaching Day 30! What big next giant leap does living on the Moon prepare astronauts to do?',
      instructions: 'Confirm humanity’s next deep-space adventure!',
      options: [
        { id: 'mars-gateway', label: 'Send the first astronauts safely to explore Mars!', isCorrect: true, feedback: 'Mission Accomplished! Earth salutes you and your awesome Moon squad!' },
        { id: 'abandon', label: 'Turn off all space telescopes and stop exploring space', isCorrect: false, feedback: 'Never! Curiosity keeps humans exploring further!' },
        { id: 'delete-logs', label: 'Throw away all the science notebooks from the trip', isCorrect: false, feedback: 'Sharing our space discoveries helps future young scientists!' },
      ],
    },
  },
];
