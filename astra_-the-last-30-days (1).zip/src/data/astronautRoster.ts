/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CrewMember } from '../types/mission';

export interface SuitTheme {
  primary: string;       // Primary suit body color
  secondary: string;     // Secondary suit panel / armor color
  accent: string;        // Accent / trim / visor glow color
  dark: string;          // Deep shading / joint color
  ledColor: string;      // Chest status LED color
  styleName: string;     // Descriptive name of suit architecture
}

export interface AstronautCharacter {
  id: string;
  name: string;
  callsign: string;
  gender: 'male' | 'female';
  category: 'biologist' | 'scientist' | 'engineer' | 'operations' | 'medic' | 'comms';
  displayCategory: string; // e.g. "BIOLOGIST", "SCIENTIST", "ENGINEER", "OPERATIONS / SOLDIER"
  role: string;
  specialty: string;
  secondarySkill: string;
  personality: string;
  visualIdentity: string;
  characterIntro: string;
  quotes: string[];
  color: string;
  accentBg: string;
  assignedModule: string;
  badgeCode: string;
  bio: string;
  health: number;
  morale: number;
  fatigue: number;
  synergyTags: string[];
  suitTheme: SuitTheme;
}

export const ASTRONAUT_ROSTER: AstronautCharacter[] = [
  {
    id: 'alex-morgan',
    name: 'Alex Morgan',
    callsign: 'Vanguard',
    gender: 'male',
    category: 'operations',
    displayCategory: 'COMMANDER / SOLDIER',
    role: 'Expedition Commander',
    specialty: 'Leadership & Crisis Coordination',
    secondarySkill: 'Emergency Pressure Lockdown',
    personality: 'Calm, confident, strategic',
    visualIdentity: 'Tactical Command Navy suit with Arctic Titanium armor plating, silver chevrons, blue comms insignia.',
    characterIntro: 'Every decision matters out here. Let\'s bring everyone home.',
    quotes: [
      'Every decision matters out here. Let\'s bring everyone home.',
      'Maintain perimeter awareness. The regolith shift is manageable.',
      'Check your seals. We stand together through the lunar night.'
    ],
    color: '#38bdf8',
    accentBg: '#0284c7',
    assignedModule: 'living-habitat',
    badgeCode: 'CMD-01',
    bio: 'Former lunar test pilot and flight lead with 800+ hours in zero-g simulations. Known for maintaining composure during sudden telemetry drops.',
    health: 98,
    morale: 95,
    fatigue: 8,
    synergyTags: ['leadership', 'crisis-response', 'operations'],
    suitTheme: {
      primary: '#1e3a5f',
      secondary: '#f1f5f9',
      accent: '#38bdf8',
      dark: '#0f172a',
      ledColor: '#38bdf8',
      styleName: 'Vanguard Command Navy & Titanium White',
    },
  },
  {
    id: 'maya-shah',
    name: 'Dr. Maya Shah',
    callsign: 'Aura',
    gender: 'female',
    category: 'engineer',
    displayCategory: 'LIFE SUPPORT / ECLSS',
    role: 'Lead ECLSS Engineer',
    specialty: 'Life-Support Systems & Environmental Control',
    secondarySkill: 'Closed-Loop Fluid Recycling',
    personality: 'Analytical, patient, practical',
    visualIdentity: 'Sterile ECLSS White suit with Aqua Cyan pressure piping, dual fluid regulator coils, digital wrist telemetry.',
    characterIntro: 'Survival begins with understanding the systems that keep us alive.',
    quotes: [
      'Survival begins with understanding the systems that keep us alive.',
      'Water distillation scrubbers are operating within 2% of optimal.',
      'I\'ve rerouted trace carbon dioxide scrubbers to the bioculture bay.'
    ],
    color: '#06b6d4',
    accentBg: '#0891b2',
    assignedModule: 'life-support',
    badgeCode: 'ECL-02',
    bio: 'Environmental systems architect who pioneered micro-distillation protocols for long-duration deep space habitats.',
    health: 97,
    morale: 93,
    fatigue: 12,
    synergyTags: ['life-support', 'water-recycling', 'atmosphere'],
    suitTheme: {
      primary: '#f8fafc',
      secondary: '#0891b2',
      accent: '#22d3ee',
      dark: '#164e63',
      ledColor: '#06b6d4',
      styleName: 'Sterile ECLSS Environmental White & Cyan',
    },
  },
  {
    id: 'ethan-park',
    name: 'Dr. Ethan Park',
    callsign: 'Strata',
    gender: 'male',
    category: 'scientist',
    displayCategory: 'SCIENTIST',
    role: 'Chief Planetary Geologist',
    specialty: 'Lunar Geology & Scientific Exploration',
    secondarySkill: 'Volatiles & Subsurface Ice Prospecting',
    personality: 'Curious, observant, thoughtful',
    visualIdentity: 'Ochre Amber field suit with Basalt Graphite protective armor, spectacles, thigh volatile canister P-0212.',
    characterIntro: 'Every rock tells a story. We just have to learn how to read it.',
    quotes: [
      'Every rock tells a story. We just have to learn how to read it.',
      'Core sample beta shows ilmenite concentrations exceeding orbital estimates!',
      'Permeable regolith layers suggest volatile trapping beneath the ridge.'
    ],
    color: '#f59e0b',
    accentBg: '#d97706',
    assignedModule: 'science-lab',
    badgeCode: 'P-0212',
    bio: 'Planetary petrologist who mapped southern polar impact melts. Passionate about uncovering ancient lunar water-ice traps.',
    health: 95,
    morale: 96,
    fatigue: 14,
    synergyTags: ['science', 'geology', 'ice-prospecting'],
    suitTheme: {
      primary: '#d97706',
      secondary: '#334155',
      accent: '#fbbf24',
      dark: '#78350f',
      ledColor: '#f59e0b',
      styleName: 'Geologist Field Amber & Basalt Graphite',
    },
  },
  {
    id: 'zara-williams',
    name: 'Commander Zara Williams',
    callsign: 'Horizon',
    gender: 'female',
    category: 'operations',
    displayCategory: 'OPERATIONS / NAV',
    role: 'Mission Operations Director',
    specialty: 'Navigation & Surface Operations',
    secondarySkill: 'Autonomous Rover Teleoperation',
    personality: 'Decisive, adventurous, composed',
    visualIdentity: 'Deep Royal Violet suit with Obsidian Black ballistic limbs, navigational wrist radar, star chart vector.',
    characterIntro: 'The Moon may look silent, but it is full of places waiting to be explored.',
    quotes: [
      'The Moon may look silent, but it is full of places waiting to be explored.',
      'Surface rover telemetry synced. Traverse coordinates locked in.',
      'Crater rim shadow velocity is rising. We need to stay on schedule.'
    ],
    color: '#818cf8',
    accentBg: '#6366f1',
    assignedModule: 'living-habitat',
    badgeCode: 'NAV-04',
    bio: 'Veteran expedition navigator with extensive experience guiding robotic traversals across permanently shadowed regions.',
    health: 99,
    morale: 94,
    fatigue: 9,
    synergyTags: ['operations', 'navigation', 'logistics'],
    suitTheme: {
      primary: '#581c87',
      secondary: '#18181b',
      accent: '#a78bfa',
      dark: '#2e1065',
      ledColor: '#c084fc',
      styleName: 'Orbital Navigator Royal Violet & Midnight',
    },
  },
  {
    id: 'noah-reyes',
    name: 'Dr. Noah Reyes',
    callsign: 'Pulse',
    gender: 'male',
    category: 'medic',
    displayCategory: 'MEDICAL / BIOMED',
    role: 'Chief Medical Officer',
    specialty: 'Medical Care & Crew Wellbeing',
    secondarySkill: 'Radiation Cytoprotection',
    personality: 'Empathetic, observant, reassuring',
    visualIdentity: 'Clinical Ceramic White suit with Biomedical Teal armored plates, vital pulse LED strip, medical cross insignia.',
    characterIntro: 'A successful mission means keeping the people behind it safe.',
    quotes: [
      'A successful mission means keeping the people behind it safe.',
      'Crew biometric vitals are stable. Remember to schedule sleep cycles.',
      'Solar radiation shielding in Habitat Alpha is holding against cosmic flux.'
    ],
    color: '#14b8a6',
    accentBg: '#0d9488',
    assignedModule: 'living-habitat',
    badgeCode: 'MED-05',
    bio: 'Space medicine physician specialized in cardiovascular adaptation to fractional 1/6th gravity and radiation biomarkers.',
    health: 100,
    morale: 96,
    fatigue: 10,
    synergyTags: ['medical', 'crew-health', 'radiation'],
    suitTheme: {
      primary: '#ffffff',
      secondary: '#0d9488',
      accent: '#ef4444',
      dark: '#134e4a',
      ledColor: '#10b981',
      styleName: 'Biomedical Trauma White, Teal & Red',
    },
  },
  {
    id: 'ava-patel',
    name: 'Dr. Himanshi Panchal',
    callsign: 'Spark',
    gender: 'female',
    category: 'engineer',
    displayCategory: 'ENGINEER',
    role: 'Robotics & Hardware Specialist',
    specialty: 'Robotics & Autonomous Systems',
    secondarySkill: 'Rapid Field Repairs & Micromechanics',
    personality: 'Inventive, energetic, problem-solving',
    visualIdentity: 'Industrial Hazard Orange suit with Charcoal Exoskeleton arm rigging, hydraulic wrist clamps, tool harness.',
    characterIntro: 'If a machine can help us survive, I want to understand every part of it.',
    quotes: [
      'If a machine can help us survive, I want to understand every part of it.',
      'Robotic arm servo calibration complete. Gripper torque is dialed in.',
      'I\'ve 3D printed replacement seal gaskets for the airlock hatch.'
    ],
    color: '#f97316',
    accentBg: '#ea580c',
    assignedModule: 'science-lab',
    badgeCode: 'ENG-06',
    bio: 'Mechatronics specialist known for improvising functional repairs using lunar regolith-compatible additive manufacturing.',
    health: 96,
    morale: 98,
    fatigue: 11,
    synergyTags: ['engineering', 'robotics', 'repairs'],
    suitTheme: {
      primary: '#ea580c',
      secondary: '#27272a',
      accent: '#fdba74',
      dark: '#7c2d12',
      ledColor: '#fb923c',
      styleName: 'Robotics Industrial Hazard Orange & Charcoal',
    },
  },
  {
    id: 'liam-chen',
    name: 'Captain Liam Chen',
    callsign: 'Volt',
    gender: 'male',
    category: 'engineer',
    displayCategory: 'POWER SYSTEMS',
    role: 'Chief Electrical Engineer',
    specialty: 'Power Systems & Electrical Engineering',
    secondarySkill: 'Cryogenic Fuel Cell Management',
    personality: 'Resourceful, focused, optimistic',
    visualIdentity: 'High-Voltage Electric Cobalt Blue suit with Insulated Dark Carbon, glowing electrical conduit channels.',
    characterIntro: 'Power isn\'t just electricity here. It\'s time, safety, and survival.',
    quotes: [
      'Power isn\'t just electricity here. It\'s time, safety, and survival.',
      'Photovoltaic angle adjusted 4 degrees. Battery charging curve optimized.',
      'Regenerative fuel cells are primed for the upcoming lunar night.'
    ],
    color: '#3b82f6',
    accentBg: '#2563eb',
    assignedModule: 'power-grid',
    badgeCode: 'PWR-07',
    bio: 'High-voltage grid engineer who designed the polar vertical solar tower tracking system for continuous sunlight harvesting.',
    health: 97,
    morale: 91,
    fatigue: 13,
    synergyTags: ['power', 'solar', 'engineering'],
    suitTheme: {
      primary: '#1d4ed8',
      secondary: '#0f172a',
      accent: '#eab308',
      dark: '#172554',
      ledColor: '#38bdf8',
      styleName: 'High-Voltage Electric Cobalt & Solar Yellow',
    },
  },
  {
    id: 'sofia-okafor',
    name: 'Dr. Prisha Mishra',
    callsign: 'Bloom',
    gender: 'female',
    category: 'biologist',
    displayCategory: 'BIOLOGIST',
    role: 'Lead Astrobiologist',
    specialty: 'Astrobiology & Greenhouse Research',
    secondarySkill: 'Hydroponic Nutrient Recycling',
    personality: 'Curious, creative, enthusiastic',
    visualIdentity: 'Biosphere Emerald Green suit with Pearl White bio-containment seals, seedling vial capsule on belt.',
    characterIntro: 'If life can find a way to grow here, we may discover something extraordinary.',
    quotes: [
      'If life can find a way to grow here, we may discover something extraordinary.',
      'The dwarf wheat cultivars are transpiring oxygen right on schedule.',
      'Micro-algae bioreactors just reached peak biomass density!'
    ],
    color: '#10b981',
    accentBg: '#059669',
    assignedModule: 'bioculture',
    badgeCode: 'BIO-08',
    bio: 'Plant physiologist researching closed-loop food generation and cyanobacteria soil enrichment for long-term lunar settlement.',
    health: 98,
    morale: 97,
    fatigue: 8,
    synergyTags: ['biology', 'food-production', 'oxygen'],
    suitTheme: {
      primary: '#047857',
      secondary: '#f0fdf4',
      accent: '#34d399',
      dark: '#064e3b',
      ledColor: '#10b981',
      styleName: 'Biosphere Emerald Green & Hydroponic Pearl',
    },
  },
  {
    id: 'arjun-mehta',
    name: 'Captain Arjun Mehta',
    callsign: 'Titan',
    gender: 'male',
    category: 'operations',
    displayCategory: 'SOLDIER / EVA OPS',
    role: 'EVA Specialist & Safety Lead',
    specialty: 'EVA Operations & Surface Exploration',
    secondarySkill: 'Extreme Terrain Extraction',
    personality: 'Brave, disciplined, adaptable',
    visualIdentity: 'Extreme Polar Ballistic Crimson suit with heavy Iron Pauldrons, reinforced knee guards, tether carabiner.',
    characterIntro: 'Before every step into the unknown, preparation comes first.',
    quotes: [
      'Before every step into the unknown, preparation comes first.',
      'Tether tension verified. Regolith slope at 28 degrees is passable.',
      'Airlock depressurization complete. Stepping onto the lunar surface.'
    ],
    color: '#ef4444',
    accentBg: '#dc2626',
    assignedModule: 'living-habitat',
    badgeCode: 'EVA-09',
    bio: 'Specialized extreme-environment explorer who conducted sub-zero expeditions in Antarctica and deep speleology surveys.',
    health: 100,
    morale: 92,
    fatigue: 9,
    synergyTags: ['operations', 'eva-safety', 'repairs'],
    suitTheme: {
      primary: '#991b1b',
      secondary: '#1e293b',
      accent: '#f87171',
      dark: '#450a0a',
      ledColor: '#ef4444',
      styleName: 'Heavy Polar EVA Ballistic Crimson & Iron',
    },
  },
  {
    id: 'nia-brooks',
    name: 'Dr. Nia Brooks',
    callsign: 'Echo',
    gender: 'female',
    category: 'comms',
    displayCategory: 'COMMUNICATIONS / DATA',
    role: 'Chief Communications Officer',
    specialty: 'Communications & Scientific Data',
    secondarySkill: 'Deep Space Optical Link Relay',
    personality: 'Creative, perceptive, quick-thinking',
    visualIdentity: 'Deep Space Optical Amethyst suit with Neon Cyan optical waveguide lines, communications headset array.',
    characterIntro: 'Even millions of kilometres away, the right signal can change everything.',
    quotes: [
      'Even millions of kilometres away, the right signal can change everything.',
      'Direct-to-Earth laser optical link bandwidth locked at 1.2 Gbps.',
      'Telemetry handshake confirmed with Goldstone Deep Space tracking station.'
    ],
    color: '#a855f7',
    accentBg: '#9333ea',
    assignedModule: 'communications',
    badgeCode: 'COM-10',
    bio: 'Signal processing engineer and orbital communications expert who pioneered lunar laser downlink protocols during solar interference.',
    health: 99,
    morale: 95,
    fatigue: 11,
    synergyTags: ['communications', 'data', 'science'],
    suitTheme: {
      primary: '#7e22ce',
      secondary: '#0e7490',
      accent: '#e879f9',
      dark: '#3b0764',
      ledColor: '#06b6d4',
      styleName: 'Optical Link Amethyst & Laser Cyan',
    },
  }
];

/**
 * Converts an AstronautCharacter into a CrewMember compatible with MissionState
 */
export function convertCharacterToCrewMember(char: AstronautCharacter): CrewMember {
  return {
    id: char.id,
    name: char.name,
    callsign: char.callsign,
    role: char.role,
    specialty: char.specialty,
    avatarSeed: char.id,
    personality: char.personality,
    color: char.color,
    quote: char.characterIntro,
    health: char.health,
    morale: char.morale,
    fatigue: char.fatigue,
    status: 'nominal',
    assignedModule: char.assignedModule,
  };
}

/**
 * Evaluates the synergies of a 4-member crew
 */
export function evaluateCrewSynergy(characters: AstronautCharacter[]): {
  title: string;
  description: string;
  perks: string[];
  balanceScore: number; // 0 - 100
} {
  const tags = new Set<string>();
  characters.forEach(c => c.synergyTags.forEach(t => tags.add(t)));

  const hasEngineer = tags.has('engineering') || tags.has('repairs') || tags.has('power');
  const hasLifeSupport = tags.has('life-support') || tags.has('water-recycling') || tags.has('atmosphere');
  const hasScience = tags.has('science') || tags.has('geology') || tags.has('biology');
  const hasMedical = tags.has('medical') || tags.has('crew-health');
  const hasLeadership = tags.has('leadership') || tags.has('operations');

  const perks: string[] = [];

  if (hasLifeSupport && tags.has('biology')) {
    perks.push('Closed-Loop Harmony: Enhanced ECLSS recycling efficiency & crop resilience.');
  }
  if (hasEngineer && tags.has('power')) {
    perks.push('High-Efficiency Grid: Power subsystem fault recovery time reduced.');
  }
  if (hasMedical) {
    perks.push('Trauma & Cytoprotection: Baseline crew health decay minimized during solar flux.');
  } else {
    perks.push('Crew Vulnerability: No dedicated medical specialist; monitor health metrics carefully.');
  }
  if (hasScience && tags.has('geology')) {
    perks.push('Volatile Prospector: +15% discovery calibration points on lunar science.');
  }
  if (hasLeadership) {
    perks.push('Command Stability: Crew morale buffer protected against emergency panic.');
  }

  let balanceScore = 65;
  if (hasEngineer) balanceScore += 8;
  if (hasLifeSupport) balanceScore += 8;
  if (hasScience) balanceScore += 7;
  if (hasMedical) balanceScore += 7;
  if (hasLeadership) balanceScore += 5;
  balanceScore = Math.min(100, balanceScore);

  let title = 'Balanced Scientific Expedition';
  let description = 'Your crew has a robust mix of scientific and operational capabilities.';

  if (hasEngineer && hasLifeSupport && hasMedical && hasScience) {
    title = 'Apex Multi-Disciplinary Expedition';
    description = 'Complete functional coverage across engineering, life-support, health, and lunar science.';
  } else if (!hasMedical) {
    title = 'High-Risk Engineering & Science Focus';
    description = 'Strong technical expertise, but lacking dedicated medical diagnostics.';
  } else if (!hasEngineer) {
    title = 'Research & Field Operations Team';
    description = 'Exceptional discovery and exploration potential; maintain outpost modules diligently.';
  }

  return { title, description, perks, balanceScore };
}
