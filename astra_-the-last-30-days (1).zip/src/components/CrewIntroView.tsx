/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  ArrowRight,
  Shield,
  Heart,
  Sparkles,
  Volume2,
  CheckCircle2,
  RotateCcw,
  Users,
  Grid,
  Info,
  Award,
  ChevronRight,
  Eye,
  Edit3,
} from 'lucide-react';
import { CrewMember, DifficultyLevel } from '../types/mission';
import {
  ASTRONAUT_ROSTER,
  AstronautCharacter,
  convertCharacterToCrewMember,
  evaluateCrewSynergy,
} from '../data/astronautRoster';
import { AstronautCardFrame } from './AstronautCardFrame';
import { AstronautBioModal } from './AstronautBioModal';
import { CrewPreviewModal } from './CrewPreviewModal';
import { soundEngine } from '../services/soundEngine';

interface CrewIntroViewProps {
  crew: CrewMember[];
  initialCrewName?: string;
  selectedDifficulty?: DifficultyLevel;
  onChangeDifficulty?: (diff: DifficultyLevel) => void;
  onProceedToTutorial: () => void;
  onDeployToOutpost: (customizedCrew?: CrewMember[], crewName?: string) => void;
  onBackToLanding?: () => void;
  isStepMode?: boolean;
  onNextToRocket?: (customizedCrew: CrewMember[], crewName: string) => void;
}

const DEFAULT_SQUAD_IDS = ['sofia-okafor', 'ethan-park', 'ava-patel', 'arjun-mehta'];

export const CrewIntroView: React.FC<CrewIntroViewProps> = ({
  crew,
  initialCrewName,
  selectedDifficulty = 'commander',
  onChangeDifficulty,
  onProceedToTutorial,
  onDeployToOutpost,
  onBackToLanding,
  isStepMode = false,
  onNextToRocket,
}) => {
  // Restore existing crew picks from mission state (so Back from Step 2 keeps selections)
  const [selectedCharacterIds, setSelectedCharacterIds] = useState<string[]>(() => {
    const validIds = (crew || [])
      .map((member) => {
        const match = ASTRONAUT_ROSTER.find(
          (r) => r.id === member.id || r.name === member.name || r.callsign === member.callsign
        );
        return match?.id;
      })
      .filter((id): id is string => Boolean(id));
    return validIds.length === 4 ? validIds : DEFAULT_SQUAD_IDS;
  });

  const [activeTab, setActiveTab] = useState<'board' | 'roster'>('board');
  const [activeBioCharacter, setActiveBioCharacter] = useState<AstronautCharacter | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [activeSpeech, setActiveSpeech] = useState<{ name: string; text: string } | null>({
    name: 'Dr. Prisha Mishra',
    text: 'If life can find a way to grow here, we may discover something extraordinary.',
  });
  const [crewName, setCrewName] = useState<string>(initialCrewName || 'Astra Vanguard');
  const [isEditingCrewName, setIsEditingCrewName] = useState(false);
  const [genderFilter, setGenderFilter] = useState<'all' | 'male' | 'female'>('all');

  // Selected characters objects
  const selectedCharacters = useMemo(() => {
    return selectedCharacterIds
      .map((id) => ASTRONAUT_ROSTER.find((c) => c.id === id))
      .filter((c): c is AstronautCharacter => !!c);
  }, [selectedCharacterIds]);

  // Crew synergy calculation
  const synergy = useMemo(() => {
    return evaluateCrewSynergy(selectedCharacters);
  }, [selectedCharacters]);

  // Handle select / deselect toggle
  const handleToggleSelect = (character: AstronautCharacter) => {
    setSelectedCharacterIds((prev) => {
      if (prev.includes(character.id)) {
        // Deselect
        soundEngine.playTelemetryClick();
        return prev.filter((id) => id !== character.id);
      } else {
        // Select if under 4
        if (prev.length < 4) {
          soundEngine.playConfirm();
          setActiveSpeech({ name: character.name, text: character.characterIntro });
          return [...prev, character.id];
        } else {
          soundEngine.playWarning();
          return prev;
        }
      }
    });
  };

  const handlePlayQuote = (character: AstronautCharacter) => {
    soundEngine.playTelemetryClick();
    setActiveSpeech({
      name: character.name,
      text: character.quotes[Math.floor(Math.random() * character.quotes.length)] || character.characterIntro,
    });
  };

  // Deploy / Next Step handler converting selected characters to CrewMember[]
  const handleConfirmDeploy = () => {
    if (selectedCharacters.length !== 4) {
      soundEngine.playWarning();
      return;
    }
    soundEngine.playConfirm();
    const finalCrew = selectedCharacters.map(convertCharacterToCrewMember);
    if (isStepMode && onNextToRocket) {
      onNextToRocket(finalCrew, crewName);
    } else {
      onDeployToOutpost(finalCrew, crewName);
    }
  };

  // Filtered roster for 10 candidates view
  const filteredRoster = useMemo(() => {
    if (genderFilter === 'all') return ASTRONAUT_ROSTER;
    return ASTRONAUT_ROSTER.filter((c) => c.gender === genderFilter);
  }, [genderFilter]);

  const canSelectMore = selectedCharacterIds.length < 4;

  return (
    <div className="relative w-full max-w-7xl mx-auto p-3 sm:p-6 lg:p-8 select-none animate-fade-in z-10 space-y-6">
      {/* 1. TOP COMMAND HEADER */}
      <div className="bg-[#121a3e]/95 backdrop-blur-md border border-indigo-400/40 rounded-3xl p-5 sm:p-6 shadow-2xl shadow-indigo-950/50 flex flex-col lg:flex-row lg:items-end justify-between gap-5">
        <div>
          {isStepMode && (
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-cyan-500/20 border border-cyan-400/50 text-[11px] font-mono font-extrabold text-cyan-300 mb-2">
              <Users className="w-3.5 h-3.5" />
              <span>STEP 1 OF 3 &bull; MARE TRANQUILLITATIS</span>
            </div>
          )}
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex flex-wrap items-center gap-3">
            <span>Pick 4 Astronauts</span>
            <span
              className={`text-xs sm:text-sm font-mono font-bold px-3 py-1 rounded-xl border ${
                selectedCharacterIds.length === 4
                  ? 'bg-emerald-500/20 border-emerald-400/60 text-emerald-300'
                  : 'bg-amber-500/20 border-amber-400/60 text-amber-300'
              }`}
            >
              {selectedCharacterIds.length === 4 ? '4/4 Ready' : `${selectedCharacterIds.length}/4 Picked`}
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-indigo-200 mt-1">
            Each hero boosts oxygen, water, food, or repairs.
          </p>

          {/* Crew Name + Difficulty Mode Picker */}
          <div className="mt-3.5 flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-indigo-300 uppercase tracking-wide">Team Name:</span>
              {isEditingCrewName ? (
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    value={crewName}
                    onChange={(e) => setCrewName(e.target.value)}
                    maxLength={24}
                    className="px-3 py-1 rounded-lg bg-[#0b1026] border border-cyan-400 text-xs font-bold text-cyan-200 focus:outline-none"
                    autoFocus
                  />
                  <button
                    onClick={() => setIsEditingCrewName(false)}
                    className="px-3 py-1 rounded-lg bg-gradient-to-r from-cyan-400 to-emerald-400 hover:brightness-110 text-slate-950 text-xs font-bold cursor-pointer"
                  >
                    Save
                  </button>
                </div>
              ) : (
                <div
                  onClick={() => setIsEditingCrewName(true)}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-[#0b1026]/80 border border-indigo-400/40 hover:border-cyan-400 text-xs font-bold text-cyan-300 cursor-pointer group transition-colors"
                  title="Click to rename your crew"
                >
                  <span>{crewName}</span>
                  <Edit3 className="w-3 h-3 text-indigo-300 group-hover:text-cyan-300" />
                </div>
              )}
            </div>

            {!isStepMode && onChangeDifficulty && (
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-indigo-300 uppercase tracking-wide">Mode:</span>
                {([
                  { id: 'beginner', label: 'Easy' },
                  { id: 'commander', label: 'Normal' },
                  { id: 'expert', label: 'Hard' },
                ] as const).map((lvl) => (
                  <button
                    key={lvl.id}
                    type="button"
                    onClick={() => {
                      soundEngine.playTelemetryClick();
                      onChangeDifficulty(lvl.id);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      selectedDifficulty === lvl.id
                        ? lvl.id === 'beginner'
                          ? 'bg-emerald-400 text-slate-950 shadow'
                          : lvl.id === 'commander'
                          ? 'bg-cyan-400 text-slate-950 shadow'
                          : 'bg-amber-400 text-slate-950 shadow'
                        : 'bg-[#0b1026]/80 border border-indigo-400/30 text-indigo-200 hover:text-white'
                    }`}
                  >
                    {lvl.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Action Controls & Navigation */}
        <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2 sm:gap-2.5 shrink-0 w-full lg:w-auto">
          {onBackToLanding && (
            <button
              onClick={onBackToLanding}
              className="px-3 py-2.5 rounded-xl border border-indigo-400/30 bg-[#0b1026]/80 hover:bg-indigo-900/60 text-xs font-semibold text-indigo-200 hover:text-white transition-colors cursor-pointer text-center"
            >
              Back
            </button>
          )}

          <button
            onClick={() => {
              soundEngine.playTelemetryClick();
              setIsPreviewOpen(true);
            }}
            disabled={selectedCharacterIds.length !== 4}
            className={`flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl border text-xs font-bold transition-colors cursor-pointer ${
              selectedCharacterIds.length === 4
                ? 'border-cyan-400/50 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200'
                : 'border-indigo-500/20 bg-[#0b1026] text-slate-500 opacity-50 cursor-not-allowed'
            }`}
          >
            <Eye className="w-3.5 h-3.5 text-cyan-300" />
            <span>Meet Squad</span>
          </button>

          {!isStepMode && (
            <button
              onClick={onProceedToTutorial}
              className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl border border-violet-400/40 bg-violet-500/20 hover:bg-violet-500/30 text-xs font-bold text-violet-200 transition-colors cursor-pointer col-span-2 sm:col-span-1"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>How It Works</span>
            </button>
          )}

          <button
            onClick={handleConfirmDeploy}
            disabled={selectedCharacterIds.length !== 4}
            className={`col-span-2 sm:col-span-1 flex items-center justify-center gap-2 px-5 py-3 sm:py-2.5 rounded-xl font-extrabold text-xs sm:text-sm shadow-xl transition-all cursor-pointer ${
              selectedCharacterIds.length === 4
                ? 'bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400 hover:brightness-110 text-slate-950 shadow-cyan-500/30 hover:-translate-y-0.5'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-50'
            }`}
          >
            <span>{isStepMode ? 'Next: Choose Rocket' : 'Launch to Moon (Day 1)'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. COMMS SPEECH BANNER */}
      {activeSpeech && (
        <div className="bg-[#121a3e]/90 border border-cyan-400/40 rounded-2xl p-3.5 sm:px-5 flex items-center justify-between gap-4 shadow-lg animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center shrink-0">
              <Volume2 className="w-4 h-4 text-cyan-300" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-300 block">
                {activeSpeech.name} &bull; Squad Voice Message
              </span>
              <p className="text-xs sm:text-sm text-indigo-100 italic">
                "{activeSpeech.text}"
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveSpeech(null)}
            className="text-xs text-indigo-300 hover:text-white font-semibold shrink-0 cursor-pointer"
          >
            Hide
          </button>
        </div>
      )}

      {/* 3. VIEW MODE TABS & ROSTER FILTERS */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-indigo-500/30 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              soundEngine.playTelemetryClick();
              setActiveTab('board');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
              activeTab === 'board'
                ? 'bg-gradient-to-r from-amber-400 to-orange-400 text-slate-950 shadow-md shadow-amber-500/30'
                : 'bg-[#121a3e] hover:bg-indigo-900/70 border border-indigo-400/30 text-indigo-200'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Your 4-Astronaut Squad</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playTelemetryClick();
              setActiveTab('roster');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
              activeTab === 'roster'
                ? 'bg-gradient-to-r from-cyan-400 to-sky-400 text-slate-950 shadow-md shadow-cyan-500/30'
                : 'bg-[#121a3e] hover:bg-indigo-900/70 border border-indigo-400/30 text-indigo-200'
            }`}
          >
            <Grid className="w-4 h-4" />
            <span>All 10 Astronauts</span>
          </button>
        </div>

        {/* Gender Filter (Active in 10 Roster Mode) */}
        {activeTab === 'roster' && (
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-indigo-300 font-semibold mr-1">Filter:</span>
            {(['all', 'male', 'female'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => {
                  soundEngine.playTelemetryClick();
                  setGenderFilter(filter);
                }}
                className={`px-3 py-1 rounded-lg uppercase font-bold tracking-wider transition-colors cursor-pointer ${
                  genderFilter === filter
                    ? 'bg-cyan-500/25 border border-cyan-400 text-cyan-200'
                    : 'bg-[#121a3e] border border-indigo-500/30 text-indigo-300 hover:text-white'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 4. MAIN CONTENT DISPLAY */}
      {activeTab === 'board' ? (
        /* The 4 Lives on the Board */
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {selectedCharacters.map((character, index) => (
              <AstronautCardFrame
                key={character.id}
                character={character}
                slotIndex={index}
                isSelected={true}
                canSelect={true}
                onToggleSelect={handleToggleSelect}
                onOpenBio={(c) => setActiveBioCharacter(c)}
                onPlayQuote={handlePlayQuote}
                onSwap={() => {
                  soundEngine.playTelemetryClick();
                  setActiveTab('roster');
                }}
              />
            ))}

            {/* If fewer than 4 selected, show empty slot placeholders */}
            {Array.from({ length: 4 - selectedCharacters.length }).map((_, emptyIdx) => (
              <div
                key={`empty-${emptyIdx}`}
                onClick={() => setActiveTab('roster')}
                className="relative flex flex-col items-center justify-center border-2 border-dashed border-indigo-400/40 hover:border-cyan-400 bg-[#121a3e]/50 rounded-2xl min-h-[180px] sm:min-h-[460px] p-5 sm:p-6 text-center cursor-pointer group transition-colors select-none"
              >
                <div className="w-16 h-16 rounded-full border border-indigo-400/50 group-hover:border-cyan-400 flex items-center justify-center text-indigo-300 group-hover:text-cyan-300 mb-3 transition-colors bg-indigo-500/10">
                  <Users className="w-8 h-8" />
                </div>
                <h4 className="font-display text-base font-bold text-indigo-200 group-hover:text-white">
                  Slot #{selectedCharacters.length + emptyIdx + 1} Open
                </h4>
                <p className="text-xs text-indigo-300/80 mt-1 max-w-[190px]">
                  Click here to pick another astronaut for your team!
                </p>
                <span className="mt-4 px-4 py-1.5 rounded-xl bg-cyan-500/20 border border-cyan-400/50 text-cyan-200 text-xs font-bold group-hover:bg-cyan-500/30 transition-colors">
                  Pick Astronaut
                </span>
              </div>
            ))}
          </div>

          {/* Crew Balance & Synergy Telemetry Bar */}
          <div className="bg-[#121a3e]/95 border border-emerald-400/40 rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-4 shadow-lg">
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <Shield className="w-4 h-4 text-emerald-400" />
                <h3 className="font-display font-bold text-white text-sm sm:text-base">
                  Team Power: {synergy.title}
                </h3>
                <span className="px-2.5 py-0.5 rounded-lg bg-emerald-500/20 border border-emerald-400/50 text-emerald-300 text-xs font-mono font-bold">
                  {synergy.balanceScore}% Team Balance
                </span>
              </div>
              <p className="text-xs text-indigo-200 max-w-2xl">
                {synergy.description}
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              {synergy.perks.map((perk, i) => (
                <div
                  key={i}
                  className="px-3 py-1 rounded-xl bg-cyan-500/15 border border-cyan-400/40 text-[11px] font-bold text-cyan-200"
                >
                  {perk}
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* Full 10 Astronaut Roster Grid */
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-indigo-200 px-1">
            <span>Tap an astronaut card’s SELECT button to add or swap them (max 4 astronauts).</span>
            <span className="font-mono text-cyan-300 font-bold">
              {selectedCharacterIds.length}/4 SQUAD SLOTS FILLED
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {filteredRoster.map((character) => {
              const isSelected = selectedCharacterIds.includes(character.id);
              return (
                <AstronautCardFrame
                  key={character.id}
                  character={character}
                  isSelected={isSelected}
                  canSelect={canSelectMore}
                  onToggleSelect={handleToggleSelect}
                  onOpenBio={(c) => setActiveBioCharacter(c)}
                  onPlayQuote={handlePlayQuote}
                />
              );
            })}
          </div>
        </div>
      )}

      {/* 5. ASTRONAUT BIO DOSSIER MODAL */}
      <AstronautBioModal
        character={activeBioCharacter}
        isSelected={activeBioCharacter ? selectedCharacterIds.includes(activeBioCharacter.id) : false}
        canSelect={canSelectMore}
        onToggleSelect={handleToggleSelect}
        onClose={() => setActiveBioCharacter(null)}
        onPlayQuote={handlePlayQuote}
      />

      {/* 6. MEET YOUR CREW PREVIEW MODAL */}
      {isPreviewOpen && (
        <CrewPreviewModal
          selectedCrew={selectedCharacters}
          crewName={crewName}
          onConfirmAndDeploy={() => {
            setIsPreviewOpen(false);
            handleConfirmDeploy();
          }}
          onClose={() => setIsPreviewOpen(false)}
        />
      )}
    </div>
  );
};
