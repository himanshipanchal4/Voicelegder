/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { EmergencyIncident, EmergencyOption } from '../types/mission';
import { ShieldAlert, CheckCircle2, ChevronDown, ChevronUp, ShieldCheck, X } from 'lucide-react';
import { soundEngine } from '../services/soundEngine';

interface EmergencyModalProps {
  emergency: EmergencyIncident;
  isOpen: boolean;
  onResolve: (option: EmergencyOption) => void;
  onClose: () => void;
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({
  emergency,
  isOpen,
  onResolve,
  onClose,
}) => {
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [showScience, setShowScience] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setSelectedOptionId(null);
      setShowScience(false);
    }
  }, [isOpen, emergency.id]);

  if (!isOpen) return null;

  const selectedOption = emergency.options.find((o) => o.id === selectedOptionId);

  const handleExecute = () => {
    if (selectedOption) {
      onResolve(selectedOption);
      setSelectedOptionId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-[#060919]/85 backdrop-blur-md select-none animate-fade-in">
      <div className="bg-[#121a3e] border border-rose-400/70 rounded-3xl max-w-xl w-full p-4 sm:p-7 shadow-2xl shadow-rose-950/60 relative max-h-[90dvh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-indigo-300 hover:text-white rounded-xl hover:bg-indigo-900/60 transition-colors cursor-pointer"
          title="Close for now"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Alert */}
        <div className="flex items-center gap-3 mb-4 pr-8">
          <div className="w-11 h-11 rounded-2xl bg-rose-500/20 border border-rose-400/60 flex items-center justify-center text-rose-300 shrink-0">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase text-rose-300 tracking-wider">
              BASE ALERT &bull; PICK A FIX
            </div>
            <h2 className="font-display text-lg sm:text-xl font-extrabold text-white">{emergency.title}</h2>
          </div>
        </div>

        {/* Short Situation Briefing */}
        <p className="p-4 rounded-2xl bg-rose-500/15 border border-rose-400/40 text-sm text-rose-100 leading-relaxed mb-3">
          {emergency.briefing}
        </p>

        {/* Collapsible Science Background */}
        <div className="mb-5">
          <button
            onClick={() => setShowScience(!showScience)}
            className="text-xs font-bold text-cyan-300 hover:text-cyan-200 flex items-center gap-1 cursor-pointer"
          >
            <span>Why does this happen? (NASA Science)</span>
            {showScience ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          {showScience && (
            <div className="mt-2 p-3 rounded-xl bg-[#0b1026]/85 border border-indigo-500/35 text-xs text-indigo-100 leading-relaxed">
              {emergency.scientificContext}
            </div>
          )}
        </div>

        {/* 1-Step Response Options */}
        <div className="space-y-2.5 mb-5">
          <div className="text-xs font-bold uppercase text-indigo-300 tracking-wide">
            Pick a quick fix:
          </div>

          {emergency.options.map((opt) => {
            const isSelected = selectedOptionId === opt.id;
            return (
              <div
                key={opt.id}
                onClick={() => {
                  soundEngine.playTelemetryClick();
                  setSelectedOptionId(opt.id);
                }}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-rose-500/20 border-rose-400 shadow-lg shadow-rose-500/20'
                    : 'bg-[#0b1026]/80 border-indigo-500/30 hover:border-indigo-400/60'
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="font-bold text-sm text-white">{opt.label}</div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg border whitespace-nowrap ${
                        opt.riskLevel === 'Low'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/50'
                          : opt.riskLevel === 'Moderate'
                          ? 'bg-amber-500/20 text-amber-300 border-amber-400/50'
                          : 'bg-rose-500/20 text-rose-300 border-rose-400/50'
                      }`}
                    >
                      {opt.riskLevel} Risk &bull; {opt.successRatePercent}% Win Rate
                    </span>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-rose-300" />}
                  </div>
                </div>

                <p className="text-xs text-indigo-200 mt-1 leading-relaxed">{opt.description}</p>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-indigo-500/30">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-indigo-400/30 text-xs font-semibold text-indigo-200 hover:text-white cursor-pointer"
          >
            Back
          </button>

          <button
            disabled={!selectedOption}
            onClick={handleExecute}
            className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-rose-500 to-orange-500 hover:brightness-110 disabled:bg-slate-800 disabled:from-slate-800 disabled:to-slate-800 disabled:text-slate-500 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Run Fix Now</span>
          </button>
        </div>
      </div>
    </div>
  );
};
