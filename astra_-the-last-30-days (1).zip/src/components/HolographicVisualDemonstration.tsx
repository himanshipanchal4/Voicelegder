/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Droplet, Sun, Layers, Shield, Sparkles, Compass } from 'lucide-react';

interface HolographicVisualDemonstrationProps {
  category: 'water-ice' | 'solar-power' | 'eclss' | 'geology' | 'radiation' | 'navigation';
  isAnswered: boolean;
  isCorrect?: boolean;
}

export const HolographicVisualDemonstration: React.FC<HolographicVisualDemonstrationProps> = ({
  category,
  isAnswered,
  isCorrect,
}) => {
  return (
    <div className="relative w-full h-44 sm:h-48 rounded-xl bg-gradient-to-b from-[#031533]/80 via-[#041026]/85 to-[#020a18]/90 border border-cyan-500/40 overflow-hidden shadow-inner flex items-center justify-center select-none group">
      {/* Background Holographic Coordinate Grid */}
      <div
        className="absolute inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(6, 182, 212, 0.25) 1px, transparent 1px), linear-gradient(to bottom, rgba(6, 182, 212, 0.25) 1px, transparent 1px)',
          backgroundSize: '20px 20px',
        }}
      />

      {/* Holographic Scanning Line Overlay */}
      <div className="absolute inset-x-0 h-6 bg-gradient-to-b from-transparent via-cyan-400/25 to-transparent pointer-events-none animate-holo-scanline" />

      {/* Category-Specific Animated Demonstration */}
      {category === 'water-ice' && (
        <div className="relative w-full h-full flex flex-col items-center justify-between p-3">
          {/* Status Label */}
          <div className="w-full flex items-center justify-between text-[10px] font-mono text-cyan-400 z-10">
            <span className="flex items-center gap-1">
              <Droplet className="w-3 h-3 text-cyan-300" />
              <span>SHACKLETON CRATER COLD TRAP</span>
            </span>
            <span className="text-cyan-300 font-bold">TEMP: 40 K (-233°C)</span>
          </div>

          {/* SVG Diagram: Crater cross-section with grazing sunlight and deep shadowed floor */}
          <div className="relative w-full flex-1 flex items-center justify-center">
            <svg viewBox="0 0 320 110" className="w-full h-full max-h-32 drop-shadow-md">
              <defs>
                <linearGradient id="sunRayGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#fbbf24" stopOpacity="0.1" />
                </linearGradient>
                <radialGradient id="iceGlow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="#0891b2" stopOpacity="0" />
                </radialGradient>
              </defs>

              {/* Grazing Sunlight Rays skimming the polar rim */}
              <path d="M 0 15 L 140 18 L 135 24 L 0 20 Z" fill="url(#sunRayGrad)" className="animate-pulse" />
              <path d="M 0 24 L 140 27 L 135 32 L 0 28 Z" fill="url(#sunRayGrad)" className="animate-pulse" />
              <text x="10" y="12" fill="#fbbf24" fontSize="7" fontFamily="monospace">GRAZING SUNLIGHT (1.5° TILT)</text>

              {/* Crater Profile */}
              {/* Left rim high peak */}
              <path
                d="M 10 75 Q 70 30 130 22 Q 155 45 160 85 Q 185 85 200 85 Q 220 50 250 35 Q 290 60 310 80 L 310 110 L 10 110 Z"
                fill="#071224"
                stroke="#0e7490"
                strokeWidth="1.5"
              />

              {/* Illuminated Rim Marker */}
              <circle cx="130" cy="22" r="3" fill="#f59e0b" className="animate-ping" />
              <circle cx="130" cy="22" r="2" fill="#fde68a" />
              <text x="75" y="18" fill="#fde68a" fontSize="7" fontFamily="monospace">ILLUMINATED RIM</text>

              {/* Permanently Shadowed Region (Deep Basin) */}
              <path d="M 155 45 Q 160 85 200 85 L 210 50 Z" fill="#020612" opacity="0.9" />

              {/* Cryogenic Ice Crystal Deposits */}
              <circle cx="175" cy="82" r="16" fill="url(#iceGlow)" className="animate-pulse" />
              <path d="M 175 75 L 178 82 L 175 89 L 172 82 Z" fill="#67e8f9" />
              <path d="M 168 82 L 175 85 L 182 82 L 175 79 Z" fill="#a5f3fc" />
              <circle cx="190" cy="83" r="1.5" fill="#cffafe" />
              <circle cx="163" cy="83" r="1.5" fill="#cffafe" />

              <text x="145" y="102" fill="#38bdf8" fontSize="8" fontFamily="monospace" fontWeight="bold">
                PERMANENT SHADOW (WATER ICE)
              </text>
            </svg>
          </div>

          <div className="w-full text-center text-[10px] text-cyan-200/90 font-mono">
            {isAnswered
              ? isCorrect
                ? '✓ Volatile cold-trap verification confirmed: Subsurface ice strata stable.'
                : 'Note: Temperatures in perpetual darkness preserve ice for over 2 billion years.'
              : 'Sensors detect concentrated water molecules sheltered from solar sublimation.'}
          </div>
        </div>
      )}

      {category === 'solar-power' && (
        <div className="relative w-full h-full flex flex-col items-center justify-between p-3">
          <div className="w-full flex items-center justify-between text-[10px] font-mono text-amber-400 z-10">
            <span className="flex items-center gap-1">
              <Sun className="w-3 h-3 text-amber-300" />
              <span>PEAKS OF ETERNAL LIGHT &bull; POLAR ARRAYS</span>
            </span>
            <span className="text-amber-300 font-bold">FLUX: 1,361 W/m²</span>
          </div>

          {/* SVG Diagram: Solar Photons to Vertical Array */}
          <div className="relative w-full flex-1 flex items-center justify-center">
            <svg viewBox="0 0 320 110" className="w-full h-full max-h-32 drop-shadow-md">
              <defs>
                <linearGradient id="solarStream" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="#22d3ee" stopOpacity="0.8" />
                </linearGradient>
              </defs>

              {/* Sun disk on left edge */}
              <circle cx="20" cy="50" r="14" fill="#fbbf24" filter="drop-shadow(0 0 8px #f59e0b)" />
              <circle cx="20" cy="50" r="8" fill="#fef08a" />

              {/* Horizontal photon streams */}
              {[35, 45, 55, 65].map((y, i) => (
                <g key={i}>
                  <line
                    x1="40"
                    y1={y}
                    x2="180"
                    y2={y}
                    stroke="url(#solarStream)"
                    strokeWidth="1.5"
                    strokeDasharray="6 4"
                    className="animate-pulse"
                  />
                  <polygon points={`180,${y} 174,${y - 2.5} 174,${y + 2.5}`} fill="#f59e0b" />
                </g>
              ))}

              {/* Vertical Polar Solar Tower */}
              <rect x="185" y="20" width="8" height="70" fill="#1e293b" stroke="#38bdf8" strokeWidth="1" />
              {/* Solar cell facets */}
              {[25, 37, 49, 61, 73].map((y, i) => (
                <rect key={i} x="186" y={y} width="6" height="8" fill="#0284c7" />
              ))}
              {/* Gimbal tracking head */}
              <circle cx="189" cy="18" r="4" fill="#38bdf8" className="animate-pulse" />

              {/* Power transmission bus line to Outpost */}
              <path d="M 189 90 L 189 98 L 260 98" fill="none" stroke="#22d3ee" strokeWidth="2" strokeDasharray="3 3" />

              {/* Habitat Battery Indicator */}
              <rect x="260" y="86" width="36" height="18" rx="3" fill="#0f172a" stroke="#22d3ee" strokeWidth="1.5" />
              <rect x="296" y="91" width="3" height="8" rx="1" fill="#22d3ee" />
              <rect x="263" y="89" width="28" height="12" rx="2" fill="#10b981" className="animate-pulse" />
              <text x="267" y="98" fill="#022c22" fontSize="7" fontFamily="monospace" fontWeight="bold">100%</text>

              <text x="160" y="14" fill="#38bdf8" fontSize="7" fontFamily="monospace">VERTICAL TOWER</text>
            </svg>
          </div>

          <div className="w-full text-center text-[10px] text-amber-200/90 font-mono">
            {isAnswered
              ? 'Vertical solar towers capture continuous horizontal grazing rays at polar heights.'
              : 'Near-permanent sunlight ensures uninterrupted power without 14-day night downtime.'}
          </div>
        </div>
      )}

      {category === 'eclss' && (
        <div className="relative w-full h-full flex flex-col items-center justify-between p-3">
          <div className="w-full flex items-center justify-between text-[10px] font-mono text-emerald-400 z-10">
            <span className="flex items-center gap-1">
              <Layers className="w-3 h-3 text-emerald-300" />
              <span>SABATIER & VACUUM DISTILLATION LOOP</span>
            </span>
            <span className="text-emerald-300 font-bold">RECOVERY: 98.4%</span>
          </div>

          {/* SVG Diagram: Closed-Loop Atmospheric & Water Cycle */}
          <div className="relative w-full flex-1 flex items-center justify-center">
            <svg viewBox="0 0 320 110" className="w-full h-full max-h-32 drop-shadow-md">
              {/* Circular Closed Loop Pipeline */}
              <circle cx="160" cy="55" r="34" fill="none" stroke="#065f46" strokeWidth="6" />
              <circle
                cx="160"
                cy="55"
                r="34"
                fill="none"
                stroke="#10b981"
                strokeWidth="2"
                strokeDasharray="12 6"
                className="animate-spin origin-center"
                style={{ animationDuration: '8s' }}
              />

              {/* Sabatier Catalytic Reactor Module */}
              <rect x="50" y="38" width="46" height="34" rx="4" fill="#064e3b" stroke="#34d399" strokeWidth="1.5" />
              <text x="56" y="52" fill="#a7f3d0" fontSize="7" fontFamily="monospace" fontWeight="bold">SABATIER</text>
              <text x="56" y="62" fill="#6ee7b7" fontSize="6" fontFamily="monospace">CO₂ + 4H₂</text>

              {/* Water Distillation Centrifuge Module */}
              <rect x="224" y="38" width="46" height="34" rx="4" fill="#0c4a6e" stroke="#38bdf8" strokeWidth="1.5" />
              <text x="232" y="52" fill="#bae6fd" fontSize="7" fontFamily="monospace" fontWeight="bold">VPD LOOP</text>
              <text x="232" y="62" fill="#7dd3fc" fontSize="6" fontFamily="monospace">H₂O VAPOR</text>

              {/* Inflow Arrow */}
              <path d="M 96 55 L 126 55" stroke="#34d399" strokeWidth="2" strokeDasharray="3 3" />
              {/* Outflow Arrow */}
              <path d="M 194 55 L 224 55" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3 3" />

              {/* Central Oxygen Recovery Core */}
              <circle cx="160" cy="55" r="14" fill="#042f2e" stroke="#2dd4bf" strokeWidth="1.5" />
              <text x="154" y="58" fill="#5eead4" fontSize="9" fontFamily="monospace" fontWeight="bold">O₂</text>

              <text x="125" y="16" fill="#a7f3d0" fontSize="8" fontFamily="monospace">CLOSED LOOP RECYCLING</text>
            </svg>
          </div>

          <div className="w-full text-center text-[10px] text-emerald-200/90 font-mono">
            {isAnswered
              ? 'Catalytic Sabatier chemistry converts exhaled CO2 into pure water and breathable O2.'
              : 'Every breath and drop of moisture is reclaimed to eliminate supply reliance on Earth.'}
          </div>
        </div>
      )}

      {category === 'geology' && (
        <div className="relative w-full h-full flex flex-col items-center justify-between p-3">
          <div className="w-full flex items-center justify-between text-[10px] font-mono text-cyan-300 z-10">
            <span className="flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-cyan-200" />
              <span>REGOLITH SINTERING & MINERAL MATRIX</span>
            </span>
            <span className="text-cyan-300 font-bold">2.45 GHz MICROWAVE</span>
          </div>

          {/* SVG Diagram: Microwave Sintering Grains */}
          <div className="relative w-full flex-1 flex items-center justify-center">
            <svg viewBox="0 0 320 110" className="w-full h-full max-h-32 drop-shadow-md">
              {/* Microwave Emitter Horn */}
              <polygon points="135,15 185,15 175,35 145,35" fill="#334155" stroke="#38bdf8" strokeWidth="1.5" />
              <text x="142" y="27" fill="#bae6fd" fontSize="7" fontFamily="monospace">EMITTER</text>

              {/* Microwave Energy Cones */}
              <path d="M 145 35 L 110 75 L 210 75 L 175 35 Z" fill="rgba(6, 182, 212, 0.15)" />
              <path d="M 150 35 L 130 75" stroke="#22d3ee" strokeWidth="1" strokeDasharray="3 3" className="animate-pulse" />
              <path d="M 170 35 L 190 75" stroke="#22d3ee" strokeWidth="1" strokeDasharray="3 3" className="animate-pulse" />

              {/* Raw Regolith Powder (Uncompacted) */}
              <rect x="40" y="75" width="70" height="25" fill="#1e293b" />
              <circle cx="55" cy="85" r="2" fill="#64748b" />
              <circle cx="75" cy="88" r="2.5" fill="#475569" />
              <circle cx="90" cy="82" r="1.5" fill="#94a3b8" />
              <text x="45" y="70" fill="#94a3b8" fontSize="7" fontFamily="monospace">RAW DUST</text>

              {/* Sintered Solid Structural Paver (Fused Ceramic Tile) */}
              <rect x="115" y="75" width="90" height="25" rx="2" fill="#0891b2" stroke="#22d3ee" strokeWidth="1.5" />
              <line x1="145" y1="75" x2="145" y2="100" stroke="#0e7490" strokeWidth="1" />
              <line x1="175" y1="75" x2="175" y2="100" stroke="#0e7490" strokeWidth="1" />
              <text x="122" y="90" fill="#ecfeff" fontSize="8" fontFamily="monospace" fontWeight="bold">SINTERED TILE</text>

              {/* Unprocessed bedrock on right */}
              <rect x="210" y="75" width="70" height="25" fill="#1e293b" />
            </svg>
          </div>

          <div className="w-full text-center text-[10px] text-cyan-200/90 font-mono">
            {isAnswered
              ? 'Microwaves fuse nanophase iron in lunar regolith into rock-solid structural tiles.'
              : 'Local lunar minerals provide foundation pavers, radiation shields, and landing pads.'}
          </div>
        </div>
      )}

      {category === 'radiation' && (
        <div className="relative w-full h-full flex flex-col items-center justify-between p-3">
          <div className="w-full flex items-center justify-between text-[10px] font-mono text-violet-400 z-10">
            <span className="flex items-center gap-1">
              <Shield className="w-3 h-3 text-violet-300" />
              <span>SUPERCONDUCTING DEFLECTION & REGOLITH BERM</span>
            </span>
            <span className="text-violet-300 font-bold">ATTENUATION: 99.2%</span>
          </div>

          {/* SVG Diagram: Incoming Proton Streams Deflected by Magnetic Arc */}
          <div className="relative w-full flex-1 flex items-center justify-center">
            <svg viewBox="0 0 320 110" className="w-full h-full max-h-32 drop-shadow-md">
              <defs>
                <linearGradient id="protonTrail" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#f43f5e" />
                  <stop offset="100%" stopColor="#fb7185" stopOpacity="0" />
                </linearGradient>
              </defs>

              {/* Incoming Solar Particle Event Particles (Deflected upwards) */}
              <path d="M 20 30 Q 140 30 160 10" fill="none" stroke="#f43f5e" strokeWidth="2" strokeDasharray="4 2" />
              <path d="M 20 50 Q 130 50 150 15" fill="none" stroke="#f43f5e" strokeWidth="2" strokeDasharray="4 2" />
              <path d="M 20 70 Q 130 70 150 105" fill="none" stroke="#f43f5e" strokeWidth="2" strokeDasharray="4 2" />
              <text x="25" y="24" fill="#fda4af" fontSize="7" fontFamily="monospace">SOLAR PROTON EVENT</text>

              {/* Active Superconducting Magnetic Shield Lorentz Arc */}
              <path d="M 140 10 Q 120 55 140 100" fill="none" stroke="#a855f7" strokeWidth="3" className="animate-pulse" />
              <path d="M 146 15 Q 128 55 146 95" fill="none" stroke="#c084fc" strokeWidth="1.5" />

              {/* Compacted 2.5m Regolith Protective Berm */}
              <path d="M 180 30 L 210 30 L 225 90 L 165 90 Z" fill="#3b2b4d" stroke="#8b5cf6" strokeWidth="1" />
              <text x="175" y="65" fill="#e9d5ff" fontSize="7" fontFamily="monospace">2.5m BERM</text>

              {/* Pressurized Habitat Safe Haven Inside */}
              <ellipse cx="250" cy="65" rx="22" ry="16" fill="#0f172a" stroke="#22d3ee" strokeWidth="1.5" />
              <text x="238" y="67" fill="#67e8f9" fontSize="8" fontFamily="monospace" fontWeight="bold">HAB</text>
            </svg>
          </div>

          <div className="w-full text-center text-[10px] text-violet-200/90 font-mono">
            {isAnswered
              ? 'Multi-meter regolith overburden and Lorentz coils stop ionizing cosmic rays.'
              : 'Crew radiation dose within the shielded habitat remains at safe terrestrial baselines.'}
          </div>
        </div>
      )}

      {category === 'navigation' && (
        <div className="relative w-full h-full flex flex-col items-center justify-between p-3">
          <div className="w-full flex items-center justify-between text-[10px] font-mono text-sky-400 z-10">
            <span className="flex items-center gap-1">
              <Compass className="w-3 h-3 text-sky-300" />
              <span>DEEP SPACE OPTICAL LASER LINK (DSOC)</span>
            </span>
            <span className="text-sky-300 font-bold">RATE: 267 Mbps</span>
          </div>

          {/* SVG Diagram: Earth to Lunar Outpost Laser Beam */}
          <div className="relative w-full flex-1 flex items-center justify-center">
            <svg viewBox="0 0 320 110" className="w-full h-full max-h-32 drop-shadow-md">
              {/* Earth Sphere on left */}
              <circle cx="35" cy="55" r="20" fill="#1e3a8a" stroke="#60a5fa" strokeWidth="1.5" />
              <circle cx="30" cy="50" r="10" fill="#10b981" opacity="0.8" />
              <text x="22" y="87" fill="#93c5fd" fontSize="7" fontFamily="monospace">EARTH</text>

              {/* High-speed Optical Laser Pulse (1550 nm infrared) */}
              <line x1="55" y1="55" x2="250" y2="55" stroke="#0284c7" strokeWidth="3" opacity="0.4" />
              <line
                x1="55"
                y1="55"
                x2="250"
                y2="55"
                stroke="#38bdf8"
                strokeWidth="1.5"
                strokeDasharray="16 8"
                className="animate-pulse"
              />

              {/* Gateway NRHO Relay Station in the middle */}
              <circle cx="150" cy="35" r="4" fill="#38bdf8" className="animate-ping" />
              <circle cx="150" cy="35" r="3" fill="#ffffff" />
              <text x="135" y="25" fill="#7dd3fc" fontSize="7" fontFamily="monospace">GATEWAY</text>

              {/* Lunar Base Transceiver Telescope on right */}
              <polygon points="255,45 270,55 255,65" fill="#0369a1" stroke="#38bdf8" strokeWidth="1" />
              <rect x="270" y="50" width="10" height="10" fill="#0f172a" stroke="#38bdf8" />
              <text x="250" y="78" fill="#bae6fd" fontSize="7" fontFamily="monospace">ASTRA OUTPOST</text>
            </svg>
          </div>

          <div className="w-full text-center text-[10px] text-sky-200/90 font-mono">
            {isAnswered
              ? 'Optical photon laser beams deliver broadband telemetry across 384,400 km in 1.3 seconds.'
              : 'Broadband optical links enable high-definition communications with mission control.'}
          </div>
        </div>
      )}
    </div>
  );
};
