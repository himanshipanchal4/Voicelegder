/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { NASA_DISCOVERIES, DiscoveryFact } from '../data/discoveriesData';
import { soundEngine } from '../services/soundEngine';
import { LUNAR_BADGES } from '../data/badgeData';
import { NasaAstronautLogo } from './NasaAstronautLogo';
import {
  Compass,
  X,
  Search,
  Award,
  Sparkles,
  Droplet,
  Sun,
  Layers,
  Shield,
  Lock,
  ExternalLink,
  ChevronRight,
  ChevronLeft,
  Filter,
  CheckCircle2,
  Sliders,
  Maximize2,
  Orbit,
  BookOpen,
  ArrowRight,
  Info,
} from 'lucide-react';

interface DiscoveryLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  unlockedDays: number[];
  onSelectDiscovery: (discovery: DiscoveryFact) => void;
}

export const DiscoveryLogModal: React.FC<DiscoveryLogModalProps> = ({
  isOpen,
  onClose,
  unlockedDays,
  onSelectDiscovery,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeInspectDiscovery, setActiveInspectDiscovery] = useState<DiscoveryFact | null>(null);

  // Interactive slider parameter inside Inspect Dossier view
  const [inspectParamValue, setInspectParamValue] = useState<number>(50);

  const unlockedSet = useMemo(() => new Set(unlockedDays), [unlockedDays]);

  // Categories with matching domain icons
  const categories = useMemo(() => [
    { id: 'all', label: 'All Fields', icon: Compass },
    { id: 'water-ice', label: 'Water Ice', icon: Droplet },
    { id: 'solar-power', label: 'Solar Power', icon: Sun },
    { id: 'eclss', label: 'ECLSS Life Support', icon: Layers },
    { id: 'geology', label: 'Lunar Geology', icon: Sparkles },
    { id: 'radiation', label: 'Radiation Physics', icon: Shield },
    { id: 'navigation', label: 'Navigation & Orbit', icon: Orbit },
  ], []);

  // Filter discoveries
  const filteredDiscoveries = useMemo(() => {
    return NASA_DISCOVERIES.filter((item) => {
      if (selectedCategory !== 'all' && item.category !== selectedCategory) {
        return false;
      }
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = item.factTitle.toLowerCase().includes(query);
        const matchesExplain = item.conciseExplanation.toLowerCase().includes(query);
        const matchesOrg = item.sourceOrg.toLowerCase().includes(query);
        const matchesDay = `day ${item.day}`.includes(query) || `${item.day}` === query;
        const matchesBadge = item.badge.title.toLowerCase().includes(query);
        return matchesTitle || matchesExplain || matchesOrg || matchesDay || matchesBadge;
      }
      return true;
    });
  }, [selectedCategory, searchQuery]);

  // Rarity classification helper
  const getRarityInfo = (day: number) => {
    if (day <= 8) {
      return {
        label: 'STANDARD ARCHIVE',
        tier: 'Standard',
        color: 'text-slate-300 border-slate-700 bg-slate-900/60',
        glow: 'border-slate-700',
      };
    } else if (day <= 16) {
      return {
        label: 'ADVANCED FINDING',
        tier: 'Advanced',
        color: 'text-cyan-300 border-cyan-700 bg-cyan-950/60',
        glow: 'border-cyan-500/50',
      };
    } else if (day <= 24) {
      return {
        label: 'RARE SPECIMEN',
        tier: 'Rare',
        color: 'text-purple-300 border-purple-700 bg-purple-950/60',
        glow: 'border-purple-500/50',
      };
    } else {
      return {
        label: 'MAJOR BREAKTHROUGH',
        tier: 'Breakthrough',
        color: 'text-amber-300 border-amber-600 bg-amber-950/60',
        glow: 'border-amber-500/60',
      };
    }
  };

  if (!isOpen) return null;

  const totalUnlocked = unlockedDays.length;
  const progressPercent = Math.round((totalUnlocked / 30) * 100);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-[#020409]/90 backdrop-blur-md select-none overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-slate-950/95 border border-cyan-500/40 rounded-2xl shadow-2xl overflow-hidden my-auto animate-fade-in flex flex-col max-h-[92vh]">
        {/* ============================================================ */}
        {/* 1. TOP HEADER & NASA SOURCE BADGE                            */}
        {/* ============================================================ */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between gap-4 bg-slate-900/40 shrink-0">
          <div className="flex items-center gap-3">
            <NasaAstronautLogo size={42} className="drop-shadow-[0_0_10px_rgba(234,179,8,0.35)]" />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-100 tracking-tight">
                  Personal Discovery Log
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800">
                  NASA SOURCES AVAILABLE
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Archived scientific findings, planetary geology notes, and mission badges.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <div className="text-[10px] font-mono text-slate-400">ARCHIVE CATALOG</div>
              <div className="text-xs font-mono font-bold text-cyan-300">
                {String(totalUnlocked).padStart(2, '0')} / 30 DISCOVERIES
              </div>
            </div>

            <button
              onClick={() => {
                soundEngine.playTelemetryClick();
                setActiveInspectDiscovery(null);
                onClose();
              }}
              className="p-2 rounded-lg border border-slate-800 hover:border-slate-700 bg-slate-900/80 text-slate-400 hover:text-slate-100 transition-colors cursor-pointer shrink-0"
              title="Close Log"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ============================================================ */}
        {/* 2. PROGRESS BAR & 5-DAY MILESTONE INSIGNIA TRACK             */}
        {/* ============================================================ */}
        <div className="p-4 border-b border-slate-800/80 bg-slate-950 space-y-3 shrink-0">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 font-mono">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span className="text-slate-200">
                SCIENTIFIC JOURNEY:{' '}
                <strong className="text-cyan-300 font-bold">
                  {String(totalUnlocked).padStart(2, '0')} / 30 DISCOVERIES
                </strong>{' '}
                ({progressPercent}%)
              </span>
            </div>
            <div className="flex items-center gap-3 text-[11px] font-mono text-slate-400">
              <span>
                Scientific Bonus Score:{' '}
                <strong className="text-amber-400">+{totalUnlocked * 50} Pts</strong>
              </span>
            </div>
          </div>

          {/* High-Tech Progress Bar Track with 5-Day Milestone Badges */}
          <div className="relative pt-1 pb-3">
            <div className="w-full h-2.5 rounded-full bg-slate-900 overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-amber-400 transition-all duration-500 rounded-full shadow-sm shadow-cyan-500/50"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            {/* 6 Milestone Nodes for Badges */}
            <div className="absolute inset-x-0 top-0 flex justify-between px-1 pointer-events-none">
              {[5, 10, 15, 20, 25, 30].map((day) => {
                const isPassed = totalUnlocked >= day;
                const badgeInfo = LUNAR_BADGES.find((b) => b.requiredDay === day);
                return (
                  <div key={day} className="flex flex-col items-center">
                    <div
                      className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center text-[7px] font-mono font-bold transition-all ${
                        isPassed
                          ? 'bg-amber-400 border-amber-300 text-slate-950 shadow-md shadow-amber-400/30'
                          : 'bg-slate-900 border-slate-700 text-slate-500'
                      }`}
                      title={badgeInfo?.title}
                    >
                      {isPassed ? '✓' : day}
                    </div>
                    <span
                      className={`text-[8px] font-mono mt-0.5 ${
                        isPassed ? 'text-amber-300' : 'text-slate-600'
                      }`}
                    >
                      D{day}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ============================================================ */}
          {/* 3. VISUAL CATEGORY TABS & SEARCH INPUT                      */}
          {/* ============================================================ */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2.5 pt-1">
            {/* Category Navigation Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-none text-[11px] font-mono">
              {categories.map((cat) => {
                const IconComponent = cat.icon;
                const countForCat =
                  cat.id === 'all'
                    ? totalUnlocked
                    : NASA_DISCOVERIES.filter(
                        (d) => d.category === cat.id && unlockedSet.has(d.day)
                      ).length;
                const totalForCat =
                  cat.id === 'all'
                    ? 30
                    : NASA_DISCOVERIES.filter((d) => d.category === cat.id).length;

                return (
                  <button
                    key={cat.id}
                    onClick={() => {
                      soundEngine.playTelemetryClick();
                      setSelectedCategory(cat.id);
                    }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border whitespace-nowrap transition-all cursor-pointer ${
                      selectedCategory === cat.id
                        ? 'bg-gradient-to-r from-cyan-500 to-sky-400 text-slate-950 font-bold border-cyan-300 shadow-md shadow-cyan-500/20'
                        : 'border-slate-800 bg-slate-900/60 text-slate-300 hover:text-slate-100 hover:bg-slate-800'
                    }`}
                  >
                    <IconComponent className="w-3.5 h-3.5" />
                    <span>{cat.label}</span>
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded font-mono ${
                        selectedCategory === cat.id
                          ? 'bg-slate-950/20 text-slate-950'
                          : 'bg-slate-950 text-slate-400 border border-slate-800'
                      }`}
                    >
                      {countForCat}/{totalForCat}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Search Input Bar */}
            <div className="relative w-full sm:w-60 shrink-0">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search discoveries, badges..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 bg-slate-900/90 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
              />
            </div>
          </div>
        </div>

        {/* ============================================================ */}
        {/* 4. MAIN CONTENT AREA: GALLERY VIEW OR INSPECT DOSSIER VIEW   */}
        {/* ============================================================ */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1">
          {/* DETAILED INSPECT DOSSIER VIEW */}
          {activeInspectDiscovery ? (
            <div className="space-y-5 animate-fade-in">
              {/* Back to Gallery Navigation Bar */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <button
                  onClick={() => {
                    soundEngine.playTelemetryClick();
                    setActiveInspectDiscovery(null);
                  }}
                  className="flex items-center gap-1.5 text-xs font-mono text-cyan-400 hover:text-cyan-300 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 transition-colors cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>BACK TO DISCOVERY GALLERY</span>
                </button>

                <div className="flex items-center gap-2">
                  <span
                    className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border ${
                      getRarityInfo(activeInspectDiscovery.day).color
                    }`}
                  >
                    {getRarityInfo(activeInspectDiscovery.day).label}
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    MISSION DAY {activeInspectDiscovery.day}
                  </span>
                </div>
              </div>

              {/* Dossier Top Banner */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-slate-900/90 via-slate-900/70 to-slate-950 border border-cyan-500/40 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-slate-950 border-2 border-cyan-400 flex items-center justify-center text-3xl shadow-lg shadow-cyan-500/20 shrink-0">
                    {activeInspectDiscovery.badge.icon}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-semibold">
                        {activeInspectDiscovery.category.replace('-', ' ')}
                      </span>
                      <span className="text-slate-600">•</span>
                      <span className="text-xs font-mono text-amber-300 flex items-center gap-1 font-bold">
                        <Award className="w-3.5 h-3.5 text-amber-400" />
                        {activeInspectDiscovery.badge.title}
                      </span>
                    </div>
                    <h3 className="text-base sm:text-xl font-bold text-slate-100">
                      {activeInspectDiscovery.factTitle}
                    </h3>
                    <p className="text-xs text-slate-400 font-mono">
                      {activeInspectDiscovery.sourceOrg} • {activeInspectDiscovery.sourceTitle}
                    </p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row md:flex-col gap-2 shrink-0">
                  <button
                    onClick={() => {
                      soundEngine.playConfirm();
                      onSelectDiscovery(activeInspectDiscovery);
                    }}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-400 hover:from-cyan-400 hover:to-sky-300 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>LAUNCH INTERACTIVE SIMULATION</span>
                  </button>

                  <a
                    href={activeInspectDiscovery.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-800 text-xs font-mono transition-colors"
                  >
                    <span>VERIFIED NASA SOURCE</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Interactive Scientific Diagram & Telemetry Parameter Slider */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/40 border border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-cyan-400" />
                    <span className="text-xs font-mono uppercase tracking-wider text-slate-300 font-bold">
                      INTERACTIVE SCIENTIFIC DEMONSTRATION & TELEMETRY
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800">
                    CALIBRATION VALUE: {inspectParamValue}%
                  </span>
                </div>

                {/* SVG Scientific Visual Demonstration */}
                <div className="relative w-full h-44 rounded-xl bg-gradient-to-b from-[#031533]/80 via-[#041026]/85 to-[#020a18]/90 border border-cyan-500/30 overflow-hidden flex items-center justify-center">
                  <div
                    className="absolute inset-0 opacity-20 pointer-events-none"
                    style={{
                      backgroundImage:
                        'linear-gradient(to right, rgba(6, 182, 212, 0.25) 1px, transparent 1px), linear-gradient(to bottom, rgba(6, 182, 212, 0.25) 1px, transparent 1px)',
                      backgroundSize: '20px 20px',
                    }}
                  />

                  {/* Dynamic Category SVG Graphics */}
                  {activeInspectDiscovery.category === 'water-ice' && (
                    <div className="relative w-full h-full flex flex-col items-center justify-center p-4">
                      <svg viewBox="0 0 340 100" className="w-full h-full">
                        <path
                          d="M10,80 Q90,30 140,25 Q170,55 175,85 Q200,85 220,85 Q240,55 270,35 Q310,65 330,80 L330,100 L10,100 Z"
                          fill="#071224"
                          stroke="#0e7490"
                          strokeWidth="1.5"
                        />
                        {/* Cold Trap Ice Reservoir */}
                        <ellipse
                          cx="195"
                          cy="83"
                          rx={25 + inspectParamValue * 0.2}
                          ry="6"
                          fill="#22d3ee"
                          opacity={0.4 + (inspectParamValue / 100) * 0.5}
                        />
                        <text x="165" y="86" fill="#f0fdf4" fontSize="8" fontFamily="monospace">
                          40 K CRYO-ICE
                        </text>
                        {/* Grazing Sunlight */}
                        <line x1="10" y1="20" x2="140" y2="25" stroke="#fbbf24" strokeWidth="2" strokeDasharray="4 2" />
                        <text x="20" y="15" fill="#fbbf24" fontSize="7" fontFamily="monospace">
                          GRAZING SUNLIGHT (1.5° TILT)
                        </text>
                      </svg>
                    </div>
                  )}

                  {activeInspectDiscovery.category === 'solar-power' && (
                    <div className="relative w-full h-full flex flex-col items-center justify-center p-4">
                      <svg viewBox="0 0 340 100" className="w-full h-full">
                        <line x1="50" y1="90" x2="310" y2="90" stroke="#334155" strokeWidth="2" />
                        {/* Bi-facial Solar Mast */}
                        <line x1="170" y1="90" x2="170" y2="20" stroke="#38bdf8" strokeWidth="3" />
                        <rect
                          x="155"
                          y="25"
                          width="30"
                          height="45"
                          rx="2"
                          fill="#0284c7"
                          stroke="#38bdf8"
                          strokeWidth="1.5"
                          transform={`rotate(${(inspectParamValue - 50) * 0.3} 170 47)`}
                        />
                        <text x="130" y="16" fill="#38bdf8" fontSize="8" fontFamily="monospace">
                          VERTICAL BI-FACIAL PV ARRAY
                        </text>
                        <line x1="20" y1="40" x2="155" y2="45" stroke="#fbbf24" strokeWidth="2" strokeDasharray="3 3" />
                        <text x="25" y="35" fill="#fbbf24" fontSize="7" fontFamily="monospace">
                          LOW-ELEVATION SUN
                        </text>
                      </svg>
                    </div>
                  )}

                  {activeInspectDiscovery.category === 'eclss' && (
                    <div className="relative w-full h-full flex flex-col items-center justify-center p-4">
                      <svg viewBox="0 0 340 100" className="w-full h-full">
                        {/* Closed loop circular nodes */}
                        <circle cx="100" cy="50" r="28" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />
                        <circle cx="240" cy="50" r="28" fill="#0f172a" stroke="#10b981" strokeWidth="2" />
                        <path d="M128,40 Q170,20 212,40" fill="none" stroke="#38bdf8" strokeWidth="2" strokeDasharray="4 2" />
                        <path d="M212,60 Q170,80 128,60" fill="none" stroke="#10b981" strokeWidth="2" strokeDasharray="4 2" />
                        <text x="80" y="48" fill="#38bdf8" fontSize="7" fontFamily="monospace">SABATIER</text>
                        <text x="75" y="58" fill="#cbd5e1" fontSize="6" fontFamily="monospace">CO2 + 4H2</text>
                        <text x="220" y="48" fill="#10b981" fontSize="7" fontFamily="monospace">VPD URINE</text>
                        <text x="222" y="58" fill="#cbd5e1" fontSize="6" fontFamily="monospace">H2O RECYC</text>
                      </svg>
                    </div>
                  )}

                  {activeInspectDiscovery.category === 'radiation' && (
                    <div className="relative w-full h-full flex flex-col items-center justify-center p-4">
                      <svg viewBox="0 0 340 100" className="w-full h-full">
                        {/* Regolith shield thickness based on slider */}
                        <rect x="120" y="20" width={10 + inspectParamValue * 0.8} height="60" fill="#475569" stroke="#94a3b8" strokeWidth="1.5" />
                        <text x="125" y="55" fill="#f8fafc" fontSize="7" fontFamily="monospace">REGOLITH SHIELD</text>
                        {/* Particle rays */}
                        <line x1="20" y1="35" x2="120" y2="35" stroke="#ef4444" strokeWidth="2" strokeDasharray="4 2" />
                        <line x1="20" y1="50" x2="120" y2="50" stroke="#f59e0b" strokeWidth="2" strokeDasharray="4 2" />
                        <line x1="20" y1="65" x2="120" y2="65" stroke="#ef4444" strokeWidth="2" strokeDasharray="4 2" />
                        <text x="25" y="28" fill="#ef4444" fontSize="7" fontFamily="monospace">COSMIC RADIATION</text>
                      </svg>
                    </div>
                  )}

                  {['geology', 'navigation'].includes(activeInspectDiscovery.category) && (
                    <div className="relative w-full h-full flex flex-col items-center justify-center p-4">
                      <svg viewBox="0 0 340 100" className="w-full h-full">
                        <circle cx="170" cy="50" r="32" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />
                        <ellipse cx="170" cy="50" rx="60" ry="16" fill="none" stroke="#0ea5e9" strokeWidth="1.2" strokeDasharray="4 2" />
                        <text x="145" y="53" fill="#38bdf8" fontSize="8" fontFamily="monospace">LUNAR MASCON</text>
                      </svg>
                    </div>
                  )}
                </div>

                {/* Slider Control Bar */}
                <div className="flex items-center gap-3 pt-1">
                  <span className="text-[10px] font-mono text-slate-400">MIN FLUX</span>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={inspectParamValue}
                    onChange={(e) => setInspectParamValue(Number(e.target.value))}
                    className="flex-1 accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                  />
                  <span className="text-[10px] font-mono text-slate-400">MAX DENSITY</span>
                </div>
              </div>

              {/* Deep Scientific Explanations Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Scientific Telemetry */}
                <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 space-y-2">
                  <div className="text-xs font-mono uppercase text-cyan-400 font-bold flex items-center gap-1.5">
                    <Info className="w-4 h-4 text-cyan-400" />
                    <span>SCIENTIFIC EXPLANATION</span>
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed">
                    {activeInspectDiscovery.conciseExplanation}
                  </p>
                </div>

                {/* Why It Matters */}
                <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 space-y-2">
                  <div className="text-xs font-mono uppercase text-amber-400 font-bold flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>WHY THIS MATTERS FOR SURVIVAL</span>
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed">
                    {activeInspectDiscovery.whyInteresting}
                  </p>
                </div>
              </div>

              {/* Commander Mentor Observation */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-blue-950/40 via-cyan-950/30 to-slate-950 border border-cyan-800/60 flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-700 flex items-center justify-center text-cyan-300 font-bold text-xs shrink-0">
                  NOVA
                </div>
                <div className="space-y-1">
                  <div className="text-[10px] font-mono uppercase text-cyan-400 font-semibold">
                    ASTRONAUT MENTOR FIELD NOTES
                  </div>
                  <p className="text-xs text-slate-200 italic leading-relaxed">
                    &ldquo;{activeInspectDiscovery.novaQuote}&rdquo;
                  </p>
                </div>
              </div>
            </div>
          ) : (
            /* COLLECTIBLE DISCOVERY CARDS GALLERY GRID */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {filteredDiscoveries.map((item) => {
                const isUnlocked = unlockedSet.has(item.day);
                const rarity = getRarityInfo(item.day);

                // Locked Card Presentation
                if (!isUnlocked) {
                  return (
                    <div
                      key={item.id}
                      className="p-4 rounded-2xl border border-dashed border-slate-800/80 bg-slate-950/50 flex items-center justify-between gap-3 text-slate-500 hover:border-slate-700 transition-colors"
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-center text-slate-600 shrink-0">
                          <Lock className="w-4 h-4" />
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-mono uppercase text-slate-600 font-bold">
                              DAY {item.day}
                            </span>
                            <span className="text-slate-700">•</span>
                            <span className="text-[10px] font-mono text-slate-600 uppercase">
                              {item.category.replace('-', ' ')}
                            </span>
                          </div>
                          <div className="text-xs font-semibold text-slate-400">
                            Classified Scientific Telemetry (Locked)
                          </div>
                          <p className="text-[11px] text-slate-600 leading-relaxed">
                            Survive and advance to Day {item.day} to calibrate this finding.
                          </p>
                        </div>
                      </div>

                      <span className="text-[10px] font-mono px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-500 shrink-0 self-start">
                        Day {item.day}
                      </span>
                    </div>
                  );
                }

                // Unlocked Collectible Card Presentation
                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      soundEngine.playTelemetryClick();
                      setInspectParamValue(50);
                      setActiveInspectDiscovery(item);
                    }}
                    className={`p-4 rounded-2xl border bg-slate-900/40 hover:bg-slate-900/80 transition-all cursor-pointer flex flex-col justify-between gap-3 group relative overflow-hidden shadow-lg ${rarity.glow}`}
                  >
                    {/* Top Meta Header */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <div className="w-11 h-11 rounded-xl bg-slate-950 border border-cyan-500/50 flex items-center justify-center text-2xl shrink-0 group-hover:scale-105 transition-transform shadow-md">
                          {item.badge.icon}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-mono text-cyan-400 uppercase font-bold">
                              DAY {String(item.day).padStart(2, '0')}
                            </span>
                            <span className="text-slate-600">•</span>
                            <span className="text-[10px] font-mono text-slate-400 uppercase">
                              {item.category.replace('-', ' ')}
                            </span>
                          </div>
                          <div className="text-xs font-mono text-amber-300 font-bold">
                            {item.badge.title}
                          </div>
                        </div>
                      </div>

                      <span
                        className={`text-[9px] font-mono px-2 py-0.5 rounded-full border ${rarity.color} shrink-0`}
                      >
                        {rarity.tier}
                      </span>
                    </div>

                    {/* Card Title & Excerpt */}
                    <div className="space-y-1">
                      <h3 className="text-xs sm:text-sm font-bold text-slate-100 group-hover:text-cyan-300 transition-colors line-clamp-1">
                        {item.factTitle}
                      </h3>
                      <p className="text-[11px] text-slate-300 line-clamp-2 leading-relaxed">
                        {item.conciseExplanation}
                      </p>
                    </div>

                    {/* Card Action Footer */}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs font-mono">
                      <span className="text-[10px] text-slate-500 truncate max-w-[180px]">
                        {item.sourceOrg}
                      </span>

                      <span className="text-cyan-400 group-hover:translate-x-1 transition-transform flex items-center gap-1 font-bold text-[11px]">
                        <span>Inspect Dossier</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* ============================================================ */}
        {/* 5. PERSONAL DISCOVERY STATISTICS SUMMARY STRIP               */}
        {/* ============================================================ */}
        <div className="p-3.5 bg-slate-900/60 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-slate-400 px-5 shrink-0">
          <div className="flex items-center gap-4">
            <span className="text-slate-300">
              Discovered: <strong className="text-cyan-300">{totalUnlocked} / 30</strong>
            </span>
            <span className="text-slate-500">•</span>
            <span className="text-slate-300">
              Active Fields:{' '}
              <strong className="text-blue-300">
                {new Set(NASA_DISCOVERIES.filter((d) => unlockedSet.has(d.day)).map((d) => d.category)).size} / 6
              </strong>
            </span>
            <span className="text-slate-500">•</span>
            <span className="text-slate-300">
              Science Bonus: <strong className="text-amber-400">+{totalUnlocked * 50} Pts</strong>
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[11px] text-slate-500 hidden sm:inline">
              Verified with NASA Mission Archives
            </span>
            <button
              onClick={() => {
                soundEngine.playTelemetryClick();
                setActiveInspectDiscovery(null);
                onClose();
              }}
              className="px-4 py-1.5 rounded-lg border border-slate-800 bg-slate-900 hover:bg-slate-800 text-xs text-slate-200 transition-colors cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
