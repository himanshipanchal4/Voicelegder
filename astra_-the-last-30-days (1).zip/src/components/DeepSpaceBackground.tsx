/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';

export type BackgroundVariant = 'cinematic' | 'game' | 'telemetry' | 'discovery' | 'launch';

interface DeepSpaceBackgroundProps {
  variant?: BackgroundVariant;
  className?: string;
}

export const DeepSpaceBackground: React.FC<DeepSpaceBackgroundProps> = ({
  variant = 'cinematic',
  className = '',
}) => {
  // Deterministic starfield with colorful cosmic hues (cyan, gold, violet, starlight white)
  const stars = useMemo(() => {
    const palette = ['#f8fafc', '#7dd3fc', '#fde68a', '#c4b5fd', '#f8fafc'];
    const starList = [];
    const count = variant === 'telemetry' ? 50 : variant === 'game' ? 65 : 105;
    for (let i = 0; i < count; i++) {
      const x = (i * 37) % 100;
      const y = (i * 61) % 100;
      const size = i % 5 === 0 ? 2.3 : i % 2 === 0 ? 1.6 : 1.1;
      const opacity = 0.3 + ((i % 7) / 10);
      const animGroup = (i % 3) + 1;
      const color = palette[i % palette.length];
      starList.push({ id: i, x, y, size, opacity, animGroup, color });
    }
    return starList;
  }, [variant]);

  return (
    <div
      aria-hidden="true"
      className={`fixed inset-0 pointer-events-none overflow-hidden select-none z-0 ${className}`}
      style={{
        background:
          variant === 'telemetry'
            ? 'linear-gradient(180deg, #0b112c 0%, #111b44 55%, #0c1230 100%)'
            : variant === 'game'
            ? 'linear-gradient(180deg, #090e26 0%, #10193f 55%, #0a102b 100%)'
            : 'radial-gradient(ellipse at 50% 18%, #1a2356 0%, #0f163b 48%, #090e24 100%)',
      }}
    >
      {/* Colorful Cosmic Nebula Clouds */}
      {variant !== 'telemetry' && (
        <>
          <div
            className="absolute -top-28 -left-20 w-[680px] h-[480px] rounded-full blur-[130px] opacity-35 pointer-events-none"
            style={{
              background:
                'radial-gradient(circle, rgba(168, 85, 247, 0.42) 0%, rgba(59, 130, 246, 0.2) 55%, transparent 80%)',
            }}
          />

          <div
            className="absolute bottom-6 -right-20 w-[720px] h-[520px] rounded-full blur-[150px] opacity-30 pointer-events-none"
            style={{
              background:
                'radial-gradient(circle, rgba(6, 182, 212, 0.38) 0%, rgba(16, 185, 129, 0.16) 55%, transparent 80%)',
            }}
          />

          <div
            className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[850px] h-[460px] rounded-full blur-[170px] opacity-20 pointer-events-none"
            style={{
              background:
                'radial-gradient(circle, rgba(244, 114, 182, 0.25) 0%, rgba(99, 102, 241, 0.18) 60%, transparent 80%)',
            }}
          />
        </>
      )}

      {/* Twinkling Colorful Starfield */}
      <svg className="absolute inset-0 w-full h-full opacity-85" xmlns="http://www.w3.org/2000/svg">
        {stars.map((s) => (
          <circle
            key={s.id}
            cx={`${s.x}%`}
            cy={`${s.y}%`}
            r={s.size}
            fill={s.color}
            className={
              s.animGroup === 1
                ? 'animate-twinkle-1'
                : s.animGroup === 2
                ? 'animate-twinkle-2'
                : 'animate-twinkle-3'
            }
            style={{
              opacity: s.opacity,
              filter: s.size > 1.6 ? 'drop-shadow(0 0 3px rgba(125, 211, 252, 0.8))' : 'none',
            }}
          />
        ))}
      </svg>

      {/* Luminous Lunar Horizon Curve */}
      {variant === 'cinematic' && (
        <div className="absolute -bottom-48 left-1/2 -translate-x-1/2 w-[160vw] max-w-[2200px] h-[360px] pointer-events-none">
          <div className="w-full h-full rounded-[100%] bg-gradient-to-t from-[#090d20] via-[#17214a] to-transparent border-t border-cyan-400/25 shadow-[0_-12px_45px_rgba(56,189,248,0.14)]" />
        </div>
      )}

      {/* Gentle edge vignette */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(circle at center, transparent 48%, rgba(7, 10, 26, 0.55) 100%)',
        }}
      />
    </div>
  );
};
