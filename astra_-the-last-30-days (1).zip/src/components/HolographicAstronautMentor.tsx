/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { HelpCircle, Sparkles, Volume2 } from 'lucide-react';
import { soundEngine } from '../services/soundEngine';

export type AstronautGesture = 'projecting' | 'celebrating' | 'explaining' | 'thinking';

interface HolographicAstronautMentorProps {
  dialogue: string;
  gesture: AstronautGesture;
  onRequestHint?: () => void;
  hintAvailable?: boolean;
  className?: string;
}

export const HolographicAstronautMentor: React.FC<HolographicAstronautMentorProps> = ({
  dialogue,
  gesture,
  onRequestHint,
  hintAvailable = true,
  className = '',
}) => {
  return (
    <div className={`relative flex flex-col items-center select-none ${className}`}>
      {/* 1. Dynamic Animated Speech Bubble Above Helmet */}
      <div className="relative mb-3 max-w-[260px] sm:max-w-[300px] z-20 animate-fade-in">
        <div className="p-3 rounded-2xl bg-slate-950/90 backdrop-blur-md border border-cyan-400/60 shadow-xl shadow-cyan-950/50 text-slate-100 relative">
          <div className="flex items-center justify-between gap-1 text-[10px] font-mono uppercase text-cyan-400 font-semibold mb-1">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
              <span>SPECIALIST NOVA &bull; MENTOR</span>
            </span>
            {hintAvailable && onRequestHint && (
              <button
                onClick={() => {
                  soundEngine.playTelemetryClick();
                  onRequestHint();
                }}
                className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-300 transition-colors cursor-pointer flex items-center gap-0.5"
                title="Request tactical hint"
              >
                <HelpCircle className="w-2.5 h-2.5" />
                <span>Hint</span>
              </button>
            )}
          </div>

          <p className="text-xs text-slate-100 leading-snug font-sans">
            &ldquo;{dialogue}&rdquo;
          </p>

          {/* Speech bubble arrow pointer pointing down to helmet */}
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[8px] border-t-cyan-500/80" />
        </div>
      </div>

      {/* 2. Full EMU Astronaut Character Illustration (Zero-G Floating) */}
      <div className="relative w-40 sm:w-48 h-56 sm:h-64 flex flex-col items-center justify-center animate-float-slow">
        {/* Ambient Cosmic Aura */}
        <div className="absolute inset-0 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Complete Astronaut Assembly */}
        <div className="relative w-36 sm:w-40 flex flex-col items-center">
          {/* A. HELMET WITH EARTH VISOR REFLECTION (Faithfully inspired by User Reference 2) */}
          <div className="relative w-20 sm:w-22 h-18 sm:h-20 flex items-center justify-center z-20">
            {/* White Outer Helmet Shell */}
            <div className="w-full h-full rounded-full bg-gradient-to-b from-slate-100 via-white to-slate-300 border-2 border-slate-300 shadow-xl flex items-center justify-center relative overflow-hidden">
              {/* Helmet Visor Ring Bezel */}
              <div className="w-16 sm:w-18 h-14 sm:h-16 rounded-full bg-slate-900 border-2 border-slate-700 relative overflow-hidden flex items-center justify-center shadow-inner">
                {/* Deep Glossy Visor Glass */}
                <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-[#030b1c] to-slate-900" />

                {/* VIVID EARTH REFLECTION (Reference 2: Blue oceans, swirling cloud systems) */}
                <div className="absolute top-1 right-1 w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 via-blue-600 to-emerald-600 opacity-95 shadow-md overflow-hidden border border-blue-400/40">
                  {/* Swirling White Cloud Ribbons */}
                  <div className="absolute top-1.5 left-1 w-7 h-2 bg-white/75 rounded-full blur-[0.4px] rotate-[-20deg]" />
                  <div className="absolute bottom-2 right-1 w-6 h-1.5 bg-white/70 rounded-full blur-[0.4px] rotate-[10deg]" />
                  <div className="absolute top-4 left-3 w-4 h-1 bg-white/60 rounded-full blur-[0.4px]" />
                </div>

                {/* Specular White Solar Glint */}
                <div className="absolute top-2 left-2.5 w-3 h-2 bg-white/90 rounded-full blur-[0.5px]" />
                {/* Secondary Rim Reflection */}
                <div className="absolute bottom-1 inset-x-2 h-1 bg-cyan-400/30 rounded-full blur-[0.8px]" />
              </div>
            </div>

            {/* Comms Antenna with Pulsing Beacon */}
            <div className="absolute -top-1.5 right-1 w-3.5 h-3.5 rounded-full bg-cyan-400 border-2 border-slate-950 animate-ping shadow-[0_0_10px_#22d3ee]" />
            <div className="absolute -top-1.5 right-1 w-3.5 h-3.5 rounded-full bg-cyan-400 border-2 border-slate-950 shadow-[0_0_8px_#22d3ee]" />

            {/* Helmet Visor Spotlight Lamp (NASA EVA Headlamp) */}
            <div className="absolute top-2 left-0.5 w-2 h-3 bg-slate-700 rounded-sm border border-slate-400" />
            <div className="absolute top-2 right-0.5 w-2 h-3 bg-slate-700 rounded-sm border border-slate-400" />
          </div>

          {/* B. METALLIC NECK CONNECTOR RING */}
          <div className="w-16 h-2.5 bg-gradient-to-r from-slate-400 via-slate-200 to-slate-400 rounded-full -mt-1 z-20 border-y border-slate-300 shadow-sm" />

          {/* C. EMU TORSO & CHEST LIFE SUPPORT PACK (DCM) */}
          <div className="relative w-28 sm:w-32 h-20 bg-gradient-to-b from-slate-100 via-white to-slate-300 rounded-xl border border-slate-300 shadow-lg flex flex-col items-center pt-1 z-10">
            {/* Shoulder Disconnect Rings */}
            <div className="absolute top-1 left-1 w-3.5 h-3.5 rounded-full border border-slate-400 bg-slate-200" />
            <div className="absolute top-1 right-1 w-3.5 h-3.5 rounded-full border border-slate-400 bg-slate-200" />

            {/* Chest Display and Control Module (DCM) */}
            <div className="w-14 sm:w-16 h-10 bg-slate-900 rounded-md border border-slate-600 flex flex-col justify-between p-1 z-10 shadow-inner">
              <div className="flex items-center justify-between">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_4px_#22d3ee]" />
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              </div>
              <div className="w-full h-2.5 bg-slate-950 rounded-xs border border-slate-700 flex items-center px-1">
                <span className="text-[6px] font-mono text-cyan-300">O2: 100%</span>
              </div>
              <div className="flex justify-around">
                <div className="w-2 h-1 bg-slate-400 rounded-xs" />
                <div className="w-2 h-1 bg-slate-400 rounded-xs" />
                <div className="w-2 h-1 bg-slate-400 rounded-xs" />
              </div>
            </div>

            {/* Left Chest: NASA Blue Meatball Insignia */}
            <div className="absolute top-3 left-2 w-4 h-4 rounded-full bg-blue-600 border border-slate-200 flex items-center justify-center text-[5px] text-white font-bold shadow-xs">
              NASA
            </div>

            {/* Right Chest: NASA Astronaut Pin */}
            <div className="absolute top-2.5 right-2 w-4 h-4 rounded-full bg-slate-950 border border-amber-400/90 flex items-center justify-center text-[7px] text-amber-300 font-bold shadow-xs" title="NASA Astronaut Pin">
              ★
            </div>

            {/* Ribbed Silver Life-Support Umbilical Hoses */}
            <div className="absolute -left-2 bottom-1 w-6 h-6 rounded-full border-b-4 border-l-4 border-slate-400 pointer-events-none" />
            <div className="absolute -right-2 bottom-1 w-6 h-6 rounded-full border-b-4 border-r-4 border-slate-400 pointer-events-none" />
          </div>

          {/* D. ARMS & INTERACTIVE GESTURE HANDS */}
          {/* Arm 1 (Left - Projector Hand) */}
          <div className="absolute -left-7 sm:-left-9 top-14 w-10 sm:w-12 h-14 flex flex-col items-center">
            {gesture === 'projecting' ? (
              /* Raised Projector Glove with Glowing Cyan Emitter */
              <div className="relative flex flex-col items-center">
                {/* Arm sleeve */}
                <div className="w-4 h-8 bg-gradient-to-b from-slate-100 to-slate-200 border border-slate-300 rounded-t-md rotate-[-25deg] origin-bottom" />
                {/* White EVA Glove with dark palm */}
                <div className="w-6 h-6 rounded-full bg-white border border-slate-400 flex items-center justify-center shadow-md relative -mt-1">
                  <div className="w-3 h-3 rounded-full bg-slate-800" />
                  {/* Glowing Holographic Projector Emitter Light (Reference 1 of gesture) */}
                  <div className="absolute inset-0 rounded-full bg-cyan-400 animate-ping opacity-75" />
                  <div className="w-4 h-4 rounded-full bg-cyan-300 border border-white shadow-[0_0_14px_#22d3ee] flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-white" />
                  </div>
                </div>

                {/* Holographic Projection Ray Flare Lines radiating towards right */}
                <div className="absolute top-2 -right-8 w-24 h-16 pointer-events-none opacity-80 animate-projection-rays">
                  <svg viewBox="0 0 100 60" className="w-full h-full overflow-visible">
                    <line x1="0" y1="30" x2="100" y2="0" stroke="#22d3ee" strokeWidth="1.5" strokeDasharray="4 2" />
                    <line x1="0" y1="30" x2="100" y2="20" stroke="#38bdf8" strokeWidth="1" strokeDasharray="3 3" />
                    <line x1="0" y1="30" x2="100" y2="40" stroke="#38bdf8" strokeWidth="1" strokeDasharray="3 3" />
                    <line x1="0" y1="30" x2="100" y2="60" stroke="#22d3ee" strokeWidth="1.5" strokeDasharray="4 2" />
                  </svg>
                </div>
              </div>
            ) : gesture === 'celebrating' ? (
              /* Celebrating Hand Up */
              <div className="relative flex flex-col items-center -translate-y-4">
                <div className="w-4 h-8 bg-gradient-to-b from-slate-100 to-slate-200 border border-slate-300 rounded-t-md rotate-[-45deg]" />
                <div className="w-6 h-6 rounded-full bg-white border border-slate-400 flex items-center justify-center shadow-md -mt-2">
                  <span className="text-xs">✌️</span>
                </div>
              </div>
            ) : (
              /* Relaxed Zero-G Floating Glove */
              <div className="relative flex flex-col items-center">
                <div className="w-4 h-10 bg-gradient-to-b from-slate-100 to-slate-200 border border-slate-300 rounded-md rotate-[10deg]" />
                <div className="w-5 h-5 rounded-full bg-white border border-slate-400 flex items-center justify-center shadow-md -mt-1">
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-800" />
                </div>
              </div>
            )}
          </div>

          {/* Arm 2 (Right - Gesturing / Neutral) */}
          <div className="absolute -right-7 sm:-right-9 top-14 w-10 sm:w-12 h-14 flex flex-col items-center">
            {gesture === 'celebrating' ? (
              <div className="relative flex flex-col items-center -translate-y-4">
                <div className="w-4 h-8 bg-gradient-to-b from-slate-100 to-slate-200 border border-slate-300 rounded-t-md rotate-[45deg]" />
                <div className="w-6 h-6 rounded-full bg-white border border-slate-400 flex items-center justify-center shadow-md -mt-2">
                  <span className="text-xs">👍</span>
                </div>
              </div>
            ) : gesture === 'explaining' ? (
              <div className="relative flex flex-col items-center">
                <div className="w-4 h-8 bg-gradient-to-b from-slate-100 to-slate-200 border border-slate-300 rounded-md rotate-[30deg]" />
                <div className="w-5 h-5 rounded-full bg-white border border-slate-400 flex items-center justify-center shadow-md -mt-1">
                  <span className="text-[10px] text-cyan-500 font-bold">👉</span>
                </div>
              </div>
            ) : (
              <div className="relative flex flex-col items-center">
                <div className="w-4 h-10 bg-gradient-to-b from-slate-100 to-slate-200 border border-slate-300 rounded-md rotate-[-10deg]" />
                <div className="w-5 h-5 rounded-full bg-white border border-slate-400 flex items-center justify-center shadow-md -mt-1">
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-800" />
                </div>
              </div>
            )}
          </div>

          {/* E. LEGS & TEAL OVERBOOT SOLES (Matches Reference 2) */}
          <div className="relative flex justify-center gap-2 -mt-1 z-0">
            {/* Left Leg */}
            <div className="w-8 sm:w-9 h-14 bg-gradient-to-b from-slate-100 via-slate-200 to-slate-300 border-x border-slate-300 rounded-b-md flex flex-col items-center justify-end">
              {/* Teal-green protective lunar boot tread sole */}
              <div className="w-9 sm:w-10 h-3 bg-teal-600 rounded-b-md border-t border-teal-400 shadow-sm flex items-center justify-around px-1">
                <div className="w-1 h-1 bg-teal-800 rounded-full" />
                <div className="w-1 h-1 bg-teal-800 rounded-full" />
              </div>
            </div>

            {/* Right Leg */}
            <div className="w-8 sm:w-9 h-14 bg-gradient-to-b from-slate-100 via-slate-200 to-slate-300 border-x border-slate-300 rounded-b-md flex flex-col items-center justify-end">
              {/* Teal-green protective lunar boot tread sole */}
              <div className="w-9 sm:w-10 h-3 bg-teal-600 rounded-b-md border-t border-teal-400 shadow-sm flex items-center justify-around px-1">
                <div className="w-1 h-1 bg-teal-800 rounded-full" />
                <div className="w-1 h-1 bg-teal-800 rounded-full" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
