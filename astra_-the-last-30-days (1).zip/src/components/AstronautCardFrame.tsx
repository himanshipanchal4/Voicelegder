/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { FileText, Check, Plus, Volume2 } from 'lucide-react';
import { AstronautCharacter } from '../data/astronautRoster';
import { AstronautCharacterFigure } from './AstronautCharacterFigure';
import { soundEngine } from '../services/soundEngine';

interface AstronautCardFrameProps {
  character: AstronautCharacter;
  slotIndex?: number;
  isSelected: boolean;
  canSelect: boolean;
  onToggleSelect: (character: AstronautCharacter) => void;
  onOpenBio: (character: AstronautCharacter) => void;
  onPlayQuote?: (character: AstronautCharacter) => void;
  onSwap?: (character: AstronautCharacter) => void;
}

export const AstronautCardFrame: React.FC<AstronautCardFrameProps> = ({
  character,
  slotIndex,
  isSelected,
  canSelect,
  onToggleSelect,
  onOpenBio,
  onPlayQuote,
  onSwap,
}) => {
  const [isHovered, setIsHovered] = React.useState(false);

  const handleSelectClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isSelected || canSelect) {
      soundEngine.playConfirm();
      onToggleSelect(character);
    } else {
      soundEngine.playWarning();
    }
  };

  const handleBioClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    soundEngine.playTelemetryClick();
    onOpenBio(character);
  };

  const handlePlayVoice = (e: React.MouseEvent) => {
    e.stopPropagation();
    soundEngine.playTelemetryClick();
    if (onPlayQuote) onPlayQuote(character);
  };

  return (
    <div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => {
        if (onPlayQuote) onPlayQuote(character);
      }}
      className={`relative flex flex-col justify-between bg-[#121a3e]/95 backdrop-blur-md transition-all duration-300 rounded-2xl cursor-pointer select-none group min-h-[370px] sm:min-h-[480px] overflow-hidden ${
        isSelected
          ? 'border-amber-400/90 shadow-[0_0_24px_rgba(251,191,36,0.28)] ring-1 ring-amber-400/50'
          : 'border-indigo-400/35 hover:border-cyan-400 hover:shadow-[0_0_20px_rgba(34,211,238,0.2)]'
      }`}
      style={{
        borderWidth: '1.5px',
      }}
    >
      {/* 1. TOP HEADER WITH CATEGORY LABEL */}
      <div className="relative pt-3.5 px-4 pb-2 border-b border-indigo-500/30 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span
            className="w-2 h-4 rounded-full inline-block shadow-sm"
            style={{ backgroundColor: character.suitTheme.accent }}
          />
          <h3 className="font-display text-xs sm:text-sm font-extrabold tracking-wider text-white uppercase">
            {character.displayCategory}
          </h3>
        </div>

        {/* Small Audio Quote Button */}
        <button
          onClick={handlePlayVoice}
          title="Play voice line"
          className="p-1.5 rounded-lg bg-[#0b1026]/80 hover:bg-indigo-900/70 text-indigo-200 hover:text-cyan-300 transition-colors"
        >
          <Volume2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 2. SUBHEADER: NAME, CALLSIGN & ROLE */}
      <div className="px-3.5 sm:px-4 py-1.5 flex items-center justify-between gap-2 text-[11px] font-mono text-indigo-300 border-b border-indigo-500/20">
        <div className="min-w-0 truncate">
          <span className="text-white font-bold text-xs font-sans">{character.name}</span>
          <span className="text-cyan-300 ml-1.5 font-mono">"{character.callsign}"</span>
        </div>
        <span
          className="px-2 py-0.5 rounded-md text-[10px] uppercase font-bold tracking-wider shrink-0"
          style={{
            backgroundColor: `${character.suitTheme.accent}25`,
            color: character.suitTheme.accent,
            border: `1px solid ${character.suitTheme.accent}55`,
          }}
        >
          {character.badgeCode}
        </span>
      </div>

      {/* 3. CENTER: FULL-BODY ASTRONAUT FIGURE */}
      <div className="relative flex-1 flex items-center justify-center py-2 px-2">
        <AstronautCharacterFigure
          character={character}
          isHovered={isHovered}
          isSelected={isSelected}
          size="md"
        />

        {/* Selected Overlay Watermark / Tag */}
        {isSelected && (
          <div
            className="absolute top-2 right-2 px-2.5 py-0.5 rounded-lg text-slate-950 font-mono font-black text-[10px] tracking-wider uppercase shadow-md flex items-center gap-1"
            style={{ backgroundColor: character.suitTheme.accent }}
          >
            <Check className="w-3 h-3 stroke-[3]" />
            <span>IN SQUAD</span>
          </div>
        )}
      </div>

      {/* 4. SHORT PERSONALITY QUOTE */}
      <div className="px-3 py-1.5 mx-3 mb-2 rounded-xl bg-[#0b1026]/75 border border-indigo-500/25 text-[11px] text-indigo-100 italic truncate">
        "{character.characterIntro}"
      </div>

      {/* 6. BOTTOM ACTION BAR */}
      <div className="pt-2.5 pb-3.5 px-3.5 border-t border-indigo-500/30 flex items-center justify-between gap-2">
        {/* BIO Button */}
        <button
          onClick={handleBioClick}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-indigo-400/40 bg-[#0b1026]/90 hover:bg-indigo-900/70 hover:border-cyan-400 text-indigo-100 hover:text-white text-xs font-bold transition-all cursor-pointer shrink-0"
          title="Open Astronaut Bio Dossier"
        >
          <FileText className="w-3.5 h-3.5 text-cyan-300" />
          <span>BIO</span>
        </button>

        {/* Optional Swap button if assigned to slot */}
        {onSwap && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onSwap(character);
            }}
            className="px-2.5 py-2 rounded-xl border border-indigo-400/30 bg-[#0b1026]/70 hover:bg-indigo-900/70 text-indigo-200 hover:text-cyan-300 text-[11px] uppercase font-bold transition-colors cursor-pointer"
            title="Swap with another astronaut"
          >
            Swap
          </button>
        )}

        {/* SELECT / SELECTED Button */}
        <button
          onClick={handleSelectClick}
          disabled={!isSelected && !canSelect}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-extrabold uppercase tracking-wider transition-all duration-200 cursor-pointer shadow-md ${
            isSelected
              ? 'bg-gradient-to-r from-amber-400 to-orange-400 hover:brightness-110 text-slate-950 shadow-amber-500/30'
              : canSelect
              ? 'bg-gradient-to-r from-cyan-400 to-emerald-400 hover:brightness-110 text-slate-950 shadow-cyan-500/25 hover:scale-[1.02]'
              : 'bg-slate-800 text-slate-500 border border-slate-700/60 cursor-not-allowed opacity-60'
          }`}
        >
          {isSelected ? (
            <>
              <Check className="w-3.5 h-3.5 stroke-[3]" />
              <span>SELECTED</span>
            </>
          ) : (
            <>
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span>SELECT</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
