/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ArrowRight, UserCheck, Shield, Zap, Droplet, Wind, Coffee, Sparkles, CheckCircle2 } from 'lucide-react';
import { CrewMember, ResourceTelemetry, DifficultyLevel } from '../types/mission';
import { NasaAstronautLogo } from './NasaAstronautLogo';

interface MissionBriefingProps {
  crew: CrewMember[];
  resources: ResourceTelemetry;
  selectedDifficulty: DifficultyLevel;
  onChangeDifficulty: (diff: DifficultyLevel) => void;
  onBeginMission: () => void;
  onBackToLanding: () => void;
  onStartTutorial: () => void;
}

export const MissionBriefing: React.FC<MissionBriefingProps> = ({
  crew,
  resources,
  selectedDifficulty,
  onChangeDifficulty,
  onBeginMission,
  onBackToLanding,
  onStartTutorial,
}) => {
  return (
    <div className="max-w-5xl mx-auto p-6 md:p-10 select-none">
      {/* Briefing Header */}
      <div className="border-b border-slate-800 pb-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="flex items-start gap-4">
          <NasaAstronautLogo size={52} className="shrink-0 mt-1 drop-shadow-[0_0_12px_rgba(234,179,8,0.35)]" />
          <div>
            <div className="text-xs font-mono uppercase text-cyan-400 tracking-wider mb-1 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
              <span>NASA Astronaut Corps · Operation Shackleton</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-100 tracking-tight">
              Expedition Briefing: Lunar Outpost ASTRA
            </h1>
            <p className="text-sm text-slate-400 mt-2 max-w-2xl">
              You are appointed Commander of Outpost ASTRA for the next 30 mission days. Your primary mandate is maintaining crew life support and base integrity through the approaching polar solar cycle.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onStartTutorial}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-lg border border-cyan-800/80 bg-cyan-950/40 hover:bg-cyan-900/50 text-xs font-semibold text-cyan-300 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Interactive Tutorial</span>
          </button>
          <button
            onClick={onBackToLanding}
            className="px-4 py-2.5 rounded-lg border border-slate-800 text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-900 transition-colors cursor-pointer"
          >
            Abort / Back
          </button>
          <button
            onClick={onBeginMission}
            className="flex items-center gap-2 px-6 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs rounded-lg shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
          >
            <span>Begin 30-Day Mission</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Difficulty Tier Selector (Requirement 7) */}
      <div className="mb-8 p-5 bg-slate-950 border border-slate-800 rounded-xl">
        <div className="text-xs font-mono uppercase text-slate-400 mb-3 flex items-center justify-between">
          <span>Choose Mission Difficulty Setting:</span>
          <span className="text-[11px] text-cyan-400">Can be adjusted per expedition</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Beginner */}
          <div
            onClick={() => onChangeDifficulty('beginner')}
            className={`p-4 rounded-xl border transition-all cursor-pointer ${
              selectedDifficulty === 'beginner'
                ? 'bg-emerald-950/40 border-emerald-400 shadow-md shadow-emerald-950'
                : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-sm text-emerald-400">Beginner Tier</span>
              {selectedDifficulty === 'beginner' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
            </div>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              +30% generous starting supplies, automatic commander hints, and forgiving crisis penalties. Great for newcomers!
            </p>
          </div>

          {/* Commander */}
          <div
            onClick={() => onChangeDifficulty('commander')}
            className={`p-4 rounded-xl border transition-all cursor-pointer ${
              selectedDifficulty === 'commander'
                ? 'bg-cyan-950/40 border-cyan-400 shadow-md shadow-cyan-950'
                : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-sm text-cyan-400">Commander (Standard)</span>
              {selectedDifficulty === 'commander' && <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
            </div>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Authentic NASA baseline survival math. Balanced recycling rates and realistic solar ridge shadow challenges.
            </p>
          </div>

          {/* Expert */}
          <div
            onClick={() => onChangeDifficulty('expert')}
            className={`p-4 rounded-xl border transition-all cursor-pointer ${
              selectedDifficulty === 'expert'
                ? 'bg-rose-950/40 border-rose-400 shadow-md shadow-rose-950'
                : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-sm text-rose-400">Expert Astronaut</span>
              {selectedDifficulty === 'expert' && <CheckCircle2 className="w-4 h-4 text-rose-400" />}
            </div>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Reduced starting reserves (-20%), severe radiation storm hazards, and strict power blackouts. For veterans.
            </p>
          </div>
        </div>
      </div>

      {/* Grid: Mission Environment & Rules */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="text-xs font-mono uppercase text-slate-400 mb-2">Location & Coordinates</div>
          <div className="text-lg font-semibold text-slate-200">Shackleton Rim (89.9°S)</div>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            Perched on the southern rim of a 21-km diameter impact crater. Deep interior permanently shadowed regions (PSRs) harbor billions of tons of water ice at 40 Kelvin.
          </p>
          <div className="mt-3 pt-3 border-t border-slate-800/80 text-[11px] text-cyan-400 font-mono">
            GRAVITY: 1.62 m/s² (1/6 Earth) · VACUUM: 10⁻¹² Pa
          </div>
        </div>

        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="text-xs font-mono uppercase text-slate-400 mb-2">Mission Duration & Target</div>
          <div className="text-lg font-semibold text-slate-200">30 Consecutive Days</div>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            Survival requires balancing dynamic consumption against closed-loop recycling. Days 14–15 will test auxiliary battery reserves during a deep ridge shadow transit.
          </p>
          <div className="mt-3 pt-3 border-t border-slate-800/80 text-[11px] text-emerald-400 font-mono">
            SUCCESS: 30 Days with Crew Intact &gt; 0% Health
          </div>
        </div>

        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="text-xs font-mono uppercase text-slate-400 mb-2">Environmental Hazards</div>
          <div className="text-lg font-semibold text-amber-300">Extreme Polar Factors</div>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            Prepare for acute solar proton events (SPEs), abrasive electrostatic lunar dust on airlock seals, and micrometeorite impacts traveling up to 25 km/s.
          </p>
          <div className="mt-3 pt-3 border-t border-slate-800/80 text-[11px] text-amber-400 font-mono">
            SHIELDING: 2.5m compacted regolith roof
          </div>
        </div>
      </div>

      {/* Initial Quota Telemetry Strip */}
      <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 mb-8">
        <div className="text-xs font-mono uppercase text-slate-400 tracking-wider mb-4 flex items-center justify-between">
          <span>Allocated Consumables (Calculated for {selectedDifficulty.toUpperCase()})</span>
          <span className="text-cyan-400 text-[11px]">NASA ECLSS Standard Baseline</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-3.5 bg-slate-900/80 rounded-lg border border-slate-800/80">
            <div className="flex items-center gap-2 text-cyan-400 mb-1">
              <Wind className="w-4 h-4" />
              <span className="text-xs font-mono">Oxygen (O2)</span>
            </div>
            <div className="text-2xl font-bold font-mono text-slate-100 tabular-nums">
              {resources.oxygenKg} <span className="text-xs text-slate-400 font-normal">kg</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">Crew burn: ~3.36 kg/d · 60% recov.</div>
          </div>

          <div className="p-3.5 bg-slate-900/80 rounded-lg border border-slate-800/80">
            <div className="flex items-center gap-2 text-blue-400 mb-1">
              <Droplet className="w-4 h-4" />
              <span className="text-xs font-mono">Potable H2O</span>
            </div>
            <div className="text-2xl font-bold font-mono text-slate-100 tabular-nums">
              {resources.waterLiters} <span className="text-xs text-slate-400 font-normal">L</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">Crew burn: ~10 L/d · 85% recov.</div>
          </div>

          <div className="p-3.5 bg-slate-900/80 rounded-lg border border-slate-800/80">
            <div className="flex items-center gap-2 text-amber-400 mb-1">
              <Coffee className="w-4 h-4" />
              <span className="text-xs font-mono">Ration Packs</span>
            </div>
            <div className="text-2xl font-bold font-mono text-slate-100 tabular-nums">
              {resources.foodPacks} <span className="text-xs text-slate-400 font-normal">packs</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">4 packs/d · +0.5 greens/d</div>
          </div>

          <div className="p-3.5 bg-slate-900/80 rounded-lg border border-slate-800/80">
            <div className="flex items-center gap-2 text-emerald-400 mb-1">
              <Zap className="w-4 h-4" />
              <span className="text-xs font-mono">Stored Energy</span>
            </div>
            <div className="text-2xl font-bold font-mono text-slate-100 tabular-nums">
              {resources.powerKwh} <span className="text-xs text-slate-400 font-normal">kWh</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">Max 300 kWh · Solar generation</div>
          </div>
        </div>
      </div>

      {/* Crew Manifest Section */}
      <div>
        <div className="text-xs font-mono uppercase text-slate-400 tracking-wider mb-4 flex items-center gap-2">
          <UserCheck className="w-4 h-4 text-cyan-400" />
          <span>Expedition Flight Manifest (4 Astronauts)</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {crew.map((member) => (
            <div
              key={member.id}
              className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 flex items-start gap-4"
            >
              <div className="w-12 h-12 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center font-mono font-bold text-cyan-400 text-sm shrink-0">
                {member.name.split(' ').map((n) => n[0]).join('')}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <div className="font-semibold text-sm text-slate-100 truncate">{member.name}</div>
                  <span className="text-xs font-mono text-slate-400 shrink-0">&ldquo;{member.callsign}&rdquo;</span>
                </div>
                <div className="text-xs text-cyan-400 font-medium">{member.role}</div>
                <div className="text-xs text-slate-400 mt-1">{member.specialty}</div>

                <div className="mt-2.5 flex items-center gap-4 text-xs font-mono text-slate-400">
                  <span>Health: <strong className="text-slate-200">{member.health}%</strong></span>
                  <span>Morale: <strong className="text-slate-200">{member.morale}%</strong></span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Launch Confirmation Footer */}
      <div className="mt-10 pt-6 border-t border-slate-800 flex items-center justify-between">
        <div className="text-xs text-slate-500">
          ASTRA FLIGHT DIRECTIVE v3.2 · NASA SPACE APPS SUBMISSION
        </div>
        <button
          onClick={onBeginMission}
          className="flex items-center gap-2 px-6 py-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-sm rounded-lg shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
        >
          <span>Confirm Readiness & Launch</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
