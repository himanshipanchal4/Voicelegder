/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { ArrowLeft, ArrowRight, CheckCircle2, Flame, Rocket, Shield, Sparkles } from 'lucide-react';
import { RocketId } from '../types/mission';
import { ROCKET_CATALOG, getRocketSpec } from '../data/rocketCatalog';
import { build3DRocketMesh } from '../services/rocket3DFactory';
import { soundEngine } from '../services/soundEngine';

interface RocketSelectStepProps {
  selectedRocketId: RocketId;
  onSelectRocket: (id: RocketId) => void;
  onNextStep: () => void;
  onBackToCrew: () => void;
}

export const RocketSelectStep: React.FC<RocketSelectStepProps> = ({
  selectedRocketId,
  onSelectRocket,
  onNextStep,
  onBackToCrew,
}) => {
  const previewMountRef = useRef<HTMLDivElement>(null);
  const selectedSpec = getRocketSpec(selectedRocketId);

  // Live 3D Three.js turntable preview that rebuilds cleanly when selectedRocketId changes
  useEffect(() => {
    const mount = previewMountRef.current;
    if (!mount) return;

    const isSoftwareGl = (() => {
      try {
        const probe = document.createElement('canvas');
        const gl = probe.getContext('webgl2') || probe.getContext('webgl');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param) || '');
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      return;
    }

    const disposables: Array<{ dispose: () => void }> = [];
    const track = <T extends { dispose: () => void }>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const width = mount.clientWidth || 360;
    const height = mount.clientHeight || 340;

    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.22;
    mount.replaceChildren(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b1230);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmremGenerator.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmremGenerator.dispose();
    track(envTarget);

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 3.1, 8.2);
    camera.lookAt(0, 2.35, 0);

    scene.add(new THREE.HemisphereLight(0x93c5fd, 0x1e1b4b, 1.0));
    const key = new THREE.DirectionalLight(0xfff1d6, 2.4);
    key.position.set(6, 10, 8);
    scene.add(key);

    const rim = new THREE.DirectionalLight(0x38bdf8, 1.5);
    rim.position.set(-7, 5, -6);
    scene.add(rim);

    // Metallic Shipyard Turntable Pad
    const padMesh = new THREE.Mesh(
      track(new THREE.CylinderGeometry(2.1, 2.4, 0.35, 32)),
      track(
        new THREE.MeshStandardMaterial({
          color: 0x1e293b,
          roughness: 0.35,
          metalness: 0.85,
        })
      )
    );
    padMesh.position.y = -0.2;
    scene.add(padMesh);

    const glowRing = new THREE.Mesh(
      track(new THREE.RingGeometry(1.75, 1.98, 36)),
      track(
        new THREE.MeshBasicMaterial({
          color: selectedSpec.accentColorHex,
          side: THREE.DoubleSide,
        })
      )
    );
    glowRing.rotation.x = -Math.PI / 2;
    glowRing.position.y = 0.0;
    scene.add(glowRing);

    const maxAniso = renderer.capabilities.getMaxAnisotropy();
    const built = build3DRocketMesh(selectedRocketId, maxAniso, track);
    built.group.position.set(0, 0.55, 0);
    built.group.scale.setScalar(0.88);
    built.flameGroup.scale.set(0.5, 0.45, 0.5);
    scene.add(built.group);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const handleResize = () => {
      if (!mount) return;
      const w = mount.clientWidth || 360;
      const h = mount.clientHeight || 340;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    const clock = new THREE.Clock();
    let frameId = 0;
    let isDisposed = false;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || typeof gl.fenceSync !== 'function') {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (isDisposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (isDisposed) return;
      const delta = Math.min(clock.getDelta(), 0.08);
      const t = clock.elapsedTime;
      built.group.rotation.y += delta * 0.75;
      built.group.position.y = 0.55 + Math.sin(t * 2.2) * 0.08;
      const flicker = 0.88 + Math.sin(t * 20) * 0.12;
      built.flameGroup.scale.set(0.45 * flicker, 0.42 * flicker, 0.45 * flicker);

      renderer.render(scene, camera);
      if (isSoftwareGl) afterDraw(tick);
      else frameId = requestAnimationFrame(tick);
    }

    if (isSoftwareGl) afterDraw(tick);
    else frameId = requestAnimationFrame(tick);

    return () => {
      isDisposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', handleResize);
      disposables.forEach((d) => {
        try {
          d.dispose();
        } catch {
          // ignore
        }
      });
      renderer.dispose();
    };
  }, [selectedRocketId, selectedSpec.accentColorHex]);

  return (
    <div className="relative w-full max-w-6xl mx-auto p-3 sm:p-6 lg:p-8 select-none animate-fade-in z-10 space-y-5">
      {/* Step Header */}
      <div className="bg-[#121a3e]/95 border border-indigo-400/40 rounded-3xl p-4 sm:p-6 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-cyan-500/20 border border-cyan-400/50 text-[11px] font-mono font-extrabold text-cyan-300 mb-2">
            <Rocket className="w-3.5 h-3.5" />
            <span>STEP 2 OF 3 &bull; TYCHO BRIGHT HIGHLANDS</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Choose Your Moon Rocket
          </h1>
          <p className="text-xs sm:text-sm text-indigo-200 mt-1">
            Your chosen rocket stays with your team for every flight across the 30-day mission!
          </p>
        </div>

        <div className="grid grid-cols-2 sm:flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => {
              soundEngine.playTelemetryClick();
              onBackToCrew();
            }}
            className="flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl border border-indigo-400/35 bg-[#0b1026]/85 hover:bg-indigo-900/60 text-xs font-bold text-indigo-200 hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Crew</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playConfirm();
              onNextStep();
            }}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400 hover:brightness-110 text-slate-950 font-extrabold text-xs sm:text-sm shadow-xl shadow-cyan-500/30 transition-all hover:-translate-y-0.5 cursor-pointer"
          >
            <span>Next: Fly to Control</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main 2-Column 3D Preview + Rocket Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Live 3D Turntable Viewport */}
        <div className="lg:col-span-5 bg-[#0b1230] border-2 border-cyan-400/50 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
          <div className="px-4 py-3 border-b border-indigo-500/30 flex items-center justify-between bg-[#10183d]">
            <span className="text-xs font-mono font-bold text-cyan-300 uppercase tracking-wider">
              Live 3D Hangar View
            </span>
            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-indigo-950 border border-indigo-400/40 ${selectedSpec.uiText}`}>
              {selectedSpec.badge}
            </span>
          </div>

          <div
            ref={previewMountRef}
            className="w-full h-[260px] sm:h-[340px] lg:flex-1 relative"
          />

          <div className="p-4 border-t border-indigo-500/30 bg-[#10183d] space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-extrabold text-white">{selectedSpec.name}</h2>
              <span className="text-xs font-mono text-amber-300 font-bold">"{selectedSpec.nickname}"</span>
            </div>
            <p className="text-xs text-indigo-200 leading-relaxed">{selectedSpec.tagline}</p>
            <div className="grid grid-cols-3 gap-2 pt-1 text-[11px] font-mono">
              <div className="p-2 rounded-xl bg-[#070c22] border border-indigo-500/30">
                <span className="text-indigo-300 block text-[10px]">THRUST</span>
                <strong className="text-amber-300">{selectedSpec.stats.thrust}</strong>
              </div>
              <div className="p-2 rounded-xl bg-[#070c22] border border-indigo-500/30">
                <span className="text-indigo-300 block text-[10px]">ARMOR</span>
                <strong className="text-cyan-300">{selectedSpec.stats.shield}</strong>
              </div>
              <div className="p-2 rounded-xl bg-[#070c22] border border-indigo-500/30">
                <span className="text-indigo-300 block text-[10px]">FEATURE</span>
                <strong className="text-emerald-300 truncate block">{selectedSpec.stats.style}</strong>
              </div>
            </div>
          </div>
        </div>

        {/* 4 Rocket Selection Cards */}
        <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {ROCKET_CATALOG.map((rocket) => {
            const isSelected = rocket.id === selectedRocketId;
            return (
              <button
                key={rocket.id}
                type="button"
                onClick={() => {
                  soundEngine.playConfirm();
                  onSelectRocket(rocket.id);
                }}
                className={`text-left p-4 sm:p-5 rounded-3xl border-2 transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                  isSelected
                    ? `bg-gradient-to-br ${rocket.uiGradient} ${rocket.uiBorder} shadow-xl ring-1 ring-white/25 scale-[1.01]`
                    : 'bg-[#121a3e]/90 border-indigo-500/30 hover:border-cyan-400/60 hover:bg-[#17214d]'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className={`text-[10px] font-mono font-extrabold px-2.5 py-0.5 rounded-lg bg-[#080d24] border border-indigo-400/30 ${rocket.uiText}`}>
                      {rocket.badge}
                    </span>
                    {isSelected && (
                      <span className="inline-flex items-center gap-1 text-xs font-extrabold text-emerald-300">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Selected</span>
                      </span>
                    )}
                  </div>

                  <div>
                    <h3 className="font-display text-lg font-extrabold text-white leading-tight">
                      {rocket.name}
                    </h3>
                    <span className="text-xs font-mono text-indigo-300">Callsign: {rocket.nickname}</span>
                  </div>

                  <p className="text-xs text-indigo-100/90 leading-relaxed">{rocket.tagline}</p>
                </div>

                <div className="pt-2.5 border-t border-indigo-400/20 flex items-center justify-between text-[11px] font-mono text-indigo-200">
                  <span className="flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5 text-amber-300" />
                    <span>{rocket.stats.thrust}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Shield className="w-3.5 h-3.5 text-cyan-300" />
                    <span>{rocket.stats.shield}</span>
                  </span>
                  <span className="flex items-center gap-1 text-emerald-300 font-bold">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{rocket.stats.style}</span>
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
