/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ExternalLink, X } from 'lucide-react';
import { SCIENCE_REFERENCES } from '../data/missionContent';
import { NasaAstronautLogo } from './NasaAstronautLogo';

interface ScienceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ScienceModal: React.FC<ScienceModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#060919]/85 backdrop-blur-md select-none">
      <div className="bg-[#121a3e] border border-cyan-400/50 rounded-3xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl relative max-h-[88vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-indigo-300 hover:text-white rounded-xl hover:bg-indigo-900/60 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5 pr-8">
          <NasaAstronautLogo size={42} className="drop-shadow-[0_0_10px_rgba(234,179,8,0.35)]" />
          <div>
            <h2 className="font-display text-xl font-extrabold text-white">NASA Space Science</h2>
            <div className="text-xs font-semibold text-cyan-300">Real Moon Facts Behind ASTRA</div>
          </div>
        </div>

        {/* Quick South Pole Highlight */}
        <div className="p-4 bg-[#0b1026]/80 border border-cyan-400/35 rounded-2xl text-xs text-indigo-100 leading-relaxed mb-5 space-y-1.5">
          <div className="font-bold text-cyan-300 text-sm">
            Why Shackleton Crater?
          </div>
          <p>
            Unlike the Moon’s equator (14 days light, 14 days dark), Shackleton Crater’s rim gets sunlight <strong>70%–86% of the year</strong>—perfect for solar power, while its icy shadows hold frozen water!
          </p>
        </div>

        {/* Scientific References List */}
        <div className="space-y-3 mb-5">
          <div className="text-xs font-bold uppercase tracking-wider text-indigo-300">
            NASA Sources
          </div>

          {SCIENCE_REFERENCES.map((ref, idx) => (
            <div
              key={idx}
              className="p-3.5 bg-[#0b1026]/80 rounded-2xl border border-indigo-500/30 flex flex-col gap-1.5"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="font-bold text-sm text-white">{ref.title}</div>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shrink-0">
                  {ref.category}
                </span>
              </div>

              <p className="text-xs text-indigo-200 leading-snug line-clamp-2">{ref.summary}</p>

              <div className="text-[11px] font-mono text-indigo-300 pt-1 border-t border-indigo-500/20 flex items-center justify-between">
                <span className="truncate">{ref.citation}</span>
                <a
                  href={ref.nasaSourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-cyan-300 hover:text-cyan-200 font-bold flex items-center gap-1 shrink-0 ml-2"
                >
                  <span>NASA</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-indigo-500/30 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-indigo-900/80 hover:bg-indigo-800 text-white text-xs font-bold rounded-xl border border-indigo-400/40 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
