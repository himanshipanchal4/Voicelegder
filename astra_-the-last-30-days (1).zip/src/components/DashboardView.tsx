/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Wind,
  Droplet,
  Coffee,
  Zap,
  Activity,
  Shield,
  Sun,
  AlertCircle,
  Clock,
  ArrowRight,
  TrendingDown,
  TrendingUp,
  Box,
  Radio,
  Cpu,
  Award
} from 'lucide-react';
import { MissionState, DailyResourceDeltas } from '../types/mission';
import { getNextUpcomingBadge } from '../data/badgeData';

interface DashboardViewProps {
  state: MissionState;
  dailyDeltas: DailyResourceDeltas;
  onAdvanceDay: () => void;
  onOpenDecision: () => void;
  onOpenEmergency: () => void;
  onOpen3DView: () => void;
  onOpenDiscovery?: () => void;
  onOpenBadges?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  state,
  dailyDeltas,
  onAdvanceDay,
  onOpenDecision,
  onOpenEmergency,
  onOpen3DView,
  onOpenDiscovery,
  onOpenBadges,
}) => {
  const { resources, crew, modules, history, logs, day, solarAngleDeg, isLunarNight, surfaceTempC } = state;

  // Safe reserve calculations (days of supply left)
  const daysO2Left = dailyDeltas.netOxygen < 0 ? Math.floor(resources.oxygenKg / Math.abs(dailyDeltas.netOxygen)) : 999;
  const daysH2OLeft = dailyDeltas.netWater < 0 ? Math.floor(resources.waterLiters / Math.abs(dailyDeltas.netWater)) : 999;
  const daysFoodLeft = dailyDeltas.netFood < 0 ? Math.floor(resources.foodPacks / Math.abs(dailyDeltas.netFood)) : 999;
  const daysPowerLeft = dailyDeltas.netPower < 0 ? Math.floor(resources.powerKwh / Math.abs(dailyDeltas.netPower)) : 999;

  // Average crew metrics
  const avgHealth = Math.round(crew.reduce((acc, c) => acc + c.health, 0) / crew.length);
  const avgMorale = Math.round(crew.reduce((acc, c) => acc + c.morale, 0) / crew.length);

  return (
    <div className="w-full max-w-7xl mx-auto p-3 sm:p-6 space-y-6 select-none overflow-x-hidden">
      {/* Top Banner: Mission Elapsed & Day Progress */}
      <div className="bg-[#121a3e]/95 border border-indigo-400/40 rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-4 shadow-xl shadow-indigo-950/40">
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-400/25 to-violet-500/25 border border-cyan-400/50 flex flex-col items-center justify-center shrink-0">
            <span className="text-[10px] font-bold text-cyan-300 uppercase leading-none">DAY</span>
            <span className="text-2xl font-extrabold font-mono text-white tabular-nums leading-none mt-1">
              {day}
            </span>
          </div>

          <div className="flex-1">
            <div className="flex items-center justify-between gap-2 max-w-sm">
              <div className="flex items-center gap-2">
                <span className="font-display text-base font-bold text-white">Mission Progress</span>
                <span className="text-xs font-mono text-cyan-300 font-semibold">({day} / 30 days)</span>
              </div>
              {onOpenBadges && (
                <button
                  onClick={onOpenBadges}
                  className="flex items-center gap-1 text-xs font-bold text-amber-300 hover:text-amber-200 transition-colors cursor-pointer"
                  title="View ASTRA Badges"
                >
                  <Award className="w-3.5 h-3.5 text-amber-400" />
                  <span>{state.unlockedBadges?.length || 0}/6 Badges</span>
                </button>
              )}
            </div>
            {/* Progress bar */}
            <div className="w-full sm:w-80 h-2.5 bg-[#0b1026] rounded-full overflow-hidden mt-2 border border-indigo-500/30">
              <div
                className="h-full bg-gradient-to-r from-cyan-400 via-violet-400 to-emerald-400 transition-all duration-500 rounded-full"
                style={{ width: `${(day / 30) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Environmental conditions readout */}
        <div className="flex items-center gap-5 sm:gap-6 text-xs font-mono text-indigo-100 w-full md:w-auto justify-between md:justify-end border-t md:border-t-0 border-indigo-500/30 pt-3 md:pt-0">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-amber-500/15 border border-amber-400/30">
              <Sun className={`w-4 h-4 ${isLunarNight ? 'text-amber-300' : 'text-yellow-300'}`} />
            </div>
            <div>
              <div className="text-[10px] text-indigo-300 uppercase">SUNLIGHT</div>
              <div className="font-bold text-white">{solarAngleDeg}°</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-500/15 border border-emerald-400/30">
              <Activity className="w-4 h-4 text-emerald-300" />
            </div>
            <div>
              <div className="text-[10px] text-indigo-300 uppercase">MOON TEMP</div>
              <div className="font-bold text-white">{surfaceTempC}°C</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-cyan-500/15 border border-cyan-400/30">
              <Shield className="w-4 h-4 text-cyan-300" />
            </div>
            <div>
              <div className="text-[10px] text-indigo-300 uppercase">BASE SHIELD</div>
              <div className="font-bold text-white">{Math.round(resources.baseIntegrity)}%</div>
            </div>
          </div>
        </div>
      </div>

      {/* Action Prompt Banner: Pending Decision or Emergency */}
      {state.activeEmergency && (
        <div className="bg-rose-950/90 border border-rose-400/70 rounded-2xl p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 animate-fade-in shadow-lg shadow-rose-950/50">
          <div className="flex items-center gap-3">
            <AlertCircle className="w-6 h-6 text-rose-300 shrink-0" />
            <div>
              <div className="text-xs font-bold uppercase text-rose-300 tracking-wider">
                BASE ALERT · NEEDS HELP
              </div>
              <div className="text-sm font-bold text-white">{state.activeEmergency.title}</div>
            </div>
          </div>
          <button
            onClick={onOpenEmergency}
            className="w-full sm:w-auto px-4 py-2.5 sm:py-2 bg-gradient-to-r from-rose-500 to-orange-500 hover:brightness-110 text-white text-xs font-extrabold rounded-xl shadow-md transition-all shrink-0 cursor-pointer"
          >
            Fix Base Alert
          </button>
        </div>
      )}

      {state.activeDecision && !state.activeEmergency && (
        <div className="bg-[#15224f] border border-cyan-400/50 rounded-2xl p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 shadow-lg">
          <div className="flex items-center gap-3">
            <Cpu className="w-6 h-6 text-cyan-300 shrink-0" />
            <div>
              <div className="text-xs font-bold uppercase text-cyan-300 tracking-wider">
                TODAY’S CHOICE READY
              </div>
              <div className="text-sm font-bold text-white">{state.activeDecision.title}</div>
            </div>
          </div>
          <button
            onClick={onOpenDecision}
            className="w-full sm:w-auto px-4 py-2.5 sm:py-2 bg-gradient-to-r from-cyan-400 to-sky-400 hover:brightness-110 text-slate-950 text-xs font-extrabold rounded-xl shadow-md transition-all shrink-0 cursor-pointer"
          >
            Make Choice
          </button>
        </div>
      )}

      {/* 4 Core Life-Support Consumables Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Oxygen */}
        <div className="bg-[#121a3e]/95 border border-cyan-400/40 rounded-2xl p-4 relative overflow-hidden shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-cyan-300 font-bold">
              <Wind className="w-4 h-4" />
              <span className="text-xs uppercase tracking-wider">Oxygen</span>
            </div>
            <span className="text-[11px] font-mono text-cyan-200/80">
              {daysO2Left > 50 ? '>50 days' : `${daysO2Left}d left`}
            </span>
          </div>

          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-3xl font-extrabold font-mono text-white tabular-nums">
              {resources.oxygenKg.toFixed(1)}
            </span>
            <span className="text-xs text-indigo-300 font-mono">/ 200 kg</span>
          </div>

          <div className="w-full h-2 bg-[#0b1026] rounded-full overflow-hidden mb-3">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                resources.oxygenKg < 40 ? 'bg-rose-500' : 'bg-gradient-to-r from-cyan-400 to-sky-400'
              }`}
              style={{ width: `${(resources.oxygenKg / 200) * 100}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-xs font-mono text-indigo-200 pt-2 border-t border-indigo-500/25">
            <span>Daily Change:</span>
            <span className={dailyDeltas.netOxygen < 0 ? 'text-amber-300 flex items-center gap-1 font-bold' : 'text-emerald-300 flex items-center gap-1 font-bold'}>
              {dailyDeltas.netOxygen < 0 ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
              {dailyDeltas.netOxygen > 0 ? `+${dailyDeltas.netOxygen}` : dailyDeltas.netOxygen} kg/d
            </span>
          </div>
        </div>

        {/* Water */}
        <div className="bg-[#121a3e]/95 border border-blue-400/40 rounded-2xl p-4 relative overflow-hidden shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-blue-300 font-bold">
              <Droplet className="w-4 h-4" />
              <span className="text-xs uppercase tracking-wider">Water</span>
            </div>
            <span className="text-[11px] font-mono text-blue-200/80">
              {daysH2OLeft > 50 ? '>50 days' : `${daysH2OLeft}d left`}
            </span>
          </div>

          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-3xl font-extrabold font-mono text-white tabular-nums">
              {resources.waterLiters.toFixed(1)}
            </span>
            <span className="text-xs text-indigo-300 font-mono">/ 250 L</span>
          </div>

          <div className="w-full h-2 bg-[#0b1026] rounded-full overflow-hidden mb-3">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                resources.waterLiters < 40 ? 'bg-rose-500' : 'bg-gradient-to-r from-blue-400 to-indigo-400'
              }`}
              style={{ width: `${(resources.waterLiters / 250) * 100}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-xs font-mono text-indigo-200 pt-2 border-t border-indigo-500/25">
            <span>Daily Change:</span>
            <span className={dailyDeltas.netWater < 0 ? 'text-amber-300 flex items-center gap-1 font-bold' : 'text-emerald-300 flex items-center gap-1 font-bold'}>
              {dailyDeltas.netWater < 0 ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
              {dailyDeltas.netWater > 0 ? `+${dailyDeltas.netWater}` : dailyDeltas.netWater} L/d
            </span>
          </div>
        </div>

        {/* Food */}
        <div className="bg-[#121a3e]/95 border border-amber-400/40 rounded-2xl p-4 relative overflow-hidden shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-amber-300 font-bold">
              <Coffee className="w-4 h-4" />
              <span className="text-xs uppercase tracking-wider">Food</span>
            </div>
            <span className="text-[11px] font-mono text-amber-200/80">
              {daysFoodLeft > 40 ? '>40 days' : `${daysFoodLeft}d left`}
            </span>
          </div>

          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-3xl font-extrabold font-mono text-white tabular-nums">
              {Math.round(resources.foodPacks)}
            </span>
            <span className="text-xs text-indigo-300 font-mono">/ 200 packs</span>
          </div>

          <div className="w-full h-2 bg-[#0b1026] rounded-full overflow-hidden mb-3">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                resources.foodPacks < 30 ? 'bg-rose-500' : 'bg-gradient-to-r from-amber-400 to-orange-400'
              }`}
              style={{ width: `${(resources.foodPacks / 200) * 100}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-xs font-mono text-indigo-200 pt-2 border-t border-indigo-500/25">
            <span>Daily Change:</span>
            <span className={dailyDeltas.netFood < 0 ? 'text-amber-300 flex items-center gap-1 font-bold' : 'text-emerald-300 flex items-center gap-1 font-bold'}>
              {dailyDeltas.netFood < 0 ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
              {dailyDeltas.netFood} packs/d
            </span>
          </div>
        </div>

        {/* Energy Storage */}
        <div className="bg-[#121a3e]/95 border border-emerald-400/40 rounded-2xl p-4 relative overflow-hidden shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-emerald-300 font-bold">
              <Zap className="w-4 h-4" />
              <span className="text-xs uppercase tracking-wider">Power</span>
            </div>
            <span className="text-[11px] font-mono text-emerald-200/80">
              {dailyDeltas.netPower >= 0 ? 'Charging' : `${daysPowerLeft}d left`}
            </span>
          </div>

          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-3xl font-extrabold font-mono text-white tabular-nums">
              {Math.round(resources.powerKwh)}
            </span>
            <span className="text-xs text-indigo-300 font-mono">/ 300 kWh</span>
          </div>

          <div className="w-full h-2 bg-[#0b1026] rounded-full overflow-hidden mb-3">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                resources.powerKwh < 60 ? 'bg-rose-500' : 'bg-gradient-to-r from-emerald-400 to-teal-300'
              }`}
              style={{ width: `${(resources.powerKwh / 300) * 100}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-xs font-mono text-indigo-200 pt-2 border-t border-indigo-500/25">
            <span>Daily Change:</span>
            <span className={dailyDeltas.netPower < 0 ? 'text-amber-300 flex items-center gap-1 font-bold' : 'text-emerald-300 flex items-center gap-1 font-bold'}>
              {dailyDeltas.netPower < 0 ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
              {dailyDeltas.netPower > 0 ? `+${dailyDeltas.netPower}` : dailyDeltas.netPower} kWh/d
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Crew & Modules vs History Chart & Log */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Telemetry Chart & Activity Log */}
        <div className="lg:col-span-2 space-y-6">
          {/* Historical Trend Multi-Series Chart */}
          <div className="bg-[#121a3e]/95 border border-indigo-400/35 rounded-2xl p-5 shadow-lg">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <div>
                <div className="text-xs font-bold uppercase text-indigo-300">Supply Tracker</div>
                <div className="font-display text-base font-bold text-white">Air, Water & Power Trend</div>
              </div>
              <div className="flex items-center gap-4 text-xs font-bold">
                <span className="text-cyan-300">● Oxygen</span>
                <span className="text-blue-300">● Water</span>
                <span className="text-emerald-300">● Power</span>
              </div>
            </div>

            {/* Responsive SVG Line Chart */}
            <div className="w-full h-48 relative bg-[#0b1026]/70 rounded-xl p-2 border border-indigo-500/20">
              <svg className="w-full h-full overflow-visible" viewBox="0 0 500 160" preserveAspectRatio="none">
                <line x1="0" y1="40" x2="500" y2="40" stroke="#312e81" strokeDasharray="3 3" />
                <line x1="0" y1="80" x2="500" y2="80" stroke="#312e81" strokeDasharray="3 3" />
                <line x1="0" y1="120" x2="500" y2="120" stroke="#312e81" strokeDasharray="3 3" />

                {history.length > 1 ? (
                  <>
                    <path
                      d={generateSvgPath(history, 'oxygen', 200, 160, 500)}
                      fill="none"
                      stroke="#22d3ee"
                      strokeWidth="2.5"
                    />
                    <path
                      d={generateSvgPath(history, 'water', 250, 160, 500)}
                      fill="none"
                      stroke="#60a5fa"
                      strokeWidth="2.5"
                    />
                    <path
                      d={generateSvgPath(history, 'power', 300, 160, 500)}
                      fill="none"
                      stroke="#34d399"
                      strokeWidth="2.5"
                    />
                  </>
                ) : (
                  <text x="250" y="80" textAnchor="middle" fill="#a5b4fc" fontSize="12" fontFamily="monospace">
                    Play Day 1 to see your supply chart grow!
                  </text>
                )}
              </svg>
            </div>
            <div className="flex justify-between text-[11px] font-mono text-indigo-300 mt-2">
              <span>Day 1</span>
              <span>Day 15 (Halfway!)</span>
              <span>Day 30 (Finish!)</span>
            </div>
          </div>

          {/* Mission Activity & Diagnostic Log */}
          <div className="bg-[#121a3e]/95 border border-indigo-400/35 rounded-2xl p-5 shadow-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-cyan-300" />
                <span className="font-display text-sm font-bold text-white">
                  Mission Adventure Log
                </span>
              </div>
              <span className="text-[11px] font-mono text-indigo-300">Latest Updates</span>
            </div>

            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {logs.map((log) => (
                <div
                  key={log.id}
                  className="flex items-start gap-2.5 p-2.5 rounded-xl bg-[#0b1026]/80 border border-indigo-500/25 text-xs"
                >
                  <span className="font-mono text-cyan-300 font-bold text-[11px] shrink-0">
                    [D{log.day}]
                  </span>
                  <span
                    className={`flex-1 ${
                      log.type === 'crit'
                        ? 'text-rose-300 font-semibold'
                        : log.type === 'warn'
                        ? 'text-amber-300'
                        : log.type === 'success'
                        ? 'text-emerald-300 font-medium'
                        : 'text-indigo-100'
                    }`}
                  >
                    {log.message}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Crew Vitals & Subsystems summary */}
        <div className="space-y-6">
          {/* Crew Status Card */}
          <div className="bg-[#121a3e]/95 border border-violet-400/40 rounded-2xl p-5 shadow-lg">
            <div className="flex items-center justify-between mb-4 gap-2 flex-wrap">
              <div>
                <div className="text-xs font-bold uppercase text-violet-300">Astronaut Squad</div>
                <div className="font-display text-base font-bold text-white">Crew Health & Mood</div>
              </div>
              <div className="text-xs font-mono text-indigo-200">
                Health: <strong className="text-cyan-300">{avgHealth}%</strong> · Mood:{' '}
                <strong className="text-emerald-300">{avgMorale}%</strong>
              </div>
            </div>

            <div className="space-y-2.5">
              {crew.map((member) => (
                <div key={member.id} className="p-3 bg-[#0b1026]/85 rounded-xl border border-indigo-500/30">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">{member.name}</span>
                    <span className="text-[10px] font-mono font-bold text-cyan-300">{member.callsign}</span>
                  </div>
                  <div className="text-[11px] text-indigo-300 truncate">{member.role}</div>

                  <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-indigo-500/20 text-[11px] font-mono">
                    <div>
                      <span className="text-indigo-300">Health: </span>
                      <span className={member.health < 40 ? 'text-rose-400 font-bold' : 'text-emerald-300 font-bold'}>
                        {member.health}%
                      </span>
                    </div>
                    <div>
                      <span className="text-indigo-300">Mood: </span>
                      <span className="text-cyan-300 font-bold">{member.morale}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Outpost Subsystems Quick Strip */}
          <div className="bg-[#121a3e]/95 border border-indigo-400/35 rounded-2xl p-5 shadow-lg">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-xs font-bold uppercase text-indigo-300">Moon Rooms</div>
                <div className="font-display text-base font-bold text-white">6 Base Buildings</div>
              </div>
              <button
                onClick={onOpen3DView}
                className="text-xs font-bold text-cyan-300 hover:text-cyan-200 flex items-center gap-1 cursor-pointer"
              >
                <Box className="w-3.5 h-3.5" />
                <span>View 3D Base</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {modules.map((m) => (
                <div key={m.id} className="p-2.5 bg-[#0b1026]/85 rounded-xl border border-indigo-500/25 text-xs">
                  <div className="font-bold text-white truncate">{m.shortName}</div>
                  <div className="flex items-center justify-between mt-1 text-[11px] font-mono">
                    <span className="text-indigo-300">{m.efficiency}%</span>
                    <span className={m.status === 'nominal' ? 'text-emerald-300 font-bold' : 'text-amber-300 font-bold'}>
                      {m.status === 'nominal' ? 'Ready' : m.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Advance to Next Day Primary Action */}
          <div className="bg-gradient-to-br from-[#162250] to-[#11183c] border border-cyan-400/50 rounded-2xl p-5 shadow-xl">
            <div className="font-display text-lg font-extrabold text-white mb-3">Day {day + 1} Ready</div>

            {onOpenDiscovery && (
              <button
                onClick={onOpenDiscovery}
                className="w-full flex items-center justify-center gap-2 py-2.5 mb-2.5 bg-gradient-to-r from-amber-500/25 to-orange-500/25 hover:from-amber-500/35 hover:to-orange-500/35 border border-amber-400/50 text-amber-200 text-xs font-extrabold rounded-xl shadow-sm transition-all cursor-pointer"
              >
                <Zap className="w-4 h-4 text-amber-300" />
                <span>Space Quiz (+50 Pts)</span>
              </button>
            )}

            <button
              onClick={onAdvanceDay}
              className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400 hover:brightness-110 text-slate-950 font-extrabold text-xs sm:text-sm rounded-xl shadow-lg shadow-cyan-500/25 transition-all hover:-translate-y-0.5 cursor-pointer"
            >
              <span>Launch Day {day + 1} / 30</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper to generate SVG path for history charts
function generateSvgPath(
  history: MissionState['history'],
  key: 'oxygen' | 'water' | 'food' | 'power',
  maxVal: number,
  svgHeight: number,
  svgWidth: number
): string {
  if (history.length === 0) return '';
  const pts = history.map((entry, idx) => {
    const x = (idx / 29) * svgWidth;
    const val = entry[key];
    const y = svgHeight - (val / maxVal) * (svgHeight - 15) - 5;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  return `M ${pts.join(' L ')}`;
}
