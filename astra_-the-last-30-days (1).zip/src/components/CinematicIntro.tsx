/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ArrowRight, SkipForward, Sparkles } from 'lucide-react';
import { soundEngine } from '../services/soundEngine';

interface CinematicIntroProps {
  onComplete: () => void;
}

export const CinematicIntro: React.FC<CinematicIntroProps> = ({ onComplete }) => {
  const [stage, setStage] = useState<number>(0);
  const [fadeState, setFadeState] = useState<'in' | 'out'>('in');

  const messages = [
    {
      kicker: 'LUNAR SOUTH POLE · 89.9°S',
      heading: '30 DAYS. ONE MOON. FOUR LIVES.',
      detail: 'In the deep vacuum of Shackleton Crater, survival is not guaranteed.',
    },
    {
      kicker: 'CRITICAL EXPEDITION PROTOCOL',
      heading: 'Your crew is counting on you.',
      detail: 'Every drop of recycled water, every amp of solar charge, every breath of oxygen.',
    },
    {
      kicker: 'EXPEDITION OUTPOST ONLINE',
      heading: 'Welcome to ASTRA.',
      detail: 'Command the frontier. Protect the lives entrusted to you.',
    },
  ];

  useEffect(() => {
    soundEngine.playTelemetryClick();
    const timer1 = setTimeout(() => {
      setFadeState('out');
      setTimeout(() => {
        setStage(1);
        setFadeState('in');
        soundEngine.playConfirm();
      }, 600);
    }, 4200);

    const timer2 = setTimeout(() => {
      setFadeState('out');
      setTimeout(() => {
        setStage(2);
        setFadeState('in');
        soundEngine.playConfirm();
      }, 600);
    }, 8800);

    const timer3 = setTimeout(() => {
      setStage(3); // Final readiness screen
    }, 13200);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, []);

  const handleSkip = () => {
    soundEngine.playConfirm();
    onComplete();
  };

  const currentMsg = messages[Math.min(stage, messages.length - 1)];

  return (
    <div className="fixed inset-0 z-50 bg-[#04060a] text-slate-100 flex flex-col justify-between p-6 sm:p-12 overflow-hidden select-none">
      {/* Dynamic Animated Starfield & Distant Earth */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Procedural Stars */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-950/20 via-[#04060a] to-[#04060a]" />
        
        {/* Approaching Moon Silhouette */}
        <div
          className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full transition-all duration-[6000ms] ease-out pointer-events-none ${
            stage === 0
              ? 'w-[280px] h-[280px] opacity-40 shadow-[0_0_80px_rgba(34,211,238,0.15)] bg-gradient-to-br from-slate-700 via-slate-800 to-slate-950'
              : stage === 1
              ? 'w-[520px] h-[520px] opacity-75 shadow-[0_0_120px_rgba(34,211,238,0.25)] bg-gradient-to-br from-slate-600 via-slate-800 to-slate-950'
              : 'w-[900px] h-[900px] opacity-90 shadow-[0_0_160px_rgba(34,211,238,0.35)] bg-gradient-to-br from-slate-700 via-slate-900 to-slate-950'
          }`}
        >
          {/* Crater details on moon */}
          <div className="absolute top-[28%] left-[32%] w-16 h-16 rounded-full border border-slate-700/60 bg-slate-900/60" />
          <div className="absolute top-[52%] left-[60%] w-24 h-24 rounded-full border border-slate-700/60 bg-slate-900/60" />
          <div className="absolute bottom-[20%] left-[45%] w-12 h-12 rounded-full border border-slate-700/60 bg-slate-900/60" />
        </div>

        {/* Small Distant Glowing Earth in upper right */}
        <div className="absolute top-12 right-16 flex items-center gap-3 opacity-80">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 via-cyan-400 to-emerald-400 shadow-[0_0_20px_rgba(59,130,246,0.6)]" />
          <span className="text-[10px] font-mono tracking-widest text-blue-300 hidden sm:inline">
            EARTH · 384,400 KM
          </span>
        </div>

        {/* Landing Spacecraft Thruster vector */}
        <div
          className={`absolute left-1/2 transition-all duration-1000 ${
            stage >= 2 ? 'bottom-[32%] opacity-100 scale-100' : 'bottom-[10%] opacity-0 scale-50'
          } -translate-x-1/2 flex flex-col items-center`}
        >
          {/* Lander hull */}
          <div className="w-10 h-8 rounded-t-xl bg-slate-300 border border-slate-400 flex items-center justify-center text-[8px] font-mono text-slate-900 font-bold">
            ASTRA
          </div>
          {/* Blue thruster flame */}
          <div className="w-3 h-10 bg-gradient-to-b from-cyan-400 via-blue-500 to-transparent blur-[1px] animate-pulse" />
        </div>
      </div>

      {/* Top Bar with Skip Intro */}
      <div className="relative z-10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
          <span className="text-xs font-mono uppercase tracking-widest text-cyan-400">
            CINEMATIC ARRIVAL SEQUENCE
          </span>
        </div>

        <button
          onClick={handleSkip}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-800 bg-slate-900/80 hover:bg-slate-800 text-xs text-slate-300 hover:text-slate-100 transition-colors cursor-pointer"
        >
          <span>Skip Intro</span>
          <SkipForward className="w-3.5 h-3.5 text-cyan-400" />
        </button>
      </div>

      {/* Central Dramatic Message Projection */}
      <div className="relative z-10 max-w-2xl mx-auto text-center my-auto px-4">
        <div
          className={`transition-all duration-700 ease-out transform ${
            fadeState === 'in' ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <div className="text-xs sm:text-sm font-mono text-cyan-400 tracking-[0.25em] uppercase mb-4">
            {currentMsg.kicker}
          </div>

          <h1 className="text-3xl sm:text-5xl md:text-6xl font-black text-slate-100 tracking-tight leading-tight mb-4 drop-shadow-2xl">
            {currentMsg.heading}
          </h1>

          <p className="text-sm sm:text-lg text-slate-300 leading-relaxed font-light max-w-xl mx-auto">
            {currentMsg.detail}
          </p>
        </div>
      </div>

      {/* Bottom Progress Bar & Ready CTA */}
      <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-slate-900">
        <div className="flex items-center gap-2">
          {[0, 1, 2].map((s) => (
            <div
              key={s}
              className={`h-1.5 rounded-full transition-all duration-500 ${
                s <= stage ? 'w-8 bg-cyan-400' : 'w-3 bg-slate-800'
              }`}
            />
          ))}
          <span className="text-xs font-mono text-slate-500 ml-2">Phase {Math.min(stage + 1, 3)}/3</span>
        </div>

        <button
          onClick={handleSkip}
          className="flex items-center gap-2 px-6 py-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm rounded-lg shadow-lg shadow-cyan-500/25 transition-all hover:translate-y-[-1px] cursor-pointer"
        >
          <span>Begin Mission Command</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
