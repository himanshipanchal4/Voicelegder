/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  AlertTriangle,
  RotateCcw,
  X,
  Download,
  CheckCircle2,
  Calendar,
  Wind,
  Users,
  Award,
} from 'lucide-react';
import { MissionState } from '../types/mission';
import { storageService } from '../services/storageService';
import { soundEngine } from '../services/soundEngine';

interface RestartConfirmationModalProps {
  isOpen: boolean;
  currentMission?: MissionState | null;
  onCancel: () => void;
  onConfirmRestart: () => void;
  isProcessing?: boolean;
}

export const RestartConfirmationModal: React.FC<RestartConfirmationModalProps> = ({
  isOpen,
  currentMission,
  onCancel,
  onConfirmRestart,
  isProcessing = false,
}) => {
  const [hasExportedBackup, setHasExportedBackup] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleExport = () => {
    soundEngine.playTelemetryClick();
    if (currentMission) {
      const ok = storageService.exportMissionBackup(currentMission);
      if (ok) setHasExportedBackup(true);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-[#060919]/88 backdrop-blur-md select-none overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="restart-modal-heading"
    >
      <div className="relative w-full max-w-xl bg-[#121a3e] border-2 border-amber-400/60 rounded-3xl shadow-2xl overflow-hidden my-auto animate-fade-in flex flex-col max-h-[92vh]">
        <div className="h-1.5 w-full bg-gradient-to-r from-amber-400 via-rose-500 to-fuchsia-500" />

        {/* Header */}
        <div className="p-5 border-b border-indigo-400/25 flex items-start justify-between gap-4 bg-indigo-950/60">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-400/60 flex items-center justify-center text-amber-300 shrink-0 shadow-lg">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              {currentMission && (
                <span className="text-[11px] font-bold text-amber-300 uppercase tracking-wider block">
                  Currently on Day {currentMission.day} of 30
                </span>
              )}
              <h2
                id="restart-modal-heading"
                className="font-display text-xl font-extrabold text-white tracking-tight"
              >
                Start a Fresh Mission?
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playTelemetryClick();
              onCancel();
            }}
            disabled={isProcessing}
            className="p-2 rounded-xl border border-indigo-400/30 bg-[#0b1026] hover:bg-indigo-800 text-indigo-200 hover:text-white transition-colors cursor-pointer shrink-0"
            title="Cancel"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 flex-1">
          <p className="text-sm text-indigo-100 leading-snug">
            Restarting resets all Moon supplies, health, badges, and quizzes back to Day 1 so you can play a fresh adventure!
          </p>

          <div className="grid grid-cols-2 gap-2.5 text-xs">
            <div className="p-3 rounded-2xl bg-[#0c1330] border border-indigo-400/25 flex items-center gap-2.5">
              <Calendar className="w-4 h-4 text-cyan-300 shrink-0" />
              <span className="font-semibold text-indigo-100">Resets to Day 1</span>
            </div>
            <div className="p-3 rounded-2xl bg-[#0c1330] border border-indigo-400/25 flex items-center gap-2.5">
              <Wind className="w-4 h-4 text-emerald-300 shrink-0" />
              <span className="font-semibold text-indigo-100">Full Air, Water, Food &amp; Power</span>
            </div>
            <div className="p-3 rounded-2xl bg-[#0c1330] border border-indigo-400/25 flex items-center gap-2.5">
              <Users className="w-4 h-4 text-violet-300 shrink-0" />
              <span className="font-semibold text-indigo-100">100% Crew Health</span>
            </div>
            <div className="p-3 rounded-2xl bg-[#0c1330] border border-indigo-400/25 flex items-center gap-2.5">
              <Award className="w-4 h-4 text-amber-300 shrink-0" />
              <span className="font-semibold text-indigo-100">Badges &amp; Score Reset</span>
            </div>
          </div>

          {currentMission && currentMission.day > 1 && (
            <div className="p-3.5 rounded-2xl bg-[#0c1330]/90 border border-indigo-400/30 flex items-center justify-between gap-3">
              <span className="text-xs text-indigo-200 font-medium">
                Want to save a copy of your mission log first?
              </span>
              <button
                type="button"
                onClick={handleExport}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-cyan-400/50 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 font-bold text-xs transition-colors cursor-pointer shrink-0"
              >
                {hasExportedBackup ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                    <span>Saved!</span>
                  </>
                ) : (
                  <>
                    <Download className="w-3.5 h-3.5" />
                    <span>Save Backup</span>
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-5 bg-indigo-950/60 border-t border-indigo-400/25 flex flex-col-reverse sm:flex-row sm:items-center justify-end gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => {
              soundEngine.playTelemetryClick();
              onCancel();
            }}
            disabled={isProcessing}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-indigo-400/40 bg-[#0c1330] hover:bg-indigo-900 text-indigo-100 text-xs font-bold transition-colors cursor-pointer"
          >
            Keep Playing
          </button>

          <button
            type="button"
            onClick={() => {
              soundEngine.playWarning();
              onConfirmRestart();
            }}
            disabled={isProcessing}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500 hover:brightness-110 text-slate-950 text-xs font-extrabold shadow-lg transition-all cursor-pointer active:scale-95"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${isProcessing ? 'animate-spin' : ''}`} />
            <span>{isProcessing ? 'Resetting...' : 'Yes, Restart Day 1'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
