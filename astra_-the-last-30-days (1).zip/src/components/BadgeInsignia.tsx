/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BadgeDefinition } from '../data/badgeData';
import { Lock, Sparkles } from 'lucide-react';

interface BadgeInsigniaProps {
  badge: BadgeDefinition;
  isUnlocked?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  isNewlyEarned?: boolean;
  onClick?: () => void;
  showTitle?: boolean;
}

export const BadgeInsignia: React.FC<BadgeInsigniaProps> = ({
  badge,
  isUnlocked = true,
  size = 'md',
  isNewlyEarned = false,
  onClick,
  showTitle = false,
}) => {
  const { id, level, romanNumeral, title, palette, starsCount } = badge;

  // Sizing mappings
  const dimensionPx = size === 'sm' ? 56 : size === 'md' ? 96 : size === 'lg' ? 148 : 220;
  const viewBoxSize = 200;

  return (
    <div
      onClick={onClick}
      className={`relative inline-flex flex-col items-center justify-center select-none ${
        onClick ? 'cursor-pointer group' : ''
      }`}
    >
      {/* Outer Glow Halo when unlocked or newly earned */}
      {isUnlocked && (
        <div
          className={`absolute rounded-full blur-xl pointer-events-none transition-all duration-500 ${
            isNewlyEarned
              ? 'opacity-80 scale-125 animate-pulse'
              : 'opacity-30 group-hover:opacity-70 group-hover:scale-110'
          }`}
          style={{
            width: `${dimensionPx}px`,
            height: `${dimensionPx}px`,
            backgroundColor: palette.accent,
          }}
        />
      )}

      {/* SVG NASA-Inspired Mission Patch */}
      <svg
        width={dimensionPx}
        height={dimensionPx}
        viewBox={`0 0 ${viewBoxSize} ${viewBoxSize}`}
        className={`relative z-10 transition-transform duration-300 drop-shadow-xl ${
          onClick ? 'group-hover:scale-105 group-hover:-translate-y-1' : ''
        } ${!isUnlocked ? 'filter grayscale contrast-75 opacity-60' : ''}`}
      >
        <defs>
          {/* Outer Metallic Rim Gradient */}
          <linearGradient id={`rimGrad-${id}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={palette.rimGrad[0]} />
            <stop offset="50%" stopColor={palette.rimGrad[1]} />
            <stop offset="100%" stopColor={palette.rimGrad[2]} />
          </linearGradient>

          {/* Badge Dark Background Gradient */}
          <radialGradient id={`bgGrad-${id}`} cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor={palette.bgGrad[0]} />
            <stop offset="100%" stopColor={palette.bgGrad[1]} />
          </radialGradient>

          {/* Accent Gold/Cyan Gradient */}
          <linearGradient id={`accentGrad-${id}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={palette.accent} />
            <stop offset="100%" stopColor={palette.secondary} />
          </linearGradient>

          {/* Moon Surface Gradient */}
          <linearGradient id={`moonGrad-${id}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#e2e8f0" />
            <stop offset="70%" stopColor="#94a3b8" />
            <stop offset="100%" stopColor="#475569" />
          </linearGradient>

          {/* Earth Marble Gradient for Level VI */}
          <radialGradient id={`earthGrad-${id}`} cx="40%" cy="40%" r="60%">
            <stop offset="0%" stopColor="#38bdf8" />
            <stop offset="50%" stopColor="#0284c7" />
            <stop offset="90%" stopColor="#0369a1" />
            <stop offset="100%" stopColor="#082f49" />
          </radialGradient>
        </defs>

        {/* 1. OUTER METALLIC EMBROIDERED RIM */}
        <circle
          cx="100"
          cy="100"
          r="96"
          fill={`url(#rimGrad-${id})`}
          stroke={palette.border}
          strokeWidth="2"
        />

        {/* Technical Stitched Ring */}
        <circle
          cx="100"
          cy="100"
          r="92"
          fill="none"
          stroke={palette.primary}
          strokeWidth="1.5"
          strokeDasharray="4 2"
        />

        {/* Outer Dark Patch Inset */}
        <circle
          cx="100"
          cy="100"
          r="88"
          fill={palette.primary}
          stroke={palette.secondary}
          strokeWidth="1"
        />

        {/* Inner Sky Dome */}
        <circle
          cx="100"
          cy="100"
          r="82"
          fill={`url(#bgGrad-${id})`}
        />

        {/* 2. STARS PATTERN BASED ON STARS COUNT */}
        {starsCount >= 3 && (
          <g fill={palette.accent}>
            <polygon points="45,45 47,48 51,48 48,50 49,54 45,51 41,54 42,50 39,48 43,48" transform="scale(0.8) translate(10,10)" />
            <polygon points="155,45 157,48 161,48 158,50 159,54 155,51 151,54 152,50 149,48 153,48" transform="scale(0.8) translate(35,10)" />
            <polygon points="100,32 101.5,35 105,35 102,37 103,40 100,38 97,40 98,37 95,35 98.5,35" />
          </g>
        )}
        {starsCount >= 4 && (
          <circle cx="160" cy="80" r="2" fill="#ffffff" />
        )}
        {starsCount >= 5 && (
          <circle cx="40" cy="82" r="2" fill="#ffffff" />
        )}
        {starsCount >= 6 && (
          <g>
            <circle cx="60" cy="58" r="1.5" fill="#fef08a" />
            <circle cx="140" cy="58" r="1.5" fill="#fef08a" />
          </g>
        )}

        {/* 3. LEVEL SPECIFIC ARTWORK */}
        {level === 1 && (
          /* Level I: Silver Crescent Moon & Small Astronaut Silhouette */
          <g>
            {/* Elegant Crescent Moon */}
            <path
              d="M120 45 C150 70, 150 130, 120 155 C160 125, 160 75, 120 45 Z"
              fill={`url(#moonGrad-${id})`}
              stroke="#94a3b8"
              strokeWidth="1.5"
            />
            {/* Crater details on crescent */}
            <circle cx="132" cy="78" r="3" fill="#64748b" opacity="0.6" />
            <circle cx="136" cy="115" r="4" fill="#64748b" opacity="0.6" />
            {/* Astronaut Silhouette */}
            <g transform="translate(65, 85) scale(0.65)">
              {/* Helmet */}
              <circle cx="30" cy="20" r="10" fill="#f8fafc" />
              <ellipse cx="32" cy="20" rx="6" ry="7" fill="#0284c7" />
              {/* Torso & Backpack */}
              <rect x="22" y="30" width="16" height="24" rx="4" fill="#f8fafc" />
              <rect x="16" y="32" width="7" height="18" rx="2" fill="#94a3b8" />
              {/* Legs */}
              <line x1="26" y1="54" x2="22" y2="76" stroke="#f8fafc" strokeWidth="5" strokeLinecap="round" />
              <line x1="34" y1="54" x2="38" y2="76" stroke="#f8fafc" strokeWidth="5" strokeLinecap="round" />
            </g>
          </g>
        )}

        {level === 2 && (
          /* Level II: Moon with Spacecraft Orbiting along Trajectory Path */
          <g>
            {/* Central Moon Globe */}
            <circle cx="100" cy="100" r="38" fill={`url(#moonGrad-${id})`} stroke="#64748b" strokeWidth="1.5" />
            <circle cx="88" cy="88" r="7" fill="#64748b" opacity="0.5" />
            <circle cx="115" cy="110" r="9" fill="#64748b" opacity="0.5" />
            <circle cx="105" cy="80" r="4" fill="#64748b" opacity="0.5" />
            {/* Elliptical Orbital Path */}
            <ellipse
              cx="100"
              cy="100"
              rx="68"
              ry="26"
              fill="none"
              stroke={palette.accent}
              strokeWidth="2"
              strokeDasharray="6 3"
              transform="rotate(-25 100 100)"
            />
            {/* Orbiting Spacecraft Capsule */}
            <g transform="translate(142, 66) rotate(65) scale(0.7)">
              <polygon points="0,-12 8,6 -8,6" fill="#f8fafc" stroke="#3b82f6" strokeWidth="1" />
              {/* Solar panels */}
              <rect x="-20" y="0" width="12" height="6" fill="#38bdf8" stroke="#1d4ed8" strokeWidth="1" />
              <rect x="8" y="0" width="12" height="6" fill="#38bdf8" stroke="#1d4ed8" strokeWidth="1" />
            </g>
          </g>
        )}

        {level === 3 && (
          /* Level III: Detailed Lunar Polar Surface, Habitat Dome, & Seismometer Drill */
          <g>
            {/* Lunar Horizon Surface */}
            <path
              d="M20 125 Q60 115 100 120 T180 125 L180 180 L20 180 Z"
              fill={`url(#moonGrad-${id})`}
            />
            {/* Illuminated Crater Rim */}
            <ellipse cx="60" cy="138" rx="18" ry="6" fill="#475569" stroke="#94a3b8" strokeWidth="1" />
            {/* Geodesic Habitat Dome */}
            <path d="M105 120 C105 102 135 102 135 120 Z" fill="#f8fafc" stroke="#0891b2" strokeWidth="1.5" />
            <line x1="120" y1="102" x2="120" y2="120" stroke="#0891b2" strokeWidth="1" />
            {/* Scientific Instrument / Drill Tripod */}
            <line x1="82" y1="116" x2="74" y2="134" stroke="#67e8f9" strokeWidth="2" />
            <line x1="82" y1="116" x2="90" y2="134" stroke="#67e8f9" strokeWidth="2" />
            <line x1="82" y1="106" x2="82" y2="130" stroke="#f8fafc" strokeWidth="2" />
            <circle cx="82" cy="106" r="3" fill="#22d3ee" className="animate-pulse" />
          </g>
        )}

        {level === 4 && (
          /* Level IV: Lunar Habitat with Bifacial Solar Array Towers & Technical Gear Motif */
          <g>
            {/* Technical Mechanical Gear Teeth Ring */}
            <circle
              cx="100"
              cy="100"
              r="76"
              fill="none"
              stroke="#d97706"
              strokeWidth="3"
              strokeDasharray="8 6"
              opacity="0.75"
            />
            {/* Lunar Outpost Horizon */}
            <path d="M22 132 Q70 124 100 128 T178 132 L178 180 L22 180 Z" fill="#334155" />
            {/* Main Habitat Module */}
            <rect x="80" y="118" width="40" height="20" rx="6" fill="#f8fafc" stroke="#d97706" strokeWidth="1.5" />
            <circle cx="100" cy="128" r="4" fill="#38bdf8" />
            {/* Two Vertical Bifacial Solar Towers */}
            <line x1="58" y1="95" x2="58" y2="134" stroke="#94a3b8" strokeWidth="3" />
            <rect x="52" y="94" width="12" height="24" rx="2" fill="#38bdf8" stroke="#fef08a" strokeWidth="1.5" />
            <line x1="142" y1="95" x2="142" y2="134" stroke="#94a3b8" strokeWidth="3" />
            <rect x="136" y="94" width="12" height="24" rx="2" fill="#38bdf8" stroke="#fef08a" strokeWidth="1.5" />
          </g>
        )}

        {level === 5 && (
          /* Level V: Radiant Golden Lunar Horizon with Artemis Spacecraft Climbing */
          <g>
            {/* Radiating Sun Beams */}
            <path d="M100 120 L40 50 M100 120 L70 35 M100 120 L100 30 M100 120 L130 35 M100 120 L160 50" stroke="#fef08a" strokeWidth="1" opacity="0.4" />
            {/* Golden Lunar Horizon */}
            <path
              d="M20 130 C60 115, 140 115, 180 130 L180 180 L20 180 Z"
              fill="url(#accentGrad-badge-level-5)"
            />
            {/* Golden Crater Ridge */}
            <path d="M40 132 Q90 124 150 134" stroke="#fffbeb" strokeWidth="2" fill="none" />
            {/* Artemis Ascent Craft */}
            <g transform="translate(100, 68) scale(0.9)">
              {/* Rocket Exhaust Plume */}
              <polygon points="-4,22 4,22 0,38" fill="#f59e0b" className="animate-pulse" />
              {/* Vehicle Body */}
              <polygon points="0,-16 8,14 -8,14" fill="#ffffff" stroke="#d97706" strokeWidth="1.5" />
              {/* Solar Array Wings */}
              <rect x="-24" y="2" width="16" height="8" rx="1" fill="#38bdf8" stroke="#fef08a" strokeWidth="1" />
              <rect x="8" y="2" width="16" height="8" rx="1" fill="#38bdf8" stroke="#fef08a" strokeWidth="1" />
            </g>
          </g>
        )}

        {level === 6 && (
          /* Level VI: Supreme Lunar Pioneer Elite — Earth Rise, Astronaut, Shackleton Crater */
          <g>
            {/* Radiant Earth Rising Above Lunar Horizon */}
            <g transform="translate(100, 64)">
              <circle cx="0" cy="0" r="26" fill={`url(#earthGrad-${id})`} stroke="#f8fafc" strokeWidth="1.5" />
              {/* Swirling Clouds & Continents */}
              <path d="M-18,-8 C-10,-15 5,-12 16,-6 C10,2 -2,1 -14,6 Z" fill="#ffffff" opacity="0.75" />
              <path d="M-12,12 C-4,6 8,10 18,16 C12,22 -2,20 -10,18 Z" fill="#ffffff" opacity="0.7" />
              {/* Atmospheric Glow Ring */}
              <circle cx="0" cy="0" r="28" fill="none" stroke="#38bdf8" strokeWidth="1.5" opacity="0.6" className="animate-pulse" />
            </g>
            {/* Lunar Polar Landscape Slopes */}
            <path
              d="M18 126 C50 110, 80 120, 110 115 C140 110, 160 125, 182 124 L182 180 L18 180 Z"
              fill={`url(#moonGrad-${id})`}
              stroke="#cbd5e1"
              strokeWidth="1.5"
            />
            {/* Astronaut Planting Expedition Beacon */}
            <g transform="translate(68, 88) scale(0.6)">
              <circle cx="20" cy="15" r="9" fill="#ffffff" />
              <ellipse cx="22" cy="15" rx="5" ry="6" fill="#38bdf8" />
              <rect x="12" y="24" width="16" height="22" rx="3" fill="#ffffff" />
              <line x1="16" y1="46" x2="12" y2="68" stroke="#ffffff" strokeWidth="4.5" strokeLinecap="round" />
              <line x1="24" y1="46" x2="28" y2="68" stroke="#ffffff" strokeWidth="4.5" strokeLinecap="round" />
              {/* Expedition Beacon Flag */}
              <line x1="42" y1="18" x2="42" y2="68" stroke="#f8fafc" strokeWidth="2.5" />
              <polygon points="42,18 64,26 42,34" fill="#38bdf8" stroke="#ffffff" strokeWidth="1" />
            </g>
          </g>
        )}

        {/* 4. TOP RIBBON: ASTRA EXPEDITION */}
        <path
          d="M 50,42 A 75,75 0 0,1 150,42"
          fill="none"
          id={`textPath-${id}`}
        />
        <text
          fontSize="9.5"
          fontFamily="monospace"
          fontWeight="bold"
          letterSpacing="3"
          fill={palette.border}
          textAnchor="middle"
        >
          <textPath href={`#textPath-${id}`} startOffset="50%">
            ASTRA &bull; NASA INSPIRED
          </textPath>
        </text>

        {/* 5. BOTTOM BANNER: ROMAN NUMERAL TIER BADGE */}
        <g transform="translate(100, 168)">
          {/* Hexagonal / Octagonal Plaque */}
          <polygon
            points="-28,-10 28,-10 34,2 28,14 -28,14 -34,2"
            fill={palette.primary}
            stroke={palette.border}
            strokeWidth="2"
          />
          <text
            x="0"
            y="5"
            textAnchor="middle"
            fontSize="12"
            fontFamily="monospace"
            fontWeight="900"
            letterSpacing="1"
            fill={palette.accent}
          >
            LEVEL {romanNumeral}
          </text>
        </g>

        {/* 6. LOCKED OVERLAY IF LOCKED */}
        {!isUnlocked && (
          <g>
            <circle cx="100" cy="100" r="82" fill="rgba(3, 7, 18, 0.75)" />
            <circle cx="100" cy="100" r="28" fill="#0f172a" stroke="#64748b" strokeWidth="2" />
            {/* Padlock Icon */}
            <path
              d="M93 96 L93 91 C93 86, 107 86, 107 91 L107 96 Z"
              fill="none"
              stroke="#94a3b8"
              strokeWidth="2.5"
            />
            <rect x="90" y="96" width="20" height="15" rx="3" fill="#cbd5e1" stroke="#475569" strokeWidth="1" />
            <circle cx="100" cy="103" r="2" fill="#0f172a" />
          </g>
        )}
      </svg>

      {/* Newly Earned "NEW" Pulsing Pill */}
      {isNewlyEarned && (
        <span className="absolute -top-1.5 -right-1.5 z-20 px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 text-slate-950 font-mono font-black text-[9px] uppercase tracking-wider shadow-lg animate-bounce flex items-center gap-0.5">
          <Sparkles className="w-2.5 h-2.5 fill-current" />
          NEW
        </span>
      )}

      {/* Optional Title Label below insignia */}
      {showTitle && (
        <div className="mt-2 text-center max-w-[120px]">
          <span className="text-[10px] font-mono font-bold tracking-wider text-slate-400 block uppercase">
            LEVEL {romanNumeral}
          </span>
          <span className="text-xs font-bold text-slate-100 truncate block">
            {title}
          </span>
        </div>
      )}
    </div>
  );
};
