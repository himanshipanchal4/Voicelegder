/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Wind,
  Droplet,
  Coffee,
  Zap,
  Heart,
  Shield,
  ArrowRight,
  ArrowLeft,
  X,
  CheckCircle2,
  AlertTriangle,
  Box,
  Compass
} from 'lucide-react';

interface TutorialModalProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

export const TutorialModal: React.FC<TutorialModalProps> = ({ isOpen, onClose, onComplete }) => {
  const [step, setStep] = useState(0);

  if (!isOpen) return null;

  const steps = [
    {
      title: 'Welcome to Lunar Outpost ASTRA!',
      subtitle: 'Your Role as Mission Commander',
      icon: Compass,
      content: (
        <div className="space-y-4 text-sm text-slate-300 leading-relaxed">
          <p>
            Welcome, Commander! You are responsible for keeping a crew of 4 astronauts alive on the Moon for <strong>30 consecutive mission days</strong>.
          </p>
          <div className="p-3.5 bg-cyan-950/40 border border-cyan-800/60 rounded-lg text-cyan-200">
            <strong>The Core Goal:</strong> Don’t let your oxygen, water, food, power, or crew health drop to zero! If all 4 crew members survive Day 30, your mission is a triumph!
          </div>
          <p>
            Every day, you will review your resource levels, inspect base modules, choose daily operational actions, handle unexpected emergencies, and advance to the next day.
          </p>
        </div>
      ),
    },
    {
      title: 'The 4 Vital Consumables',
      subtitle: 'What Your Astronauts Need to Live',
      icon: Wind,
      content: (
        <div className="space-y-3 text-xs sm:text-sm">
          <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 flex items-start gap-3">
            <div className="p-2 rounded bg-cyan-950 text-cyan-400 shrink-0">
              <Wind className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-100">Oxygen (O2) · How You Breathe</div>
              <p className="text-slate-400 text-xs mt-0.5">
                Astronauts consume ~3.4 kg of oxygen daily. The base recycles expired breath using the Sabatier reactor and greenhouse plants. Keep reserves above 20 kg.
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 flex items-start gap-3">
            <div className="p-2 rounded bg-blue-950 text-blue-400 shrink-0">
              <Droplet className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-100">Water (H2O) · Drinking & Hydration</div>
              <p className="text-slate-400 text-xs mt-0.5">
                Crew uses ~10 liters daily for drinking and food prep. The ECLSS hub cleans and recycles ~85% of wastewater. If water hits zero, health plummets rapidly!
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 flex items-start gap-3">
            <div className="p-2 rounded bg-amber-950 text-amber-400 shrink-0">
              <Coffee className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-100">Rations · Caloric Nutrition</div>
              <p className="text-slate-400 text-xs mt-0.5">
                Astronauts eat 4 freeze-dried packs daily. The greenhouse supplements fresh greens. Running out causes severe fatigue and lowered immune defense.
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 flex items-start gap-3">
            <div className="p-2 rounded bg-emerald-950 text-emerald-400 shrink-0">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-100">Energy (Power) · Heaters & Systems</div>
              <p className="text-slate-400 text-xs mt-0.5">
                Solar panels harvest electricity during sunlight to power base life support and charge batteries (max 300 kWh). During twilight/night, the base relies entirely on stored batteries!
              </p>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: 'Crew Vitals & Base Integrity',
      subtitle: 'Astronaut Well-Being & Structural Safety',
      icon: Heart,
      content: (
        <div className="space-y-4 text-sm text-slate-300 leading-relaxed">
          <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 flex items-start gap-3">
            <div className="p-2 rounded bg-rose-950 text-rose-400 shrink-0">
              <Heart className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-100">Crew Health & Morale</div>
              <p className="text-slate-400 text-xs mt-0.5">
                You command 4 specialists (Geologist Dr. Ethan Park, Engineer Dr. Himanshi Panchal, Biologist Dr. Prisha Mishra, and EVA Lead Captain Arjun Mehta). Rest, exercise, fresh food, and family calls keep their morale and health high.
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 flex items-start gap-3">
            <div className="p-2 rounded bg-cyan-950 text-cyan-400 shrink-0">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-100">Base Integrity (0–100%)</div>
              <p className="text-slate-400 text-xs mt-0.5">
                Represents airlock seals, pressure hull, and micrometeorite shielding. Natural moon dust and quakes cause small daily wear. Perform airlock cleaning to keep it near 100%.
              </p>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: 'Making Daily Strategic Decisions',
      subtitle: 'Clear Previews & Meaningful Trade-offs',
      icon: Box,
      content: (
        <div className="space-y-4 text-sm text-slate-300 leading-relaxed">
          <p>
            Each mission day presents an operational decision. For example, should you pump airlock gas back into tanks (saves O2, costs energy), or vent it quickly to save time?
          </p>
          <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-lg text-emerald-200 text-xs">
            <strong>Transparent Previews:</strong> Every decision card clearly previews the exact resource changes (e.g. +15 kWh, -2 kg O2) and provides plain-language commander advice before you confirm!
          </div>
          <p className="text-xs text-slate-400">
            During early days (Days 1–5), decisions are gentle and introduce basic habits. As you progress toward the Day 15 solar shadow, tactical trade-offs become more challenging.
          </p>
        </div>
      ),
    },
    {
      title: 'Emergencies & Advancing the Day',
      subtitle: 'Responding to Crises & Cycle Progression',
      icon: AlertTriangle,
      content: (
        <div className="space-y-4 text-sm text-slate-300 leading-relaxed">
          <p>
            Occasional emergencies (like a solar radiation storm or water pump leak) will trigger an alarm. You will have 3 response options (Conservative, Balanced, or Spacewalk) with clear success probabilities.
          </p>
          <div className="p-3 bg-cyan-950/40 border border-cyan-800/60 rounded-lg text-cyan-200 text-xs">
            <strong>Advancing the Day:</strong> Once you make your daily choice, click the green &ldquo;Advance to Next Day&rdquo; button. The simulation simulates 24 hours of astronaut survival and records your progress!
          </div>
          <p className="text-xs text-slate-400">
            You can also open the <strong>3D Lunar Outpost</strong> view anytime to inspect all 6 base modules and trigger special maintenance routines!
          </p>
        </div>
      ),
    },
  ];

  const currentStep = steps[step];
  const StepIcon = currentStep.icon;

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      onComplete();
      onClose();
    }
  };

  const handlePrev = () => {
    if (step > 0) {
      setStep(step - 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="bg-slate-950 border border-cyan-800/80 rounded-2xl max-w-xl w-full p-6 sm:p-8 shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-900 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400 shrink-0">
            <StepIcon className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-mono uppercase text-cyan-400">
              Commander Onboarding · Step {step + 1} of {steps.length}
            </div>
            <h2 className="text-xl font-bold text-slate-100">{currentStep.title}</h2>
          </div>
        </div>

        {/* Content Body */}
        <div className="min-h-[220px] mb-8">{currentStep.content}</div>

        {/* Footer Navigation */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-800">
          <div className="flex items-center gap-1.5">
            {steps.map((_, i) => (
              <div
                key={i}
                className={`h-1.5 rounded-full transition-all ${
                  i === step ? 'w-6 bg-cyan-400' : 'w-2 bg-slate-800'
                }`}
              />
            ))}
          </div>

          <div className="flex items-center gap-2">
            {step > 0 && (
              <button
                onClick={handlePrev}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-800 text-xs text-slate-300 hover:bg-slate-900 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
            )}

            <button
              onClick={handleNext}
              className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer"
            >
              <span>{step === steps.length - 1 ? 'Start Mission' : 'Next Step'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
