/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { MissionState } from '../types/mission';
import { Award, RotateCcw, ShieldCheck, AlertOctagon, Heart, Zap, Droplet, Wind, Coffee, Orbit, CheckCircle2, Sparkles } from 'lucide-react';
import { LUNAR_BADGES } from '../data/badgeData';
import { BadgeInsignia } from './BadgeInsignia';
import { NasaAstronautLogo } from './NasaAstronautLogo';

interface FinalReportViewProps {
  state: MissionState;
  onRestartMission: () => void;
  onOpenScience: () => void;
}

export const FinalReportView: React.FC<FinalReportViewProps> = ({
  state,
  onRestartMission,
  onOpenScience,
}) => {
  const isVictory = state.phase === 'victory';
  const { stats, crew, resources, day, difficulty } = state;

  const livingCrew = crew.filter((c) => c.health > 0);
  const avgHealth = Math.round(crew.reduce((acc, c) => acc + c.health, 0) / crew.length);
  const avgMorale = Math.round(crew.reduce((acc, c) => acc + c.morale, 0) / crew.length);

  // Performance Rating tier
  let rankTitle = 'Space Cadet';
  let rankBadgeColor = 'text-slate-400 border-slate-700 bg-slate-900';
  if (isVictory) {
    if (stats.finalScore > 8000) {
      rankTitle = 'Distinguished NASA Flight Director';
      rankBadgeColor = 'text-amber-300 border-amber-600 bg-amber-950/40';
    } else if (stats.finalScore > 6500) {
      rankTitle = 'Senior Expedition Commander';
      rankBadgeColor = 'text-cyan-300 border-cyan-600 bg-cyan-950/40';
    } else {
      rankTitle = 'Certified Lunar Astronaut';
      rankBadgeColor = 'text-emerald-300 border-emerald-600 bg-emerald-950/40';
    }
  }

  return (
    <div className="max-w-4xl mx-auto p-6 md:p-10 select-none animate-fade-in">
      {/* Debrief Header Banner */}
      <div
        className={`p-6 sm:p-8 rounded-2xl border mb-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl ${
          isVictory
            ? 'bg-gradient-to-br from-cyan-950/70 via-slate-950 to-emerald-950/60 border-cyan-500/60'
            : 'bg-gradient-to-br from-rose-950/70 via-slate-950 to-slate-900 border-rose-600/60'
        }`}
      >
        <div className="flex items-center gap-4 text-center md:text-left">
          <NasaAstronautLogo
            size={64}
            className="shrink-0 drop-shadow-[0_0_16px_rgba(234,179,8,0.4)]"
          />

          <div>
            <div className="text-xs font-mono uppercase text-slate-400 tracking-wider">
              NASA Houston Flight Evaluation · Mission Debrief
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-100 mt-1">
              {isVictory ? 'MISSION ACCOMPLISHED: EXPEDITION SURVIVED' : 'MISSION ABORTED: BASE EVACUATION'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              {isVictory
                ? 'All 30 lunar mission days successfully completed. Crew is operational and prepared for handover.'
                : state.failureReason || 'Life-support thresholds collapsed before Day 30 could be achieved.'}
            </p>
          </div>
        </div>

        <div className="text-center md:text-right shrink-0">
          <div className="text-xs font-mono uppercase text-slate-400">Total Score</div>
          <div className="text-4xl font-extrabold font-mono text-cyan-300 tabular-nums">
            {stats.finalScore.toLocaleString()}
          </div>
          <div className={`mt-2 px-3 py-1 rounded-full border text-xs font-semibold ${rankBadgeColor}`}>
            {rankTitle}
          </div>
        </div>
      </div>

      {/* Stats Breakdown Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl">
          <div className="text-xs font-mono uppercase text-slate-400">Days Completed</div>
          <div className="text-2xl font-bold font-mono text-slate-100 tabular-nums mt-1">
            {day} / 30
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Difficulty: {difficulty.toUpperCase()}</div>
        </div>

        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl">
          <div className="text-xs font-mono uppercase text-slate-400">Crew Survival</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums mt-1">
            {livingCrew.length} / 4 Alive
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Avg Health: {avgHealth}%</div>
        </div>

        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl">
          <div className="text-xs font-mono uppercase text-slate-400">Emergencies Resolved</div>
          <div className="text-2xl font-bold font-mono text-cyan-400 tabular-nums mt-1">
            {stats.emergenciesResolved} / {stats.emergenciesFaced}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">100% Protocol Response</div>
        </div>

        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl">
          <div className="text-xs font-mono uppercase text-slate-400">Science Discoveries</div>
          <div className="text-2xl font-bold font-mono text-amber-400 tabular-nums mt-1">
            {stats.scienceDiscoveries}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">PSRs Volatiles Logged</div>
        </div>
      </div>

      {/* 4 Lives Entrusted to Command — Mission Survival Manifest */}
      <div className="p-5 rounded-xl bg-slate-950/80 border border-slate-800 mb-8">
        <div className="text-xs font-mono uppercase text-cyan-400 mb-3 flex items-center justify-between">
          <span>CREW MANIFEST &bull; 4 LIVES ENTRUSTED TO COMMAND</span>
          {state.crewName && <span className="text-slate-400">UNIT: {state.crewName.toUpperCase()}</span>}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {crew.map((member) => (
            <div
              key={member.id}
              className="p-3 rounded-lg bg-slate-900/70 border border-slate-800 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-xs text-slate-100">{member.name}</span>
                  <span
                    className="text-[9px] font-mono px-1.5 py-0.2 rounded font-bold"
                    style={{ backgroundColor: `${member.color}25`, color: member.color }}
                  >
                    "{member.callsign}"
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 truncate">{member.role}</div>
              </div>
              <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono">
                <span className="text-slate-500">Status:</span>
                <span className={member.health > 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {member.health > 0 ? `Alive (${member.health}%)` : 'Critical Failure'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 30 DAYS. SIX BADGES. ONE EXTRAORDINARY MISSION. */}
      <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/90 via-slate-950 to-slate-900/80 border border-amber-500/50 mb-8 shadow-2xl relative overflow-hidden">
        <div className="text-center mb-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-950/80 border border-amber-500/40 text-amber-300 text-xs font-mono uppercase tracking-widest mb-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>ASTRA TRAINING CAMPAIGN FINALE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-100 tracking-tight font-mono">
            30 DAYS. SIX BADGES. ONE EXTRAORDINARY MISSION.
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto mt-1 font-sans">
            {isVictory
              ? 'Congratulations Commander! You have successfully mastered every 5-day polar training milestone.'
              : 'Your lunar training records and earned mission insignia across the campaign:'}
          </p>
        </div>

        {/* 6 Badges Lineup */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-2">
          {LUNAR_BADGES.map((b) => {
            const isEarned = (state.unlockedBadges || []).includes(b.id) || (isVictory && b.level <= 6);
            return (
              <div
                key={b.id}
                className={`p-3 rounded-xl border flex flex-col items-center text-center ${
                  isEarned
                    ? 'bg-slate-900/80 border-amber-500/50 shadow-lg'
                    : 'bg-slate-950/40 border-slate-900 opacity-60'
                }`}
              >
                <BadgeInsignia badge={b} isUnlocked={isEarned} size="sm" />
                <span className="text-[10px] font-mono text-amber-400 font-bold mt-1.5">
                  LEVEL {b.romanNumeral}
                </span>
                <span className="text-[11px] font-bold text-slate-200 truncate w-full">
                  {b.title}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Final Consumables Level */}
      <div className="p-5 rounded-2xl bg-[#121a3e]/95 border border-indigo-400/35 mb-8">
        <div className="text-xs font-bold uppercase text-indigo-300 mb-3">
          Final Supplies Remaining
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
          <div className="p-3 bg-[#0c1330] rounded-xl border border-cyan-400/30 flex items-center gap-3">
            <Wind className="w-4 h-4 text-cyan-300" />
            <div>
              <span className="text-cyan-300 block text-[10px] font-sans font-bold">AIR (O₂)</span>
              <span className="text-base font-bold text-white">{resources.oxygenKg.toFixed(1)} kg</span>
            </div>
          </div>

          <div className="p-3 bg-[#0c1330] rounded-xl border border-sky-400/30 flex items-center gap-3">
            <Droplet className="w-4 h-4 text-sky-300" />
            <div>
              <span className="text-sky-300 block text-[10px] font-sans font-bold">WATER</span>
              <span className="text-base font-bold text-white">{resources.waterLiters.toFixed(1)} L</span>
            </div>
          </div>

          <div className="p-3 bg-[#0c1330] rounded-xl border border-emerald-400/30 flex items-center gap-3">
            <Coffee className="w-4 h-4 text-emerald-300" />
            <div>
              <span className="text-emerald-300 block text-[10px] font-sans font-bold">FOOD</span>
              <span className="text-base font-bold text-white">{Math.round(resources.foodPacks)} packs</span>
            </div>
          </div>

          <div className="p-3 bg-[#0c1330] rounded-xl border border-amber-400/30 flex items-center gap-3">
            <Zap className="w-4 h-4 text-amber-300" />
            <div>
              <span className="text-amber-300 block text-[10px] font-sans font-bold">POWER</span>
              <span className="text-base font-bold text-white">{Math.round(resources.powerKwh)} kWh</span>
            </div>
          </div>
        </div>
      </div>

      {/* Space Academy Takeaway */}
      <div className="p-5 rounded-2xl bg-[#121a3e]/95 border border-indigo-400/35 mb-8 space-y-2.5">
        <div className="text-xs font-bold uppercase text-cyan-300 flex items-center gap-1.5">
          <Orbit className="w-4 h-4" />
          <span>What We Learned on the Moon</span>
        </div>
        <p className="text-xs sm:text-sm text-indigo-100 leading-relaxed">
          Astronauts at the Moon’s South Pole survive by recycling almost every drop of water and breath of air—plus catching low polar sunlight on tall solar towers!
        </p>
        <div className="pt-1 flex items-center gap-3">
          <button
            onClick={onOpenScience}
            className="text-xs text-cyan-300 hover:text-cyan-200 font-bold underline cursor-pointer"
          >
            Explore Real NASA Science Sources →
          </button>
        </div>
      </div>

      {/* Action Footer */}
      <div className="flex items-center justify-between pt-5 border-t border-indigo-400/30">
        <div className="text-xs text-indigo-300 font-semibold">
          ASTRA: THE LAST 30 DAYS
        </div>

        <button
          onClick={onRestartMission}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400 hover:brightness-110 text-slate-950 font-extrabold text-sm rounded-xl shadow-lg shadow-cyan-500/25 transition-all cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Play Again!</span>
        </button>
      </div>
    </div>
  );
};
