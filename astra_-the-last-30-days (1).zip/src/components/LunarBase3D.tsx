/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OutpostModule } from '../types/mission';

interface LunarBase3DProps {
  modules: OutpostModule[];
  selectedModuleId: string | null;
  onSelectModule: (moduleId: string) => void;
  solarAngleDeg: number;
  isLunarNight: boolean;
}

export const LunarBase3D: React.FC<LunarBase3DProps> = ({
  modules,
  selectedModuleId,
  onSelectModule,
  solarAngleDeg,
  isLunarNight,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [webGlSupported, setWebGlSupported] = useState<boolean>(true);
  const [hoveredModule, setHoveredModule] = useState<string | null>(null);

  // References to keep 3D loop independent of React renders
  const onSelectModuleRef = useRef(onSelectModule);
  onSelectModuleRef.current = onSelectModule;
  const hoveredModuleRef = useRef<string | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const moduleMeshesRef = useRef<Map<string, THREE.Group>>(new Map());
  const targetCamPosRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 16, 32));
  const targetLookAtRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 2, 0));
  const currentLookAtRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 2, 0));
  const sunLightRef = useRef<THREE.DirectionalLight | null>(null);

  // Module positions in world space (X, Z)
  const moduleCoords: Record<string, [number, number]> = {
    'living-habitat': [0, 0],
    'solar-power': [-14, -8],
    'life-support': [9, -4],
    'greenhouse': [-8, 8],
    'research-lab': [8, 8],
    'comm-station': [14, -12],
  };

  // Adjust camera target when selected module changes
  useEffect(() => {
    if (selectedModuleId && moduleCoords[selectedModuleId]) {
      const [mx, mz] = moduleCoords[selectedModuleId];
      targetCamPosRef.current.set(mx + 6, 8, mz + 12);
      targetLookAtRef.current.set(mx, 2, mz);
    } else {
      // Default overview orbit
      targetCamPosRef.current.set(0, 18, 34);
      targetLookAtRef.current.set(0, 2, 0);
    }
  }, [selectedModuleId]);

  // Adjust sunlight elevation
  useEffect(() => {
    if (sunLightRef.current) {
      const rad = (solarAngleDeg * Math.PI) / 180;
      const intensity = isLunarNight ? 0.3 : 2.4;
      sunLightRef.current.intensity = intensity;
      sunLightRef.current.position.set(40 * Math.cos(rad), Math.max(3, 40 * Math.sin(rad)), 20);
    }
  }, [solarAngleDeg, isLunarNight]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // WebGL support check
    try {
      const testCanvas = document.createElement('canvas');
      const gl = testCanvas.getContext('webgl2') || testCanvas.getContext('webgl');
      if (!gl) {
        setWebGlSupported(false);
        return;
      }
    } catch {
      setWebGlSupported(false);
      return;
    }

    // 1. Scene Setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x05070d);
    scene.fog = new THREE.FogExp2(0x05070d, 0.015);
    sceneRef.current = scene;

    // 2. Camera Setup
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;
    const isPortrait = width < height;
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    if (isPortrait) {
      targetCamPosRef.current.set(0, 20, 44);
    }
    camera.position.copy(targetCamPosRef.current);
    cameraRef.current = camera;

    // 3. Renderer Setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.replaceChildren(renderer.domElement);

    // 4. Lighting Rig
    const ambientLight = new THREE.AmbientLight(0x0f172a, 0.8);
    scene.add(ambientLight);

    const hemiLight = new THREE.HemisphereLight(0x94a3b8, 0x1e293b, 0.6);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfffaed, 2.4);
    sunLight.position.set(35, 12, 18);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 0.5;
    sunLight.shadow.camera.far = 120;
    sunLight.shadow.camera.left = -28;
    sunLight.shadow.camera.right = 28;
    sunLight.shadow.camera.top = 28;
    sunLight.shadow.camera.bottom = -28;
    sunLight.shadow.bias = -0.0005;
    scene.add(sunLight);
    sunLightRef.current = sunLight;

    // 5. Starfield, Distant Earth & Orbital Crew Spacecraft
    createStarfield(scene);
    createDistantEarth(scene);
    createOrbitalSpacecraft(scene);

    // 6. Lunar Terrain Surface
    createLunarTerrain(scene);

    // 7. Composite Outpost Modules
    const moduleMap = new Map<string, THREE.Group>();

    // Habitation Alpha
    const habGroup = createHabitationModule();
    habGroup.position.set(0, 0, 0);
    habGroup.userData = { moduleId: 'living-habitat' };
    scene.add(habGroup);
    moduleMap.set('living-habitat', habGroup);

    // Solar Power Station
    const powerGroup = createSolarPowerModule();
    powerGroup.position.set(-14, 0, -8);
    powerGroup.userData = { moduleId: 'solar-power' };
    scene.add(powerGroup);
    moduleMap.set('solar-power', powerGroup);

    // ECLSS Life Support
    const eclssGroup = createECLSSModule();
    eclssGroup.position.set(9, 0, -4);
    eclssGroup.userData = { moduleId: 'life-support' };
    scene.add(eclssGroup);
    moduleMap.set('life-support', eclssGroup);

    // Hydroponic Greenhouse
    const greenGroup = createGreenhouseModule();
    greenGroup.position.set(-8, 0, 8);
    greenGroup.userData = { moduleId: 'greenhouse' };
    scene.add(greenGroup);
    moduleMap.set('greenhouse', greenGroup);

    // Research Laboratory
    const labGroup = createResearchLabModule();
    labGroup.position.set(8, 0, 8);
    labGroup.userData = { moduleId: 'research-lab' };
    scene.add(labGroup);
    moduleMap.set('research-lab', labGroup);

    // Expedition Lander & Crew Spaceship
    const commGroup = createCrewSpaceshipModule();
    commGroup.position.set(14, 0, -12);
    commGroup.userData = { moduleId: 'comm-station' };
    scene.add(commGroup);
    moduleMap.set('comm-station', commGroup);

    moduleMeshesRef.current = moduleMap;

    // Pre-cache interactive meshes once so pointermove doesn't traverse every frame
    const interactiveObjects: THREE.Object3D[] = [];
    moduleMap.forEach((grp) => {
      grp.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) interactiveObjects.push(child);
      });
    });

    // 8. Smooth 360° Camera Orbit Dragging & Interaction
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    let isDragging = false;
    let dragStartX = 0;
    let dragStartY = 0;
    let dragMoved = false;
    let sphericalRadius = isPortrait ? 48 : 38;
    let sphericalTheta = 0.48; // ~28 degrees elevation
    let sphericalPhi = 0;      // azimuth

    const updateCameraOrbitPosition = () => {
      const x = targetLookAtRef.current.x + sphericalRadius * Math.cos(sphericalTheta) * Math.sin(sphericalPhi);
      const y = targetLookAtRef.current.y + sphericalRadius * Math.sin(sphericalTheta);
      const z = targetLookAtRef.current.z + sphericalRadius * Math.cos(sphericalTheta) * Math.cos(sphericalPhi);
      targetCamPosRef.current.set(x, y, z);
    };

    const setHoverSafe = (nextHover: string | null) => {
      if (hoveredModuleRef.current !== nextHover) {
        hoveredModuleRef.current = nextHover;
        setHoveredModule(nextHover);
      }
    };

    const onPointerDown = (e: PointerEvent) => {
      isDragging = true;
      dragStartX = e.clientX;
      dragStartY = e.clientY;
      dragMoved = false;
      container.style.cursor = 'grabbing';
    };

    const onPointerMove = (e: PointerEvent) => {
      if (isDragging) {
        const dx = e.clientX - dragStartX;
        const dy = e.clientY - dragStartY;
        if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
          dragMoved = true;
        }
        sphericalPhi -= dx * 0.007;
        sphericalTheta = Math.max(0.12, Math.min(Math.PI / 2.2, sphericalTheta + dy * 0.006));
        dragStartX = e.clientX;
        dragStartY = e.clientY;
        updateCameraOrbitPosition();
        return;
      }

      // Hover Raycasting
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(interactiveObjects);
      if (intersects.length > 0) {
        let parent: THREE.Object3D | null = intersects[0].object;
        while (parent && !parent.userData?.moduleId) {
          parent = parent.parent;
        }
        if (parent && parent.userData?.moduleId) {
          setHoverSafe(parent.userData.moduleId);
          container.style.cursor = 'pointer';
          return;
        }
      }
      setHoverSafe(null);
      container.style.cursor = 'grab';
    };

    const onPointerUp = (e: PointerEvent) => {
      if (!isDragging) return;
      isDragging = false;
      container.style.cursor = hoveredModuleRef.current ? 'pointer' : 'grab';

      // If user tapped without dragging, trigger module selection
      if (!dragMoved) {
        const rect = renderer.domElement.getBoundingClientRect();
        mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

        raycaster.setFromCamera(mouse, camera);
        const intersects = raycaster.intersectObjects(interactiveObjects);
        if (intersects.length > 0) {
          let parent: THREE.Object3D | null = intersects[0].object;
          while (parent && !parent.userData?.moduleId) {
            parent = parent.parent;
          }
          if (parent && parent.userData?.moduleId) {
            onSelectModuleRef.current(parent.userData.moduleId);
          }
        }
      }
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      sphericalRadius = Math.max(16, Math.min(52, sphericalRadius + e.deltaY * 0.035));
      updateCameraOrbitPosition();
    };

    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    renderer.domElement.addEventListener('wheel', onWheel, { passive: false });

    // 9. Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: w, height: h } = entry.contentRect;
        if (w > 0 && h > 0) {
          camera.aspect = w / h;
          camera.updateProjectionMatrix();
          renderer.setSize(w, h);
        }
      }
    });
    resizeObserver.observe(container);

    // Lunar Dust Particles (Electrostatic Levitation motes)
    const dustGeo = new THREE.BufferGeometry();
    const dustCount = 300;
    const dustPositions = new Float32Array(dustCount * 3);
    for (let i = 0; i < dustCount * 3; i += 3) {
      dustPositions[i] = (Math.random() - 0.5) * 60;
      dustPositions[i + 1] = Math.random() * 8 + 0.3;
      dustPositions[i + 2] = (Math.random() - 0.5) * 60;
    }
    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
    const dustMat = new THREE.PointsMaterial({
      color: 0x94a3b8,
      size: 0.3,
      transparent: true,
      opacity: 0.5,
    });
    const dustParticles = new THREE.Points(dustGeo, dustMat);
    scene.add(dustParticles);

    // 10. Animation Loop
    let animId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const delta = Math.min(clock.getDelta(), 0.05);
      const elapsed = clock.getElapsedTime();

      // Smooth camera damp
      camera.position.lerp(targetCamPosRef.current, delta * 3.5);
      currentLookAtRef.current.lerp(targetLookAtRef.current, delta * 3.5);
      camera.lookAt(currentLookAtRef.current);

      // Spaceship antenna sweep & nav beacon pulse
      const shipMesh = moduleMap.get('comm-station');
      if (shipMesh) {
        const dish = shipMesh.getObjectByName('dish');
        if (dish) {
          dish.rotation.y = Math.sin(elapsed * 0.25) * 0.15;
        }
        const beacon = shipMesh.getObjectByName('shipBeacon') as THREE.Mesh | undefined;
        if (beacon && beacon.material) {
          (beacon.material as THREE.Material).opacity = 0.4 + 0.6 * Math.abs(Math.sin(elapsed * 3.5));
        }
      }

      // Solar tracking array rotation
      const powerMesh = moduleMap.get('solar-power');
      if (powerMesh) {
        const panel = powerMesh.getObjectByName('solarPanels');
        if (panel) {
          panel.rotation.y = Math.PI / 4 + Math.sin(elapsed * 0.12) * 0.2;
        }
      }

      // Drifting lunar dust motes (frame-rate independent)
      if (dustParticles) {
        const posAttr = dustParticles.geometry.attributes.position as THREE.BufferAttribute;
        for (let i = 1; i < dustCount * 3; i += 3) {
          posAttr.array[i] += Math.sin(elapsed + i) * delta * 0.3;
        }
        posAttr.needsUpdate = true;
      }

      // Orbital crew command ship slow deep-space drift
      const orbiter = scene.getObjectByName('orbitalSpacecraft');
      if (orbiter) {
        const orbitAngle = elapsed * 0.035;
        orbiter.position.x = Math.cos(orbitAngle) * 85 - 15;
        orbiter.position.z = Math.sin(orbitAngle) * 55 - 85;
        orbiter.rotation.y = -orbitAngle + Math.PI / 2;
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      resizeObserver.disconnect();
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      renderer.domElement.removeEventListener('wheel', onWheel);
      renderer.dispose();
      // Dispose meshes, points, materials, and GPU textures cleanly
      scene.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh || (obj as THREE.Points).isPoints) {
          const renderObj = obj as THREE.Mesh | THREE.Points;
          renderObj.geometry?.dispose();
          const mats = Array.isArray(renderObj.material) ? renderObj.material : [renderObj.material];
          mats.forEach((m) => {
            if (!m) return;
            const stdMat = m as THREE.MeshStandardMaterial;
            stdMat.map?.dispose();
            stdMat.bumpMap?.dispose();
            stdMat.roughnessMap?.dispose();
            m.dispose();
          });
        }
      });
    };
  }, []);

  return (
    <div className="relative w-full h-full min-h-[420px] bg-[#070b1c] overflow-hidden">
      {/* 3D Canvas Mount Point (touch-none prevents mobile browser scroll while orbiting) */}
      <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing touch-none" />

      {/* Fallback if WebGL fails */}
      {!webGlSupported && (
        <div className="absolute inset-0 flex flex-col items-center justify-center p-6 bg-[#0b1026] text-slate-200">
          <div className="text-cyan-300 font-bold mb-2">Interactive Moonbase Map</div>
          <p className="text-xs text-indigo-200 mb-6 text-center max-w-md">
            Tap any building below to inspect it and use quick boosts.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 w-full max-w-2xl">
            {modules.map((m) => (
              <button
                key={m.id}
                onClick={() => onSelectModule(m.id)}
                className={`p-3 text-left rounded-2xl border transition-colors cursor-pointer ${
                  selectedModuleId === m.id
                    ? 'border-cyan-400 bg-cyan-500/20 text-cyan-200'
                    : 'border-indigo-400/30 bg-[#121a3e] hover:border-cyan-400/60 text-indigo-100'
                }`}
              >
                <div className="text-[10px] font-bold uppercase text-cyan-300">{m.category}</div>
                <div className="font-bold text-sm text-white">{m.name}</div>
                <div className="text-xs text-emerald-300 mt-1">{m.efficiency}% Working</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Clean Hover Tooltip (No occlusion under top HUD) */}
      {hoveredModule && (
        <div className="hidden lg:flex absolute top-[184px] left-3 pointer-events-none z-10">
          <div className="bg-[#121a3e]/95 text-cyan-200 px-3 py-1.5 rounded-xl border border-cyan-400/60 text-xs font-bold shadow-lg">
            Click to inspect: {modules.find((m) => m.id === hoveredModule)?.name || hoveredModule}
          </div>
        </div>
      )}

      {/* Module Quick Select Strip positioned cleanly without overlapping HUD, Coach Nova, or Story Card */}
      <div className="absolute top-[154px] sm:top-[124px] lg:top-[136px] left-2.5 right-2.5 lg:right-auto lg:left-3 lg:max-w-[calc(100vw-360px)] flex items-center gap-1 p-1 sm:p-1.5 bg-[#121a3e]/92 backdrop-blur-md rounded-xl sm:rounded-2xl border border-indigo-400/40 shadow-xl overflow-x-auto z-10">
        <button
          onClick={() => onSelectModule('')}
          className={`px-2.5 sm:px-3 py-1 sm:py-1.5 text-[11px] sm:text-xs font-bold rounded-lg sm:rounded-xl whitespace-nowrap transition-colors cursor-pointer shrink-0 ${
            !selectedModuleId
              ? 'bg-gradient-to-r from-cyan-400 to-sky-400 text-slate-950 shadow'
              : 'text-indigo-200 hover:text-white hover:bg-indigo-800/60'
          }`}
        >
          Overview
        </button>
        {modules.map((m) => (
          <button
            key={m.id}
            onClick={() => onSelectModule(m.id)}
            className={`px-2.5 sm:px-3 py-1 sm:py-1.5 text-[11px] sm:text-xs font-bold rounded-lg sm:rounded-xl whitespace-nowrap transition-colors flex items-center gap-1.5 cursor-pointer shrink-0 ${
              selectedModuleId === m.id
                ? 'bg-gradient-to-r from-cyan-400 to-sky-400 text-slate-950 shadow'
                : 'text-indigo-200 hover:text-white hover:bg-indigo-800/60'
            }`}
          >
            <span>{m.shortName}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

// ==========================================
// PROCEDURAL 3D ASSET BUILDERS (Zero 404s)
// ==========================================

function createStarfield(scene: THREE.Scene): void {
  const starGeo = new THREE.BufferGeometry();
  const starCount = 1800;
  const positions = new Float32Array(starCount * 3);

  for (let i = 0; i < starCount * 3; i += 3) {
    const radius = 250 + Math.random() * 50;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(Math.random() * 2 - 1);

    positions[i] = radius * Math.sin(phi) * Math.cos(theta);
    positions[i + 1] = Math.abs(radius * Math.cos(phi)) + 10; // Keep mostly above horizon
    positions[i + 2] = radius * Math.sin(phi) * Math.sin(theta);
  }

  starGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const starMat = new THREE.PointsMaterial({
    color: 0xffffff,
    size: 1.2,
    transparent: true,
    opacity: 0.85,
  });

  const stars = new THREE.Points(starGeo, starMat);
  scene.add(stars);
}

function createDistantEarth(scene: THREE.Scene): void {
  const earthGroup = new THREE.Group();
  earthGroup.position.set(-80, 55, -120);

  // Earth sphere with atmosphere
  const earthGeo = new THREE.SphereGeometry(6, 32, 32);
  const earthMat = new THREE.MeshStandardMaterial({
    color: 0x1d4ed8,
    roughness: 0.7,
    metalness: 0.1,
    emissive: 0x0c2461,
    emissiveIntensity: 0.25,
  });
  const earthMesh = new THREE.Mesh(earthGeo, earthMat);
  earthGroup.add(earthMesh);

  // Clouds swirl
  const cloudsGeo = new THREE.SphereGeometry(6.08, 32, 32);
  const cloudsMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    transparent: true,
    opacity: 0.45,
    roughness: 1.0,
  });
  const cloudsMesh = new THREE.Mesh(cloudsGeo, cloudsMat);
  earthGroup.add(cloudsMesh);

  scene.add(earthGroup);
}

function createOrbitalSpacecraft(scene: THREE.Scene): THREE.Group {
  const orbiterGrp = new THREE.Group();
  orbiterGrp.name = 'orbitalSpacecraft';
  orbiterGrp.position.set(-65, 52, -100);

  // Cylindrical Service Module with thermal radiators
  const smGeo = new THREE.CylinderGeometry(0.9, 0.9, 1.8, 16);
  const smMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.8, roughness: 0.25 });
  const sm = new THREE.Mesh(smGeo, smMat);
  sm.rotation.z = Math.PI / 2;
  orbiterGrp.add(sm);

  // Conical Astronaut Crew Command Capsule
  const cmGeo = new THREE.ConeGeometry(0.95, 1.4, 16);
  const cmMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, metalness: 0.45, roughness: 0.2 });
  const cm = new THREE.Mesh(cmGeo, cmMat);
  cm.rotation.z = -Math.PI / 2;
  cm.position.x = 1.35;
  orbiterGrp.add(cm);

  // Tinted cockpit visor on command capsule
  const winGeo = new THREE.BoxGeometry(0.2, 0.35, 0.6);
  const winMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
  const win = new THREE.Mesh(winGeo, winMat);
  win.position.set(1.4, 0.45, 0);
  orbiterGrp.add(win);

  // Vacuum Main Propulsion Engine Bell
  const bellGeo = new THREE.ConeGeometry(0.4, 0.65, 12, 1, true);
  const bellMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.9, side: THREE.DoubleSide });
  const bell = new THREE.Mesh(bellGeo, bellMat);
  bell.rotation.z = Math.PI / 2;
  bell.position.x = -1.2;
  orbiterGrp.add(bell);

  // 4 Solar Array Wings in X-pattern
  for (let i = 0; i < 4; i++) {
    const angle = (i * Math.PI) / 2 + Math.PI / 4;
    const wingGeo = new THREE.BoxGeometry(0.05, 2.2, 0.7);
    const wingMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      metalness: 0.9,
      roughness: 0.15,
      emissive: 0x0369a1,
      emissiveIntensity: 0.2,
    });
    const wing = new THREE.Mesh(wingGeo, wingMat);
    wing.position.set(-0.2, Math.sin(angle) * 1.8, Math.cos(angle) * 1.8);
    orbiterGrp.add(wing);
  }

  // Cyan ion engine thrust glow plume
  const glowGeo = new THREE.SphereGeometry(0.22, 8, 8);
  const glowMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
  const glow = new THREE.Mesh(glowGeo, glowMat);
  glow.position.x = -1.55;
  orbiterGrp.add(glow);

  scene.add(orbiterGrp);
  return orbiterGrp;
}

function createLunarTerrain(scene: THREE.Scene): void {
  // High-detail lunar regolith ground with undulating basins and crater rims
  const planeGeo = new THREE.PlaneGeometry(96, 96, 80, 80);
  planeGeo.rotateX(-Math.PI / 2);

  // Perturb vertices for realistic crater bowls, raised rims & ridges
  const craters = [
    { x: 18, z: -14, r: 10, depth: 1.9 },
    { x: -22, z: 16, r: 14, depth: 2.3 },
    { x: -26, z: -22, r: 8, depth: 1.4 },
    { x: 28, z: 22, r: 11, depth: 1.8 },
    { x: 4, z: -26, r: 6.5, depth: 1.1 },
  ];
  const pos = planeGeo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    // Gentle highland rolls kept flat near base modules (radius < 16)
    const distFromCenter = Math.hypot(x, z);
    const centerFlatten = Math.min(1, Math.max(0, (distFromCenter - 15) / 10));
    let y = (Math.sin(x * 0.07) * Math.cos(z * 0.07) * 0.8 + Math.sin((x + z) * 0.04) * 0.5) * centerFlatten;

    for (const c of craters) {
      const d = Math.hypot(x - c.x, z - c.z);
      if (d < c.r * 1.25) {
        if (d < c.r * 0.82) {
          y -= Math.cos((d / (c.r * 0.82)) * (Math.PI / 2)) * c.depth;
        } else {
          // Raised crater ejecta rim
          const rimT = (d - c.r * 0.82) / (c.r * 0.43);
          y += Math.sin(rimT * Math.PI) * (c.depth * 0.24);
        }
      }
    }
    pos.setY(i, y);
  }
  planeGeo.computeVertexNormals();

  // Procedural high-detail lunar soil albedo + bump textures
  const size = 1024;
  const colCanvas = document.createElement('canvas');
  colCanvas.width = size;
  colCanvas.height = size;
  const cCtx = colCanvas.getContext('2d')!;

  const bmpCanvas = document.createElement('canvas');
  bmpCanvas.width = size;
  bmpCanvas.height = size;
  const bCtx = bmpCanvas.getContext('2d')!;

  cCtx.fillStyle = '#5c616a';
  cCtx.fillRect(0, 0, size, size);
  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, size, size);

  // Subtle dusty mare/highland patches & micro-craters
  let seed = 4242;
  const rand = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  for (let i = 0; i < 160; i++) {
    const cx = rand() * size;
    const cy = rand() * size;
    const r = 4 + rand() * 26;
    const cg = cCtx.createRadialGradient(cx, cy, r * 0.1, cx, cy, r);
    cg.addColorStop(0, 'rgba(54, 57, 64, 0.52)');
    cg.addColorStop(0.75, 'rgba(92, 95, 102, 0.25)');
    cg.addColorStop(0.9, 'rgba(182, 185, 191, 0.35)');
    cg.addColorStop(1, 'rgba(0,0,0,0)');
    cCtx.fillStyle = cg;
    cCtx.beginPath();
    cCtx.arc(cx, cy, r, 0, Math.PI * 2);
    cCtx.fill();

    const bg = bCtx.createRadialGradient(cx, cy, r * 0.1, cx, cy, r);
    bg.addColorStop(0, 'rgba(28,28,28,0.65)');
    bg.addColorStop(0.82, 'rgba(220,220,220,0.55)');
    bg.addColorStop(1, 'rgba(128,128,128,0)');
    bCtx.fillStyle = bg;
    bCtx.beginPath();
    bCtx.arc(cx, cy, r, 0, Math.PI * 2);
    bCtx.fill();
  }

  // Fine basalt regolith speckle
  const imgData = cCtx.getImageData(0, 0, size, size);
  const d = imgData.data;
  for (let i = 0; i < d.length; i += 4) {
    const g = (rand() - 0.5) * 22;
    d[i] = Math.max(0, Math.min(255, d[i] + g));
    d[i + 1] = Math.max(0, Math.min(255, d[i + 1] + g));
    d[i + 2] = Math.max(0, Math.min(255, d[i + 2] + g));
  }
  cCtx.putImageData(imgData, 0, 0);

  const groundTex = new THREE.CanvasTexture(colCanvas);
  groundTex.colorSpace = THREE.SRGBColorSpace;
  groundTex.wrapS = THREE.RepeatWrapping;
  groundTex.wrapT = THREE.RepeatWrapping;
  groundTex.repeat.set(3, 3);

  const groundBump = new THREE.CanvasTexture(bmpCanvas);
  groundBump.wrapS = THREE.RepeatWrapping;
  groundBump.wrapT = THREE.RepeatWrapping;
  groundBump.repeat.set(3, 3);

  const regolithMat = new THREE.MeshStandardMaterial({
    map: groundTex,
    bumpMap: groundBump,
    bumpScale: 0.35,
    roughness: 0.94,
    metalness: 0.04,
  });

  const terrain = new THREE.Mesh(planeGeo, regolithMat);
  terrain.receiveShadow = true;
  scene.add(terrain);

  // Regolith boulders scattered around
  const rockGeo = new THREE.DodecahedronGeometry(0.7, 1);
  const rockMat = new THREE.MeshStandardMaterial({ color: 0x181e2b, roughness: 0.95 });
  const rocks = new THREE.InstancedMesh(rockGeo, rockMat, 25);
  const matrix = new THREE.Matrix4();

  for (let i = 0; i < 25; i++) {
    const rx = (Math.random() - 0.5) * 65;
    const rz = (Math.random() - 0.5) * 65;
    const scale = 0.4 + Math.random() * 0.9;
    matrix.makeTranslation(rx, scale * 0.4, rz);
    matrix.multiply(new THREE.Matrix4().makeScale(scale, scale * 0.8, scale));
    rocks.setMatrixAt(i, matrix);
  }
  rocks.instanceMatrix.needsUpdate = true;
  rocks.receiveShadow = true;
  scene.add(rocks);
}

// 1. Habitation Alpha Module
function createHabitationModule(): THREE.Group {
  const grp = new THREE.Group();

  // Main cylindrical pressure hull
  const hullGeo = new THREE.CylinderGeometry(2.8, 2.8, 4.2, 24);
  const whiteHullMat = new THREE.MeshStandardMaterial({
    color: 0xdde4ec,
    metalness: 0.3,
    roughness: 0.35,
  });
  const hull = new THREE.Mesh(hullGeo, whiteHullMat);
  hull.rotation.z = Math.PI / 2;
  hull.position.y = 2.4;
  hull.castShadow = true;
  hull.receiveShadow = true;
  grp.add(hull);

  // End hemispherical domes
  const capGeo = new THREE.SphereGeometry(2.8, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2);
  const cap1 = new THREE.Mesh(capGeo, whiteHullMat);
  cap1.rotation.z = -Math.PI / 2;
  cap1.position.set(-2.1, 2.4, 0);
  cap1.castShadow = true;
  grp.add(cap1);

  const cap2 = new THREE.Mesh(capGeo, whiteHullMat);
  cap2.rotation.z = Math.PI / 2;
  cap2.position.set(2.1, 2.4, 0);
  cap2.castShadow = true;
  grp.add(cap2);

  // Airlock vestibule
  const airlockGeo = new THREE.BoxGeometry(1.6, 1.8, 2.2);
  const darkMetalMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.6, roughness: 0.4 });
  const airlock = new THREE.Mesh(airlockGeo, darkMetalMat);
  airlock.position.set(0, 1.0, 2.6);
  airlock.castShadow = true;
  grp.add(airlock);

  // Top observation cupola with sapphire reflection
  const cupolaGeo = new THREE.CylinderGeometry(0.9, 1.1, 0.7, 16);
  const glassMat = new THREE.MeshStandardMaterial({
    color: 0x06b6d4,
    metalness: 0.8,
    roughness: 0.1,
    emissive: 0x0891b2,
    emissiveIntensity: 0.3,
  });
  const cupola = new THREE.Mesh(cupolaGeo, glassMat);
  cupola.position.set(0, 4.7, 0);
  grp.add(cupola);

  // Support landing pylons
  for (let i = 0; i < 4; i++) {
    const legGeo = new THREE.CylinderGeometry(0.12, 0.2, 2.2, 8);
    const leg = new THREE.Mesh(legGeo, darkMetalMat);
    const angle = (i * Math.PI) / 2 + Math.PI / 4;
    leg.position.set(Math.cos(angle) * 2.2, 1.1, Math.sin(angle) * 2.2);
    leg.castShadow = true;
    grp.add(leg);
  }

  // Cyan status beacon
  const beaconGeo = new THREE.SphereGeometry(0.15, 8, 8);
  const beaconMat = new THREE.MeshBasicMaterial({ color: 0x22d3ee });
  const beacon = new THREE.Mesh(beaconGeo, beaconMat);
  beacon.position.set(0, 5.2, 0);
  grp.add(beacon);

  return grp;
}

// 2. Solar Array Module
function createSolarPowerModule(): THREE.Group {
  const grp = new THREE.Group();

  // Central equipment hub
  const hubGeo = new THREE.BoxGeometry(2.5, 1.4, 2.5);
  const hubMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.7, roughness: 0.3 });
  const hub = new THREE.Mesh(hubGeo, hubMat);
  hub.position.y = 0.7;
  hub.castShadow = true;
  grp.add(hub);

  // Vertical support mast
  const mastGeo = new THREE.CylinderGeometry(0.2, 0.25, 7.5, 12);
  const mastMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8, roughness: 0.2 });
  const mast = new THREE.Mesh(mastGeo, mastMat);
  mast.position.y = 4.2;
  mast.castShadow = true;
  grp.add(mast);

  // Solar Photovoltaic Panels (Blue silicon)
  const panelGeo = new THREE.BoxGeometry(7.5, 3.2, 0.12);
  const solarMat = new THREE.MeshStandardMaterial({
    color: 0x1e3a8a,
    roughness: 0.2,
    metalness: 0.85,
    emissive: 0x172554,
    emissiveIntensity: 0.2,
  });

  const panel1 = new THREE.Mesh(panelGeo, solarMat);
  panel1.name = 'solarPanels';
  panel1.position.set(0, 6.2, 0);
  panel1.rotation.y = Math.PI / 4;
  panel1.castShadow = true;
  grp.add(panel1);

  // Battery storage pods at base
  for (let i = 0; i < 2; i++) {
    const podGeo = new THREE.CylinderGeometry(0.6, 0.6, 1.6, 16);
    const podMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.5, roughness: 0.4 });
    const pod = new THREE.Mesh(podGeo, podMat);
    pod.rotation.x = Math.PI / 2;
    pod.position.set(-1.8 + i * 3.6, 0.8, 1.2);
    pod.castShadow = true;
    grp.add(pod);
  }

  return grp;
}

// 3. ECLSS Hub Module
function createECLSSModule(): THREE.Group {
  const grp = new THREE.Group();

  // Central recycling manifold
  const coreGeo = new THREE.BoxGeometry(3.0, 2.5, 2.2);
  const coreMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.4, roughness: 0.5 });
  const core = new THREE.Mesh(coreGeo, coreMat);
  core.position.y = 1.25;
  core.castShadow = true;
  grp.add(core);

  // Oxygen Cryo-Tank (Blue cylinder)
  const o2TankGeo = new THREE.CylinderGeometry(0.85, 0.85, 3.2, 16);
  const o2Mat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.6, roughness: 0.3 });
  const o2Tank = new THREE.Mesh(o2TankGeo, o2Mat);
  o2Tank.position.set(-1.4, 2.0, -1.0);
  o2Tank.castShadow = true;
  grp.add(o2Tank);

  // Water Distillation Tank (Teal cylinder)
  const h2oTankGeo = new THREE.CylinderGeometry(0.85, 0.85, 3.2, 16);
  const h2oMat = new THREE.MeshStandardMaterial({ color: 0x0d9488, metalness: 0.6, roughness: 0.3 });
  const h2oTank = new THREE.Mesh(h2oTankGeo, h2oMat);
  h2oTank.position.set(1.4, 2.0, -1.0);
  h2oTank.castShadow = true;
  grp.add(h2oTank);

  // Heat radiator cooling fins on top
  for (let i = 0; i < 3; i++) {
    const finGeo = new THREE.BoxGeometry(2.4, 1.0, 0.08);
    const finMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8, roughness: 0.2 });
    const fin = new THREE.Mesh(finGeo, finMat);
    fin.position.set(0, 3.0, -0.6 + i * 0.6);
    fin.castShadow = true;
    grp.add(fin);
  }

  return grp;
}

// 4. Hydroponic Greenhouse Module
function createGreenhouseModule(): THREE.Group {
  const grp = new THREE.Group();

  // Geodesic translucent dome
  const domeGeo = new THREE.SphereGeometry(3.0, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2);
  const domeMat = new THREE.MeshStandardMaterial({
    color: 0x10b981,
    transparent: true,
    opacity: 0.55,
    roughness: 0.2,
    metalness: 0.3,
  });
  const dome = new THREE.Mesh(domeGeo, domeMat);
  dome.position.y = 0.5;
  grp.add(dome);

  // Circular hydroponic substrate base
  const baseGeo = new THREE.CylinderGeometry(3.2, 3.4, 0.6, 24);
  const baseMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.6 });
  const base = new THREE.Mesh(baseGeo, baseMat);
  base.position.y = 0.3;
  base.castShadow = true;
  base.receiveShadow = true;
  grp.add(base);

  // Internal glowing photosynthetic crop trays
  const cropGeo = new THREE.CylinderGeometry(2.2, 2.2, 0.4, 16);
  const cropMat = new THREE.MeshBasicMaterial({ color: 0x34d399 });
  const crops = new THREE.Mesh(cropGeo, cropMat);
  crops.position.y = 0.8;
  grp.add(crops);

  // Central LED photosynthetic grow-light column
  const lightGeo = new THREE.CylinderGeometry(0.15, 0.15, 2.4, 8);
  const lightMat = new THREE.MeshBasicMaterial({ color: 0xa855f7 });
  const lightCol = new THREE.Mesh(lightGeo, lightMat);
  lightCol.position.y = 1.8;
  grp.add(lightCol);

  return grp;
}

// 5. Research Laboratory Module
function createResearchLabModule(): THREE.Group {
  const grp = new THREE.Group();

  // Hexagonal primary lab building
  const labGeo = new THREE.CylinderGeometry(2.6, 2.8, 2.8, 6);
  const labMat = new THREE.MeshStandardMaterial({ color: 0xcfd8dc, metalness: 0.4, roughness: 0.35 });
  const lab = new THREE.Mesh(labGeo, labMat);
  lab.position.y = 1.4;
  lab.castShadow = true;
  lab.receiveShadow = true;
  grp.add(lab);

  // Roof sensor mast
  const mastGeo = new THREE.CylinderGeometry(0.1, 0.15, 3.2, 8);
  const mastMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.7 });
  const mast = new THREE.Mesh(mastGeo, mastMat);
  mast.position.set(0, 4.4, 0);
  mast.castShadow = true;
  grp.add(mast);

  // Spectrometer optical dome
  const domeGeo = new THREE.SphereGeometry(0.8, 16, 16);
  const domeMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.8, roughness: 0.2 });
  const dome = new THREE.Mesh(domeGeo, domeMat);
  dome.position.set(1.2, 2.9, 0.8);
  grp.add(dome);

  return grp;
}

// 6. Expedition Lander & Crew Spaceship Module (Realistic Astronaut Spacecraft)
function createCrewSpaceshipModule(): THREE.Group {
  const grp = new THREE.Group();

  // 1. Heavy Reinforced Octagonal Landing Pad
  const padGeo = new THREE.CylinderGeometry(5.2, 5.6, 0.4, 8);
  const padMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.9,
    metalness: 0.2,
  });
  const pad = new THREE.Mesh(padGeo, padMat);
  pad.position.y = 0.2;
  pad.receiveShadow = true;
  grp.add(pad);

  // Central blast deflector ring
  const deflectorGeo = new THREE.CylinderGeometry(2.2, 2.4, 0.1, 16);
  const deflectorMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.7,
    metalness: 0.5,
  });
  const deflector = new THREE.Mesh(deflectorGeo, deflectorMat);
  deflector.position.y = 0.42;
  deflector.receiveShadow = true;
  grp.add(deflector);

  // 8 Perimeter LED Landing Guidance Lights
  for (let i = 0; i < 8; i++) {
    const angle = (i * Math.PI * 2) / 8 + Math.PI / 8;
    const lightMarkerGeo = new THREE.CylinderGeometry(0.12, 0.14, 0.35, 8);
    const lightMarkerMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8 });
    const lightMarker = new THREE.Mesh(lightMarkerGeo, lightMarkerMat);
    lightMarker.position.set(Math.cos(angle) * 4.9, 0.45, Math.sin(angle) * 4.9);
    grp.add(lightMarker);

    const bulbGeo = new THREE.SphereGeometry(0.1, 8, 8);
    const isAmber = i % 2 === 0;
    const bulbMat = new THREE.MeshBasicMaterial({ color: isAmber ? 0xfbbf24 : 0x06b6d4 });
    const bulb = new THREE.Mesh(bulbGeo, bulbMat);
    bulb.position.set(Math.cos(angle) * 4.9, 0.65, Math.sin(angle) * 4.9);
    grp.add(bulb);
  }

  // 2. Gold Foil Multi-Layer Insulation (MLI) Descent Stage Core
  const descentGeo = new THREE.CylinderGeometry(2.3, 2.5, 1.8, 8);
  const goldFoilMat = new THREE.MeshStandardMaterial({
    color: 0xd97706,
    metalness: 0.96,
    roughness: 0.18,
    emissive: 0x78350f,
    emissiveIntensity: 0.15,
  });
  const descentStage = new THREE.Mesh(descentGeo, goldFoilMat);
  descentStage.position.y = 1.6;
  descentStage.castShadow = true;
  descentStage.receiveShadow = true;
  grp.add(descentStage);

  // 4 Outrigger Propellant Tanks (Spherical LOX & Methane Cryo-Dewars)
  const tankGeo = new THREE.SphereGeometry(0.7, 16, 16);
  const titaniumTankMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.85, roughness: 0.2 });
  const bronzeTankMat = new THREE.MeshStandardMaterial({ color: 0xb45309, metalness: 0.9, roughness: 0.25 });

  for (let i = 0; i < 4; i++) {
    const angle = (i * Math.PI) / 2;
    const mat = i % 2 === 0 ? titaniumTankMat : bronzeTankMat;
    const tank = new THREE.Mesh(tankGeo, mat);
    tank.position.set(Math.cos(angle) * 2.1, 1.6, Math.sin(angle) * 2.1);
    tank.castShadow = true;
    grp.add(tank);
  }

  // Central Vacuum Rocket Engine Bell
  const bellGeo = new THREE.ConeGeometry(0.85, 1.3, 16, 1, true);
  const bellMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.9,
    roughness: 0.25,
    side: THREE.DoubleSide,
  });
  const engineBell = new THREE.Mesh(bellGeo, bellMat);
  engineBell.position.y = 0.95;
  engineBell.castShadow = true;
  grp.add(engineBell);

  // Engine Throat Glow Ring
  const throatGeo = new THREE.TorusGeometry(0.3, 0.08, 8, 16);
  const throatMat = new THREE.MeshBasicMaterial({ color: 0x0284c7 });
  const throat = new THREE.Mesh(throatGeo, throatMat);
  throat.rotation.x = Math.PI / 2;
  throat.position.y = 1.1;
  grp.add(throat);

  // 4 Heavy Landing Gear Outriggers with Shock-Absorbing Struts and Footpads
  const strutMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8, roughness: 0.3 });
  const footpadGeo = new THREE.CylinderGeometry(0.55, 0.65, 0.12, 12);
  const footpadMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.75, roughness: 0.35 });

  for (let i = 0; i < 4; i++) {
    const angle = (i * Math.PI) / 2 + Math.PI / 4;
    const legGrp = new THREE.Group();
    legGrp.position.set(0, 1.4, 0);
    legGrp.rotation.y = angle;

    // Main primary telescoping strut angled down to the pad
    const mainStrutGeo = new THREE.CylinderGeometry(0.1, 0.14, 2.6, 8);
    const mainStrut = new THREE.Mesh(mainStrutGeo, strutMat);
    mainStrut.rotation.z = -Math.PI / 4.2;
    mainStrut.position.set(2.0, -0.6, 0);
    mainStrut.castShadow = true;
    legGrp.add(mainStrut);

    // A-frame secondary stabilizing truss
    const subStrutGeo = new THREE.CylinderGeometry(0.06, 0.06, 1.8, 6);
    const subStrut = new THREE.Mesh(subStrutGeo, strutMat);
    subStrut.rotation.z = Math.PI / 5;
    subStrut.position.set(1.9, -0.3, 0.4);
    subStrut.castShadow = true;
    legGrp.add(subStrut);

    const subStrut2 = new THREE.Mesh(subStrutGeo, strutMat);
    subStrut2.rotation.z = Math.PI / 5;
    subStrut2.position.set(1.9, -0.3, -0.4);
    subStrut2.castShadow = true;
    legGrp.add(subStrut2);

    // Circular Landing Footpad
    const padMesh = new THREE.Mesh(footpadGeo, footpadMat);
    padMesh.position.set(3.2, -1.35, 0);
    padMesh.castShadow = true;
    legGrp.add(padMesh);

    grp.add(legGrp);
  }

  // Astronaut EVA Egress Ladder extending down the forward leg
  const ladderGrp = new THREE.Group();
  ladderGrp.position.set(0, 0, 0);
  const railGeo = new THREE.CylinderGeometry(0.03, 0.03, 2.8, 6);
  const railMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.8 });
  const railL = new THREE.Mesh(railGeo, railMat);
  railL.rotation.x = Math.PI / 5.5;
  railL.position.set(1.9, 1.6, 1.8);
  ladderGrp.add(railL);

  const railR = new THREE.Mesh(railGeo, railMat);
  railR.rotation.x = Math.PI / 5.5;
  railR.position.set(2.4, 1.6, 1.8);
  ladderGrp.add(railR);

  // Ladder rungs
  for (let r = 0; r < 7; r++) {
    const rungGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.5, 6);
    const rung = new THREE.Mesh(rungGeo, railMat);
    rung.rotation.z = Math.PI / 2;
    rung.position.set(2.15, 0.6 + r * 0.35, 2.1 - r * 0.16);
    ladderGrp.add(rung);
  }
  grp.add(ladderGrp);

  // 3. Pressurized Astronaut Crew Cabin (Ascent Vehicle)
  // Lower crew habitat cylinder
  const crewCylGeo = new THREE.CylinderGeometry(1.9, 2.15, 1.4, 16);
  const whiteHullMat = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    metalness: 0.45,
    roughness: 0.28,
  });
  const crewCyl = new THREE.Mesh(crewCylGeo, whiteHullMat);
  crewCyl.position.y = 3.2;
  crewCyl.castShadow = true;
  crewCyl.receiveShadow = true;
  grp.add(crewCyl);

  // Upper aerodynamic command cone / nose cone
  const coneGeo = new THREE.CylinderGeometry(1.0, 1.9, 1.9, 16);
  const commandCone = new THREE.Mesh(coneGeo, whiteHullMat);
  commandCone.position.y = 4.85;
  commandCone.castShadow = true;
  commandCone.receiveShadow = true;
  grp.add(commandCone);

  // Black ceramic thermal heatshield tiles band around the forward rim
  const heatshieldGeo = new THREE.TorusGeometry(1.92, 0.12, 8, 24);
  const heatshieldMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.9 });
  const heatshield = new THREE.Mesh(heatshieldGeo, heatshieldMat);
  heatshield.rotation.x = Math.PI / 2;
  heatshield.position.y = 3.9;
  grp.add(heatshield);

  // 4. Cockpit Flight Deck Panoramic Windows (Sapphire Cyan Glass)
  const windowGeo = new THREE.BoxGeometry(0.7, 0.45, 0.15);
  const windowMat = new THREE.MeshStandardMaterial({
    color: 0x0284c7,
    emissive: 0x0ea5e9,
    emissiveIntensity: 0.45,
    metalness: 0.95,
    roughness: 0.1,
  });

  // Commander window
  const winLeft = new THREE.Mesh(windowGeo, windowMat);
  winLeft.rotation.y = -Math.PI / 8;
  winLeft.rotation.x = -Math.PI / 8;
  winLeft.position.set(-0.45, 4.7, 1.4);
  grp.add(winLeft);

  // Pilot window
  const winRight = new THREE.Mesh(windowGeo, windowMat);
  winRight.rotation.y = Math.PI / 8;
  winRight.rotation.x = -Math.PI / 8;
  winRight.position.set(0.45, 4.7, 1.4);
  grp.add(winRight);

  // 5. Astronaut Ingress / Egress Airlock Hatch
  const hatchGeo = new THREE.CylinderGeometry(0.45, 0.48, 0.18, 16);
  const hatchMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.7, roughness: 0.3 });
  const hatch = new THREE.Mesh(hatchGeo, hatchMat);
  hatch.rotation.z = Math.PI / 2;
  hatch.position.set(2.0, 3.2, 0.5);
  hatch.castShadow = true;
  grp.add(hatch);

  // Hatch rotating manual dog-latch ring
  const latchGeo = new THREE.TorusGeometry(0.2, 0.04, 6, 12);
  const latchMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9 });
  const latch = new THREE.Mesh(latchGeo, latchMat);
  latch.rotation.y = Math.PI / 2;
  latch.position.set(2.1, 3.2, 0.5);
  grp.add(latch);

  // 6. Reaction Control System (RCS) 4-Way Thruster Quads
  const rcsBlockMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.85, roughness: 0.3 });
  const nozzleGeo = new THREE.ConeGeometry(0.08, 0.16, 8, 1, true);
  const nozzleMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9, side: THREE.DoubleSide });

  for (let i = 0; i < 4; i++) {
    const angle = (i * Math.PI) / 2;
    const rcsGrp = new THREE.Group();
    rcsGrp.position.set(Math.cos(angle) * 1.85, 3.6, Math.sin(angle) * 1.85);
    rcsGrp.rotation.y = angle;

    const blockGeo = new THREE.BoxGeometry(0.22, 0.22, 0.22);
    const block = new THREE.Mesh(blockGeo, rcsBlockMat);
    rcsGrp.add(block);

    // 4 miniature divergent nozzles (+X, -X, +Y, -Y)
    const n1 = new THREE.Mesh(nozzleGeo, nozzleMat);
    n1.rotation.z = -Math.PI / 2;
    n1.position.set(0.18, 0, 0);
    rcsGrp.add(n1);

    const n2 = new THREE.Mesh(nozzleGeo, nozzleMat);
    n2.rotation.x = Math.PI / 2;
    n2.position.set(0, 0, 0.18);
    rcsGrp.add(n2);

    const n3 = new THREE.Mesh(nozzleGeo, nozzleMat);
    n3.rotation.x = -Math.PI / 2;
    n3.position.set(0, 0, -0.18);
    rcsGrp.add(n3);

    grp.add(rcsGrp);
  }

  // 7. Zenith International Docking Adapter Ring
  const dockingRingGeo = new THREE.TorusGeometry(0.65, 0.1, 8, 24);
  const dockingRingMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.85, roughness: 0.25 });
  const dockingRing = new THREE.Mesh(dockingRingGeo, dockingRingMat);
  dockingRing.rotation.x = Math.PI / 2;
  dockingRing.position.y = 5.85;
  dockingRing.castShadow = true;
  grp.add(dockingRing);

  // 8. Steerable High-Gain Deep Space Communications & Radar Dish (Gimbaled)
  const dishGrp = new THREE.Group();
  dishGrp.name = 'dish';
  dishGrp.position.set(0.6, 5.9, -0.4);

  const boomGeo = new THREE.CylinderGeometry(0.06, 0.08, 0.8, 8);
  const boomMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8 });
  const boom = new THREE.Mesh(boomGeo, boomMat);
  boom.position.y = 0.4;
  dishGrp.add(boom);

  // Dish reflector
  const dishPoints: THREE.Vector2[] = [];
  for (let i = 0; i <= 8; i++) {
    const t = i / 8;
    dishPoints.push(new THREE.Vector2(t * 0.9, (t * 0.9) ** 2 * 0.25));
  }
  const dishGeo = new THREE.LatheGeometry(dishPoints, 16);
  const dishMat = new THREE.MeshStandardMaterial({
    color: 0xf1f5f9,
    metalness: 0.8,
    roughness: 0.2,
    side: THREE.DoubleSide,
  });
  const dishMesh = new THREE.Mesh(dishGeo, dishMat);
  dishMesh.rotation.x = Math.PI / 3;
  dishMesh.position.set(0, 0.85, 0);
  dishMesh.castShadow = true;
  dishGrp.add(dishMesh);

  // Subreflector feedhorn
  const subFeedGeo = new THREE.CylinderGeometry(0.04, 0.08, 0.3, 6);
  const subFeedMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.9 });
  const subFeed = new THREE.Mesh(subFeedGeo, subFeedMat);
  subFeed.position.set(0, 1.25, 0.25);
  dishGrp.add(subFeed);

  grp.add(dishGrp);

  // 9. Navigation Strobe Beacons (Animated in render loop)
  const beaconMat = new THREE.MeshBasicMaterial({ color: 0x22d3ee, transparent: true, opacity: 0.9 });
  const beaconGeo = new THREE.SphereGeometry(0.12, 8, 8);
  const beacon = new THREE.Mesh(beaconGeo, beaconMat);
  beacon.name = 'shipBeacon';
  beacon.position.set(-0.6, 5.95, -0.4);
  grp.add(beacon);

  return grp;
}
