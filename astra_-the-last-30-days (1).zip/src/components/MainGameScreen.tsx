/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { LunarBase3D } from './LunarBase3D';
import { ResourceRadialMeters } from './ResourceRadialMeters';
import { DailyStoryCard } from './DailyStoryCard';
import { MissionState, DailyResourceDeltas, OutpostModuleAction } from '../types/mission';
import {
  Box,
  Wrench,
  ChevronDown,
  ChevronUp,
  BarChart3,
  Award,
  X,
  Sun,
  Moon,
  ShieldCheck,
} from 'lucide-react';
import { soundEngine } from '../services/soundEngine';
import { getNextUpcomingBadge } from '../data/badgeData';

interface MainGameScreenProps {
  state: MissionState;
  deltas: DailyResourceDeltas;
  onAdvanceDay: () => void;
  onOpenDecision: () => void;
  onOpenEmergency: () => void;
  onExecuteModuleAction: (moduleId: string, action: OutpostModuleAction) => void;
  onSwitchToTelemetry: () => void;
  onOpenDiscovery?: () => void;
  onOpenBadges?: () => void;
}

export const MainGameScreen: React.FC<MainGameScreenProps> = ({
  state,
  deltas,
  onAdvanceDay,
  onOpenDecision,
  onOpenEmergency,
  onExecuteModuleAction,
  onSwitchToTelemetry,
  onOpenDiscovery,
  onOpenBadges,
}) => {
  const [selectedModuleId, setSelectedModuleId] = useState<string | null>(null);
  const [isInspectorExpanded, setIsInspectorExpanded] = useState<boolean>(true);

  const selectedModule = state.modules.find((m) => m.id === selectedModuleId);
  const nextBadgeInfo = getNextUpcomingBadge(state.day);

  return (
    <div className="relative w-full h-[calc(100dvh-54px)] min-h-[540px] overflow-hidden select-none bg-[#090e24]">
      {/* 1. HERO 3D LUNAR OUTPOST VIEWPORT */}
      <div className="absolute inset-0 z-0">
        <LunarBase3D
          modules={state.modules}
          selectedModuleId={selectedModuleId}
          onSelectModule={(id) => {
            soundEngine.playTelemetryClick();
            setSelectedModuleId(id || null);
            if (id) setIsInspectorExpanded(true);
          }}
          solarAngleDeg={state.solarAngleDeg}
          isLunarNight={state.isLunarNight}
        />
      </div>

      {/* 2. FLOATING TOP HUD (Clean, Colorful & Responsive) */}
      <div className="absolute top-2 sm:top-3 left-2.5 right-2.5 sm:left-3 sm:right-3 z-10 pointer-events-none flex flex-col gap-1.5 sm:gap-2.5 max-w-7xl mx-auto">
        <div className="flex items-center justify-between gap-1.5 sm:gap-2 overflow-x-auto no-scrollbar">
          {/* Day & Sunlight Tracker */}
          <div className="pointer-events-auto bg-[#121a3d]/90 backdrop-blur-md px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-xl sm:rounded-2xl border border-indigo-400/40 flex items-center gap-2 sm:gap-3 shadow-lg shrink-0">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] sm:text-[11px] font-bold uppercase text-cyan-300">Day</span>
              <span className="text-sm sm:text-base font-extrabold font-mono text-white tabular-nums">
                {state.day}
                <span className="text-[11px] sm:text-xs text-indigo-300 font-normal">/30</span>
              </span>
            </div>
            <span className="text-indigo-500">|</span>
            <div className="text-[11px] sm:text-xs font-semibold flex items-center gap-1">
              {state.isLunarNight ? (
                <>
                  <Moon className="w-3.5 h-3.5 text-amber-300" />
                  <span className="text-amber-200">Shadow</span>
                </>
              ) : (
                <>
                  <Sun className="w-3.5 h-3.5 text-emerald-300" />
                  <span className="text-emerald-200">Sunny</span>
                </>
              )}
            </div>
            <span className="text-indigo-500 hidden sm:inline">|</span>
            <div className="hidden sm:flex items-center gap-1.5 text-xs font-semibold text-cyan-200">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-300" />
              <span>Base Shield: {Math.round(state.resources.baseIntegrity)}%</span>
            </div>
          </div>

          {/* Next Explorer Badge Progress */}
          {nextBadgeInfo.badge && (
            <button
              type="button"
              onClick={() => {
                soundEngine.playTelemetryClick();
                if (onOpenBadges) onOpenBadges();
              }}
              className="pointer-events-auto bg-[#1b1942]/90 backdrop-blur-md px-2.5 sm:px-3.5 py-1 sm:py-1.5 rounded-xl sm:rounded-2xl border border-amber-400/50 hover:border-amber-300 flex items-center gap-2 shadow-lg transition-all cursor-pointer text-left shrink-0"
              title="Click to see all 6 NASA Explorer Badges"
            >
              <Award className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-300 shrink-0" />
              <div className="flex flex-col">
                <div className="flex items-center gap-1 text-[10px] sm:text-[11px] font-bold">
                  <span className="text-amber-300 whitespace-nowrap">{nextBadgeInfo.badge.title}</span>
                  <span className="text-indigo-200 hidden md:inline font-mono">
                    ({nextBadgeInfo.daysRemaining}d left)
                  </span>
                </div>
                <div className="w-16 sm:w-28 h-1.5 bg-indigo-950 rounded-full overflow-hidden mt-0.5 border border-amber-400/30">
                  <div
                    className="h-full bg-gradient-to-r from-amber-400 to-yellow-300 rounded-full transition-all duration-500"
                    style={{ width: `${nextBadgeInfo.progressPercent}%` }}
                  />
                </div>
              </div>
            </button>
          )}

          {/* 4-Astronaut Squad Health Pills */}
          <div className="hidden md:flex pointer-events-auto bg-[#121a3d]/90 backdrop-blur-md px-2.5 py-1.5 rounded-2xl border border-violet-400/40 items-center gap-1.5 shadow-lg shrink-0">
            {state.crew.map((member) => (
              <div
                key={member.id}
                className="flex items-center gap-1.5 px-2 py-0.5 rounded-xl bg-[#0b112c]/90 border border-indigo-400/25"
                title={`${member.name} (${member.role}) · Health: ${member.health}% · Mood: ${member.morale}%`}
              >
                <div
                  className="w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold text-white"
                  style={{ backgroundColor: `${member.color}45`, border: `1.5px solid ${member.color}` }}
                >
                  {member.name[0]}
                </div>
                <span className="text-[11px] font-semibold text-indigo-100 hidden lg:inline">
                  {member.callsign}
                </span>
                <span
                  className={`text-[10px] font-mono font-bold tabular-nums ${
                    member.health < 50 ? 'text-rose-300' : 'text-emerald-300'
                  }`}
                >
                  {member.health}%
                </span>
              </div>
            ))}
          </div>

          {/* Switch to Crew & Stats (Desktop shortcut; mobile uses TopBar tab) */}
          <button
            onClick={() => {
              soundEngine.playTelemetryClick();
              onSwitchToTelemetry();
            }}
            className="hidden sm:flex pointer-events-auto items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-400 hover:to-fuchsia-400 text-white text-xs font-extrabold shadow-lg shadow-violet-500/25 transition-all cursor-pointer whitespace-nowrap shrink-0"
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Crew & Stats</span>
          </button>
        </div>

        {/* 4 Color-Coded Resource Meters */}
        <div className="pointer-events-auto max-w-3xl">
          <ResourceRadialMeters resources={state.resources} deltas={deltas} />
        </div>
      </div>

      {/* 3. COLLAPSIBLE BASE BUILDING INSPECTOR (Bottom sheet on mobile, right panel on desktop) */}
      {selectedModule ? (
        <div className="absolute bottom-2.5 left-2.5 right-2.5 lg:bottom-auto lg:left-auto lg:top-36 lg:right-3 z-30 lg:w-80 pointer-events-auto transition-all duration-300">
          <div className="bg-[#121a3e]/97 backdrop-blur-md border-2 border-cyan-400/55 rounded-2xl shadow-2xl overflow-hidden max-h-[54dvh] lg:max-h-none flex flex-col">
            <div
              className="p-3 bg-indigo-950/80 border-b border-indigo-400/25 flex items-center justify-between cursor-pointer shrink-0"
              onClick={() => setIsInspectorExpanded(!isInspectorExpanded)}
            >
              <div className="flex items-center gap-2 min-w-0">
                <Box className="w-4 h-4 text-cyan-300 shrink-0" />
                <span className="font-display font-bold text-sm text-white truncate">{selectedModule.name}</span>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-lg border ${
                    selectedModule.status === 'nominal'
                      ? 'bg-emerald-500/20 text-emerald-200 border-emerald-400/50'
                      : 'bg-amber-500/20 text-amber-200 border-amber-400/50'
                  }`}
                >
                  {selectedModule.status === 'nominal' ? 'Working Great' : selectedModule.status}
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsInspectorExpanded(!isInspectorExpanded);
                  }}
                  className="p-1 text-indigo-200 hover:text-white cursor-pointer"
                >
                  {isInspectorExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    soundEngine.playTelemetryClick();
                    setSelectedModuleId(null);
                  }}
                  className="p-1 text-indigo-200 hover:text-white hover:bg-indigo-800 rounded-lg transition-colors cursor-pointer"
                  title="Close Inspector"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {isInspectorExpanded && (
              <div className="p-3.5 space-y-3 text-xs overflow-y-auto">
                <p className="text-indigo-100 leading-snug line-clamp-2">{selectedModule.description}</p>

                <div className="grid grid-cols-2 gap-2 font-mono text-xs">
                  <div className="p-2 bg-[#0c1330] rounded-xl border border-indigo-400/25">
                    <span className="text-indigo-300 block text-[10px]">Condition</span>
                    <span className="font-bold text-emerald-300">{selectedModule.efficiency}%</span>
                  </div>
                  <div className="p-2 bg-[#0c1330] rounded-xl border border-indigo-400/25">
                    <span className="text-indigo-300 block text-[10px]">Power Used</span>
                    <span className="font-bold text-cyan-300">{selectedModule.powerDrawKw} kW</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-indigo-400/20">
                  <div className="text-[11px] font-bold uppercase text-amber-300 mb-2 flex items-center gap-1.5">
                    <Wrench className="w-3.5 h-3.5" />
                    <span>Quick Boosts</span>
                  </div>

                  <div className="space-y-1.5">
                    {selectedModule.actions.map((act) => {
                      const onCooldown = act.lastUsedDay && state.day - act.lastUsedDay < act.cooldownDays;
                      return (
                        <div
                          key={act.id}
                          className="p-2.5 bg-[#0c1330]/90 rounded-xl border border-indigo-400/25 flex items-center justify-between gap-2"
                        >
                          <div className="min-w-0">
                            <div className="text-xs font-bold text-white truncate">{act.label}</div>
                            <div className="text-[10px] text-indigo-200 truncate">{act.effectDesc}</div>
                          </div>
                          <button
                            disabled={!!onCooldown}
                            onClick={() => onExecuteModuleAction(selectedModule.id, act)}
                            className={`px-3 py-1.5 rounded-lg text-[11px] font-extrabold shrink-0 transition-colors cursor-pointer ${
                              onCooldown
                                ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                                : 'bg-gradient-to-r from-cyan-400 to-sky-400 hover:from-cyan-300 hover:to-sky-300 text-slate-950 shadow'
                            }`}
                          >
                            {onCooldown ? 'Wait' : 'Boost'}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <button
          onClick={() => {
            soundEngine.playTelemetryClick();
            setSelectedModuleId('living-habitat');
          }}
          className="hidden lg:flex absolute top-36 right-3 z-10 pointer-events-auto items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-[#121a3d]/90 backdrop-blur-md border border-cyan-400/45 hover:border-cyan-300 text-xs font-bold text-cyan-200 shadow-lg transition-colors cursor-pointer whitespace-nowrap"
          title="Click to inspect or boost Moon base buildings"
        >
          <Box className="w-4 h-4 text-cyan-300" />
          <span>Inspect Buildings</span>
        </button>
      )}

      {/* 4. BOTTOM ACTION DECK */}
      <div className="absolute bottom-2.5 left-2.5 right-2.5 lg:bottom-3 lg:left-3 lg:right-3 z-10 pointer-events-none flex justify-center lg:justify-end lg:pr-4">
        <div className="pointer-events-auto w-full max-w-xl">
          <DailyStoryCard
            day={state.day}
            decision={state.activeDecision}
            emergency={state.activeEmergency}
            crew={state.crew}
            onOpenDecision={onOpenDecision}
            onOpenEmergency={onOpenEmergency}
            onAdvanceDay={onAdvanceDay}
            onOpenDiscovery={onOpenDiscovery}
          />
        </div>
      </div>
    </div>
  );
};
