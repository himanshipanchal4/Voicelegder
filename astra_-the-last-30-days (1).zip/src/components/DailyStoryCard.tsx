/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowRight, Sparkles, CheckCircle2, ShieldAlert, Zap } from 'lucide-react';
import { DailyDecision, EmergencyIncident, CrewMember } from '../types/mission';

interface DailyStoryCardProps {
  day: number;
  decision?: DailyDecision;
  emergency?: EmergencyIncident;
  crew: CrewMember[];
  onOpenDecision: () => void;
  onOpenEmergency: () => void;
  onAdvanceDay: () => void;
  onOpenDiscovery?: () => void;
}

export const DailyStoryCard: React.FC<DailyStoryCardProps> = ({
  day,
  decision,
  emergency,
  crew,
  onOpenDecision,
  onOpenEmergency,
  onAdvanceDay,
  onOpenDiscovery,
}) => {
  let chapterTitle = 'Day 1: Moon Landing!';
  let chapterGoal = 'Check your gauges and make today’s first choice.';

  if (day >= 2 && day <= 5) {
    chapterTitle = `Day ${day}: Building Our Base Routine`;
    chapterGoal = 'Keep air, water, and power balanced to earn Badge Level I!';
  } else if (day >= 6 && day <= 13) {
    chapterTitle = `Day ${day}: Space Science Explorer`;
    chapterGoal = 'Test Moon rocks and keep your base clean from Moon dust.';
  } else if (day === 14 || day === 15) {
    chapterTitle = `Day ${day}: Mountain Shadow Challenge!`;
    chapterGoal = 'Save battery power while a huge crater peak blocks the Sun.';
  } else if (day >= 16 && day <= 27) {
    chapterTitle = `Day ${day}: Deep Space Endurance`;
    chapterGoal = 'Grow fresh space food and keep your squad energized.';
  } else if (day >= 28) {
    chapterTitle = `Day ${day}: Final Countdown!`;
    chapterGoal = 'Send your science discoveries to Earth and finish strong!';
  }

  const randomCrew = crew[(day - 1) % crew.length] || crew[0];
  const needsAction = Boolean(emergency || decision);

  return (
    <div className="bg-[#121a3e]/94 backdrop-blur-md border-2 border-indigo-400/40 rounded-2xl sm:rounded-3xl p-3 sm:p-5 shadow-2xl space-y-2 sm:space-y-2.5 select-none">
      {/* Header Row */}
      <div className="flex items-center justify-between border-b border-indigo-400/20 pb-1.5 sm:pb-2 gap-2">
        <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
          <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl bg-gradient-to-br from-cyan-400 to-indigo-500 flex items-center justify-center text-slate-950 shrink-0 font-mono text-[11px] sm:text-xs font-extrabold shadow-md">
            D{day}
          </div>
          <div className="min-w-0">
            <div className="text-[10px] font-bold uppercase text-cyan-300 tracking-wide">
              {needsAction ? 'Step 1 of 2' : 'Step 2 of 2'}
            </div>
            <h3 className="font-display text-xs sm:text-base font-extrabold text-white truncate">
              {chapterTitle}
            </h3>
          </div>
        </div>

        {emergency ? (
          <span className="text-[11px] sm:text-xs px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-lg sm:rounded-xl bg-rose-500/25 text-rose-200 border border-rose-400/60 font-bold flex items-center gap-1 shrink-0 whitespace-nowrap">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-300" />
            <span>Alert!</span>
          </span>
        ) : decision ? (
          <span className="text-[11px] sm:text-xs px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-lg sm:rounded-xl bg-amber-500/25 text-amber-200 border border-amber-400/60 font-bold shrink-0 whitespace-nowrap">
            Choice
          </span>
        ) : (
          <span className="text-[11px] sm:text-xs px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-lg sm:rounded-xl bg-emerald-500/25 text-emerald-200 border border-emerald-400/60 font-bold shrink-0 whitespace-nowrap">
            Ready
          </span>
        )}
      </div>

      {/* Single Short Story Line */}
      <p className="text-xs sm:text-sm text-indigo-100 leading-snug line-clamp-2">
        {decision?.context || chapterGoal}
      </p>

      {/* Compact Crew Quote (hidden on narrow mobile to keep 3D base roomy) */}
      <div className="hidden sm:flex px-3 py-1.5 bg-[#0d1433]/80 rounded-xl border border-indigo-400/25 items-center gap-2">
        <div
          className="w-6 h-6 rounded-full flex items-center justify-center font-mono font-bold text-[10px] text-white shrink-0 border"
          style={{ backgroundColor: `${randomCrew.color}35`, borderColor: randomCrew.color }}
        >
          {randomCrew.name[0]}
        </div>
        <div className="flex-1 min-w-0 text-xs truncate">
          <span className="font-bold text-amber-300 mr-1.5">{randomCrew.callsign}:</span>
          <span className="text-indigo-100 italic">&ldquo;{randomCrew.quote}&rdquo;</span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center justify-between gap-2 pt-0.5 sm:pt-1">
        {onOpenDiscovery && (
          <button
            onClick={onOpenDiscovery}
            title="Play today’s quick Space Quiz for +50 bonus points"
            className="flex items-center justify-center gap-1 sm:gap-1.5 px-2.5 sm:px-3.5 py-2 sm:py-2.5 bg-gradient-to-r from-violet-500/30 to-fuchsia-500/30 hover:from-violet-500/45 hover:to-fuchsia-500/45 text-fuchsia-200 border border-fuchsia-400/50 rounded-xl text-[11px] sm:text-xs font-bold transition-all cursor-pointer shrink-0 whitespace-nowrap"
          >
            <Zap className="w-3.5 h-3.5 text-amber-300" />
            <span className="sm:hidden">Quiz +50</span>
            <span className="hidden sm:inline">Space Quiz (+50 pts)</span>
          </button>
        )}

        <div className="flex items-center gap-2 ml-auto">
          {emergency ? (
            <button
              onClick={onOpenEmergency}
              className="flex items-center gap-1.5 sm:gap-2 px-3.5 sm:px-5 py-2 sm:py-2.5 bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-400 hover:to-pink-400 text-white text-xs sm:text-sm font-extrabold rounded-xl shadow-lg shadow-rose-500/30 transition-all cursor-pointer shrink-0 whitespace-nowrap"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Fix Base Alert!</span>
            </button>
          ) : decision ? (
            <button
              onClick={onOpenDecision}
              className="flex items-center gap-1.5 sm:gap-2 px-3.5 sm:px-5 py-2 sm:py-2.5 bg-gradient-to-r from-cyan-400 to-sky-400 hover:from-cyan-300 hover:to-sky-300 text-slate-950 text-xs sm:text-sm font-extrabold rounded-xl shadow-lg shadow-cyan-500/30 transition-all cursor-pointer shrink-0 whitespace-nowrap"
            >
              <Sparkles className="w-4 h-4" />
              <span>Make Today’s Choice</span>
            </button>
          ) : (
            <button
              onClick={onAdvanceDay}
              className="flex items-center gap-1.5 sm:gap-2 px-3.5 sm:px-5 py-2 sm:py-2.5 bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400 hover:from-emerald-300 hover:to-sky-300 text-slate-950 font-extrabold text-xs sm:text-sm rounded-xl shadow-lg shadow-emerald-500/30 transition-all hover:translate-y-[-1px] cursor-pointer group shrink-0 whitespace-nowrap"
              title="Launch to the next day on the Moon (Shortcut: Space)"
            >
              <CheckCircle2 className="w-4 h-4 text-slate-950" />
              <span>{day >= 30 ? 'Complete Mission!' : `Launch to Day ${day + 1}`}</span>
              <ArrowRight className="w-4 h-4 text-slate-950 group-hover:translate-x-0.5 transition-transform" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
