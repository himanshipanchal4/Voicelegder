/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Award,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Volume2,
  Orbit,
  FastForward,
  BookOpen,
} from 'lucide-react';
import { BadgeDefinition } from '../data/badgeData';
import { BadgeInsignia } from './BadgeInsignia';
import { soundEngine } from '../services/soundEngine';

interface BadgeCeremonyModalProps {
  badge: BadgeDefinition;
  completedDay: number;
  onAddToCollection: (badgeId: string) => void;
  onContinue: () => void;
}

export const BadgeCeremonyModal: React.FC<BadgeCeremonyModalProps> = ({
  badge,
  completedDay,
  onAddToCollection,
  onContinue,
}) => {
  const [animationStep, setAnimationStep] = useState<number>(1);
  const [isAdded, setIsAdded] = useState(false);

  // Play fanfare victory sound on mount
  useEffect(() => {
    soundEngine.playDiscoveryReveal();

    const t1 = setTimeout(() => setAnimationStep(2), 800);   // Holographic materialization
    const t2 = setTimeout(() => setAnimationStep(3), 2000);  // Badge assembly & settle
    const t3 = setTimeout(() => setAnimationStep(4), 3200);  // Mentor dialogue & actions

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, []);

  const handleSkipAnimation = () => {
    soundEngine.playTelemetryClick();
    setAnimationStep(4);
  };

  const handleAddClick = () => {
    soundEngine.playConfirm();
    setIsAdded(true);
    onAddToCollection(badge.id);
  };

  const handleContinueClick = () => {
    soundEngine.playConfirm();
    onContinue();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl animate-fade-in select-none">
      {/* Dynamic Starfield Background Glow */}
      <div
        className="absolute inset-0 pointer-events-none opacity-40 blur-3xl transition-all duration-1000"
        style={{
          background: `radial-gradient(circle at 50% 50%, ${badge.palette.accent}40 0%, ${badge.palette.primary}30 50%, transparent 75%)`,
        }}
      />

      <div
        className="relative w-full max-w-2xl bg-[#030712]/95 border rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col items-center text-center overflow-hidden transition-all duration-500"
        style={{
          borderColor: `${badge.palette.border}80`,
          boxShadow: `0 0 60px ${badge.palette.glow}, 0 25px 50px rgba(0,0,0,0.9)`,
        }}
      >
        {/* Skip Animation Button */}
        {animationStep < 4 && (
          <button
            onClick={handleSkipAnimation}
            className="absolute top-4 right-4 flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/80 border border-slate-700 hover:border-cyan-400 text-xs font-mono text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            <FastForward className="w-3.5 h-3.5" />
            <span>Skip</span>
          </button>
        )}

        {/* STEP 1: MILESTONE BANNER */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/50 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-3 animate-pulse">
          <Award className="w-3.5 h-3.5 text-cyan-400" />
          <span>TRAINING MILESTONE ACHIEVED &bull; DAY {completedDay} COMPLETE</span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-black text-slate-100 tracking-tight">
          New Insignia Conferred
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1 font-mono">
          NASA ASTRONAUT CORPS SURVIVAL TRAINING &bull; LEVEL {badge.romanNumeral}
        </p>

        {/* STEP 3 & 4: BADGE MATERIALISATION & REVEAL STAGE */}
        <div className="my-6 relative flex items-center justify-center min-h-[230px]">
          {animationStep < 2 ? (
            /* Holographic Wireframe Outline Pulse */
            <div className="w-48 h-48 rounded-full border-2 border-dashed border-cyan-400/80 animate-spin flex items-center justify-center">
              <Sparkles className="w-12 h-12 text-cyan-400 animate-ping" />
            </div>
          ) : (
            /* Finished Badge settling in center */
            <div className="animate-scale-in transition-all duration-700">
              <BadgeInsignia
                badge={badge}
                isUnlocked={true}
                size="xl"
                isNewlyEarned={true}
              />
            </div>
          )}
        </div>

        {/* BADGE DETAILS & DESCRIPTION */}
        <div className="space-y-2 max-w-lg">
          <h2 className="text-xl sm:text-2xl font-black tracking-wide text-slate-100 font-mono">
            LEVEL {badge.romanNumeral} &bull; {badge.title}
          </h2>
          <p className="text-xs sm:text-sm text-cyan-300 font-sans italic">
            &ldquo;{badge.description}&rdquo;
          </p>
          <p className="text-xs text-slate-400 leading-relaxed font-sans pt-1">
            {badge.lore}
          </p>
        </div>

        {/* STEP 5: ASTRONAUT MENTOR CONGRATULATIONS */}
        <div className="mt-5 w-full bg-slate-900/80 border border-slate-800 rounded-2xl p-4 text-left flex items-start gap-3.5 animate-fade-in">
          {/* Mentor Mini Visor Avatar */}
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-900 to-slate-950 border border-cyan-500/60 flex items-center justify-center shrink-0 shadow-inner">
            <Orbit className="w-5 h-5 text-cyan-400 animate-spin" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between text-[11px] font-mono text-cyan-400 font-bold mb-1">
              <span>SPECIALIST NOVA &bull; EXPEDITION MENTOR</span>
              <button
                onClick={() => soundEngine.playConfirm()}
                className="text-[10px] text-slate-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
              >
                <Volume2 className="w-3 h-3" />
                <span>Replay</span>
              </button>
            </div>
            <p className="text-xs text-slate-200 leading-relaxed font-sans">
              &ldquo;{badge.mentorQuote}&rdquo;
            </p>
          </div>
        </div>

        {/* STEP 6 & 7: ACTION CONTROLS */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-3 w-full">
          {!isAdded ? (
            <button
              onClick={handleAddClick}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs sm:text-sm font-mono shadow-xl shadow-orange-500/25 transition-all hover:scale-[1.02] cursor-pointer"
            >
              <Sparkles className="w-4 h-4 fill-current" />
              <span>ADD TO MY COLLECTION</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 font-mono text-xs font-bold">
              <CheckCircle2 className="w-4 h-4" />
              <span>ADDED TO COLLECTION</span>
            </div>
          )}

          <button
            onClick={handleContinueClick}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-100 font-bold text-xs sm:text-sm font-mono transition-all hover:translate-x-0.5 cursor-pointer"
          >
            <span>
              {completedDay >= 30 ? 'View Final Mission Report' : `Continue Mission (Day ${completedDay + 1})`}
            </span>
            <ArrowRight className="w-4 h-4 text-cyan-400" />
          </button>
        </div>
      </div>
    </div>
  );
};
