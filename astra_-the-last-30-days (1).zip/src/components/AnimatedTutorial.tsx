/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Wind, Droplet, Coffee, Zap, Heart, ArrowRight, ArrowLeft, X, CheckCircle2, RotateCcw } from 'lucide-react';
import { soundEngine } from '../services/soundEngine';

interface AnimatedTutorialProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

export const AnimatedTutorial: React.FC<AnimatedTutorialProps> = ({
  isOpen,
  onClose,
  onComplete,
}) => {
  const [activeScene, setActiveScene] = useState<number>(0);

  useEffect(() => {
    if (isOpen) {
      setActiveScene(0);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const scenes = [
    {
      id: 'oxygen',
      title: 'Oxygen Life-Support Loop',
      tagline: 'How Your Astronauts Breathe',
      icon: Wind,
      color: '#06b6d4',
      explanation: 'Expired CO2 from astronauts passes through the Sabatier catalytic reactor, recovering fresh breathable O2 alongside the greenhouse. Never let this fall to zero.',
      renderAnimation: () => (
        <div className="relative w-full h-44 bg-slate-950 rounded-xl border border-cyan-900/60 flex items-center justify-between px-6 overflow-hidden">
          {/* Sabatier Hub */}
          <div className="flex flex-col items-center z-10">
            <div className="w-14 h-14 rounded-xl bg-cyan-950 border-2 border-cyan-500 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Wind className="w-7 h-7 text-cyan-400 animate-pulse" />
            </div>
            <span className="text-[11px] font-mono text-cyan-300 mt-2">ECLSS Scrubber</span>
          </div>

          {/* Flowing O2 Particle Stream */}
          <div className="flex-1 relative flex items-center justify-center mx-4">
            <div className="w-full h-1 bg-cyan-950 rounded-full overflow-hidden">
              <div className="w-1/3 h-full bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-[shimmer_1.5s_infinite]" />
            </div>
            <div className="absolute flex gap-3">
              <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
              <div className="w-2 h-2 rounded-full bg-cyan-300 animate-bounce" />
            </div>
            <span className="absolute -top-5 text-[10px] font-mono text-cyan-400 uppercase tracking-widest">
              +2.0 kg/day Recycled O2
            </span>
          </div>

          {/* Astronaut Helmet receiving air */}
          <div className="flex flex-col items-center z-10">
            <div className="w-14 h-14 rounded-full bg-slate-900 border-2 border-cyan-400 flex items-center justify-center relative overflow-hidden shadow-lg shadow-cyan-400/20">
              <div className="w-9 h-7 rounded-full bg-cyan-500/30 border border-cyan-300/60" />
              <div className="absolute inset-0 bg-cyan-400/10 animate-pulse" />
            </div>
            <span className="text-[11px] font-mono text-slate-200 mt-2">Astronaut Vitals: 98%</span>
          </div>
        </div>
      ),
    },
    {
      id: 'water',
      title: 'Water Distillation & Recovery',
      tagline: 'Every Drop Is Recycled',
      icon: Droplet,
      color: '#3b82f6',
      explanation: 'In the closed loop of the outpost, moisture and graywater pass through multi-stage vacuum distillation, achieving an 85% recovery rate into pristine drinking water.',
      renderAnimation: () => (
        <div className="relative w-full h-44 bg-slate-950 rounded-xl border border-blue-900/60 flex items-center justify-between px-6 overflow-hidden">
          {/* Wastewater collector */}
          <div className="flex flex-col items-center z-10">
            <div className="w-14 h-14 rounded-xl bg-blue-950 border-2 border-blue-600 flex items-center justify-center">
              <Droplet className="w-7 h-7 text-blue-400" />
            </div>
            <span className="text-[11px] font-mono text-blue-300 mt-2">Graywater Recovery</span>
          </div>

          {/* Distillation Centrifuge Pipe */}
          <div className="flex-1 relative flex items-center justify-center mx-4">
            <div className="w-full h-1 bg-blue-950 rounded-full" />
            {/* Animated dripping water droplets */}
            <div className="absolute flex gap-4">
              <div className="w-3 h-3 rounded-full bg-blue-400 animate-bounce" />
              <div className="w-3.5 h-3.5 rounded-full bg-cyan-300 shadow-md shadow-cyan-400 animate-pulse" />
            </div>
            <span className="absolute -top-5 text-[10px] font-mono text-blue-400 uppercase tracking-widest">
              85% Closed-Loop Distillation
            </span>
          </div>

          {/* Pure Potable Tank */}
          <div className="flex flex-col items-center z-10">
            <div className="w-14 h-14 rounded-xl bg-slate-900 border-2 border-cyan-400 flex flex-col justify-end p-1 overflow-hidden shadow-lg shadow-blue-500/20">
              <div className="w-full h-3/4 bg-gradient-to-t from-blue-600 to-cyan-400 rounded-b animate-pulse" />
            </div>
            <span className="text-[11px] font-mono text-cyan-300 mt-2">Potable H2O Tank</span>
          </div>
        </div>
      ),
    },
    {
      id: 'food',
      title: 'Greenhouse Bioculture Dome',
      tagline: 'Fresh Nutrients & Psychological Boost',
      icon: Coffee,
      color: '#10b981',
      explanation: 'Packaged freeze-dried rations are supplemented by fresh dwarf greens and spirulina microalgae. Fresh harvests raise crew morale and keep stamina peak.',
      renderAnimation: () => (
        <div className="relative w-full h-44 bg-slate-950 rounded-xl border border-emerald-900/60 flex items-center justify-between px-6 overflow-hidden">
          {/* Seed/Sprout Phase */}
          <div className="flex flex-col items-center z-10">
            <div className="w-14 h-14 rounded-xl bg-emerald-950 border-2 border-emerald-600 flex items-center justify-center">
              <span className="text-xl">🌱</span>
            </div>
            <span className="text-[11px] font-mono text-emerald-300 mt-2">Nursery Trays</span>
          </div>

          {/* LED Photosynthesis spectrum light bar */}
          <div className="flex-1 relative flex items-center justify-center mx-4">
            <div className="w-full h-2 bg-gradient-to-r from-purple-600 via-pink-500 to-emerald-400 rounded-full animate-pulse shadow-md" />
            <span className="absolute -top-5 text-[10px] font-mono text-emerald-400 uppercase tracking-widest">
              LED Grow Spectrum Active
            </span>
          </div>

          {/* Mature Harvest */}
          <div className="flex flex-col items-center z-10">
            <div className="w-14 h-14 rounded-xl bg-slate-900 border-2 border-emerald-400 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <span className="text-2xl animate-bounce">🥗</span>
            </div>
            <span className="text-[11px] font-mono text-emerald-300 mt-2">+Fresh Rations & Morale</span>
          </div>
        </div>
      ),
    },
    {
      id: 'energy',
      title: 'Grazing Solar Power & Battery Storage',
      tagline: 'Harvesting Sunlight at 89.9° South',
      icon: Zap,
      color: '#f59e0b',
      explanation: 'Vertical bifacial solar panels track the low-angle sun on crater ridges. Electricity charges our 300 kWh battery banks to power life support through shadow transits.',
      renderAnimation: () => (
        <div className="relative w-full h-44 bg-slate-950 rounded-xl border border-amber-900/60 flex items-center justify-between px-6 overflow-hidden">
          {/* Solar Mast */}
          <div className="flex flex-col items-center z-10">
            <div className="w-14 h-14 rounded-xl bg-amber-950 border-2 border-amber-500 flex items-center justify-center shadow-lg shadow-amber-500/20">
              <Zap className="w-7 h-7 text-amber-400 animate-pulse" />
            </div>
            <span className="text-[11px] font-mono text-amber-300 mt-2">Vertical PV Mast</span>
          </div>

          {/* Electrical Current Pulse */}
          <div className="flex-1 relative flex items-center justify-center mx-4">
            <div className="w-full h-1 bg-amber-950 rounded-full" />
            <div className="absolute w-4 h-4 rounded-full bg-amber-400 shadow-[0_0_12px_#f59e0b] animate-ping" />
            <span className="absolute -top-5 text-[10px] font-mono text-amber-400 uppercase tracking-widest">
              +60 kWh/day Solar Influx
            </span>
          </div>

          {/* Stored Battery Bank */}
          <div className="flex flex-col items-center z-10">
            <div className="w-14 h-14 rounded-xl bg-slate-900 border-2 border-amber-400 flex flex-col justify-end p-1.5 shadow-lg shadow-amber-500/20">
              <div className="w-full h-4/5 bg-amber-400 rounded animate-pulse" />
            </div>
            <span className="text-[11px] font-mono text-amber-300 mt-2">300 kWh Battery Bank</span>
          </div>
        </div>
      ),
    },
    {
      id: 'crew',
      title: 'Astronaut Crew & Well-Being',
      tagline: 'Protecting Human Lives on the Frontier',
      icon: Heart,
      color: '#ec4899',
      explanation: 'Dr. Ethan Park, Dr. Himanshi Panchal, Dr. Prisha Mishra, and Captain Arjun Mehta keep your outpost running. Keep morale and health high to avoid critical mistakes.',
      renderAnimation: () => (
        <div className="relative w-full h-44 bg-slate-950 rounded-xl border border-pink-900/60 flex items-center justify-around px-4 overflow-hidden">
          {[
            { name: 'Ethan', role: 'Geol', col: 'text-amber-400' },
            { name: 'Himanshi', role: 'Eng', col: 'text-orange-400' },
            { name: 'Prisha', role: 'Bio', col: 'text-emerald-400' },
            { name: 'Arjun', role: 'Ops', col: 'text-rose-400' },
          ].map((c, i) => (
            <div key={i} className="flex flex-col items-center">
              <div className="w-12 h-12 rounded-full bg-slate-900 border-2 border-pink-500/60 flex items-center justify-center font-mono font-bold text-slate-100 shadow-md">
                {c.name[0]}
              </div>
              <span className={`text-[11px] font-mono font-semibold ${c.col} mt-1.5`}>{c.name}</span>
              <span className="text-[9px] font-mono text-slate-400">{c.role}</span>
              <div className="flex items-center gap-1 mt-1 text-[10px] text-pink-400">
                <Heart className="w-2.5 h-2.5 fill-pink-500" />
                <span>100%</span>
              </div>
            </div>
          ))}
        </div>
      ),
    },
  ];

  const current = scenes[activeScene];
  const SceneIcon = current.icon;

  const handleNext = () => {
    soundEngine.playTelemetryClick();
    if (activeScene < scenes.length - 1) {
      setActiveScene(activeScene + 1);
    } else {
      soundEngine.playConfirm();
      onComplete();
      onClose();
    }
  };

  const handlePrev = () => {
    soundEngine.playTelemetryClick();
    if (activeScene > 0) {
      setActiveScene(activeScene - 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md select-none">
      <div className="bg-slate-950 border border-cyan-800/80 rounded-2xl max-w-xl w-full p-6 sm:p-8 shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-900 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Scene Header */}
        <div className="flex items-center gap-3 mb-5">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border"
            style={{ backgroundColor: `${current.color}15`, borderColor: current.color, color: current.color }}
          >
            <SceneIcon className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-mono uppercase text-slate-400">
              Interactive Training · Scene {activeScene + 1} of {scenes.length}
            </div>
            <h2 className="text-xl font-bold text-slate-100">{current.title}</h2>
          </div>
        </div>

        {/* Animated Visual Canvas */}
        <div className="mb-5">{current.renderAnimation()}</div>

        {/* 1 Short Plain Explanation */}
        <div className="p-4 bg-slate-900/60 rounded-xl border border-slate-800/80 text-sm text-slate-200 leading-relaxed mb-6">
          <div className="font-semibold text-xs text-cyan-300 font-mono uppercase mb-1">
            {current.tagline}
          </div>
          {current.explanation}
        </div>

        {/* Footer Navigation */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-800">
          {/* Stepper dots */}
          <div className="flex items-center gap-1.5">
            {scenes.map((_, i) => (
              <div
                key={i}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  i === activeScene ? 'w-6 bg-cyan-400' : 'w-2 bg-slate-800'
                }`}
              />
            ))}
          </div>

          <div className="flex items-center gap-2">
            {activeScene > 0 && (
              <button
                onClick={handlePrev}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-800 text-xs text-slate-300 hover:bg-slate-900 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
            )}

            <button
              onClick={handleNext}
              className="flex items-center gap-1.5 px-5 py-2.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer"
            >
              <span>{activeScene === scenes.length - 1 ? 'Finish Tutorial' : 'Continue'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
