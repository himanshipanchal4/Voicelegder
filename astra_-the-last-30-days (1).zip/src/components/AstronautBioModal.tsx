/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  X,
  Shield,
  Heart,
  Activity,
  Award,
  Zap,
  Volume2,
  CheckCircle2,
  Plus,
  Compass,
  Layers,
  Sparkles,
} from 'lucide-react';
import { AstronautCharacter } from '../data/astronautRoster';
import { AstronautCharacterFigure } from './AstronautCharacterFigure';
import { soundEngine } from '../services/soundEngine';

interface AstronautBioModalProps {
  character: AstronautCharacter | null;
  isSelected: boolean;
  canSelect: boolean;
  onToggleSelect: (character: AstronautCharacter) => void;
  onClose: () => void;
  onPlayQuote: (character: AstronautCharacter) => void;
}

export const AstronautBioModal: React.FC<AstronautBioModalProps> = ({
  character,
  isSelected,
  canSelect,
  onToggleSelect,
  onClose,
  onPlayQuote,
}) => {
  if (!character) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-fade-in select-none">
      <div
        className="relative w-full max-w-3xl bg-[#030712] border border-cyan-500/40 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        style={{
          boxShadow: '0 0 50px rgba(6, 182, 212, 0.15), 0 20px 40px rgba(0,0,0,0.9)',
        }}
      >
        {/* Top Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-widest text-cyan-400">
              ASTRA PERSONNEL DOSSIER &bull; {character.badgeCode}
            </span>
          </div>
          <button
            onClick={() => {
              soundEngine.playTelemetryClick();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body: Two Columns on tablet+ */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Left Column: Full-Body Character Figure + Quotes */}
          <div className="md:col-span-5 flex flex-col items-center justify-between bg-slate-950/80 rounded-xl p-4 border border-slate-800">
            <div className="w-full flex justify-between items-center text-[11px] font-mono text-slate-400 mb-2">
              <span className="font-bold text-orange-400 uppercase">{character.displayCategory}</span>
              <span className="text-slate-500">GENDER: {character.gender.toUpperCase()}</span>
            </div>

            <div className="w-full h-72 flex items-center justify-center">
              <AstronautCharacterFigure
                character={character}
                isSelected={isSelected}
                isHovered={true}
                size="md"
              />
            </div>

            {/* Tactical Speech Line Box */}
            <div className="w-full mt-3 p-3 rounded-lg bg-slate-900/90 border border-cyan-800/50 flex flex-col gap-2">
              <div className="flex items-center justify-between text-[11px] font-mono text-cyan-400">
                <span>COMMS TRANSMISSION</span>
                <button
                  onClick={() => onPlayQuote(character)}
                  className="flex items-center gap-1 text-[10px] text-cyan-300 hover:text-cyan-100 underline cursor-pointer"
                >
                  <Volume2 className="w-3 h-3" />
                  <span>Replay</span>
                </button>
              </div>
              <p className="text-xs text-slate-200 italic font-sans">
                "{character.characterIntro}"
              </p>
            </div>
          </div>

          {/* Right Column: Bio, Skills, Telemetry & Synergies */}
          <div className="md:col-span-7 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-black text-slate-100 tracking-tight">
                    {character.name}
                  </h2>
                  <p className="text-sm font-mono text-cyan-400">
                    Callsign: <span className="font-bold">"{character.callsign}"</span> &bull; {character.role}
                  </p>
                </div>
              </div>

              {/* Bio summary */}
              <div className="mt-3 text-xs sm:text-sm text-slate-300 leading-relaxed font-sans bg-slate-900/40 p-3.5 rounded-xl border border-slate-800">
                {character.bio}
              </div>

              {/* Specialties & Skills */}
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800/90 flex flex-col gap-1">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Award className="w-3 h-3 text-amber-400" />
                    <span>Primary Specialty</span>
                  </span>
                  <span className="text-xs font-bold text-slate-100">
                    {character.specialty}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800/90 flex flex-col gap-1">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Zap className="w-3 h-3 text-cyan-400" />
                    <span>Secondary Skill</span>
                  </span>
                  <span className="text-xs font-bold text-slate-100">
                    {character.secondarySkill}
                  </span>
                </div>
              </div>

              {/* Exploration Suit Architecture */}
              <div className="mt-3.5 p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 flex flex-col gap-2">
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                  <span className="flex items-center gap-1.5 text-cyan-300 font-bold uppercase">
                    <Shield className="w-3.5 h-3.5 text-cyan-400" />
                    <span>INDIVIDUAL SUIT ARCHITECTURE</span>
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span
                      className="w-3 h-3 rounded-full border border-slate-600 shadow-sm"
                      style={{ backgroundColor: character.suitTheme.primary }}
                      title="Primary Suit Color"
                    />
                    <span
                      className="w-3 h-3 rounded-full border border-slate-600 shadow-sm"
                      style={{ backgroundColor: character.suitTheme.secondary }}
                      title="Secondary Armor Color"
                    />
                    <span
                      className="w-3 h-3 rounded-full border border-slate-600 shadow-sm"
                      style={{ backgroundColor: character.suitTheme.accent }}
                      title="Accent Trim Glow"
                    />
                  </div>
                </div>

                <div className="text-xs font-bold font-mono text-slate-200">
                  {character.suitTheme.styleName}
                </div>
                <div className="text-[11px] text-slate-300 font-sans leading-relaxed">
                  {character.visualIdentity}
                </div>
              </div>

              {/* NASA Space Physiology Telemetry */}
              <div className="mt-4 p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 flex flex-col gap-2">
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5 text-emerald-400" />
                    <span>PHYSIOLOGICAL BASELINE</span>
                  </span>
                  <span className="text-emerald-400 font-bold">READY FOR FLIGHT</span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center pt-1 font-mono">
                  <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">HEALTH</span>
                    <span className="text-xs font-bold text-emerald-300">{character.health}%</span>
                  </div>
                  <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">MORALE</span>
                    <span className="text-xs font-bold text-cyan-300">{character.morale}%</span>
                  </div>
                  <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">FATIGUE</span>
                    <span className="text-xs font-bold text-amber-300">{character.fatigue}%</span>
                  </div>
                </div>
              </div>

              {/* Synergies */}
              <div className="mt-3 flex flex-wrap gap-1.5">
                {character.synergyTags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2 py-0.5 rounded-md bg-slate-900 border border-slate-800 text-[10px] font-mono text-slate-300 capitalize"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Bottom Modal Actions */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-3">
              <button
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl border border-slate-700 bg-slate-900 text-xs font-mono text-slate-300 hover:text-white transition-colors cursor-pointer"
              >
                Close File
              </button>

              <button
                onClick={() => {
                  soundEngine.playConfirm();
                  onToggleSelect(character);
                  onClose();
                }}
                disabled={!isSelected && !canSelect}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-mono text-xs font-bold uppercase transition-all shadow-lg cursor-pointer ${
                  isSelected
                    ? 'bg-rose-950/80 border border-rose-500 text-rose-300 hover:bg-rose-900/90'
                    : canSelect
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 shadow-orange-500/25'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-50'
                }`}
              >
                {isSelected ? (
                  <>
                    <X className="w-4 h-4" />
                    <span>Remove From Active Crew</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Assign To Crew (Slot)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
