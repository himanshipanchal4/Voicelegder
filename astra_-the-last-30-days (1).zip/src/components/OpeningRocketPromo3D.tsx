/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Rocket, SkipForward, Sparkles, ArrowRight } from 'lucide-react';
import { soundEngine } from '../services/soundEngine';
import { createRealisticMoonTextures } from '../services/rocket3DFactory';
import { NasaAstronautLogo } from './NasaAstronautLogo';

interface OpeningRocketPromo3DProps {
  onComplete: () => void;
}

type PromoPhase = 'ignition' | 'liftoff' | 'ascent';

// Reusable scratch math objects outside frame loop (zero GC in loop)
const _dummy = new THREE.Object3D();
const _vecCamTarget = new THREE.Vector3();
const _vecLookTarget = new THREE.Vector3();
const _currentLook = new THREE.Vector3(0, 2.2, 0);
const _tmpColor = new THREE.Color();

function createRocketHullTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    // Crisp glossy pearl-white composite hull base
    const grad = ctx.createLinearGradient(0, 0, 512, 0);
    grad.addColorStop(0, '#e2e8f0');
    grad.addColorStop(0.5, '#ffffff');
    grad.addColorStop(1, '#cbd5e1');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 512);

    // Subtle spacecraft panel seams
    ctx.strokeStyle = 'rgba(100, 116, 139, 0.25)';
    ctx.lineWidth = 2;
    for (let y = 64; y < 512; y += 96) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(512, y);
      ctx.stroke();
    }

    // Vibrant cobalt & crimson promo stripes
    ctx.fillStyle = '#0ea5e9';
    ctx.fillRect(0, 72, 512, 26);
    ctx.fillStyle = '#f97316';
    ctx.fillRect(0, 102, 512, 10);

    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, 410, 512, 22);
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(0, 434, 512, 12);

    // Bold ASTRA emblem facing camera (+Z faces u ~ 0.25/0.75 depending on cylinder seam; stamp twice cleanly)
    const drawWordmark = (cx: number) => {
      ctx.save();
      ctx.translate(cx, 265);
      ctx.fillStyle = '#0f172a';
      ctx.font = '900 44px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('ASTRA', 0, 0);
      ctx.fillStyle = '#ef4444';
      ctx.font = '800 18px monospace';
      ctx.fillText('MOON-01', 0, 26);
      ctx.restore();
    };
    drawWordmark(128);
    drawWordmark(384);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createLunarGroundTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const bg = ctx.createRadialGradient(256, 256, 10, 256, 256, 256);
    bg.addColorStop(0, '#334155');
    bg.addColorStop(0.55, '#1e293b');
    bg.addColorStop(1, '#0b1126');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, 512, 512);

    // Deterministic procedural craters for crisp 3D surface grounding
    for (let i = 0; i < 42; i++) {
      const angle = i * 2.39996;
      const dist = 45 + ((i * 37) % 190);
      const x = 256 + Math.cos(angle) * dist;
      const y = 256 + Math.sin(angle) * dist;
      const r = 6 + ((i * 13) % 18);
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(15, 23, 42, 0.55)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.2)';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export const OpeningRocketPromo3D: React.FC<OpeningRocketPromo3DProps> = ({ onComplete }) => {
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  const [promoPhase, setPromoPhase] = useState<PromoPhase>('ignition');
  const [countdownNum, setCountdownNum] = useState<number>(3);
  const [isExiting, setIsExiting] = useState<boolean>(false);
  const [webGlReady, setWebGlReady] = useState<boolean>(true);
  const liftoffSfxTriggeredRef = useRef<boolean>(false);
  const isExitingRef = useRef<boolean>(false);
  const exitTimerRef = useRef<number | null>(null);

  const triggerExit = () => {
    if (isExitingRef.current) return;
    isExitingRef.current = true;
    setIsExiting(true);
    soundEngine.playConfirm();
    exitTimerRef.current = window.setTimeout(() => {
      onCompleteRef.current();
    }, 360);
  };

  useEffect(() => {
    return () => {
      if (exitTimerRef.current !== null) {
        clearTimeout(exitTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    // Detect software WebGL cleanly without touching UI layout
    const isSoftwareGl = (() => {
      try {
        const probe = document.createElement('canvas');
        const gl = probe.getContext('webgl2') || probe.getContext('webgl');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param) || '');
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebGlReady(false);
      return;
    }

    const disposables: Array<{ dispose: () => void }> = [];
    const track = <T extends { dispose: () => void }>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const width = mount.clientWidth || window.innerWidth;
    const height = mount.clientHeight || window.innerHeight;
    const isPortrait = width < height;

    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.18;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    mount.replaceChildren(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x070b22);
    scene.fog = new THREE.FogExp2(0x070b22, 0.011);

    // Mandatory Studio PBR Reflections
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmremGenerator.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmremGenerator.dispose();
    track(envTarget);

    const camera = new THREE.PerspectiveCamera(isPortrait ? 52 : 44, width / height, 0.1, 300);
    camera.position.set(isPortrait ? 7.5 : 6.5, 3.2, isPortrait ? 13.5 : 10.5);
    _currentLook.set(0, 2.2, 0);
    camera.lookAt(_currentLook);

    // 3-Point Warm/Cool Studio + Exhaust Dynamic Lighting
    const hemiLight = new THREE.HemisphereLight(0x7dd3fc, 0x1e1b4b, 0.85);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff1d6, 2.5);
    keyLight.position.set(12, 18, 10);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.left = -12;
    keyLight.shadow.camera.right = 12;
    keyLight.shadow.camera.top = 14;
    keyLight.shadow.camera.bottom = -12;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.5);
    rimLight.position.set(-10, 8, -12);
    scene.add(rimLight);

    const exhaustLight = new THREE.PointLight(0xff7b00, 0, 26, 1.6);
    exhaustLight.position.set(0, 0.7, 0);
    scene.add(exhaustLight);

    const maxAniso = renderer.capabilities.getMaxAnisotropy();

    // Extended Lunar / Launch Terrain (no floating box!)
    const groundTex = track(createLunarGroundTexture(maxAniso));
    const terrainGeo = track(new THREE.CircleGeometry(95, 64));
    const terrainMat = track(
      new THREE.MeshStandardMaterial({
        map: groundTex,
        roughness: 0.92,
        metalness: 0.05,
      })
    );
    const terrain = new THREE.Mesh(terrainGeo, terrainMat);
    terrain.rotation.x = -Math.PI / 2;
    terrain.position.y = 0;
    terrain.receiveShadow = true;
    scene.add(terrain);

    // Distant Realistic Moon & Blue Earth in Upper Sky
    const moonTextures = createRealisticMoonTextures(maxAniso);
    track(moonTextures.map);
    track(moonTextures.bumpMap);
    track(moonTextures.roughnessMap);

    const moonGeo = track(new THREE.SphereGeometry(5.5, 48, 48));
    const moonMat = track(
      new THREE.MeshStandardMaterial({
        map: moonTextures.map,
        bumpMap: moonTextures.bumpMap,
        bumpScale: 0.22,
        roughnessMap: moonTextures.roughnessMap,
        roughness: 0.94,
        metalness: 0.02,
      })
    );
    const distantMoon = new THREE.Mesh(moonGeo, moonMat);
    distantMoon.position.set(-18, 28, -58);
    scene.add(distantMoon);

    const earthGeo = track(new THREE.SphereGeometry(3.2, 32, 32));
    const earthMat = track(
      new THREE.MeshStandardMaterial({
        color: 0x0284c7,
        emissive: 0x0ea5e9,
        emissiveIntensity: 0.35,
        roughness: 0.45,
        metalness: 0.15,
      })
    );
    const distantEarth = new THREE.Mesh(earthGeo, earthMat);
    distantEarth.position.set(20, 22, -62);
    scene.add(distantEarth);

    // =========================================================================
    // 3D METALLIC LAUNCHPAD & ANIMATED CLAMPS (Grounded flush at y = 0)
    // =========================================================================
    const padGroup = new THREE.Group();
    scene.add(padGroup);

    const padBaseMat = track(
      new THREE.MeshStandardMaterial({
        color: 0x334155,
        roughness: 0.48,
        metalness: 0.72,
      })
    );
    const padDeckMat = track(
      new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        roughness: 0.35,
        metalness: 0.82,
      })
    );
    const beaconMat = track(
      new THREE.MeshStandardMaterial({
        color: 0xf59e0b,
        emissive: 0xf59e0b,
        emissiveIntensity: 1.8,
        roughness: 0.25,
      })
    );

    const padBase = new THREE.Mesh(track(new THREE.CylinderGeometry(3.5, 4.3, 0.55, 8)), padBaseMat);
    padBase.position.y = 0.275;
    padBase.receiveShadow = true;
    padBase.castShadow = true;
    padGroup.add(padBase);

    const padRing = new THREE.Mesh(track(new THREE.CylinderGeometry(2.1, 2.35, 0.22, 24)), padDeckMat);
    padRing.position.y = 0.66;
    padRing.receiveShadow = true;
    padGroup.add(padRing);

    // 8 glowing launchpad perimeter beacons
    const beaconGeo = track(new THREE.SphereGeometry(0.12, 12, 12));
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const beacon = new THREE.Mesh(beaconGeo, beaconMat);
      beacon.position.set(Math.cos(a) * 3.1, 0.58, Math.sin(a) * 3.1);
      padGroup.add(beacon);
    }

    // 4 Hinged Launch Clamps that swing open at T-0
    const clamps: THREE.Group[] = [];
    const clampArmGeo = track(new THREE.BoxGeometry(0.22, 1.3, 0.28));
    for (let i = 0; i < 4; i++) {
      const clampPivot = new THREE.Group();
      const angle = (i / 4) * Math.PI * 2 + Math.PI / 4;
      clampPivot.position.set(Math.cos(angle) * 1.65, 0.75, Math.sin(angle) * 1.65);
      clampPivot.rotation.y = -angle;

      const arm = new THREE.Mesh(clampArmGeo, padBaseMat);
      arm.position.set(-0.3, 0.55, 0);
      arm.rotation.z = 0.26;
      arm.castShadow = true;
      clampPivot.add(arm);

      padGroup.add(clampPivot);
      clamps.push(clampPivot);
    }

    // Umbilical Gantry Tower beside pad
    const towerGroup = new THREE.Group();
    towerGroup.position.set(-3.3, 0, -1.0);
    const towerPillarGeo = track(new THREE.BoxGeometry(0.22, 6.2, 0.22));
    const towerMat = track(
      new THREE.MeshStandardMaterial({
        color: 0x475569,
        roughness: 0.4,
        metalness: 0.78,
      })
    );
    [
      [-0.4, -0.4],
      [0.4, -0.4],
      [-0.4, 0.4],
      [0.4, 0.4],
    ].forEach(([px, pz]) => {
      const post = new THREE.Mesh(towerPillarGeo, towerMat);
      post.position.set(px, 3.1, pz);
      post.castShadow = true;
      towerGroup.add(post);
    });
    const crossBarGeo = track(new THREE.BoxGeometry(1.05, 0.14, 1.05));
    for (let y = 1.1; y <= 5.6; y += 1.12) {
      const brace = new THREE.Mesh(crossBarGeo, towerMat);
      brace.position.y = y;
      towerGroup.add(brace);
    }
    const towerTipBeacon = new THREE.Mesh(
      track(new THREE.SphereGeometry(0.16, 12, 12)),
      track(
        new THREE.MeshStandardMaterial({
          color: 0xef4444,
          emissive: 0xef4444,
          emissiveIntensity: 2.2,
        })
      )
    );
    towerTipBeacon.position.set(0, 6.35, 0);
    towerGroup.add(towerTipBeacon);
    scene.add(towerGroup);

    // =========================================================================
    // COMPOSITE 10-PART 3D SMALL HERO ROCKET (Bottom-center pivot at y = 0)
    // =========================================================================
    const rocketGroup = new THREE.Group();
    rocketGroup.position.set(0, 0.77, 0);
    scene.add(rocketGroup);

    const hullTex = track(createRocketHullTexture(maxAniso));
    const hullMat = track(
      new THREE.MeshStandardMaterial({
        map: hullTex,
        roughness: 0.22,
        metalness: 0.15,
      })
    );
    const crimsonNoseMat = track(
      new THREE.MeshStandardMaterial({
        color: 0xef4444,
        roughness: 0.28,
        metalness: 0.35,
      })
    );
    const chromeMat = track(
      new THREE.MeshStandardMaterial({
        color: 0xe2e8f0,
        roughness: 0.16,
        metalness: 0.92,
      })
    );
    const goldRingMat = track(
      new THREE.MeshStandardMaterial({
        color: 0xfbbf24,
        roughness: 0.22,
        metalness: 0.88,
      })
    );
    const darkNozzleMat = track(
      new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        roughness: 0.38,
        metalness: 0.85,
      })
    );
    const cockpitGlassMat = track(
      new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        emissive: 0x0ea5e9,
        emissiveIntensity: 1.4,
        roughness: 0.1,
        metalness: 0.25,
      })
    );

    // 1. Main Engine Nozzle Bell (LatheGeometry seated at local y = 0..0.55)
    const nozzleProfile = [
      new THREE.Vector2(0.46, 0.0),
      new THREE.Vector2(0.42, 0.18),
      new THREE.Vector2(0.28, 0.42),
      new THREE.Vector2(0.36, 0.56),
    ];
    const nozzleGeo = track(new THREE.LatheGeometry(nozzleProfile, 28));
    const nozzle = new THREE.Mesh(nozzleGeo, darkNozzleMat);
    nozzle.castShadow = true;
    rocketGroup.add(nozzle);

    // 2. Glowing Inner Nozzle Thruster Core
    const thrusterCoreMat = track(
      new THREE.MeshBasicMaterial({
        color: 0xfef08a,
      })
    );
    const thrusterCore = new THREE.Mesh(
      track(new THREE.CircleGeometry(0.4, 24)),
      thrusterCoreMat
    );
    thrusterCore.rotation.x = Math.PI / 2;
    thrusterCore.position.y = 0.04;
    rocketGroup.add(thrusterCore);

    // 3. Lower Engine Collar Ring
    const lowerCollar = new THREE.Mesh(
      track(new THREE.CylinderGeometry(0.76, 0.62, 0.35, 32)),
      darkNozzleMat
    );
    lowerCollar.position.y = 0.72;
    lowerCollar.castShadow = true;
    rocketGroup.add(lowerCollar);

    // 4. Main Glossy Cylindrical Body
    const mainBody = new THREE.Mesh(
      track(new THREE.CylinderGeometry(0.76, 0.76, 2.75, 36)),
      hullMat
    );
    mainBody.position.y = 2.27;
    mainBody.rotation.y = -Math.PI / 2; // Align ASTRA wordmark toward camera
    mainBody.castShadow = true;
    rocketGroup.add(mainBody);

    // 5. Metallic Gold & Chrome Interstage Accent Rings
    const ringGeo = track(new THREE.TorusGeometry(0.77, 0.045, 12, 36));
    const goldRing = new THREE.Mesh(ringGeo, goldRingMat);
    goldRing.rotation.x = Math.PI / 2;
    goldRing.position.y = 3.63;
    rocketGroup.add(goldRing);

    const chromeRing = new THREE.Mesh(ringGeo, chromeMat);
    chromeRing.rotation.x = Math.PI / 2;
    chromeRing.position.y = 0.92;
    rocketGroup.add(chromeRing);

    // 6. Aerodynamic Ogive Nose Cone (LatheGeometry)
    const nosePts: THREE.Vector2[] = [];
    for (let i = 0; i <= 14; i++) {
      const t = i / 14;
      const radius = 0.76 * Math.pow(1 - t, 0.68);
      nosePts.push(new THREE.Vector2(Math.max(0.03, radius), t * 1.48));
    }
    const noseGeo = track(new THREE.LatheGeometry(nosePts, 32));
    const noseCone = new THREE.Mesh(noseGeo, crimsonNoseMat);
    noseCone.position.y = 3.65;
    noseCone.castShadow = true;
    rocketGroup.add(noseCone);

    // 7. Chrome Nose Tip Spire
    const tipSpire = new THREE.Mesh(track(new THREE.CylinderGeometry(0.015, 0.055, 0.32, 16)), chromeMat);
    tipSpire.position.y = 5.25;
    rocketGroup.add(tipSpire);

    // 8. Cockpit Porthole Window (Metallic Bezel + Glowing Blue Glass Dome)
    const portholeGroup = new THREE.Group();
    portholeGroup.position.set(0.32, 2.95, 0.68);
    portholeGroup.lookAt(0.65, 2.95, 1.4);
    const bezel = new THREE.Mesh(track(new THREE.TorusGeometry(0.24, 0.05, 14, 28)), chromeMat);
    const glass = new THREE.Mesh(track(new THREE.SphereGeometry(0.22, 20, 16)), cockpitGlassMat);
    glass.scale.z = 0.45;
    portholeGroup.add(bezel, glass);
    rocketGroup.add(portholeGroup);

    // 9. Three Beveled Swept Tail Fins (ExtrudeGeometry)
    const finShape = new THREE.Shape();
    finShape.moveTo(0, 0);
    finShape.lineTo(0.75, -0.35);
    finShape.lineTo(0.75, 0.35);
    finShape.lineTo(0.06, 1.15);
    finShape.lineTo(0, 1.15);
    finShape.closePath();

    const finGeo = track(
      new THREE.ExtrudeGeometry(finShape, {
        depth: 0.08,
        bevelEnabled: true,
        bevelThickness: 0.02,
        bevelSize: 0.02,
        bevelSegments: 2,
      })
    );
    finGeo.translate(0, 0, -0.04);

    for (let i = 0; i < 3; i++) {
      const finHolder = new THREE.Group();
      finHolder.rotation.y = (i / 3) * Math.PI * 2 + 0.4;
      const finMesh = new THREE.Mesh(finGeo, crimsonNoseMat);
      finMesh.position.set(0.72, 0.78, 0);
      finMesh.castShadow = true;
      finHolder.add(finMesh);
      rocketGroup.add(finHolder);
    }

    // 10. Twin Side Mini-Boosters with Cones & Nozzles
    const boosterBodyGeo = track(new THREE.CylinderGeometry(0.24, 0.24, 1.75, 20));
    const boosterConeGeo = track(new THREE.ConeGeometry(0.24, 0.55, 20));
    const boosterNozzleGeo = track(new THREE.CylinderGeometry(0.14, 0.22, 0.28, 16));
    [-0.95, 0.95].forEach((bx) => {
      const bGroup = new THREE.Group();
      bGroup.position.set(bx, 0.3, 0);
      const bBody = new THREE.Mesh(boosterBodyGeo, chromeMat);
      bBody.position.y = 1.05;
      bBody.castShadow = true;
      const bCone = new THREE.Mesh(boosterConeGeo, crimsonNoseMat);
      bCone.position.y = 2.2;
      const bNoz = new THREE.Mesh(boosterNozzleGeo, darkNozzleMat);
      bNoz.position.y = 0.04;
      bGroup.add(bBody, bCone, bNoz);
      rocketGroup.add(bGroup);
    });

    // Dynamic 3D Multi-Layer Plasma Plume attached beneath rocket nozzle
    const flameGroup = new THREE.Group();
    flameGroup.position.set(0, 0.02, 0);
    rocketGroup.add(flameGroup);

    const innerFlameMat = track(
      new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.95,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    const midFlameMat = track(
      new THREE.MeshBasicMaterial({
        color: 0xfbbf24,
        transparent: true,
        opacity: 0.85,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    const outerFlameMat = track(
      new THREE.MeshBasicMaterial({
        color: 0xf97316,
        transparent: true,
        opacity: 0.6,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );

    const makeFlameCone = (radius: number, len: number, mat: THREE.Material) => {
      const geo = track(new THREE.ConeGeometry(radius, len, 20));
      geo.rotateX(Math.PI);
      geo.translate(0, -len / 2, 0);
      return new THREE.Mesh(geo, mat);
    };

    const innerFlame = makeFlameCone(0.28, 1.5, innerFlameMat);
    const midFlame = makeFlameCone(0.45, 2.5, midFlameMat);
    const outerFlame = makeFlameCone(0.68, 3.6, outerFlameMat);
    flameGroup.add(outerFlame, midFlame, innerFlame);
    flameGroup.scale.set(0.5, 0.25, 0.5);

    // =========================================================================
    // INSTANCED 3D STARFIELD, LAUNCH SMOKE CLOUDS & HOT SPARKS
    // =========================================================================
    // A. Deep-Space Starfield (360 stars)
    const STAR_COUNT = 360;
    const starGeo = track(new THREE.OctahedronGeometry(0.11, 0));
    const starMat = track(
      new THREE.MeshBasicMaterial({
        color: 0xffffff,
      })
    );
    const starInstanced = new THREE.InstancedMesh(starGeo, starMat, STAR_COUNT);
    starInstanced.frustumCulled = false;
    const starData: Array<{ x: number; y: number; z: number; scale: number; phase: number }> = [];
    for (let i = 0; i < STAR_COUNT; i++) {
      const theta = Math.random() * Math.PI * 2;
      const dist = 26 + Math.random() * 68;
      const sx = Math.cos(theta) * dist;
      const sz = Math.sin(theta) * dist - 10;
      const sy = 4 + Math.random() * 95;
      const sc = 0.6 + Math.random() * 1.5;
      starData.push({ x: sx, y: sy, z: sz, scale: sc, phase: Math.random() * Math.PI * 2 });
      _dummy.position.set(sx, sy, sz);
      _dummy.scale.setScalar(sc);
      _dummy.updateMatrix();
      starInstanced.setMatrixAt(i, _dummy.matrix);
      _tmpColor.setHSL(0.55 + Math.random() * 0.25, 0.8, 0.82);
      starInstanced.setColorAt(i, _tmpColor);
    }
    starInstanced.instanceMatrix.needsUpdate = true;
    if (starInstanced.instanceColor) starInstanced.instanceColor.needsUpdate = true;
    scene.add(starInstanced);

    // B. Volumetric Exhaust Smoke Clouds (95 billowing spheres)
    const SMOKE_COUNT = 95;
    const smokeGeo = track(new THREE.IcosahedronGeometry(0.45, 1));
    const smokeMat = track(
      new THREE.MeshStandardMaterial({
        color: 0xf8fafc,
        emissive: 0xf97316,
        emissiveIntensity: 0.28,
        roughness: 0.95,
        transparent: true,
        opacity: 0.72,
        depthWrite: false,
      })
    );
    const smokeMesh = new THREE.InstancedMesh(smokeGeo, smokeMat, SMOKE_COUNT);
    smokeMesh.frustumCulled = false;
    const smokeParticles = Array.from({ length: SMOKE_COUNT }, (_, i) => {
      const angle = (i / SMOKE_COUNT) * Math.PI * 2 * 3 + Math.random() * 0.5;
      const speed = 1.6 + Math.random() * 3.8;
      return {
        vx: Math.cos(angle) * speed,
        vy: 0.2 + Math.random() * 1.1,
        vz: Math.sin(angle) * speed,
        age: Math.random() * 1.2,
        life: 0.8 + Math.random() * 0.8,
        baseScale: 0.6 + Math.random() * 0.9,
      };
    });
    for (let i = 0; i < SMOKE_COUNT; i++) {
      _tmpColor.setHex(i % 3 === 0 ? 0xfdba74 : 0xe2e8f0);
      smokeMesh.setColorAt(i, _tmpColor);
    }
    if (smokeMesh.instanceColor) smokeMesh.instanceColor.needsUpdate = true;
    scene.add(smokeMesh);

    // C. Hot Fiery Exhaust Sparks (80 fast-moving embers)
    const SPARK_COUNT = 80;
    const sparkGeo = track(new THREE.OctahedronGeometry(0.08, 0));
    const sparkMat = track(
      new THREE.MeshBasicMaterial({
        color: 0xfef08a,
        blending: THREE.AdditiveBlending,
        transparent: true,
        opacity: 0.9,
        depthWrite: false,
      })
    );
    const sparkMesh = new THREE.InstancedMesh(sparkGeo, sparkMat, SPARK_COUNT);
    sparkMesh.frustumCulled = false;
    const sparkParticles = Array.from({ length: SPARK_COUNT }, () => ({
      x: (Math.random() - 0.5) * 0.8,
      y: 0.6,
      z: (Math.random() - 0.5) * 0.8,
      vx: (Math.random() - 0.5) * 4.5,
      vy: -(3.5 + Math.random() * 6),
      vz: (Math.random() - 0.5) * 4.5,
      age: Math.random(),
    }));
    scene.add(sparkMesh);

    // Pre-warm GPU shaders once on hardware WebGL
    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const handleResize = () => {
      if (!mount) return;
      const w = mount.clientWidth || window.innerWidth;
      const h = mount.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.fov = w < h ? 52 : 44;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    };
    window.addEventListener('resize', handleResize);

    // Animation loop state
    const clock = new THREE.Clock();
    let elapsed = 0;
    let frameId = 0;
    let isDisposed = false;
    let lastPhase: PromoPhase = 'ignition';
    let lastCount = 3;

    const LIFTOFF_TIME = 2.4; // Smooth 0.8s per countdown beat (3..2..1)
    const ASCENT_DURATION = 6.0; // Majestic slow 6-second climb before stable cruise hold
    const TOTAL_PROGRESS_TIME = LIFTOFF_TIME + ASCENT_DURATION;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || typeof gl.fenceSync !== 'function') {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (isDisposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (isDisposed) return;

      const delta = Math.min(clock.getDelta(), 0.08);
      elapsed += delta;

      // Sync React HUD stages smoothly without spamming state updates
      const pct = Math.min(100, (elapsed / TOTAL_PROGRESS_TIME) * 100);
      if (progressBarRef.current) {
        progressBarRef.current.style.width = `${pct.toFixed(1)}%`;
      }

      const newCount = elapsed < 0.8 ? 3 : elapsed < 1.6 ? 2 : 1;
      if (newCount !== lastCount) {
        lastCount = newCount;
        setCountdownNum(newCount);
      }

      const nextPhase: PromoPhase =
        elapsed < LIFTOFF_TIME
          ? 'ignition'
          : elapsed < TOTAL_PROGRESS_TIME
          ? 'liftoff'
          : 'ascent';
      if (nextPhase !== lastPhase) {
        lastPhase = nextPhase;
        setPromoPhase(nextPhase);
      }

      if (elapsed >= LIFTOFF_TIME && !liftoffSfxTriggeredRef.current) {
        liftoffSfxTriggeredRef.current = true;
        soundEngine.playPromoLiftoff();
      }

      // 1. Gentle Clamp Swing-Open Animation (between t = 1.7s and 2.5s)
      const clampT = THREE.MathUtils.clamp((elapsed - 1.7) / 0.8, 0, 1);
      const clampOpenAngle = clampT * clampT * (3 - 2 * clampT) * 1.15;
      for (let i = 0; i < clamps.length; i++) {
        clamps[i].rotation.z = -clampOpenAngle;
      }

      // 2. Smooth, Slow Rocket Ascent -> Stable Cruise Hover
      const isLiftoff = elapsed >= LIFTOFF_TIME;
      const flightTime = Math.max(0, elapsed - LIFTOFF_TIME);
      const climbT = THREE.MathUtils.clamp(flightTime / ASCENT_DURATION, 0, 1);
      const smoothClimb = climbT * climbT * (3 - 2 * climbT);
      const hoverWave = climbT >= 1 ? Math.sin((elapsed - TOTAL_PROGRESS_TIME) * 1.1) * 0.25 : 0;
      const rocketAltitude = isLiftoff ? 0.77 + smoothClimb * 13.8 + hoverWave : 0.77;

      // Subtle, smooth pre-launch micro-shimmer (no jarring vibration)
      const shimmer = isLiftoff ? 0 : THREE.MathUtils.clamp(elapsed / LIFTOFF_TIME, 0, 1) * 0.008;
      rocketGroup.position.set(
        Math.sin(elapsed * 22) * shimmer,
        rocketAltitude,
        Math.cos(elapsed * 26) * shimmer
      );

      // Continuous graceful roll during flight & cruise
      if (isLiftoff) {
        rocketGroup.rotation.y += delta * 0.36;
      } else {
        rocketGroup.rotation.y = Math.sin(elapsed * 0.9) * 0.04;
      }

      // 3. Smooth Dynamic Flame Plume & Nozzle PointLight
      const smoothFlicker = 0.92 + Math.sin(elapsed * 18) * 0.06 + Math.cos(elapsed * 27) * 0.04;
      const thrustPower = isLiftoff
        ? (climbT >= 1 ? 0.88 : 1.08) * smoothFlicker
        : 0.22 + 0.55 * THREE.MathUtils.clamp(elapsed / LIFTOFF_TIME, 0, 1) * smoothFlicker;
      flameGroup.scale.set(
        0.5 + thrustPower * 0.42,
        0.25 + thrustPower * 1.05,
        0.5 + thrustPower * 0.42
      );
      exhaustLight.position.set(
        rocketGroup.position.x,
        Math.max(0.5, rocketGroup.position.y - 0.6),
        rocketGroup.position.z
      );
      exhaustLight.intensity = 5 + thrustPower * 14;

      // 4. Smooth Exhaust Smoke Clouds (pad steam during launch, gentle fade in upper cruise)
      const padSteamFade = 1 - THREE.MathUtils.clamp((flightTime - 2.2) / 3.0, 0, 0.72);
      for (let i = 0; i < SMOKE_COUNT; i++) {
        const p = smokeParticles[i];
        p.age += delta * (isLiftoff ? 0.75 : 0.45);
        if (p.age > p.life) p.age = 0;
        const tNorm = p.age / p.life;
        const spread = isLiftoff ? 1.15 : 0.7;
        const originY = Math.min(rocketAltitude - 0.35, 3.2);
        _dummy.position.set(
          p.vx * p.age * spread,
          Math.max(0.25, originY + p.vy * p.age * 0.45 - tNorm * 0.25),
          p.vz * p.age * spread
        );
        const s =
          padSteamFade *
          p.baseScale *
          (0.4 + tNorm * 1.6) *
          (1 - Math.max(0, tNorm - 0.7) * 2.2);
        _dummy.scale.setScalar(Math.max(0.01, s));
        _dummy.rotation.set(tNorm * 1.2, tNorm * 0.9, 0);
        _dummy.updateMatrix();
        smokeMesh.setMatrixAt(i, _dummy.matrix);
      }
      smokeMesh.instanceMatrix.needsUpdate = true;

      // 5. Smooth Fiery Sparks Trailing Behind Nozzle
      for (let i = 0; i < SPARK_COUNT; i++) {
        const sp = sparkParticles[i];
        sp.age += delta * 1.25;
        if (sp.age >= 1) {
          sp.age = 0;
          sp.x = rocketGroup.position.x + (Math.random() - 0.5) * 0.45;
          sp.y = rocketGroup.position.y - 0.25;
          sp.z = rocketGroup.position.z + (Math.random() - 0.5) * 0.45;
        }
        const px = sp.x + sp.vx * sp.age * 0.45;
        const py = Math.max(0.15, sp.y + sp.vy * sp.age * 0.55);
        const pz = sp.z + sp.vz * sp.age * 0.45;
        _dummy.position.set(px, py, pz);
        _dummy.scale.set(0.7, 1.5, 0.7);
        _dummy.scale.multiplyScalar(1 - sp.age * 0.85);
        _dummy.updateMatrix();
        sparkMesh.setMatrixAt(i, _dummy.matrix);
      }
      sparkMesh.instanceMatrix.needsUpdate = true;

      // 6. Gentle Twinkling Starfield
      for (let i = 0; i < STAR_COUNT; i++) {
        const st = starData[i];
        const twinkle = 0.78 + 0.3 * Math.sin(elapsed * 2.2 + st.phase);
        _dummy.position.set(st.x, st.y, st.z);
        _dummy.scale.setScalar(st.scale * twinkle);
        _dummy.updateMatrix();
        starInstanced.setMatrixAt(i, _dummy.matrix);
      }
      starInstanced.instanceMatrix.needsUpdate = true;

      // 7. Smooth Cinematic Camera Choreography (Zero Shake -> Stable Orbit Hold)
      const camZoomBack = isPortrait ? 13.8 : 10.6;
      if (!isLiftoff) {
        const sweep = elapsed * 0.28;
        _vecCamTarget.set(
          Math.sin(sweep) * (camZoomBack * 0.65),
          2.6 + elapsed * 0.22,
          Math.cos(sweep) * camZoomBack
        );
        _vecLookTarget.set(0, 2.35, 0);
      } else if (climbT < 1) {
        const trackAngle = 0.65 + smoothClimb * 0.45;
        _vecCamTarget.set(
          Math.sin(trackAngle) * (camZoomBack * 0.72),
          rocketAltitude - 0.2 + smoothClimb * 1.4,
          Math.cos(trackAngle) * (camZoomBack + smoothClimb * 2.2)
        );
        _vecLookTarget.set(0, rocketAltitude + 1.8, 0);
      } else {
        // Stable continuous cosmic orbit around hovering rocket until user clicks START
        const cruiseOrbit = 1.1 + (elapsed - TOTAL_PROGRESS_TIME) * 0.2;
        const orbitRadius = camZoomBack * 0.95;
        _vecCamTarget.set(
          Math.sin(cruiseOrbit) * orbitRadius,
          rocketAltitude + 1.3 + Math.sin((elapsed - TOTAL_PROGRESS_TIME) * 0.35) * 0.6,
          Math.cos(cruiseOrbit) * orbitRadius
        );
        _vecLookTarget.set(0, rocketAltitude + 1.9, 0);
      }

      camera.position.x = THREE.MathUtils.damp(camera.position.x, _vecCamTarget.x, 3.0, delta);
      camera.position.y = THREE.MathUtils.damp(camera.position.y, _vecCamTarget.y, 3.0, delta);
      camera.position.z = THREE.MathUtils.damp(camera.position.z, _vecCamTarget.z, 3.0, delta);

      _currentLook.x = THREE.MathUtils.damp(_currentLook.x, _vecLookTarget.x, 3.5, delta);
      _currentLook.y = THREE.MathUtils.damp(_currentLook.y, _vecLookTarget.y, 3.5, delta);
      _currentLook.z = THREE.MathUtils.damp(_currentLook.z, _vecLookTarget.z, 3.5, delta);
      camera.lookAt(_currentLook);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    if (isSoftwareGl) {
      afterDraw(tick);
    } else {
      frameId = requestAnimationFrame(tick);
    }

    return () => {
      isDisposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', handleResize);
      disposables.forEach((d) => {
        try {
          d.dispose();
        } catch {
          // ignore
        }
      });
      renderer.dispose();
    };
  }, []);

  // Allow launching into the game with Space or Enter if desired, staying stable otherwise until START is clicked
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.key === 'Enter' || e.key === 'Escape') {
        e.preventDefault();
        triggerExit();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <div
      className={`fixed inset-0 z-[70] bg-[#070b22] text-white select-none overflow-hidden transition-opacity duration-400 ${
        isExiting ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Dedicated WebGL 3D Canvas Container */}
      <div ref={canvasMountRef} className="absolute inset-0 w-full h-full" />

      {/* Fallback visual if WebGL is unavailable */}
      {!webGlReady && (
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-b from-[#070b22] via-[#131d4c] to-[#1e1b4b]">
          <div className="w-24 h-24 rounded-full bg-cyan-400/20 border-2 border-cyan-300 flex items-center justify-center animate-bounce">
            <Rocket className="w-12 h-12 text-amber-300" />
          </div>
        </div>
      )}

      {/* Minimal Top Promo Bar (no backdrop-blur over WebGL) */}
      <div className="relative z-10 flex items-center justify-between px-4 sm:px-8 pt-4 sm:pt-6 pointer-events-none">
        <div
          className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl border border-cyan-400/40 pointer-events-auto"
          style={{ backgroundColor: 'rgba(11, 17, 46, 0.85)' }}
        >
          <NasaAstronautLogo size={26} />
          <span className="font-display text-xs sm:text-sm font-black tracking-wide bg-gradient-to-r from-cyan-300 via-sky-300 to-amber-300 bg-clip-text text-transparent">
            ASTRA // MOON LAUNCH
          </span>
        </div>

        <button
          onClick={triggerExit}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-indigo-400/40 hover:border-cyan-300 text-xs font-bold text-indigo-100 hover:text-white transition-colors cursor-pointer pointer-events-auto"
          style={{ backgroundColor: 'rgba(11, 17, 46, 0.88)' }}
        >
          <span>Skip</span>
          <SkipForward className="w-3.5 h-3.5 text-cyan-300" />
        </button>
      </div>

      {/* Bottom Compact Promo Callout Dock (Zero Center Occlusion) */}
      <div className="absolute bottom-4 sm:bottom-7 inset-x-3 sm:inset-x-auto sm:left-1/2 sm:-translate-x-1/2 sm:w-full sm:max-w-2xl z-10">
        <div
          className="rounded-3xl border border-indigo-400/45 p-4 sm:p-5 shadow-2xl"
          style={{ backgroundColor: 'rgba(12, 18, 48, 0.88)' }}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                {promoPhase === 'ignition' && (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-amber-500/20 border border-amber-400/50 text-[11px] font-mono font-extrabold text-amber-300">
                    <Rocket className="w-3.5 h-3.5" />
                    <span>T-MINUS {countdownNum}... ENGINES ARMED</span>
                  </span>
                )}
                {promoPhase === 'liftoff' && (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-orange-500/25 border border-orange-400/60 text-[11px] font-mono font-extrabold text-orange-200">
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>LIFTOFF! HEADED TO THE MOON</span>
                  </span>
                )}
                {promoPhase === 'ascent' && (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-emerald-500/25 border border-emerald-400/60 text-[11px] font-mono font-extrabold text-emerald-200">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
                    <span>30-DAY SPACE ADVENTURE READY</span>
                  </span>
                )}
              </div>

              <h2 className="font-display text-xl sm:text-3xl font-black tracking-tight text-white leading-none">
                ASTRA:{' '}
                <span className="bg-gradient-to-r from-cyan-300 via-sky-300 to-fuchsia-300 bg-clip-text text-transparent">
                  THE LAST 30 DAYS
                </span>
              </h2>

              <p className="text-xs sm:text-sm text-indigo-100 font-medium">
                {promoPhase === 'ignition'
                  ? 'Firing thrusters for Moon Base Alpha...'
                  : promoPhase === 'liftoff'
                  ? '4 Astronauts • 6 Base Modules • 6 NASA Badges'
                  : 'Command your lunar base and survive 30 days!'}
              </p>
            </div>

            <button
              onClick={triggerExit}
              className={`w-full sm:w-auto flex items-center justify-center gap-2 px-7 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400 hover:brightness-110 text-slate-950 font-black tracking-wide text-sm sm:text-base shadow-xl shadow-cyan-500/35 transition-all hover:scale-[1.03] active:scale-[0.98] cursor-pointer shrink-0`}
            >
              <span>START</span>
              <ArrowRight className="w-4 h-4 stroke-[2.75]" />
            </button>
          </div>

          {/* Smooth Ignition Progress Bar */}
          <div className="mt-3 w-full h-1.5 bg-[#060a1f] rounded-full overflow-hidden border border-indigo-500/30">
            <div
              ref={progressBarRef}
              className="h-full bg-gradient-to-r from-amber-400 via-orange-400 to-cyan-400 rounded-full"
              style={{ width: '0%' }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
