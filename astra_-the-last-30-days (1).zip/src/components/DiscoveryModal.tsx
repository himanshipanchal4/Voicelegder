/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { DiscoveryFact } from '../data/discoveriesData';
import { soundEngine } from '../services/soundEngine';
import { HolographicAstronautMentor, AstronautGesture } from './HolographicAstronautMentor';
import { HolographicVisualDemonstration } from './HolographicVisualDemonstration';
import {
  Sparkles,
  ExternalLink,
  Award,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Zap,
  Droplet,
  Sun,
  Shield,
  Layers,
  Compass,
  X,
  ChevronDown,
  ChevronUp,
  ArrowRight,
  Maximize2,
} from 'lucide-react';

interface DiscoveryModalProps {
  discovery: DiscoveryFact;
  isOpen: boolean;
  onClose: () => void;
  onCollect: (discovery: DiscoveryFact) => void;
  isAlreadyCollected?: boolean;
}

export const DiscoveryModal: React.FC<DiscoveryModalProps> = ({
  discovery,
  isOpen,
  onClose,
  onCollect,
  isAlreadyCollected = false,
}) => {
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [feedbackText, setFeedbackText] = useState<string>('');
  const [isCompletedView, setIsCompletedView] = useState<boolean>(false);
  const [isExpandedDetailsOpen, setIsExpandedDetailsOpen] = useState<boolean>(false);
  const [mentorGesture, setMentorGesture] = useState<AstronautGesture>('projecting');
  const [mentorDialogue, setMentorDialogue] = useState<string>('');

  // Initial contextual dialogue based on mission day & category
  const initialDialogue = useMemo(() => {
    switch (discovery.category) {
      case 'water-ice':
        return `Check it out! Our crater scanners found hidden Moon ice. Ready for a quick quiz?`;
      case 'solar-power':
        return `Sunlight is skimming the mountains low today. Ready for a quick solar challenge?`;
      case 'eclss':
        return `Our air & water recyclers are hard at work! Want to test your space-life knowledge?`;
      case 'geology':
        return `There's cool volcanic Moon rock right under our boots! Ready for today’s science question?`;
      case 'radiation':
        return `Space radiation sensors are on! Let’s see how we keep astronauts safe!`;
      case 'navigation':
        return `Our signal link to Earth is locked in! Ready for today’s quick navigation quiz?`;
      default:
        return `Ready for today’s quick space quiz? Unlock a cool Moon fact + 50 bonus points!`;
    }
  }, [discovery]);

  // Reset or initialize state when opening a new discovery
  useEffect(() => {
    if (isOpen) {
      soundEngine.playTelemetryClick();
      setSelectedOptionId(null);
      setIsAnswered(false);
      setIsSuccess(false);
      setFeedbackText('');
      setIsCompletedView(false);
      setIsExpandedDetailsOpen(false);
      setMentorGesture('projecting');
      setMentorDialogue(initialDialogue);
    }
  }, [isOpen, discovery, initialDialogue]);

  if (!isOpen) return null;

  const handleSelectOption = (optionId: string) => {
    if (isAnswered) return;
    setSelectedOptionId(optionId);
    const opt = discovery.challenge.options?.find((o) => o.id === optionId);

    if (opt) {
      setIsAnswered(true);
      setIsSuccess(opt.isCorrect);
      setFeedbackText(opt.feedback);

      if (opt.isCorrect) {
        soundEngine.playConfirm();
        setMentorGesture('celebrating');
        setMentorDialogue(`Nailed it! You're thinking like a real NASA astronaut!`);
      } else {
        soundEngine.playWarning();
        setMentorGesture('thinking');
        setMentorDialogue(`Close try! Check out why the science works that way!`);
      }
    }
  };

  const handleRequestHint = () => {
    soundEngine.playTelemetryClick();
    setMentorGesture('explaining');
    setMentorDialogue(
      `Quick hint: Think about how ${discovery.category.replace('-', ' ')} works in space with no air!`
    );
  };

  const handleProceedToComplete = () => {
    soundEngine.playConfirm();
    setIsCompletedView(true);
    setMentorGesture('celebrating');
    setMentorDialogue(`Awesome job! You unlocked a new Discovery Badge for your logbook!`);
  };

  const handleFinalCollectAndClose = () => {
    soundEngine.playConfirm();
    onCollect(discovery);
  };

  // Category Configuration
  const categoryConfig = {
    'water-ice': {
      label: 'Moon Ice & Water',
      badgeClass: 'bg-cyan-950/90 text-cyan-300 border-cyan-500/80',
      icon: <Droplet className="w-3.5 h-3.5 text-cyan-400" />,
      accentColor: '#06b6d4',
    },
    'solar-power': {
      label: 'Solar Power & Heat',
      badgeClass: 'bg-amber-950/90 text-amber-300 border-amber-500/80',
      icon: <Sun className="w-3.5 h-3.5 text-amber-400" />,
      accentColor: '#f59e0b',
    },
    'eclss': {
      label: 'Air, Water & Plants',
      badgeClass: 'bg-emerald-950/90 text-emerald-300 border-emerald-500/80',
      icon: <Layers className="w-3.5 h-3.5 text-emerald-400" />,
      accentColor: '#10b981',
    },
    'geology': {
      label: 'Moon Rocks & Dust',
      badgeClass: 'bg-stone-900 text-stone-200 border-stone-600',
      icon: <Sparkles className="w-3.5 h-3.5 text-stone-300" />,
      accentColor: '#94a3b8',
    },
    'radiation': {
      label: 'Space Shields',
      badgeClass: 'bg-violet-950/90 text-violet-300 border-violet-500/80',
      icon: <Shield className="w-3.5 h-3.5 text-violet-400" />,
      accentColor: '#8b5cf6',
    },
    'navigation': {
      label: 'Orbit & Landers',
      badgeClass: 'bg-sky-950/90 text-sky-300 border-sky-500/80',
      icon: <Compass className="w-3.5 h-3.5 text-sky-400" />,
      accentColor: '#0ea5e9',
    },
  }[discovery.category];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-[#01040a]/92 backdrop-blur-md select-none overflow-y-auto animate-fade-in">
      {/* Surrounding Ambient Cosmic Vignette */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_center,rgba(6,182,212,0.12)_0%,transparent_75%)]" />

      {/* Main Holographic Container: Dual-Pane (Astronaut Mentor Left + Holographic Screen Right) */}
      <div className="relative w-full max-w-5xl my-auto flex flex-col lg:flex-row items-center justify-center gap-4 lg:gap-6 z-10">
        {/* PANE 1: ANIMATED ASTRONAUT MENTOR (Inspired by User Reference 2) */}
        <div className="w-full lg:w-72 shrink-0 flex justify-center order-2 lg:order-1">
          <HolographicAstronautMentor
            dialogue={mentorDialogue}
            gesture={mentorGesture}
            onRequestHint={!isAnswered ? handleRequestHint : undefined}
            hintAvailable={!isAnswered}
          />
        </div>

        {/* PANE 2: FUTURISTIC HOLOGRAPHIC QUESTION PROJECTION PANEL */}
        <div className="relative flex-1 w-full max-w-2xl bg-[#030e24]/85 border-2 border-cyan-400/70 rounded-2xl shadow-[0_0_40px_rgba(6,182,212,0.28)] backdrop-blur-xl overflow-hidden order-1 lg:order-2 animate-holo-shimmer">
          {/* Holographic Glowing Corner L-Brackets */}
          <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-cyan-300 pointer-events-none" />
          <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-cyan-300 pointer-events-none" />
          <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-cyan-300 pointer-events-none" />
          <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-cyan-300 pointer-events-none" />

          {/* Holographic Moving Scanline Overlay */}
          <div className="absolute inset-x-0 h-8 bg-gradient-to-b from-transparent via-cyan-400/20 to-transparent pointer-events-none animate-holo-scanline" />

          {/* Holographic Subtle Grid Texture */}
          <div
            className="absolute inset-0 opacity-15 pointer-events-none"
            style={{
              backgroundImage:
                'linear-gradient(to right, rgba(6, 182, 212, 0.3) 1px, transparent 1px), linear-gradient(to bottom, rgba(6, 182, 212, 0.3) 1px, transparent 1px)',
              backgroundSize: '24px 24px',
            }}
          />

          {/* Top Holographic Navigation Bar */}
          <div className="relative p-3 sm:p-4 border-b border-cyan-500/30 bg-cyan-950/30 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span className="text-[11px] font-mono uppercase tracking-widest text-cyan-300 font-bold">
                DAILY SPACE QUIZ
              </span>
              <span className="text-slate-600">&bull;</span>
              <span className="text-[11px] font-mono text-cyan-400 font-semibold">
                DAY {discovery.day < 10 ? `0${discovery.day}` : discovery.day}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <span className={`text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded border ${categoryConfig.badgeClass} hidden sm:flex items-center gap-1`}>
                {categoryConfig.icon}
                <span>{categoryConfig.label}</span>
              </span>

              <button
                onClick={() => {
                  soundEngine.playTelemetryClick();
                  onClose();
                }}
                className="p-1.5 rounded-lg border border-cyan-800/80 hover:border-cyan-400 bg-slate-950/70 text-cyan-400 hover:text-cyan-200 transition-colors cursor-pointer"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Main Holographic Body */}
          <div className="relative p-3.5 sm:p-5 space-y-3.5 sm:space-y-4 max-h-[62dvh] sm:max-h-[75dvh] overflow-y-auto">
            {/* VIEW A: INTERACTIVE QUESTION & VISUAL DEMONSTRATION */}
            {!isCompletedView ? (
              <>
                {/* 1. Animated Scientific Visual Demonstration */}
                <HolographicVisualDemonstration
                  category={discovery.category}
                  isAnswered={isAnswered}
                  isCorrect={isSuccess}
                />

                {/* 2. Holographic Question Header */}
                <div className="space-y-1.5 pt-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest flex items-center gap-1">
                      <Zap className="w-3 h-3 text-amber-400" />
                      <span>QUICK QUESTION</span>
                    </span>
                    <span className="text-[10px] font-mono text-amber-300 font-bold">
                      {isAlreadyCollected ? 'PRACTICE QUIZ • LOGGED' : '+50 PTS • DISCOVERY BADGE'}
                    </span>
                  </div>

                  <h3 className="text-sm sm:text-base font-bold text-slate-100 tracking-tight leading-snug">
                    {discovery.challenge.prompt}
                  </h3>
                  <p className="text-[11px] font-mono text-slate-300">
                    {discovery.challenge.instructions}
                  </p>
                </div>

                {/* 3. Interactive Holographic Answer Options */}
                <div className="space-y-2 pt-1">
                  {discovery.challenge.options?.map((opt, idx) => {
                    const isSelected = selectedOptionId === opt.id;
                    const optionTag = String.fromCharCode(65 + idx); // A, B, C, D

                    let btnStyles =
                      'border-cyan-500/40 bg-slate-950/60 text-slate-200 hover:border-cyan-400 hover:bg-cyan-950/40 shadow-sm';
                    if (isAnswered) {
                      if (opt.isCorrect) {
                        btnStyles =
                          'border-emerald-500 bg-emerald-950/80 text-emerald-100 font-bold shadow-[0_0_15px_rgba(16,185,129,0.35)]';
                      } else if (isSelected && !opt.isCorrect) {
                        btnStyles =
                          'border-amber-500 bg-amber-950/70 text-amber-200 shadow-[0_0_15px_rgba(245,158,11,0.25)]';
                      } else {
                        btnStyles = 'border-slate-800 bg-slate-950/30 text-slate-500 opacity-50';
                      }
                    }

                    return (
                      <button
                        key={opt.id}
                        disabled={isAnswered}
                        onClick={() => handleSelectOption(opt.id)}
                        className={`w-full p-3 rounded-xl border text-left text-xs sm:text-sm transition-all duration-200 flex items-start gap-3 cursor-pointer disabled:cursor-default relative overflow-hidden group ${btnStyles}`}
                      >
                        {/* Option Tag Badge */}
                        <span
                          className={`w-6 h-6 rounded-md font-mono font-bold text-xs flex items-center justify-center shrink-0 border ${
                            isAnswered && opt.isCorrect
                              ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                              : isAnswered && isSelected && !opt.isCorrect
                              ? 'bg-amber-500 text-slate-950 border-amber-400'
                              : 'bg-cyan-950 text-cyan-300 border-cyan-800 group-hover:bg-cyan-900'
                          }`}
                        >
                          {isAnswered && opt.isCorrect ? (
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          ) : isAnswered && isSelected && !opt.isCorrect ? (
                            <AlertCircle className="w-3.5 h-3.5" />
                          ) : (
                            optionTag
                          )}
                        </span>

                        <span className="flex-1 leading-snug pt-0.5">{opt.label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* 4. Compact Science Discovery Card (Unfolds after Answer) */}
                {isAnswered && (
                  <div className="p-4 rounded-xl border border-cyan-400/50 bg-gradient-to-r from-cyan-950/70 via-slate-950/80 to-blue-950/70 shadow-lg space-y-3 animate-fade-in">
                    <div className="flex items-center justify-between border-b border-cyan-800/60 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-base">{discovery.badge.icon}</span>
                        <div>
                          <span className="text-[9px] font-mono text-cyan-400 uppercase tracking-wider block">
                            COOL SPACE FACT!
                          </span>
                          <h4 className="text-xs sm:text-sm font-bold text-slate-100">
                            {discovery.factTitle}
                          </h4>
                        </div>
                      </div>

                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                          isSuccess ? 'bg-emerald-950 text-emerald-300 border border-emerald-700' : 'bg-amber-950 text-amber-300 border border-amber-700'
                        }`}
                      >
                        {isSuccess ? 'NICE JOB!' : 'LEARNED!'}
                      </span>
                    </div>

                    <div className="space-y-1 text-xs">
                      <div className="text-slate-300 leading-relaxed font-sans">
                        <strong className="text-cyan-300 font-mono">Why It Matters: </strong>
                        {discovery.whyInteresting}
                      </div>

                      <p className="text-[11px] text-slate-400 pt-1 leading-relaxed">
                        {feedbackText}
                      </p>
                    </div>

                    {/* Expandable Details Accordion */}
                    <div>
                      <button
                        onClick={() => setIsExpandedDetailsOpen(!isExpandedDetailsOpen)}
                        className="text-[11px] font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors cursor-pointer pt-1"
                      >
                        <span>{isExpandedDetailsOpen ? 'Hide Extra Science Info' : 'Read More + NASA Link'}</span>
                        {isExpandedDetailsOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                      </button>

                      {isExpandedDetailsOpen && (
                        <div className="mt-2 p-3 rounded-lg bg-slate-950/90 border border-cyan-900/80 text-xs text-slate-300 space-y-2 animate-fade-in">
                          <p className="leading-relaxed">{discovery.conciseExplanation}</p>
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-slate-800 text-[10px] text-slate-400">
                            <div>
                              <span className="text-slate-500">Source: </span>
                              <strong className="text-slate-300">{discovery.sourceOrg}</strong> &bull; {discovery.sourceTitle}
                            </div>
                            <a
                              href={discovery.sourceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300 underline font-mono shrink-0"
                            >
                              <span>Open NASA Page</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </>
            ) : (
              /* VIEW B: DISTINCTIVE QUIZ COMPLETION CELEBRATION (Unfolds Holographic Badge) */
              <div className="py-6 px-4 text-center space-y-5 animate-fade-in">
                {/* Unfolding Holographic Mission Badge */}
                <div className="relative mx-auto w-24 h-24 sm:w-28 sm:h-28 flex items-center justify-center animate-badge-unfold">
                  <div className="absolute inset-0 rounded-full bg-cyan-400/25 blur-xl animate-pulse" />
                  <div className="relative w-full h-full rounded-2xl bg-gradient-to-br from-cyan-900 via-slate-950 to-blue-950 border-2 border-cyan-400 p-2 shadow-2xl flex flex-col items-center justify-center">
                    <span className="text-3xl sm:text-4xl">{discovery.badge.icon}</span>
                    <span className="text-[9px] font-mono text-cyan-300 uppercase font-bold mt-1">
                      {discovery.badge.title}
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5 max-w-md mx-auto">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/90 text-cyan-300 border border-cyan-700 text-xs font-mono font-bold">
                    <Award className="w-3.5 h-3.5 text-amber-400" />
                    <span>{isAlreadyCollected ? 'PRACTICE COMPLETE' : 'QUIZ COMPLETE (+50 PTS)'}</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-extrabold text-slate-100 tracking-tight">
                    {isAlreadyCollected ? 'Already in Your Discovery Log!' : 'Saved to Your Discovery Log!'}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed font-sans">
                    Awesome work! <strong className="text-cyan-300">{discovery.factTitle}</strong>{' '}
                    {isAlreadyCollected ? 'is verified in your logbook.' : 'is now unlocked in your logbook.'}
                  </p>
                </div>

                {/* Score & Badge Summary Card */}
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-cyan-500/30 max-w-md mx-auto grid grid-cols-2 gap-3 text-xs font-mono">
                  <div className="p-2 rounded bg-cyan-950/40 border border-cyan-900/60 text-left">
                    <span className="text-[10px] text-slate-400 block uppercase">BONUS SCORE</span>
                    <strong className="text-amber-400 text-sm font-bold">
                      {isAlreadyCollected ? 'Already Claimed' : '+50 Points'}
                    </strong>
                  </div>
                  <div className="p-2 rounded bg-cyan-950/40 border border-cyan-900/60 text-left">
                    <span className="text-[10px] text-slate-400 block uppercase">LOGBOOK</span>
                    <strong className="text-cyan-300 text-sm font-bold">Unlocked</strong>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Holographic Actions */}
          <div className="relative p-3.5 sm:p-4 bg-cyan-950/30 border-t border-cyan-500/30 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>ASTRA Space Academy</span>
            </div>

            <div className="flex items-center gap-2.5 w-full sm:w-auto">
              {!isCompletedView ? (
                <>
                  <button
                    onClick={() => {
                      soundEngine.playTelemetryClick();
                      onClose();
                    }}
                    className="flex-1 sm:flex-none px-3.5 py-2 rounded-xl border border-cyan-900/80 hover:bg-cyan-950/60 text-xs text-slate-300 font-mono transition-colors cursor-pointer"
                  >
                    Close
                  </button>

                  <button
                    disabled={!isAnswered}
                    onClick={handleProceedToComplete}
                    className={`flex-1 sm:flex-none px-5 py-2 rounded-xl font-bold text-xs font-mono transition-all flex items-center justify-center gap-1.5 shadow-lg ${
                      isAnswered
                        ? 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-cyan-500/25 cursor-pointer'
                        : 'bg-slate-900 border border-slate-800 text-slate-600 cursor-not-allowed opacity-50'
                    }`}
                  >
                    <span>Claim Reward</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </>
              ) : (
                <button
                  onClick={handleFinalCollectAndClose}
                  className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs font-mono shadow-xl shadow-cyan-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{isAlreadyCollected ? 'Back to Base' : 'Save & Continue (+50 pts)'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
