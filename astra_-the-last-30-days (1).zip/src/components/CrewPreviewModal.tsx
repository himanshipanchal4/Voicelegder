/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Rocket,
  Shield,
  Sparkles,
  CheckCircle2,
  X,
  Volume2,
  Compass,
  ArrowRight,
} from 'lucide-react';
import { AstronautCharacter, evaluateCrewSynergy } from '../data/astronautRoster';
import { AstronautCharacterFigure } from './AstronautCharacterFigure';
import { NasaAstronautLogo } from './NasaAstronautLogo';
import { soundEngine } from '../services/soundEngine';

interface CrewPreviewModalProps {
  selectedCrew: AstronautCharacter[];
  crewName: string;
  onConfirmAndDeploy: () => void;
  onClose: () => void;
}

export const CrewPreviewModal: React.FC<CrewPreviewModalProps> = ({
  selectedCrew,
  crewName,
  onConfirmAndDeploy,
  onClose,
}) => {
  const synergy = evaluateCrewSynergy(selectedCrew);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/90 backdrop-blur-lg animate-fade-in select-none">
      <div
        className="relative w-full max-w-5xl bg-[#030712] border border-cyan-500/50 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[95vh]"
        style={{
          boxShadow: '0 0 60px rgba(6, 182, 212, 0.2), 0 25px 50px rgba(0,0,0,0.95)',
        }}
      >
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <NasaAstronautLogo size={28} className="drop-shadow-[0_0_8px_rgba(234,179,8,0.4)]" />
            <span className="text-xs font-mono uppercase tracking-widest text-cyan-400 font-bold">
              NASA ASTRONAUT CREW &bull; EXPEDITION ROSTER
            </span>
          </div>
          <button
            onClick={() => {
              soundEngine.playTelemetryClick();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Cinematic Formation Stage */}
        <div className="p-6 sm:p-8 flex-1 overflow-y-auto flex flex-col items-center justify-between text-center space-y-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-2">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>{crewName || 'Astra Expeditionary Unit'}</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-black text-slate-100 tracking-tight">
              Four Explorers. One Outpost.
            </h2>
            <p className="text-sm sm:text-base text-slate-300 max-w-xl mx-auto mt-2 font-sans">
              Thirty days to survive Shackleton Rim. Your crew formation is sealed and flight-certified.
            </p>
          </div>

          {/* 4 Astronauts Standing in Line / Formation */}
          <div className="w-full grid grid-cols-2 md:grid-cols-4 gap-4 py-4">
            {selectedCrew.map((char, index) => (
              <div
                key={char.id}
                className="bg-slate-900/60 rounded-2xl border border-slate-800 p-4 flex flex-col items-center justify-between relative overflow-hidden group hover:border-cyan-500/50 transition-all duration-300"
                style={{
                  animationDelay: `${index * 150}ms`,
                }}
              >
                {/* Slot Tag */}
                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                  CREW 0{index + 1} &bull; {char.displayCategory}
                </span>

                {/* Figure */}
                <div className="w-full h-56 flex items-center justify-center">
                  <AstronautCharacterFigure
                    character={char}
                    isSelected={true}
                    isHovered={false}
                    size="sm"
                  />
                </div>

                {/* Name & Specialty */}
                <div className="mt-2 text-center w-full">
                  <h4 className="font-bold text-slate-100 text-sm">{char.name}</h4>
                  <p className="text-[11px] font-mono text-cyan-400 truncate">
                    "{char.callsign}" &bull; {char.specialty}
                  </p>
                  <span
                    className="text-[9px] font-mono px-2 py-0.5 rounded mt-1 inline-block font-semibold"
                    style={{
                      backgroundColor: `${char.suitTheme.accent}20`,
                      color: char.suitTheme.accent,
                      border: `1px solid ${char.suitTheme.accent}40`,
                    }}
                  >
                    {char.suitTheme.styleName}
                  </span>
                  <p className="text-[10px] text-slate-400 italic mt-1 line-clamp-1">
                    "{char.characterIntro}"
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Synergy Banner */}
          <div className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl p-4 text-left flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                <h4 className="font-bold text-slate-100 text-sm">
                  {synergy.title} (Balance: {synergy.balanceScore}%)
                </h4>
              </div>
              <p className="text-xs text-slate-300 font-sans">
                {synergy.description}
              </p>
            </div>

            <div className="flex flex-wrap gap-2 text-[11px] font-mono">
              {synergy.perks.slice(0, 2).map((perk, i) => (
                <span
                  key={i}
                  className="px-2.5 py-1 rounded bg-slate-800/90 border border-slate-700 text-cyan-300"
                >
                  &bull; {perk}
                </span>
              ))}
            </div>
          </div>

          {/* Action Button */}
          <div className="w-full flex items-center justify-center gap-4 pt-2">
            <button
              onClick={onClose}
              className="px-6 py-3 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-xs sm:text-sm font-mono text-slate-300 transition-colors cursor-pointer"
            >
              Modify Crew
            </button>

            <button
              onClick={() => {
                soundEngine.playConfirm();
                onConfirmAndDeploy();
              }}
              className="flex items-center gap-2 px-8 py-3.5 rounded-xl bg-gradient-to-r from-orange-500 via-amber-500 to-cyan-500 hover:from-orange-400 hover:to-cyan-400 text-slate-950 font-black text-sm sm:text-base font-mono shadow-2xl shadow-orange-500/30 transition-all hover:scale-[1.02] cursor-pointer"
            >
              <Rocket className="w-5 h-5 text-slate-950 fill-current" />
              <span>CONFIRM CREW & BEGIN MISSION</span>
              <ArrowRight className="w-4 h-4 text-slate-950 stroke-[3]" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
