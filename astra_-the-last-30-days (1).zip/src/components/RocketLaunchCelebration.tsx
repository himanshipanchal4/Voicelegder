/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowRight, Award, CheckCircle2, Sparkles } from 'lucide-react';
import { RocketId } from '../types/mission';
import { getMoonDaySector, getRocketSpec } from '../data/rocketCatalog';
import { MoonGlobeFlight3D } from './MoonGlobeFlight3D';
import { soundEngine } from '../services/soundEngine';

interface RocketLaunchCelebrationProps {
  completedDay: number;
  nextDay: number;
  scoreGained: number;
  rocketId?: RocketId;
  unlockedDiscoveryTitle?: string;
  isFinalMissionComplete?: boolean;
  onContinue: () => void;
}

export const RocketLaunchCelebration: React.FC<RocketLaunchCelebrationProps> = ({
  completedDay,
  nextDay,
  scoreGained,
  rocketId,
  unlockedDiscoveryTitle,
  isFinalMissionComplete = false,
  onContinue,
}) => {
  const fromSpot = getMoonDaySector(completedDay);
  const toSpot = getMoonDaySector(completedDay >= 30 ? 1 : nextDay);
  const rocketSpec = getRocketSpec(rocketId);

  return (
    <MoonGlobeFlight3D
      rocketId={rocketId}
      fromSpot={fromSpot}
      toSpot={toSpot}
      badgeText={`DAY ${completedDay} COMPLETE`}
      headline={`Flying ${rocketSpec.name} to ${toSpot.name}`}
      subtext={`Day ${completedDay} survival milestone cleared! Moving across the Moon to Day ${nextDay}.`}
      ctaLabel={isFinalMissionComplete ? 'View Final Mission Report' : `Start Day ${nextDay}`}
      onComplete={onContinue}
      renderLandedOverlay={() => (
        <div
          className="p-5 sm:p-6 border-2 border-cyan-400/70 rounded-3xl shadow-2xl space-y-4 animate-fade-in text-left"
          style={{ backgroundColor: 'rgba(14, 21, 56, 0.94)' }}
        >
          <div className="flex items-center justify-between border-b border-indigo-400/25 pb-3 gap-2">
            <div>
              <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-cyan-300 uppercase tracking-wider">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>
                  {isFinalMissionComplete ? '30-Day Expedition Complete!' : `Arrived at ${toSpot.name}`}
                </span>
              </span>
              <h3 className="font-display text-lg sm:text-xl font-extrabold text-white mt-0.5">
                {isFinalMissionComplete ? 'Final Mission Debrief Ready' : `Mission Day ${nextDay} Begins`}
              </h3>
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/20 text-amber-300 border border-amber-400/50 rounded-xl font-mono text-xs font-bold shrink-0">
              <Award className="w-4 h-4 text-amber-300" />
              <span>+{scoreGained} Pts</span>
            </div>
          </div>

          {unlockedDiscoveryTitle && !isFinalMissionComplete && (
            <div className="p-3 bg-[#09102b] rounded-2xl border border-indigo-400/35 text-xs space-y-1">
              <div className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-300 uppercase tracking-wider">
                <Sparkles className="w-3 h-3" />
                <span>New Space Quiz Unlocked:</span>
              </div>
              <div className="font-bold text-white">{unlockedDiscoveryTitle}</div>
            </div>
          )}

          <p className="text-xs sm:text-sm text-indigo-100 leading-relaxed">
            {isFinalMissionComplete
              ? 'Amazing job, Commander! All 30 days on the Moon are complete—let’s see your final score!'
              : `${rocketSpec.name} touched down safely! New sunlight angles and science events are ready for Day ${nextDay}.`}
          </p>

          <button
            onClick={() => {
              soundEngine.playConfirm();
              onContinue();
            }}
            className="w-full py-3 px-4 bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400 hover:brightness-110 text-slate-950 font-extrabold text-xs sm:text-sm rounded-xl shadow-lg shadow-cyan-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>{isFinalMissionComplete ? 'View Final Mission Report' : `Start Day ${nextDay}`}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    />
  );
};
