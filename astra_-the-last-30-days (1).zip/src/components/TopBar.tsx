/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Volume2,
  VolumeX,
  BookOpen,
  Orbit,
  RotateCcw,
  ShieldAlert,
  Sparkles,
  Box,
  BarChart3,
  Compass,
  Award,
} from 'lucide-react';
import { NasaAstronautLogo } from './NasaAstronautLogo';
import { MissionPhase } from '../types/mission';

interface TopBarProps {
  day: number;
  phase: MissionPhase;
  solarAngleDeg: number;
  isLunarNight: boolean;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenScience: () => void;
  onOpenHelp: () => void;
  onOpenTutorial: () => void;
  onOpenDiscoveryLog?: () => void;
  discoveryCount?: number;
  onOpenBadges?: () => void;
  badgeCount?: number;
  onResetMission: () => void;
  activeEmergencyCount: number;
  activeView: 'game' | 'telemetry';
  onChangeView: (view: 'game' | 'telemetry') => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  phase,
  soundEnabled,
  onToggleSound,
  onOpenScience,
  onOpenHelp,
  onOpenTutorial,
  onOpenDiscoveryLog,
  discoveryCount,
  onOpenBadges,
  badgeCount,
  onResetMission,
  activeEmergencyCount,
  activeView,
  onChangeView,
}) => {
  return (
    <header className="w-full bg-[#10173a]/95 backdrop-blur-md border-b border-indigo-400/30 text-slate-100 px-2.5 sm:px-5 py-2 flex items-center justify-between gap-1.5 sm:gap-3 sticky top-0 z-30 select-none shadow-lg shadow-indigo-950/40">
      {/* Zone 1: Brand Lockup */}
      <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
        <NasaAstronautLogo
          size={34}
          className="transition-transform duration-200 hover:scale-105 drop-shadow-[0_0_10px_rgba(56,189,248,0.45)]"
        />
        <div className="flex items-baseline gap-2">
          <span className="font-display font-extrabold text-sm sm:text-lg tracking-wide bg-gradient-to-r from-cyan-300 via-sky-200 to-amber-300 bg-clip-text text-transparent whitespace-nowrap">
            ASTRA
          </span>
        </div>
      </div>

      {/* Zone 2: Active Mode Navigation */}
      {(phase === 'crew-intro' ||
        phase === 'setup-crew' ||
        phase === 'setup-rocket' ||
        phase === 'setup-briefing') && (
        <div className="hidden sm:flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-violet-500/20 border border-violet-400/40 text-violet-200 text-xs font-semibold whitespace-nowrap shrink-0">
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>
            {phase === 'setup-rocket'
              ? 'Step 2/3 · Choose Your Moon Rocket'
              : phase === 'setup-briefing'
              ? 'Step 3/3 · Mission Rules & Mode'
              : 'Step 1/3 · Pick Your 4-Astronaut Squad'}
          </span>
        </div>
      )}

      {phase === 'active' && (
        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center p-0.5 sm:p-1 bg-[#0a0f26] rounded-xl border border-indigo-500/30 shrink-0">
            <button
              onClick={() => onChangeView('game')}
              title="3D Moon Base View (Key: 1)"
              className={`flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1 sm:py-1.5 text-[11px] sm:text-xs font-bold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                activeView === 'game'
                  ? 'bg-gradient-to-r from-cyan-400 to-sky-400 text-slate-950 shadow-md shadow-cyan-500/30'
                  : 'text-indigo-200 hover:text-white'
              }`}
            >
              <Box className="w-3.5 h-3.5" />
              <span className="sm:hidden">Base</span>
              <span className="hidden sm:inline">3D Base</span>
            </button>
            <button
              onClick={() => onChangeView('telemetry')}
              title="Crew & Base Stats (Key: 2)"
              className={`flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1 sm:py-1.5 text-[11px] sm:text-xs font-bold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                activeView === 'telemetry'
                  ? 'bg-gradient-to-r from-violet-400 to-fuchsia-400 text-slate-950 shadow-md shadow-violet-500/30'
                  : 'text-indigo-200 hover:text-white'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span className="sm:hidden">Stats</span>
              <span className="hidden sm:inline">Crew & Stats</span>
            </button>
          </div>

          {activeEmergencyCount > 0 && (
            <div className="hidden md:flex items-center gap-1.5 bg-rose-500/20 text-rose-200 px-2.5 py-1 rounded-lg border border-rose-400/50 font-bold text-xs whitespace-nowrap shrink-0">
              <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
              <span>Base Alert</span>
            </div>
          )}
        </div>
      )}

      {/* Zone 3: Quick Game Tools & Music Toggle */}
      <div className="flex items-center gap-1 sm:gap-2 shrink-0">
        {onOpenDiscoveryLog && (
          <button
            onClick={onOpenDiscoveryLog}
            title="Space Discovery Log (Key: D)"
            className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-xl border border-cyan-400/40 bg-cyan-500/15 hover:bg-cyan-500/25 text-xs text-cyan-200 font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Compass className="w-3.5 h-3.5 text-cyan-300" />
            <span className="hidden sm:inline">Discoveries</span>
            {discoveryCount !== undefined && (
              <span className="font-mono text-[10px] sm:text-[11px] text-cyan-300 tabular-nums">
                {discoveryCount}/30
              </span>
            )}
          </button>
        )}

        {onOpenBadges && (
          <button
            onClick={onOpenBadges}
            title="Explorer Badges (Key: B)"
            className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-xl border border-amber-400/40 bg-amber-500/15 hover:bg-amber-500/25 text-xs text-amber-200 font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Award className="w-3.5 h-3.5 text-amber-300" />
            <span className="hidden sm:inline">Badges</span>
            {badgeCount !== undefined && (
              <span className="font-mono text-[10px] sm:text-[11px] text-amber-300 tabular-nums">
                {badgeCount}/6
              </span>
            )}
          </button>
        )}

        <button
          onClick={onOpenTutorial}
          title="Quick Visual Tutorial"
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-emerald-400/35 bg-emerald-500/15 hover:bg-emerald-500/25 text-xs text-emerald-200 font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
          <span className="hidden md:inline">Tutorial</span>
        </button>

        <button
          onClick={onToggleSound}
          title={soundEnabled ? 'Mute Music & Sounds' : 'Play Fun Space Music & Sounds'}
          className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-xl border text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
            soundEnabled
              ? 'border-fuchsia-400/40 bg-fuchsia-500/20 text-fuchsia-200 hover:bg-fuchsia-500/30'
              : 'border-indigo-500/30 bg-[#0b1026] text-slate-400 hover:text-slate-200'
          }`}
        >
          {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-fuchsia-300" /> : <VolumeX className="w-3.5 h-3.5" />}
          <span className="hidden xl:inline">{soundEnabled ? 'Music On' : 'Muted'}</span>
        </button>

        <button
          onClick={onOpenScience}
          title="NASA Space Facts"
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-indigo-400/30 bg-indigo-500/15 hover:bg-indigo-500/25 text-xs text-indigo-200 font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <Orbit className="w-3.5 h-3.5 text-sky-300" />
          <span className="hidden lg:inline">Science</span>
        </button>

        <button
          onClick={onOpenHelp}
          title="How to Play Guide"
          className="flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-xl border border-indigo-400/30 bg-indigo-500/15 hover:bg-indigo-500/25 text-xs text-indigo-200 font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <BookOpen className="w-3.5 h-3.5 text-amber-300" />
          <span className="hidden sm:inline">Guide</span>
        </button>

        {phase !== 'landing' && phase !== 'cinematic' && (
          <button
            onClick={onResetMission}
            title="Start Over / Reset Mission"
            className="p-1.5 sm:p-2 rounded-xl border border-rose-400/30 bg-rose-500/15 hover:bg-rose-500/30 text-rose-200 transition-colors cursor-pointer shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </header>
  );
};
