/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HelpCircle } from 'lucide-react';

interface TermTooltipProps {
  term: string;
  definition: string;
  children?: React.ReactNode;
}

export const TermTooltip: React.FC<TermTooltipProps> = ({ term, definition, children }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <span className="relative inline-flex items-center group">
      <span
        onClick={() => setIsOpen(!isOpen)}
        onMouseEnter={() => setIsOpen(true)}
        onMouseLeave={() => setIsOpen(false)}
        className="underline decoration-dotted decoration-cyan-400/60 hover:decoration-cyan-400 cursor-help text-inherit inline-flex items-center gap-0.5"
      >
        {children || term}
        <HelpCircle className="w-3 h-3 text-cyan-400/70 inline ml-0.5" />
      </span>

      {isOpen && (
        <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-2.5 bg-slate-950 text-slate-200 text-xs rounded-lg border border-cyan-800/80 shadow-2xl shadow-cyan-950/80 z-50 pointer-events-none text-left leading-normal font-sans">
          <span className="block font-bold text-cyan-300 mb-1 border-b border-slate-800 pb-1 font-mono text-[11px] uppercase">
            {term}
          </span>
          <span className="text-slate-300 text-xs block">{definition}</span>
          <span className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-slate-950" />
        </span>
      )}
    </span>
  );
};
