/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Activity,
  ArrowLeft,
  ArrowRight,
  Award,
  CheckCircle2,
  Cpu,
  Droplet,
  Rocket,
  Sparkles,
  Users,
  Wind,
  Zap,
  Coffee,
} from 'lucide-react';
import { CrewMember, DifficultyLevel, ResourceTelemetry, RocketId } from '../types/mission';
import { getRocketSpec } from '../data/rocketCatalog';
import { soundEngine } from '../services/soundEngine';

interface InstructionsStepProps {
  crew: CrewMember[];
  crewName?: string;
  selectedRocketId?: RocketId;
  resources: ResourceTelemetry;
  selectedDifficulty: DifficultyLevel;
  onChangeDifficulty: (diff: DifficultyLevel) => void;
  onOpenInteractiveTour: () => void;
  onBackToRocket: () => void;
  onLaunchDay1: () => void;
}

export const InstructionsStep: React.FC<InstructionsStepProps> = ({
  crew,
  crewName = 'Astra Vanguard',
  selectedRocketId,
  resources,
  selectedDifficulty,
  onChangeDifficulty,
  onOpenInteractiveTour,
  onBackToRocket,
  onLaunchDay1,
}) => {
  const rocketSpec = getRocketSpec(selectedRocketId);

  return (
    <div className="relative w-full max-w-6xl mx-auto p-3 sm:p-6 lg:p-8 select-none animate-fade-in z-10 space-y-5">
      {/* Header */}
      <div className="bg-[#121a3e]/95 border border-indigo-400/40 rounded-3xl p-4 sm:p-6 shadow-2xl flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-400/50 text-[11px] font-mono font-extrabold text-emerald-300 mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>STEP 3 OF 3 &bull; OCEANUS PROCELLARUM</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Mission Rules &amp; Final Check
          </h1>
          <p className="text-xs sm:text-sm text-indigo-200 mt-1">
            Learn how your Moon base works, pick your difficulty mode, and touch down on Day 1!
          </p>
        </div>

        <div className="grid grid-cols-2 sm:flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => {
              soundEngine.playTelemetryClick();
              onBackToRocket();
            }}
            className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-indigo-400/35 bg-[#0b1026]/85 hover:bg-indigo-900/60 text-xs font-bold text-indigo-200 hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playTelemetryClick();
              onOpenInteractiveTour();
            }}
            className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-violet-400/40 bg-violet-500/20 hover:bg-violet-500/30 text-xs font-bold text-violet-200 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Quick Tour</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playConfirm();
              onLaunchDay1();
            }}
            className="col-span-2 sm:col-span-1 flex items-center justify-center gap-2 px-6 py-3 sm:py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400 hover:brightness-110 text-slate-950 font-extrabold text-xs sm:text-sm shadow-xl shadow-cyan-500/30 transition-all hover:-translate-y-0.5 cursor-pointer"
          >
            <span>Launch Day 1!</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 4 Simple Mission Instructions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-2xl bg-[#121a3e]/95 border border-cyan-400/40 shadow-lg space-y-1.5">
          <div className="w-9 h-9 rounded-xl bg-cyan-400/20 border border-cyan-400/50 flex items-center justify-center text-cyan-300">
            <Activity className="w-4 h-4" />
          </div>
          <h3 className="font-display text-sm font-extrabold text-white">1. Watch 4 Supplies</h3>
          <p className="text-xs text-indigo-200 leading-relaxed">
            Keep Oxygen, Water, Food, and Solar Power above zero for all 30 days.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-[#121a3e]/95 border border-emerald-400/40 shadow-lg space-y-1.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-400/20 border border-emerald-400/50 flex items-center justify-center text-emerald-300">
            <Zap className="w-4 h-4" />
          </div>
          <h3 className="font-display text-sm font-extrabold text-white">2. Tap 3D Buildings</h3>
          <p className="text-xs text-indigo-200 leading-relaxed">
            Click buildings in your 3D Moon Base to repair shields, recycle water, or grow crops.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-[#121a3e]/95 border border-amber-400/40 shadow-lg space-y-1.5">
          <div className="w-9 h-9 rounded-xl bg-amber-400/20 border border-amber-400/50 flex items-center justify-center text-amber-300">
            <Cpu className="w-4 h-4" />
          </div>
          <h3 className="font-display text-sm font-extrabold text-white">3. Daily Choices</h3>
          <p className="text-xs text-indigo-200 leading-relaxed">
            Make a smart daily decision and solve quick Base Alerts before launching to the next day.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-[#121a3e]/95 border border-violet-400/40 shadow-lg space-y-1.5">
          <div className="w-9 h-9 rounded-xl bg-violet-400/20 border border-violet-400/50 flex items-center justify-center text-violet-300">
            <Award className="w-4 h-4" />
          </div>
          <h3 className="font-display text-sm font-extrabold text-white">4. Quizzes &amp; Badges</h3>
          <p className="text-xs text-indigo-200 leading-relaxed">
            Score +50 bonus points on daily Space Quizzes and unlock all 6 NASA milestone badges!
          </p>
        </div>
      </div>

      {/* Difficulty Picker + Starting Supplies */}
      <div className="bg-[#121a3e]/95 border border-indigo-400/35 rounded-3xl p-4 sm:p-6 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-display text-base sm:text-lg font-extrabold text-white">
            Pick Difficulty &amp; Starting Supplies
          </h2>
          <span className="text-xs font-mono text-cyan-300 font-bold">
            Team {crewName} &bull; {rocketSpec.name}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {([
            {
              id: 'beginner' as const,
              title: 'Easy (Cadet)',
              desc: '+30% extra starting supplies & helpful tips.',
              activeCls: 'bg-emerald-500/20 border-emerald-400 text-emerald-300',
            },
            {
              id: 'commander' as const,
              title: 'Normal (Commander)',
              desc: 'Balanced NASA survival challenge.',
              activeCls: 'bg-cyan-500/20 border-cyan-400 text-cyan-300',
            },
            {
              id: 'expert' as const,
              title: 'Hard (Pro)',
              desc: '-20% starting reserves & tougher space storms.',
              activeCls: 'bg-amber-500/20 border-amber-400 text-amber-300',
            },
          ]).map((tier) => {
            const active = selectedDifficulty === tier.id;
            return (
              <button
                key={tier.id}
                type="button"
                onClick={() => {
                  soundEngine.playTelemetryClick();
                  onChangeDifficulty(tier.id);
                }}
                className={`p-3.5 rounded-2xl border-2 text-left transition-all cursor-pointer ${
                  active
                    ? `${tier.activeCls} shadow-lg`
                    : 'bg-[#0b1026]/80 border-indigo-500/30 text-indigo-200 hover:border-indigo-400'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-display font-extrabold text-sm">{tier.title}</span>
                  {active && <CheckCircle2 className="w-4 h-4" />}
                </div>
                <p className="text-xs text-indigo-100/80 mt-1">{tier.desc}</p>
              </button>
            );
          })}
        </div>

        {/* Starting Resource Readout */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
          <div className="p-3 rounded-2xl bg-[#0b1026]/85 border border-cyan-400/35 flex items-center gap-2.5">
            <Wind className="w-4 h-4 text-cyan-300 shrink-0" />
            <div>
              <div className="text-[10px] font-mono text-indigo-300 uppercase">Oxygen</div>
              <div className="font-mono font-extrabold text-sm text-white">{resources.oxygenKg} kg</div>
            </div>
          </div>
          <div className="p-3 rounded-2xl bg-[#0b1026]/85 border border-blue-400/35 flex items-center gap-2.5">
            <Droplet className="w-4 h-4 text-blue-300 shrink-0" />
            <div>
              <div className="text-[10px] font-mono text-indigo-300 uppercase">Water</div>
              <div className="font-mono font-extrabold text-sm text-white">{resources.waterLiters} L</div>
            </div>
          </div>
          <div className="p-3 rounded-2xl bg-[#0b1026]/85 border border-amber-400/35 flex items-center gap-2.5">
            <Coffee className="w-4 h-4 text-amber-300 shrink-0" />
            <div>
              <div className="text-[10px] font-mono text-indigo-300 uppercase">Food</div>
              <div className="font-mono font-extrabold text-sm text-white">{resources.foodPacks} packs</div>
            </div>
          </div>
          <div className="p-3 rounded-2xl bg-[#0b1026]/85 border border-emerald-400/35 flex items-center gap-2.5">
            <Zap className="w-4 h-4 text-emerald-300 shrink-0" />
            <div>
              <div className="text-[10px] font-mono text-indigo-300 uppercase">Power</div>
              <div className="font-mono font-extrabold text-sm text-white">{resources.powerKwh} kWh</div>
            </div>
          </div>
        </div>
      </div>

      {/* Selected Squad & Rocket Bar */}
      <div className="bg-[#121a3e]/95 border border-indigo-400/35 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 flex-wrap text-xs">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-200 font-bold">
            <Rocket className="w-3.5 h-3.5" />
            <span>{rocketSpec.name}</span>
          </span>
          <span className="inline-flex items-center gap-1.5 text-indigo-200 font-semibold">
            <Users className="w-3.5 h-3.5 text-amber-300" />
            <span>{crew.map((c) => c.name).join(' · ')}</span>
          </span>
        </div>

        <button
          onClick={() => {
            soundEngine.playConfirm();
            onLaunchDay1();
          }}
          className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400 hover:brightness-110 text-slate-950 font-extrabold text-xs sm:text-sm shadow-lg shadow-cyan-500/25 cursor-pointer shrink-0"
        >
          <span>Launch Day 1!</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
