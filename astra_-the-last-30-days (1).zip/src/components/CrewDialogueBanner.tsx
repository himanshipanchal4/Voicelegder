/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { MessageSquare, Sparkles } from 'lucide-react';
import { CrewMember } from '../types/mission';

interface CrewDialogueBannerProps {
  speaker: CrewMember;
  message: string;
  expression?: 'nominal' | 'concerned' | 'triumphant' | 'focused';
}

export const CrewDialogueBanner: React.FC<CrewDialogueBannerProps> = ({
  speaker,
  message,
  expression = 'nominal',
}) => {
  return (
    <div className="bg-slate-950/85 backdrop-blur-md border border-slate-800 rounded-xl p-3 sm:p-4 shadow-xl flex items-center gap-3.5 max-w-xl select-none animate-fade-in">
      {/* Astronaut Portrait Circle */}
      <div
        className="w-11 h-11 rounded-full flex items-center justify-center font-mono font-bold text-sm text-slate-100 shrink-0 border-2 relative"
        style={{
          backgroundColor: `${speaker.color}25`,
          borderColor: speaker.color,
        }}
      >
        {speaker.name.split(' ').map((n) => n[0]).join('')}
        <span
          className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border border-slate-950"
          style={{ backgroundColor: speaker.color }}
        />
      </div>

      {/* Dialogue Speech Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-xs text-slate-100">{speaker.name}</span>
          <span className="text-[10px] font-mono text-slate-400">({speaker.role.split('&')[0]})</span>
        </div>
        <p className="text-xs text-cyan-200 mt-0.5 italic font-mono leading-relaxed line-clamp-2">
          &ldquo;{message}&rdquo;
        </p>
      </div>
    </div>
  );
};
