/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { LunarBase3D } from './LunarBase3D';
import { OutpostModule, OutpostModuleAction } from '../types/mission';
import { ArrowLeft, Box, CheckCircle2, AlertTriangle, Zap, Activity, Info, Wrench } from 'lucide-react';

interface LunarBaseViewProps {
  modules: OutpostModule[];
  solarAngleDeg: number;
  isLunarNight: boolean;
  onExecuteModuleAction: (moduleId: string, action: OutpostModuleAction) => void;
  onReturnToDashboard: () => void;
  currentDay: number;
}

export const LunarBaseView: React.FC<LunarBaseViewProps> = ({
  modules,
  solarAngleDeg,
  isLunarNight,
  onExecuteModuleAction,
  onReturnToDashboard,
  currentDay,
}) => {
  const [selectedModuleId, setSelectedModuleId] = useState<string>('living-habitat');

  const selectedModule = modules.find((m) => m.id === selectedModuleId) || modules[0];

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6 select-none">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono uppercase text-cyan-400">
            Tactical Reconnaissance · Shackleton Base Grid
          </div>
          <h1 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
            <span>Lunar Outpost Exploration</span>
            <span className="text-xs font-mono text-slate-400 font-normal">
              (6 Modular Facilities)
            </span>
          </h1>
        </div>

        <button
          onClick={onReturnToDashboard}
          className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition-colors self-start sm:self-auto cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-cyan-400" />
          <span>Return to Mission Control</span>
        </button>
      </div>

      {/* Main Split: 3D Canvas Viewport + Detailed Inspection Dock */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 8 Cols: Three.js 3D Viewport */}
        <div className="lg:col-span-8 h-[480px] sm:h-[540px] rounded-xl overflow-hidden border border-slate-800 relative shadow-2xl">
          <LunarBase3D
            modules={modules}
            selectedModuleId={selectedModuleId}
            onSelectModule={(id) => setSelectedModuleId(id || 'living-habitat')}
            solarAngleDeg={solarAngleDeg}
            isLunarNight={isLunarNight}
          />
        </div>

        {/* Right 4 Cols: Module Diagnostic & Operations Dock */}
        <div className="lg:col-span-4 bg-slate-900/70 border border-slate-800 rounded-xl p-5 space-y-5">
          {/* Module Selector Ribbon */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <div className="text-[10px] font-mono uppercase text-slate-400">Selected Facility</div>
              <div className="text-base font-bold text-slate-100">{selectedModule.name}</div>
            </div>
            <span
              className={`text-xs font-mono px-2 py-0.5 rounded border ${
                selectedModule.status === 'nominal'
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                  : 'bg-amber-950 text-amber-300 border-amber-800'
              }`}
            >
              ● {selectedModule.status.toUpperCase()}
            </span>
          </div>

          {/* Plain-Language Purpose */}
          <div>
            <div className="text-xs font-mono uppercase text-slate-400 mb-1 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              <span>What This Facility Does:</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3 rounded-lg border border-slate-800/80">
              {selectedModule.description}
            </p>
          </div>

          {/* Telemetry Metrics Strip */}
          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">OPERATING EFFICIENCY</span>
              <span className="text-base font-bold text-slate-100">{selectedModule.efficiency}%</span>
            </div>
            <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">POWER LOAD</span>
              <span className="text-base font-bold text-cyan-400">{selectedModule.powerDrawKw} kW</span>
            </div>
          </div>

          {/* Scientific Foundation */}
          <div>
            <div className="text-[11px] font-mono uppercase text-slate-400 mb-1">
              Scientific Principle:
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              {selectedModule.scientificPrinciple}
            </p>
          </div>

          {/* Possible Risks */}
          {selectedModule.potentialRisks.length > 0 && (
            <div>
              <div className="text-[11px] font-mono uppercase text-amber-400/90 mb-1 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Known Environmental Hazards:</span>
              </div>
              <ul className="text-xs text-slate-400 space-y-1 list-disc list-inside">
                {selectedModule.potentialRisks.map((r, i) => (
                  <li key={i}>{r}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Available Operational Directives */}
          <div className="pt-3 border-t border-slate-800">
            <div className="text-xs font-mono uppercase text-cyan-400 mb-2.5 flex items-center gap-1.5">
              <Wrench className="w-3.5 h-3.5" />
              <span>Available Facility Directives:</span>
            </div>

            <div className="space-y-2">
              {selectedModule.actions.map((act) => {
                const onCooldown = act.lastUsedDay && currentDay - act.lastUsedDay < act.cooldownDays;
                return (
                  <div
                    key={act.id}
                    className="p-3 bg-slate-950 rounded-lg border border-slate-800/80 flex flex-col gap-2"
                  >
                    <div>
                      <div className="text-xs font-semibold text-slate-200">{act.label}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">{act.effectDesc}</div>
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-slate-900 text-[11px] font-mono">
                      <span className="text-slate-400">Power: -{act.powerCostKw} kW</span>
                      <button
                        disabled={!!onCooldown}
                        onClick={() => onExecuteModuleAction(selectedModule.id, act)}
                        className={`px-3 py-1 rounded text-xs font-semibold transition-colors cursor-pointer ${
                          onCooldown
                            ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                            : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-sm'
                        }`}
                      >
                        {onCooldown ? `Cooldown (${act.cooldownDays}d)` : 'Execute'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
