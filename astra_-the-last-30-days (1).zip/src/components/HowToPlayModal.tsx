/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Wind, Droplet, Coffee, Zap, X, Sparkles } from 'lucide-react';
import { NasaAstronautLogo } from './NasaAstronautLogo';

interface HowToPlayModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartTutorial: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({
  isOpen,
  onClose,
  onStartTutorial,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#060919]/85 backdrop-blur-md select-none">
      <div className="bg-[#121a3e] border border-cyan-400/50 rounded-3xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl relative max-h-[88vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-indigo-300 hover:text-white rounded-xl hover:bg-indigo-900/60 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5 pr-8">
          <NasaAstronautLogo size={42} className="drop-shadow-[0_0_10px_rgba(234,179,8,0.35)]" />
          <div>
            <h2 className="font-display text-xl font-extrabold text-white">How to Play</h2>
            <div className="text-xs font-semibold text-cyan-300">Survive 30 days on the Moon!</div>
          </div>
        </div>

        {/* Interactive Tutorial Launcher Banner */}
        <div className="p-3.5 bg-cyan-500/15 border border-cyan-400/40 rounded-2xl flex flex-wrap items-center justify-between gap-3 mb-5">
          <div className="text-xs sm:text-sm font-bold text-white">
            New here? Try the 5-step visual walkthrough!
          </div>
          <button
            onClick={() => {
              onClose();
              onStartTutorial();
            }}
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-cyan-400 to-emerald-400 hover:brightness-110 text-slate-950 font-extrabold text-xs rounded-xl shadow transition-all shrink-0 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Start Walkthrough</span>
          </button>
        </div>

        {/* Section 1: Daily Loop */}
        <div className="space-y-2.5 mb-5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-300">
            Daily Routine
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
            <div className="p-3 bg-[#0b1026]/80 rounded-2xl border border-indigo-500/30">
              <div className="font-bold text-cyan-300 mb-0.5">1. Check Gauges</div>
              <p className="text-indigo-200">Watch Oxygen, Water, Food, and Power.</p>
            </div>

            <div className="p-3 bg-[#0b1026]/80 rounded-2xl border border-indigo-500/30">
              <div className="font-bold text-amber-300 mb-0.5">2. Make a Choice</div>
              <p className="text-indigo-200">Pick the best daily option or fix alerts.</p>
            </div>

            <div className="p-3 bg-[#0b1026]/80 rounded-2xl border border-indigo-500/30">
              <div className="font-bold text-emerald-300 mb-0.5">3. Launch Next Day</div>
              <p className="text-indigo-200">Earn 1 NASA badge every 5 days!</p>
            </div>
          </div>
        </div>

        {/* Section 2: 4 Resources */}
        <div className="space-y-2.5 mb-5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-300">
            The 4 Supplies
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
            <div className="p-3 bg-[#0b1026]/80 rounded-2xl border border-cyan-400/30 flex items-center gap-2.5">
              <Wind className="w-4 h-4 text-cyan-300 shrink-0" />
              <div>
                <strong className="text-white block">Oxygen</strong>
                <span className="text-indigo-200">Clean air for breathing.</span>
              </div>
            </div>

            <div className="p-3 bg-[#0b1026]/80 rounded-2xl border border-blue-400/30 flex items-center gap-2.5">
              <Droplet className="w-4 h-4 text-blue-300 shrink-0" />
              <div>
                <strong className="text-white block">Water</strong>
                <span className="text-indigo-200">85% recycled daily!</span>
              </div>
            </div>

            <div className="p-3 bg-[#0b1026]/80 rounded-2xl border border-amber-400/30 flex items-center gap-2.5">
              <Coffee className="w-4 h-4 text-amber-300 shrink-0" />
              <div>
                <strong className="text-white block">Food</strong>
                <span className="text-indigo-200">4 meal packs per day.</span>
              </div>
            </div>

            <div className="p-3 bg-[#0b1026]/80 rounded-2xl border border-emerald-400/30 flex items-center gap-2.5">
              <Zap className="w-4 h-4 text-emerald-300 shrink-0" />
              <div>
                <strong className="text-white block">Power</strong>
                <span className="text-indigo-200">Solar + 300 kWh batteries.</span>
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Difficulty */}
        <div className="space-y-2.5 mb-5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-300">
            Difficulty Modes
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
            <div className="p-3 bg-emerald-500/15 border border-emerald-400/40 rounded-2xl">
              <div className="font-bold text-emerald-300">Beginner</div>
              <p className="text-indigo-100 mt-0.5">+30% extra supplies & tips.</p>
            </div>

            <div className="p-3 bg-cyan-500/15 border border-cyan-400/40 rounded-2xl">
              <div className="font-bold text-cyan-300">Commander</div>
              <p className="text-indigo-100 mt-0.5">Standard NASA balance.</p>
            </div>

            <div className="p-3 bg-rose-500/15 border border-rose-400/40 rounded-2xl">
              <div className="font-bold text-rose-300">Expert</div>
              <p className="text-indigo-100 mt-0.5">Tight margins & tough storms.</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-indigo-500/30 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-indigo-900/80 hover:bg-indigo-800 text-white text-xs font-bold rounded-xl border border-indigo-400/40 transition-colors cursor-pointer"
          >
            Got It!
          </button>
        </div>
      </div>
    </div>
  );
};
