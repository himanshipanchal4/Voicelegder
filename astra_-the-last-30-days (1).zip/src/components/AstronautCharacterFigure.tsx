/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AstronautCharacter } from '../data/astronautRoster';

interface AstronautCharacterFigureProps {
  character: AstronautCharacter;
  isHovered?: boolean;
  isSelected?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const AstronautCharacterFigure: React.FC<AstronautCharacterFigureProps> = ({
  character,
  isHovered = false,
  isSelected = false,
  size = 'md',
}) => {
  const { id, color, badgeCode, suitTheme } = character;

  // Height and scale styles
  const containerHeight = size === 'sm' ? 'h-56' : size === 'lg' ? 'h-[420px]' : 'h-80 sm:h-96';

  // Skin tone & hair variations
  let skinColor = '#e0a97a';
  let hairColor = '#2d1e18';
  let hasGlasses = false;
  let hasBeard = false;
  let hasPonytail = false;
  let isShaved = false;

  if (id === 'alex-morgan') {
    skinColor = '#b57b52';
    hairColor = '#1c1917';
  } else if (id === 'maya-shah') {
    skinColor = '#c68642';
    hairColor = '#18181b';
    hasPonytail = true;
  } else if (id === 'ethan-park') {
    skinColor = '#e8be9e';
    hairColor = '#451a03';
    hasGlasses = true;
    hasBeard = true;
  } else if (id === 'zara-williams') {
    skinColor = '#8d5524';
    hairColor = '#09090b';
    hasPonytail = true;
  } else if (id === 'noah-reyes') {
    skinColor = '#c8956e';
    hairColor = '#27272a';
  } else if (id === 'ava-patel') {
    skinColor = '#b07d57';
    hairColor = '#1c1917';
    hasPonytail = true;
  } else if (id === 'liam-chen') {
    skinColor = '#e2b58d';
    hairColor = '#0f172a';
  } else if (id === 'sofia-okafor') {
    skinColor = '#5c3826';
    hairColor = '#0a0a0a';
    hasPonytail = true;
  } else if (id === 'arjun-mehta') {
    skinColor = '#c68a58';
    hairColor = '#18181b';
    isShaved = true;
  } else if (id === 'nia-brooks') {
    skinColor = '#4a2c1d';
    hairColor = '#09090b';
  }

  const { primary, secondary, accent, dark, ledColor } = suitTheme;

  return (
    <div className={`relative w-full ${containerHeight} flex items-center justify-center select-none overflow-hidden group`}>
      {/* Background Soft Glow matching Character's Personalized Accent */}
      <div
        className="absolute inset-0 opacity-20 blur-2xl pointer-events-none transition-all duration-500 rounded-full scale-90"
        style={{
          backgroundColor: isSelected ? accent : isHovered ? color : primary,
          transform: isHovered || isSelected ? 'scale(1.15)' : 'scale(0.85)',
        }}
      />

      {/* Ground Shadow & Perspective Ellipse */}
      <div className="absolute bottom-2 w-36 h-4 bg-black/75 rounded-full blur-[3px] pointer-events-none" />

      {/* SVG Full-Body Character Figure */}
      <svg
        viewBox="0 0 200 380"
        className="w-full h-full max-h-full drop-shadow-[0_12px_24px_rgba(0,0,0,0.85)] transition-transform duration-300 transform group-hover:scale-[1.03]"
        style={{
          filter: isSelected
            ? `drop-shadow(0 0 16px ${accent}80)`
            : isHovered
            ? `drop-shadow(0 0 12px ${color}66)`
            : 'none',
        }}
      >
        <defs>
          {/* Individual Suit Primary Gradient */}
          <linearGradient id={`suitPrimary-${id}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={primary} />
            <stop offset="60%" stopColor={primary} />
            <stop offset="100%" stopColor={dark} />
          </linearGradient>

          {/* Individual Suit Secondary / Armor Gradient */}
          <linearGradient id={`suitSecondary-${id}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={secondary} />
            <stop offset="100%" stopColor={dark} />
          </linearGradient>

          {/* Individual Accent Ribbon Gradient */}
          <linearGradient id={`suitAccent-${id}`} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={accent} />
            <stop offset="100%" stopColor={color} />
          </linearGradient>

          {/* Boots Dark Tread */}
          <linearGradient id={`bootGrad-${id}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#334155" />
            <stop offset="70%" stopColor="#1e293b" />
            <stop offset="100%" stopColor="#020617" />
          </linearGradient>
        </defs>

        {/* Group with gentle idle breathing animation */}
        <g className="animate-[pulse_4s_ease-in-out_infinite]">
          {/* 1. LEGS & BOOTS */}
          {/* Left Leg */}
          <path
            d="M74 215 L66 310 L60 350 L84 350 L88 300 L94 215 Z"
            fill={`url(#suitPrimary-${id})`}
            stroke={dark}
            strokeWidth="1.5"
          />
          {/* Right Leg */}
          <path
            d="M106 215 L112 300 L116 350 L140 350 L134 310 L126 215 Z"
            fill={`url(#suitPrimary-${id})`}
            stroke={dark}
            strokeWidth="1.5"
          />

          {/* Individual Leg Striping / Accents */}
          {id === 'liam-chen' && (
            /* High-Voltage glowing conduit stripes */
            <g>
              <line x1="72" y1="230" x2="68" y2="340" stroke="#eab308" strokeWidth="2.5" strokeDasharray="4 2" />
              <line x1="128" y1="230" x2="132" y2="340" stroke="#eab308" strokeWidth="2.5" strokeDasharray="4 2" />
            </g>
          )}

          {id === 'nia-brooks' && (
            /* Fiber-optic light waveguides */
            <g>
              <line x1="72" y1="230" x2="68" y2="340" stroke="#22d3ee" strokeWidth="2" />
              <line x1="128" y1="230" x2="132" y2="340" stroke="#e879f9" strokeWidth="2" />
            </g>
          )}

          {/* Knee Reinforcement Pads */}
          <rect x="62" y="270" width="24" height="24" rx="4" fill={secondary} stroke={dark} strokeWidth="1" />
          <rect x="65" y="274" width="18" height="6" rx="2" fill={dark} />
          <rect x="65" y="284" width="18" height="6" rx="2" fill={accent} />

          <rect x="114" y="270" width="24" height="24" rx="4" fill={secondary} stroke={dark} strokeWidth="1" />
          <rect x="117" y="274" width="18" height="6" rx="2" fill={dark} />
          <rect x="117" y="284" width="18" height="6" rx="2" fill={accent} />

          {/* Thigh Pouches & Badge */}
          <rect x="115" y="222" width="16" height="26" rx="3" fill="#0f172a" stroke={dark} strokeWidth="1" />
          <rect x="117" y="238" width="12" height="7" rx="1" fill={accent} />
          <text x="123" y="243" fontSize="4.5" fill="#f8fafc" textAnchor="middle" fontWeight="bold">
            {badgeCode}
          </text>

          {/* Individual Gear Attached to Belt / Thigh */}
          {id === 'ethan-park' && (
            /* Geology Rock Core Canister */
            <g>
              <rect x="54" y="224" width="10" height="26" rx="3" fill="#475569" stroke="#fbbf24" strokeWidth="1" />
              <rect x="56" y="228" width="6" height="18" rx="1" fill="#0f172a" />
              <circle cx="59" cy="237" r="2" fill="#fbbf24" />
            </g>
          )}

          {id === 'sofia-okafor' && (
            /* Glowing Biosphere Plant Vial */
            <g>
              <rect x="54" y="222" width="11" height="28" rx="4" fill="#064e3b" stroke="#34d399" strokeWidth="1.2" />
              <circle cx="59.5" cy="230" r="3" fill="#10b981" className="animate-pulse" />
              <line x1="59.5" y1="233" x2="59.5" y2="242" stroke="#34d399" strokeWidth="1.5" />
            </g>
          )}

          {id === 'arjun-mehta' && (
            /* Heavy Tactical Piton Tether Carabiner */
            <g>
              <rect x="52" y="222" width="12" height="24" rx="2" fill="#1e293b" stroke="#ef4444" strokeWidth="1.2" />
              <circle cx="58" cy="227" r="2.5" fill="none" stroke="#f87171" strokeWidth="1" />
              <path d="M58 230 L58 244" stroke="#f87171" strokeWidth="1.5" />
            </g>
          )}

          {/* Boots with Individual Color Seal Rings */}
          {/* Left Boot */}
          <path
            d="M56 348 L86 348 L86 364 L50 364 C48 360 50 352 56 348 Z"
            fill={`url(#bootGrad-${id})`}
            stroke={dark}
            strokeWidth="1.5"
          />
          <rect x="58" y="346" width="28" height="4" rx="1" fill={`url(#suitAccent-${id})`} />
          <line x1="52" y1="362" x2="84" y2="362" stroke={accent} strokeWidth="1.5" />

          {/* Right Boot */}
          <path
            d="M114 348 L144 348 C150 352 152 360 150 364 L114 364 Z"
            fill={`url(#bootGrad-${id})`}
            stroke={dark}
            strokeWidth="1.5"
          />
          <rect x="114" y="346" width="28" height="4" rx="1" fill={`url(#suitAccent-${id})`} />
          <line x1="116" y1="362" x2="148" y2="362" stroke={accent} strokeWidth="1.5" />

          {/* 2. TORSO & SUIT BODY */}
          <path
            d="M62 120 L138 120 L126 220 L74 220 Z"
            fill={`url(#suitPrimary-${id})`}
            stroke={dark}
            strokeWidth="1.5"
          />

          {/* Waist Technical Belt with Accent Stripe */}
          <rect x="72" y="208" width="56" height="12" rx="2" fill="#0f172a" stroke={secondary} strokeWidth="1.5" />
          <rect x="74" y="213" width="52" height="2.5" fill={`url(#suitAccent-${id})`} />
          <rect x="94" y="209" width="12" height="10" rx="2" fill="#475569" stroke="#94a3b8" strokeWidth="1" />

          {/* CHARACTER-SPECIFIC CHEST RIG & SUIT ARCHITECTURE */}
          {id === 'alex-morgan' ? (
            /* Commander: Navy body with Arctic White chest plate & command chevrons */
            <g>
              <path d="M52 112 L148 112 L138 152 L62 152 Z" fill={`url(#suitSecondary-${id})`} stroke="#334155" strokeWidth="2" />
              <rect x="74" y="132" width="52" height="54" rx="6" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
              {/* Three Command Chevrons */}
              <path d="M92 144 L100 150 L108 144" fill="none" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
              <path d="M92 152 L100 158 L108 152" fill="none" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
              <rect x="84" y="166" width="32" height="12" rx="2" fill="#1e293b" />
              <circle cx="100" cy="172" r="3" fill={ledColor} className="animate-pulse" />
            </g>
          ) : id === 'maya-shah' ? (
            /* ECLSS Engineer: Clean sterile white suit with dual aqua loop coils */
            <g>
              <rect x="72" y="132" width="56" height="56" rx="6" fill="#f8fafc" stroke="#0891b2" strokeWidth="2" />
              <rect x="80" y="140" width="40" height="24" rx="4" fill="#0f172a" stroke="#06b6d4" strokeWidth="1" />
              <circle cx="92" cy="152" r="4" fill="#22d3ee" className="animate-ping" />
              <circle cx="108" cy="152" r="4" fill="#06b6d4" />
              {/* ECLSS fluid loop tubes */}
              <path d="M74 168 C58 180, 56 210, 72 212" fill="none" stroke="#22d3ee" strokeWidth="4" strokeLinecap="round" />
              <path d="M126 168 C142 180, 144 210, 128 212" fill="none" stroke="#06b6d4" strokeWidth="4" strokeLinecap="round" />
            </g>
          ) : id === 'ethan-park' ? (
            /* Geologist: Ochre amber suit with diagonal harness & spectrometer pack */
            <g>
              <line x1="68" y1="122" x2="124" y2="208" stroke="#334155" strokeWidth="6" />
              <line x1="132" y1="122" x2="76" y2="208" stroke="#334155" strokeWidth="6" />
              <rect x="78" y="136" width="44" height="50" rx="6" fill="#1e293b" stroke="#f59e0b" strokeWidth="2" />
              <rect x="84" y="142" width="32" height="20" rx="3" fill="#0f172a" />
              <rect x="88" y="146" width="24" height="4" fill="#fbbf24" />
              <rect x="88" y="153" width="16" height="3" fill="#d97706" />
              <circle cx="100" cy="172" r="4" fill="#f59e0b" className="animate-pulse" />
            </g>
          ) : id === 'zara-williams' ? (
            /* Navigator: Royal violet suit with orbital star chart & radar */
            <g>
              <path d="M60 114 L140 114 L132 155 L68 155 Z" fill="#18181b" stroke="#818cf8" strokeWidth="1.5" />
              <rect x="76" y="134" width="48" height="52" rx="6" fill="#2e1065" stroke="#a78bfa" strokeWidth="1.8" />
              <circle cx="100" cy="155" r="12" fill="none" stroke="#a78bfa" strokeWidth="1.5" strokeDasharray="3 2" />
              <line x1="100" y1="140" x2="100" y2="170" stroke="#c084fc" strokeWidth="1" />
              <line x1="85" y1="155" x2="115" y2="155" stroke="#c084fc" strokeWidth="1" />
              <circle cx="100" cy="155" r="3" fill="#c084fc" className="animate-ping" />
            </g>
          ) : id === 'noah-reyes' ? (
            /* Doctor: Pure white suit with teal armor & red medical cross */
            <g>
              <rect x="74" y="132" width="52" height="54" rx="6" fill="#f8fafc" stroke="#0d9488" strokeWidth="2" />
              {/* Red Medical Cross */}
              <rect x="95" y="142" width="10" height="24" rx="1.5" fill="#ef4444" />
              <rect x="88" y="149" width="24" height="10" rx="1.5" fill="#ef4444" />
              {/* Pulse ECG display */}
              <rect x="82" y="170" width="36" height="10" rx="2" fill="#0f172a" />
              <path d="M84 175 L89 175 L92 172 L95 178 L98 174 L102 175 L116 175" fill="none" stroke="#10b981" strokeWidth="1.2" />
            </g>
          ) : id === 'ava-patel' ? (
            /* Robotics: Industrial orange with mechanical exoskeleton arm rig */
            <g>
              <path d="M66 120 L134 120 L126 180 L74 180 Z" fill="#27272a" stroke="#ea580c" strokeWidth="2" />
              <rect x="78" y="184" width="44" height="4" fill="#fb923c" />
              <rect x="84" y="135" width="32" height="36" rx="4" fill="#0f172a" stroke="#f97316" strokeWidth="1.5" />
              <circle cx="100" cy="153" r="6" fill="#f97316" className="animate-pulse" />
            </g>
          ) : id === 'liam-chen' ? (
            /* Power Engineer: Cobalt Blue with high-voltage conduits & battery core */
            <g>
              <rect x="74" y="132" width="52" height="56" rx="6" fill="#0f172a" stroke="#eab308" strokeWidth="2" />
              {/* Battery Core */}
              <rect x="88" y="140" width="24" height="32" rx="3" fill="#1d4ed8" stroke="#38bdf8" strokeWidth="1.5" />
              <polygon points="100,146 95,156 101,156 99,166 106,154 100,154" fill="#eab308" className="animate-pulse" />
            </g>
          ) : id === 'sofia-okafor' ? (
            /* Astrobiologist: Emerald green with pearl white bio-panels & leaf motif */
            <g>
              <rect x="74" y="132" width="52" height="54" rx="6" fill="#f0fdf4" stroke="#047857" strokeWidth="2" />
              <circle cx="100" cy="152" r="14" fill="#064e3b" stroke="#10b981" strokeWidth="1.5" />
              {/* Botanical sprout icon */}
              <path d="M100 160 C100 152, 94 148, 92 144 C98 144, 102 148, 100 160 Z" fill="#34d399" />
              <path d="M100 160 C100 150, 106 146, 108 142 C104 142, 99 146, 100 160 Z" fill="#10b981" />
              <rect x="84" y="170" width="32" height="10" rx="2" fill="#064e3b" />
              <circle cx="100" cy="175" r="2.5" fill="#34d399" className="animate-pulse" />
            </g>
          ) : id === 'arjun-mehta' ? (
            /* Heavy Polar EVA: Massive crimson ballistic chest rig with iron pauldrons */
            <g>
              <path d="M46 110 L154 110 L142 152 L58 152 Z" fill="#1e293b" stroke="#991b1b" strokeWidth="2.5" />
              <rect x="70" y="130" width="60" height="62" rx="8" fill="#450a0a" stroke="#ef4444" strokeWidth="2" />
              <rect x="78" y="138" width="44" height="24" rx="4" fill="#1e293b" stroke="#991b1b" strokeWidth="1.5" />
              <rect x="92" y="145" width="16" height="10" rx="2" fill="#ef4444" className="animate-pulse" />
              <line x1="84" y1="172" x2="116" y2="172" stroke="#fca5a5" strokeWidth="2" />
              <line x1="84" y1="180" x2="116" y2="180" stroke="#fca5a5" strokeWidth="2" />
            </g>
          ) : (
            /* Dr. Nia Brooks: Amethyst Purple with Laser cyan optical signal waveguides */
            <g>
              <rect x="74" y="132" width="52" height="54" rx="6" fill="#3b0764" stroke="#a855f7" strokeWidth="2" />
              {/* Radio waveform graphics */}
              <circle cx="100" cy="154" r="14" fill="none" stroke="#22d3ee" strokeWidth="1.5" strokeDasharray="4 2" />
              <circle cx="100" cy="154" r="8" fill="none" stroke="#e879f9" strokeWidth="1.5" />
              <circle cx="100" cy="154" r="3" fill="#22d3ee" className="animate-ping" />
            </g>
          )}

          {/* 3. ARMS & HANDS */}
          {/* Left Arm */}
          <path
            d="M62 124 L38 175 L44 235 L58 235 L54 185 L72 135 Z"
            fill={`url(#suitPrimary-${id})`}
            stroke={dark}
            strokeWidth="1.5"
          />
          {/* Left Gauntlet / Glove */}
          <rect x="36" y="215" width="20" height="14" rx="3" fill={secondary} stroke={dark} strokeWidth="1" />
          <path d="M38 229 L54 229 L50 250 L40 250 Z" fill={dark} stroke={secondary} strokeWidth="1" />
          <rect x="38" y="220" width="16" height="2" fill={`url(#suitAccent-${id})`} />

          {/* Right Arm */}
          <path
            d="M138 124 L162 175 L156 235 L142 235 L146 185 L128 135 Z"
            fill={`url(#suitPrimary-${id})`}
            stroke={dark}
            strokeWidth="1.5"
          />
          {/* Right Gauntlet / Glove */}
          <rect x="144" y="215" width="20" height="14" rx="3" fill={secondary} stroke={dark} strokeWidth="1" />
          <path d="M146 229 L162 229 L160 250 L150 250 Z" fill={dark} stroke={secondary} strokeWidth="1" />
          <rect x="146" y="220" width="16" height="2" fill={`url(#suitAccent-${id})`} />

          {/* Himanshi Panchal Mechanical Exoskeleton Right Arm Attachment */}
          {id === 'ava-patel' && (
            <g>
              <rect x="142" y="145" width="8" height="45" rx="2" fill="#475569" stroke="#ea580c" strokeWidth="1" />
              <circle cx="146" cy="180" r="4" fill="#f97316" />
              <line x1="146" y1="184" x2="152" y2="230" stroke="#f97316" strokeWidth="2" />
            </g>
          )}

          {/* Nia Brooks Antenna Headset */}
          {id === 'nia-brooks' && (
            <g>
              <line x1="118" y1="84" x2="135" y2="52" stroke="#22d3ee" strokeWidth="2" strokeLinecap="round" />
              <circle cx="135" cy="52" r="3" fill="#e879f9" className="animate-ping" />
            </g>
          )}

          {/* 4. HEAD / FACE / HELMET */}
          {/* Neck Collar */}
          <path d="M82 114 L118 114 L122 126 L78 126 Z" fill={dark} stroke={secondary} strokeWidth="1.5" />
          <rect x="84" y="122" width="32" height="3" fill={`url(#suitAccent-${id})`} />

          {/* Head & Face */}
          {/* Neck */}
          <rect x="91" y="94" width="18" height="22" rx="4" fill={skinColor} />

          {/* Face Base */}
          <ellipse cx="100" cy="80" rx="19" ry="24" fill={skinColor} stroke="#78350f" strokeWidth="0.8" />

          {/* Hair */}
          {!isShaved && (
            <path
              d={
                hasPonytail
                  ? "M81 76 C81 55, 119 55, 119 76 C119 65, 126 50, 100 48 C74 50, 81 65, 81 76 Z"
                  : "M80 75 C80 50, 120 50, 120 75 C118 64, 110 54, 100 54 C90 54, 82 64, 80 75 Z"
              }
              fill={hairColor}
            />
          )}
          {hasPonytail && (
            /* High Ponytail/Bun */
            <circle cx="100" cy="46" r="8" fill={hairColor} />
          )}

          {/* Eyes & Eyebrows */}
          <ellipse cx="93" cy="78" rx="2.5" ry="1.5" fill="#0f172a" />
          <ellipse cx="107" cy="78" rx="2.5" ry="1.5" fill="#0f172a" />
          <line x1="89" y1="74" x2="96" y2="74" stroke={hairColor} strokeWidth="1.2" />
          <line x1="104" y1="74" x2="111" y2="74" stroke={hairColor} strokeWidth="1.2" />

          {/* Glasses if Ethan Park */}
          {hasGlasses && (
            <g>
              <rect x="88" y="74" width="10" height="8" rx="2" fill="none" stroke="#fbbf24" strokeWidth="1.4" />
              <rect x="102" y="74" width="10" height="8" rx="2" fill="none" stroke="#fbbf24" strokeWidth="1.4" />
              <line x1="98" y1="78" x2="102" y2="78" stroke="#fbbf24" strokeWidth="1.4" />
            </g>
          )}

          {/* Beard if Ethan Park */}
          {hasBeard && (
            <path d="M89 86 C89 98, 111 98, 111 86 C105 92, 95 92, 89 86 Z" fill={hairColor} />
          )}

          {/* Nose & Mouth */}
          <path d="M100 78 L98 84 L102 84" fill="none" stroke="#92400e" strokeWidth="1" strokeLinecap="round" />
          <line x1="95" y1="90" x2="105" y2="90" stroke="#78350f" strokeWidth="1.2" strokeLinecap="round" />

          {/* Retracted Open Visor Arc above head with individualized tint color */}
          <path
            d="M74 88 C70 45, 130 45, 126 88"
            fill="none"
            stroke={secondary}
            strokeWidth="3.5"
            strokeLinecap="round"
          />
          <path
            d="M77 84 C74 48, 126 48, 123 84"
            fill="none"
            stroke={accent}
            strokeWidth="1.8"
            strokeOpacity="0.8"
          />
        </g>
      </svg>
    </div>
  );
};
