/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { DailyDecision, DecisionChoice } from '../types/mission';
import { Cpu, CheckCircle2, HelpCircle, ShieldCheck, ChevronDown, ChevronUp, X } from 'lucide-react';
import { soundEngine } from '../services/soundEngine';

interface DailyDecisionModalProps {
  decision: DailyDecision;
  isOpen: boolean;
  onConfirmChoice: (choice: DecisionChoice) => void;
  onClose: () => void;
  showHints: boolean;
}

export const DailyDecisionModal: React.FC<DailyDecisionModalProps> = ({
  decision,
  isOpen,
  onConfirmChoice,
  onClose,
  showHints,
}) => {
  const [selectedChoiceId, setSelectedChoiceId] = useState<string | null>(null);
  const [showHintCard, setShowHintCard] = useState<boolean>(showHints);
  const [showScienceFact, setShowScienceFact] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setSelectedChoiceId(null);
      setShowHintCard(showHints);
      setShowScienceFact(false);
    }
  }, [isOpen, decision.day, showHints]);

  if (!isOpen) return null;

  const selectedChoice = decision.choices.find((c) => c.id === selectedChoiceId);

  const handleApply = () => {
    if (selectedChoice) {
      onConfirmChoice(selectedChoice);
      setSelectedChoiceId(null);
    }
  };

  // Helper to turn choice deltas into quick teen-friendly +/- badges
  const renderDeltaChips = (choice: DecisionChoice) => {
    const chips: { label: string; good: boolean }[] = [];
    const d = choice.deltas;
    if (d.netOxygen) chips.push({ label: `${d.netOxygen > 0 ? '+' : ''}${d.netOxygen} kg O₂`, good: d.netOxygen > 0 });
    if (d.netWater) chips.push({ label: `${d.netWater > 0 ? '+' : ''}${d.netWater} L Water`, good: d.netWater > 0 });
    if (d.netFood) chips.push({ label: `${d.netFood > 0 ? '+' : ''}${d.netFood} Food`, good: d.netFood > 0 });
    if (d.netPower) chips.push({ label: `${d.netPower > 0 ? '+' : ''}${d.netPower} kWh Power`, good: d.netPower > 0 });
    if (d.netIntegrity) chips.push({ label: `${d.netIntegrity > 0 ? '+' : ''}${d.netIntegrity}% Base`, good: d.netIntegrity > 0 });
    if (d.crewMoraleDelta) chips.push({ label: `${d.crewMoraleDelta > 0 ? '+' : ''}${d.crewMoraleDelta}% Morale`, good: d.crewMoraleDelta > 0 });
    if (d.crewHealthDelta) chips.push({ label: `${d.crewHealthDelta > 0 ? '+' : ''}${d.crewHealthDelta}% Health`, good: d.crewHealthDelta > 0 });

    if (chips.length === 0) {
      return (
        <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-300">
          No supply cost
        </span>
      );
    }

    return chips.map((chip, idx) => (
      <span
        key={idx}
        className={`text-[11px] font-mono px-2 py-0.5 rounded border font-semibold ${
          chip.good
            ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800/80'
            : 'bg-amber-950/80 text-amber-300 border-amber-800/80'
        }`}
      >
        {chip.label}
      </span>
    ));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-[#060919]/85 backdrop-blur-sm select-none">
      <div className="bg-[#121a3e] border border-cyan-400/50 rounded-3xl max-w-xl w-full p-4 sm:p-7 shadow-2xl shadow-indigo-950/70 relative max-h-[90dvh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-indigo-300 hover:text-white rounded-xl hover:bg-indigo-900/60 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4 pr-8">
          <div className="w-11 h-11 rounded-2xl bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center text-cyan-300 shrink-0">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase text-cyan-300 tracking-wider">
              Day {decision.day} Choice
            </div>
            <h2 className="font-display text-lg sm:text-xl font-extrabold text-white">{decision.title}</h2>
          </div>
        </div>

        {/* Short Context */}
        <p className="p-4 rounded-2xl bg-[#0b1026]/85 border border-indigo-500/35 text-sm text-indigo-100 leading-relaxed mb-4">
          {decision.context}
        </p>

        {/* Coach Nova's Tip + Optional Space Science Toggle */}
        <div className="mb-5 space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <button
              onClick={() => setShowHintCard(!showHintCard)}
              className="text-amber-300 hover:text-amber-200 flex items-center gap-1.5 font-bold cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>{showHintCard ? 'Hide Nova’s Tip' : 'Show Nova’s Tip'}</span>
            </button>

            <button
              onClick={() => setShowScienceFact(!showScienceFact)}
              className="text-cyan-300 hover:text-cyan-200 flex items-center gap-1 font-bold cursor-pointer"
            >
              <span>NASA Space Fact</span>
              {showScienceFact ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>

          {showHintCard && (
            <div className="p-3 rounded-xl bg-amber-500/15 border border-amber-400/40 text-xs text-amber-100 leading-relaxed">
              <strong className="text-amber-300">Nova’s Tip: </strong>
              {decision.plainHint || 'Check which supply is lowest before picking!'}
            </div>
          )}

          {showScienceFact && (
            <div className="p-3 rounded-xl bg-violet-500/15 border border-violet-400/40 text-xs text-indigo-100 leading-relaxed">
              <strong className="text-cyan-300 text-[11px] block uppercase font-bold mb-0.5">
                Real NASA Science:
              </strong>
              {decision.educationalNote}
            </div>
          )}
        </div>

        {/* 1-Step Choices */}
        <div className="space-y-3 mb-5">
          <div className="text-xs font-bold uppercase text-indigo-300 tracking-wide">
            Tap one option, then click Confirm:
          </div>

          {decision.choices.map((choice) => {
            const isSelected = selectedChoiceId === choice.id;
            return (
              <div
                key={choice.id}
                onClick={() => {
                  soundEngine.playTelemetryClick();
                  setSelectedChoiceId(choice.id);
                }}
                className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-500/20 border-cyan-400 shadow-lg shadow-cyan-500/20'
                    : 'bg-[#0b1026]/80 border-indigo-500/30 hover:border-indigo-400/60'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="font-bold text-sm text-white">{choice.title}</div>
                  {isSelected && <CheckCircle2 className="w-5 h-5 text-cyan-300 shrink-0" />}
                </div>

                <p className="text-xs text-indigo-200 mt-1 leading-relaxed">{choice.description}</p>

                <div className="mt-3 pt-2.5 border-t border-indigo-500/25 flex flex-wrap items-center gap-1.5">
                  {renderDeltaChips(choice)}
                  {choice.plainAdvice && (
                    <span className="text-[11px] text-indigo-300 italic ml-auto">
                      {choice.plainAdvice}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-indigo-500/30">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-indigo-400/30 text-xs font-semibold text-indigo-200 hover:text-white cursor-pointer"
          >
            Back
          </button>

          <button
            disabled={!selectedChoice}
            onClick={handleApply}
            className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-emerald-400 to-cyan-400 hover:brightness-110 disabled:bg-slate-800 disabled:from-slate-800 disabled:to-slate-800 disabled:text-slate-500 text-slate-950 font-extrabold text-xs rounded-xl shadow-md transition-all cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Confirm Choice</span>
          </button>
        </div>
      </div>
    </div>
  );
};
