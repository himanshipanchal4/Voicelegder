/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useId } from 'react';

export interface NasaAstronautLogoProps {
  className?: string;
  size?: number | string;
  variant?: 'corps-emblem' | 'pin' | 'meatball';
  showLabel?: boolean;
  labelText?: string;
}

/**
 * Official NASA Astronaut Logo combining the custom astronaut-on-rocket artwork
 * with the authentic NASA blue & gold space insignia and preserved NASA text.
 * Reference image asset: /assets/aistudio/image_1483b422.png
 */
export const NasaAstronautLogo: React.FC<NasaAstronautLogoProps> = ({
  className = '',
  size = 36,
  variant = 'corps-emblem',
  showLabel = false,
  labelText = 'NASA',
}) => {
  const uid = useId().replace(/:/g, '');
  const goldGradId = `astroGoldGrad-${uid}`;
  const blueGradId = `nasaBlueGrad-${uid}`;
  const textArcId = `nasaTextArc-${uid}`;
  const pixelSize = typeof size === 'number' ? `${size}px` : size;

  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      <div
        className="relative shrink-0 flex items-center justify-center group cursor-pointer"
        style={{ width: pixelSize, height: pixelSize }}
        title="NASA Astronaut Corps · Outpost ASTRA"
      >
        {/* Ambient NASA blue & gold glow */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-blue-600/45 via-cyan-500/30 to-amber-400/45 blur-[4px] group-hover:blur-[7px] transition-all" />

        {/* Outer Insignia Frame & NASA Blue Starfield Ring */}
        <svg
          viewBox="0 0 100 100"
          className="absolute inset-0 w-full h-full z-10 drop-shadow-[0_2px_10px_rgba(11,61,145,0.75)] overflow-visible"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id={goldGradId} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FEF08A" />
              <stop offset="28%" stopColor="#FACC15" />
              <stop offset="58%" stopColor="#EAB308" />
              <stop offset="85%" stopColor="#CA8A04" />
              <stop offset="100%" stopColor="#854D0E" />
            </linearGradient>

            <radialGradient id={blueGradId} cx="50%" cy="42%" r="60%">
              <stop offset="0%" stopColor="#1D4ED8" />
              <stop offset="55%" stopColor="#0B3D91" />
              <stop offset="100%" stopColor="#061A40" />
            </radialGradient>
          </defs>

          {/* Outer Gold Rim */}
          <circle cx="50" cy="50" r="49" fill={`url(#${goldGradId})`} />
          {/* Dark Navy Separator */}
          <circle cx="50" cy="50" r="46.2" fill="#030A16" />
          {/* NASA Deep Blue Field */}
          <circle cx="50" cy="50" r="44.8" fill={`url(#${blueGradId})`} />

          {/* Starfield accents on NASA blue ring */}
          <g fill="#FFFFFF" opacity="0.9">
            <circle cx="24" cy="21" r="1.0" />
            <circle cx="76" cy="21" r="1.0" />
            <circle cx="14" cy="48" r="0.8" />
            <circle cx="86" cy="48" r="0.8" />
            <circle cx="19" cy="68" r="0.9" />
            <circle cx="81" cy="68" r="0.9" />
            <circle cx="50" cy="7.5" r="1.1" fill="#FEF08A" />
          </g>

          {/* Subtle orbital ellipse around the medallion */}
          <ellipse
            cx="50"
            cy="46"
            rx="42"
            ry="15"
            transform="rotate(-22 50 46)"
            stroke="#FACC15"
            strokeWidth="1.2"
            strokeDasharray="6 4"
            opacity="0.55"
          />

          {/* Inner White Medallion Backing (positioned slightly up to preserve full rocket + NASA text) */}
          <circle
            cx="50"
            cy="43.5"
            r="34.5"
            fill="#FFFFFF"
            stroke={`url(#${goldGradId})`}
            strokeWidth="2.2"
          />
        </svg>

        {/* Crisp HTML Image Layer for the Astronaut-on-Rocket Photo */}
        <div
          className="absolute z-20 rounded-full overflow-hidden flex items-center justify-center pointer-events-none bg-white"
          style={{
            left: '16.5%',
            top: '10%',
            width: '67%',
            height: '67%',
          }}
        >
          <img
            src="/assets/aistudio/image_1483b422.png"
            alt="NASA Astronaut riding rocket"
            className="w-[94%] h-[94%] object-contain"
            draggable={false}
          />
        </div>

        {/* Top SVG Overlay: Crisp NASA Text & Variant Accent */}
        <svg
          viewBox="0 0 100 100"
          className="absolute inset-0 w-full h-full z-30 pointer-events-none overflow-visible"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <path id={textArcId} d="M 21 81 Q 50 96 79 81" fill="none" />
          </defs>
          {/* Preserved Arched Bold NASA Text along the lower NASA blue ring */}
          <text
            fill={variant === 'pin' ? '#FDE047' : '#FFFFFF'}
            fontFamily="Arial, Helvetica, sans-serif"
            fontWeight="900"
            fontSize="12.5"
            letterSpacing="2.4"
            textAnchor="middle"
          >
            <textPath href={`#${textArcId}`} startOffset="50%">
              NASA
            </textPath>
          </text>
        </svg>
      </div>

      {showLabel && (
        <div className="flex flex-col">
          <span className="text-[11px] font-mono tracking-widest text-amber-400 font-bold uppercase leading-none">
            {labelText}
          </span>
          <span className="text-[9px] font-mono text-slate-400 tracking-wider mt-0.5">
            ASTRONAUT CORPS
          </span>
        </div>
      )}
    </div>
  );
};
