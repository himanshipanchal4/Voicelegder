/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sparkles, X, ChevronRight, HelpCircle, Globe } from 'lucide-react';
import { soundEngine } from '../services/soundEngine';

export interface AstronautGuideProps {
  message?: string;
  headline?: string;
  mood?: 'neutral' | 'curious' | 'warning' | 'celebration' | 'hint';
  onDismiss?: () => void;
  onRequestHint?: () => void;
  onOpenDiscovery?: () => void;
  hintAvailable?: boolean;
}

export const AstronautGuide: React.FC<AstronautGuideProps> = ({
  message,
  headline = 'Coach Nova',
  mood = 'neutral',
  onDismiss,
  onRequestHint,
  onOpenDiscovery,
  hintAvailable = true,
}) => {
  const [isMinimized, setIsMinimized] = useState<boolean>(() =>
    typeof window !== 'undefined' ? window.innerWidth < 1024 : false
  );

  const moodStyles = {
    neutral: 'border-cyan-400/60 shadow-cyan-500/20 text-cyan-200',
    curious: 'border-violet-400/70 shadow-violet-500/25 text-violet-200',
    warning: 'border-amber-400/80 shadow-amber-500/25 text-amber-200',
    celebration: 'border-emerald-400/80 shadow-emerald-500/25 text-emerald-200',
    hint: 'border-sky-400/75 shadow-sky-500/25 text-sky-100',
  }[mood];

  const moodBadge = {
    neutral: 'Base Buddy',
    curious: 'Space Fact',
    warning: 'Heads Up!',
    celebration: 'Badge Earned!',
    hint: 'Quick Tip',
  }[mood];

  return (
    <div className="fixed bottom-[164px] sm:bottom-[190px] lg:bottom-3 left-2.5 sm:left-3 z-20 select-none max-w-[calc(100vw-20px)] sm:max-w-sm pointer-events-auto animate-fade-in">
      {!isMinimized && message ? (
        <div
          className={`p-3.5 bg-[#121a3e]/95 backdrop-blur-md rounded-3xl border-2 ${moodStyles} shadow-2xl flex items-start gap-3 transition-all duration-300 relative`}
        >
          {/* Illustrated Astronaut Figure Badge */}
          <div className="relative shrink-0 animate-float-slow">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-b from-[#1a2554] via-[#10183a] to-[#0a0f26] border-2 border-cyan-300/80 p-1 shadow-lg flex flex-col items-center justify-center overflow-hidden relative">
              <div className="relative w-11 h-12 flex flex-col items-center">
                <div className="w-8 h-7 rounded-full bg-gradient-to-b from-white to-slate-200 border border-slate-300 shadow flex items-center justify-center">
                  <div className="w-6 h-5 rounded-full bg-slate-950 border border-slate-700 relative overflow-hidden flex items-center justify-center">
                    <div className="absolute top-0.5 right-0.5 w-3.5 h-3.5 rounded-full bg-gradient-to-br from-sky-400 via-blue-500 to-emerald-400 opacity-95" />
                    <div className="absolute top-1 left-1 w-1.5 h-1 bg-white/90 rounded-full" />
                  </div>
                </div>
                <div className="w-6 h-1 bg-amber-400 rounded-full -mt-0.5 z-10" />
                <div className="w-10 h-5 bg-gradient-to-b from-white to-slate-200 rounded-b-md relative flex items-center justify-center border border-slate-300">
                  <div className="w-4 h-3 bg-slate-900 rounded-xs flex items-center justify-around px-0.5">
                    <div className="w-1 h-1 rounded-full bg-cyan-400" />
                    <div className="w-1 h-1 rounded-full bg-emerald-400" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Dialogue Content */}
          <div className="flex-1 min-w-0 pr-5">
            <div className="font-display text-xs font-extrabold text-white flex items-center gap-1.5">
              <span>{headline}</span>
              <span className="text-[10px] font-bold uppercase text-amber-300">&bull; {moodBadge}</span>
            </div>
            <p className="text-xs text-indigo-100 mt-0.5 leading-snug line-clamp-3">{message}</p>

            <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
              {hintAvailable && onRequestHint && (
                <button
                  onClick={() => {
                    soundEngine.playTelemetryClick();
                    onRequestHint();
                  }}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-cyan-400/20 hover:bg-cyan-400/30 border border-cyan-400/50 text-[11px] font-bold text-cyan-200 transition-colors cursor-pointer"
                >
                  <HelpCircle className="w-3 h-3 text-cyan-300" />
                  <span>Hint</span>
                </button>
              )}

              {onOpenDiscovery && (
                <button
                  onClick={() => {
                    soundEngine.playTelemetryClick();
                    onOpenDiscovery();
                  }}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-fuchsia-500/25 hover:bg-fuchsia-500/35 border border-fuchsia-400/50 text-[11px] font-bold text-fuchsia-200 transition-colors cursor-pointer"
                >
                  <Globe className="w-3 h-3 text-fuchsia-300" />
                  <span>Space Quiz</span>
                </button>
              )}
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playTelemetryClick();
              setIsMinimized(true);
              if (onDismiss) onDismiss();
            }}
            className="absolute top-2.5 right-2.5 p-1 rounded-lg hover:bg-indigo-800/80 text-indigo-300 hover:text-white transition-colors cursor-pointer"
            title="Minimize Coach Nova"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : (
        <button
          onClick={() => {
            soundEngine.playTelemetryClick();
            setIsMinimized(false);
          }}
          className="px-3.5 py-2 bg-[#141d46]/95 border-2 border-cyan-400/60 hover:border-cyan-300 rounded-full shadow-lg flex items-center gap-2 text-xs font-bold text-cyan-200 transition-all hover:scale-105 cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>Coach Nova</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      )}
    </div>
  );
};
