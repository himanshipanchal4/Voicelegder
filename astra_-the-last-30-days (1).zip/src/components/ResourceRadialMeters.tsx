/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Wind, Droplet, Coffee, Zap, TrendingDown, TrendingUp, X } from 'lucide-react';
import { ResourceTelemetry, DailyResourceDeltas } from '../types/mission';
import { soundEngine } from '../services/soundEngine';

interface ResourceRadialMetersProps {
  resources: ResourceTelemetry;
  deltas: DailyResourceDeltas;
}

export const ResourceRadialMeters: React.FC<ResourceRadialMetersProps> = ({
  resources,
  deltas,
}) => {
  const [selectedRes, setSelectedRes] = useState<string | null>(null);

  const items = [
    {
      id: 'oxygen',
      label: 'Oxygen',
      unit: 'kg',
      val: Number(resources.oxygenKg.toFixed(1)),
      max: 200,
      delta: deltas.netOxygen,
      icon: Wind,
      color: '#22d3ee',
      cardBg: 'bg-cyan-950/75 border-cyan-400/45 hover:border-cyan-300',
      activeBorder: 'border-cyan-300 ring-2 ring-cyan-400/40',
      status: resources.oxygenKg > 60 ? 'Great' : resources.oxygenKg > 25 ? 'Low' : 'Danger!',
      detail: 'Air for your 4 astronauts! Plants & air scrubbers help refill it every day.',
    },
    {
      id: 'water',
      label: 'Water',
      unit: 'L',
      val: Number(resources.waterLiters.toFixed(1)),
      max: 250,
      delta: deltas.netWater,
      icon: Droplet,
      color: '#60a5fa',
      cardBg: 'bg-blue-950/75 border-blue-400/45 hover:border-blue-300',
      activeBorder: 'border-blue-300 ring-2 ring-blue-400/40',
      status: resources.waterLiters > 60 ? 'Great' : resources.waterLiters > 25 ? 'Low' : 'Danger!',
      detail: 'Drinking water for the crew. Over 85% gets recycled cleanly every day!',
    },
    {
      id: 'food',
      label: 'Food',
      unit: 'packs',
      val: Math.round(resources.foodPacks),
      max: 200,
      delta: deltas.netFood,
      icon: Coffee,
      color: '#fb923c',
      cardBg: 'bg-amber-950/70 border-amber-400/45 hover:border-amber-300',
      activeBorder: 'border-amber-300 ring-2 ring-amber-400/40',
      status: resources.foodPacks > 45 ? 'Great' : resources.foodPacks > 18 ? 'Low' : 'Danger!',
      detail: 'Tasty space meals plus fresh snacks grown inside the Space Greenhouse!',
    },
    {
      id: 'power',
      label: 'Power',
      unit: 'kWh',
      val: Math.round(resources.powerKwh),
      max: 300,
      delta: deltas.netPower,
      icon: Zap,
      color: '#34d399',
      cardBg: 'bg-emerald-950/75 border-emerald-400/45 hover:border-emerald-300',
      activeBorder: 'border-emerald-300 ring-2 ring-emerald-400/40',
      status: resources.powerKwh > 70 ? 'Great' : resources.powerKwh > 30 ? 'Low' : 'Danger!',
      detail: 'Solar energy stored in giant batteries to run lights, heaters, and air machines.',
    },
  ];

  return (
    <div className="relative select-none">
      {/* 4 Colorful Circular Meters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 sm:gap-2.5">
        {items.map((item) => {
          const pct = Math.min(100, Math.max(0, (item.val / item.max) * 100));
          const circumference = 2 * Math.PI * 22;
          const strokeDashoffset = circumference - (pct / 100) * circumference;
          const Icon = item.icon;
          const statusColor =
            item.status === 'Great'
              ? 'text-emerald-300'
              : item.status === 'Low'
              ? 'text-amber-300'
              : 'text-rose-300';

          return (
            <button
              type="button"
              key={item.id}
              onClick={() => {
                soundEngine.playTelemetryClick();
                setSelectedRes(selectedRes === item.id ? null : item.id);
              }}
              className={`p-1.5 sm:p-2.5 rounded-xl sm:rounded-2xl border backdrop-blur-md transition-all cursor-pointer flex items-center gap-2 sm:gap-2.5 text-left shadow-lg ${
                selectedRes === item.id ? `${item.cardBg} ${item.activeBorder}` : item.cardBg
              }`}
            >
              {/* Circular Radial Gauge */}
              <div className="relative w-8 h-8 sm:w-11 sm:h-11 flex items-center justify-center shrink-0">
                <svg className="w-8 h-8 sm:w-11 sm:h-11 -rotate-90" viewBox="0 0 52 52">
                  <circle
                    cx="26"
                    cy="26"
                    r="22"
                    fill="transparent"
                    stroke="rgba(255,255,255,0.12)"
                    strokeWidth="4.5"
                  />
                  <circle
                    cx="26"
                    cy="26"
                    r="22"
                    fill="transparent"
                    stroke={item.color}
                    strokeWidth="4.5"
                    strokeDasharray={circumference}
                    strokeDashoffset={strokeDashoffset}
                    strokeLinecap="round"
                    className="transition-all duration-700 ease-out"
                  />
                </svg>

                <div className="absolute inset-0 flex items-center justify-center">
                  <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" style={{ color: item.color }} />
                </div>
              </div>

              {/* Data Text */}
              <div className="flex-1 min-w-0">
                <div className="text-[10px] sm:text-[11px] font-bold text-slate-200 flex items-center justify-between gap-1">
                  <span className="truncate">{item.label}</span>
                  <span className={`text-[9px] sm:text-[10px] font-bold ${statusColor}`}>{item.status}</span>
                </div>
                <div className="text-xs sm:text-sm font-extrabold font-mono text-white tabular-nums truncate leading-tight">
                  {item.val} <span className="text-[9px] sm:text-[10px] font-normal text-slate-300">{item.unit}</span>
                </div>
                <div className="hidden sm:flex items-center gap-1 text-[10px] font-mono tabular-nums">
                  {item.delta < 0 ? (
                    <span className="text-amber-300 flex items-center">
                      <TrendingDown className="w-2.5 h-2.5 mr-0.5" />
                      {item.delta}/day
                    </span>
                  ) : (
                    <span className="text-emerald-300 flex items-center">
                      <TrendingUp className="w-2.5 h-2.5 mr-0.5" />
                      +{item.delta}/day
                    </span>
                  )}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Friendly Info Popover */}
      {selectedRes && (
        <div className="absolute top-full left-0 right-0 mt-2 p-3.5 bg-[#121a3c] border border-cyan-400/50 rounded-2xl shadow-2xl z-30 flex items-start justify-between gap-3 text-xs text-indigo-100">
          <div>
            <strong className="text-cyan-300 font-display text-xs uppercase tracking-wide block mb-0.5">
              {items.find((i) => i.id === selectedRes)?.label} Tip
            </strong>
            <p>{items.find((i) => i.id === selectedRes)?.detail}</p>
          </div>
          <button
            type="button"
            onClick={() => setSelectedRes(null)}
            className="text-indigo-300 hover:text-white p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
