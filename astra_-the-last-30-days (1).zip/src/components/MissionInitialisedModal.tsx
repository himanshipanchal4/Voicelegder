/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  CheckCircle2,
  ArrowRight,
  Wind,
  Droplet,
  Coffee,
  Zap,
  Users,
  Award,
} from 'lucide-react';
import { MissionState } from '../types/mission';
import { NasaAstronautLogo } from './NasaAstronautLogo';
import { soundEngine } from '../services/soundEngine';

interface MissionInitialisedModalProps {
  isOpen: boolean;
  state: MissionState;
  onProceedToCrewAssembly: () => void;
  onEnterOutpost: () => void;
}

export const MissionInitialisedModal: React.FC<MissionInitialisedModalProps> = ({
  isOpen,
  state,
  onProceedToCrewAssembly,
  onEnterOutpost,
}) => {
  if (!isOpen) return null;

  const { resources, difficulty } = state;
  const modeLabel =
    difficulty === 'beginner' ? 'Easy Mode' : difficulty === 'expert' ? 'Hard Mode' : 'Normal Mode';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-[#060919]/88 backdrop-blur-md select-none overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative w-full max-w-lg bg-[#121a3e] border-2 border-cyan-400/60 rounded-3xl shadow-2xl overflow-hidden my-auto animate-fade-in flex flex-col">
        <div className="h-1.5 w-full bg-gradient-to-r from-cyan-400 via-sky-400 to-emerald-400" />

        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-indigo-400/25 bg-indigo-950/60 text-center">
          <div className="flex items-center justify-center gap-3 mb-2.5">
            <NasaAstronautLogo size={46} className="drop-shadow-[0_0_12px_rgba(234,179,8,0.4)]" />
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/60 flex items-center justify-center shadow-lg">
              <CheckCircle2 className="w-5 h-5 text-emerald-300" />
            </div>
          </div>

          <h2 className="font-display text-2xl font-extrabold text-white tracking-tight">
            Ready for Launch!
          </h2>

          <div className="inline-flex items-center gap-2 mt-2 px-3 py-1 rounded-full bg-cyan-500/20 border border-cyan-400/50 text-xs font-bold text-cyan-200">
            <span>{modeLabel}</span>
            <span className="text-indigo-400">&bull;</span>
            <span>Day 1 / 30</span>
          </div>
        </div>

        {/* Starting Supplies Grid */}
        <div className="p-5 sm:p-6 space-y-4">
          <div className="grid grid-cols-2 gap-3 font-mono">
            <div className="p-3 rounded-2xl bg-[#0c1330] border border-cyan-400/35 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-cyan-500/20 flex items-center justify-center text-cyan-300 shrink-0">
                <Wind className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[10px] font-sans font-bold text-cyan-300 uppercase">Air (O₂)</div>
                <div className="text-sm font-extrabold text-white">{Math.round(resources.oxygenKg)} kg</div>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-[#0c1330] border border-sky-400/35 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-sky-500/20 flex items-center justify-center text-sky-300 shrink-0">
                <Droplet className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[10px] font-sans font-bold text-sky-300 uppercase">Water</div>
                <div className="text-sm font-extrabold text-white">{Math.round(resources.waterLiters)} L</div>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-[#0c1330] border border-emerald-400/35 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-300 shrink-0">
                <Coffee className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[10px] font-sans font-bold text-emerald-300 uppercase">Food</div>
                <div className="text-sm font-extrabold text-white">{Math.round(resources.foodPacks)} packs</div>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-[#0c1330] border border-amber-400/35 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-300 shrink-0">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[10px] font-sans font-bold text-amber-300 uppercase">Power</div>
                <div className="text-sm font-extrabold text-white">{Math.round(resources.powerKwh)} kWh</div>
              </div>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-[#0c1330]/80 border border-indigo-400/25 flex items-center justify-between text-xs text-indigo-100 px-4">
            <span className="flex items-center gap-1.5 font-semibold">
              <Users className="w-3.5 h-3.5 text-cyan-300" />
              <span>4 Astronauts Ready</span>
            </span>
            <span className="flex items-center gap-1.5 font-semibold">
              <Award className="w-3.5 h-3.5 text-amber-300" />
              <span>0 / 6 Badges</span>
            </span>
          </div>
        </div>

        {/* Actions */}
        <div className="p-5 bg-indigo-950/60 border-t border-indigo-400/25 flex flex-col sm:flex-row gap-2.5">
          <button
            onClick={() => {
              soundEngine.playConfirm();
              onEnterOutpost();
            }}
            className="flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400 hover:brightness-110 text-slate-950 font-extrabold text-xs sm:text-sm shadow-lg transition-all cursor-pointer"
          >
            <span>Play Day 1 Now</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              soundEngine.playTelemetryClick();
              onProceedToCrewAssembly();
            }}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#0c1330] hover:bg-indigo-900 text-indigo-100 border border-indigo-400/40 font-bold text-xs transition-all cursor-pointer"
          >
            <Users className="w-3.5 h-3.5 text-cyan-300" />
            <span>Pick Squad &amp; Mode</span>
          </button>
        </div>
      </div>
    </div>
  );
};
