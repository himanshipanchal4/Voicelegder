/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  X,
  Award,
  Sparkles,
  Lock,
  CheckCircle2,
  Calendar,
  RotateCcw,
  BookOpen,
  Orbit,
  ArrowRight,
} from 'lucide-react';
import { LUNAR_BADGES, BadgeDefinition, getNextUpcomingBadge } from '../data/badgeData';
import { BadgeInsignia } from './BadgeInsignia';
import { NasaAstronautLogo } from './NasaAstronautLogo';
import { soundEngine } from '../services/soundEngine';

interface BadgeCollectionModalProps {
  unlockedBadgeIds: string[];
  currentDay: number;
  onClose: () => void;
  onReplayCeremony?: (badge: BadgeDefinition) => void;
}

export const BadgeCollectionModal: React.FC<BadgeCollectionModalProps> = ({
  unlockedBadgeIds,
  currentDay,
  onClose,
  onReplayCeremony,
}) => {
  const [selectedBadge, setSelectedBadge] = useState<BadgeDefinition>(() => {
    // Default selected to latest unlocked or level 1
    const latest = [...LUNAR_BADGES]
      .reverse()
      .find((b) => unlockedBadgeIds.includes(b.id));
    return latest || LUNAR_BADGES[0];
  });

  const nextMilestone = getNextUpcomingBadge(currentDay);
  const earnedCount = unlockedBadgeIds.length;
  const isSelectedUnlocked = unlockedBadgeIds.includes(selectedBadge.id);

  const handleSelectBadge = (badge: BadgeDefinition) => {
    soundEngine.playTelemetryClick();
    setSelectedBadge(badge);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md animate-fade-in select-none">
      <div
        className="relative w-full max-w-5xl bg-[#030712] border border-cyan-500/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[94vh]"
        style={{
          boxShadow: '0 0 60px rgba(6, 182, 212, 0.15), 0 25px 50px rgba(0,0,0,0.95)',
        }}
      >
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <NasaAstronautLogo size={32} className="drop-shadow-[0_0_8px_rgba(234,179,8,0.4)]" />
            <div>
              <h2 className="text-xs font-mono uppercase tracking-widest text-cyan-400 font-bold">
                NASA ASTRONAUT CORPS &bull; LUNAR TRAINING INSIGNIA
              </h2>
              <p className="text-[11px] text-slate-400 font-sans hidden sm:block">
                Official 30-Day Polar Expedition Achievement Register
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              soundEngine.playTelemetryClick();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Milestone Progress Bar Header */}
        <div className="px-6 py-3.5 bg-slate-950 border-b border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              <span className="font-mono text-xs text-slate-200">
                Insignia Earned:{' '}
                <strong className="text-amber-400 text-sm">{earnedCount}</strong> / 6
              </span>
            </div>
            <span className="text-slate-700">|</span>
            <span className="text-xs font-mono text-slate-400">
              Training Day: <strong className="text-cyan-300">{currentDay}</strong> / 30
            </span>
          </div>

          {/* Next Badge Countdown */}
          {nextMilestone.badge ? (
            <div className="flex items-center gap-2.5">
              <div className="text-right">
                <span className="text-[10px] font-mono uppercase text-slate-400 block">
                  NEXT MILESTONE: {nextMilestone.badge.title}
                </span>
                <span className="text-xs font-mono text-cyan-300 font-bold">
                  {nextMilestone.daysRemaining} More Training Day{nextMilestone.daysRemaining > 1 ? 's' : ''} to Unlock
                </span>
              </div>
              <div className="w-24 h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-amber-400 rounded-full transition-all duration-500"
                  style={{ width: `${nextMilestone.progressPercent}%` }}
                />
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-xs font-mono text-emerald-400 font-bold">
              <CheckCircle2 className="w-4 h-4" />
              <span>All 6 Training Insignia Mastered!</span>
            </div>
          )}
        </div>

        {/* Main Body: 6 Badges Grid + Detail Inspector */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Area (7 Cols): 6 Badges Card Showcase */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
              {LUNAR_BADGES.map((b) => {
                const isUnlocked = unlockedBadgeIds.includes(b.id);
                const isSelected = selectedBadge.id === b.id;

                return (
                  <div
                    key={b.id}
                    onClick={() => handleSelectBadge(b)}
                    className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer flex flex-col items-center justify-between text-center relative overflow-hidden group ${
                      isSelected
                        ? 'bg-slate-900/95 border-cyan-400 shadow-xl shadow-cyan-950/80 ring-2 ring-cyan-400/50 scale-[1.02]'
                        : isUnlocked
                        ? 'bg-slate-950/80 border-slate-800 hover:border-slate-600 hover:bg-slate-900/60'
                        : 'bg-slate-950/40 border-slate-900 opacity-70 hover:opacity-90'
                    }`}
                  >
                    {/* Top Level indicator */}
                    <div className="w-full flex items-center justify-between text-[10px] font-mono text-slate-400 mb-1">
                      <span className="font-bold">LEVEL {b.romanNumeral}</span>
                      <span>{b.dayRange}</span>
                    </div>

                    {/* Badge SVG Insignia */}
                    <div className="my-1.5">
                      <BadgeInsignia
                        badge={b}
                        isUnlocked={isUnlocked}
                        size="md"
                      />
                    </div>

                    {/* Title & Status */}
                    <div className="w-full mt-1">
                      <h4 className="font-bold text-xs text-slate-100 truncate">
                        {b.title}
                      </h4>
                      <p className="text-[10px] font-mono mt-0.5 truncate">
                        {isUnlocked ? (
                          <span className="text-emerald-400 flex items-center justify-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>EARNED</span>
                          </span>
                        ) : (
                          <span className="text-slate-500 flex items-center justify-center gap-1">
                            <Lock className="w-3 h-3" />
                            <span>DAY {b.requiredDay}</span>
                          </span>
                        )}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Scientific Progression Info Note */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400 font-sans">
              <Orbit className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <p>
                Each badge reflects real spaceflight mission challenges encountered on Shackleton Rim. Badges are unlocked automatically upon successfully completing every 5-day training block without base life-support collapse.
              </p>
            </div>
          </div>

          {/* Right Area (5 Cols): Selected Badge Detailed Inspection Dossier */}
          <div className="lg:col-span-5 bg-slate-950/90 rounded-2xl border border-slate-800 p-5 flex flex-col justify-between space-y-4">
            <div>
              {/* Badge Preview Stage */}
              <div className="w-full flex flex-col items-center justify-center py-4 relative">
                <BadgeInsignia
                  badge={selectedBadge}
                  isUnlocked={isSelectedUnlocked}
                  size="lg"
                />
                <div className="mt-3 text-center">
                  <div className="flex items-center justify-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-[10px] font-mono text-amber-300 font-bold">
                      LEVEL {selectedBadge.romanNumeral}
                    </span>
                    <span className="text-xs font-mono text-slate-400">
                      {selectedBadge.dayRange}
                    </span>
                  </div>
                  <h3 className="text-lg font-black text-slate-100 mt-1 font-mono">
                    {selectedBadge.title}
                  </h3>
                  <p className="text-xs text-cyan-400 font-mono">
                    {selectedBadge.subtitle}
                  </p>
                </div>
              </div>

              {/* Requirement or Earned Status */}
              <div
                className={`p-3 rounded-xl border text-xs font-mono flex items-center justify-between ${
                  isSelectedUnlocked
                    ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400'
                }`}
              >
                <span className="flex items-center gap-1.5 font-bold">
                  {isSelectedUnlocked ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>OFFICIALLY EARNED IN ASTRA</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4 text-amber-400" />
                      <span>UNLOCK REQUIREMENT:</span>
                    </>
                  )}
                </span>
                <span>
                  {isSelectedUnlocked
                    ? `Day ${selectedBadge.requiredDay} Completed`
                    : `Complete Day ${selectedBadge.requiredDay}`}
                </span>
              </div>

              {/* Description & Lore */}
              <div className="mt-4 space-y-2 text-xs">
                <p className="text-slate-200 font-sans italic">
                  &ldquo;{selectedBadge.description}&rdquo;
                </p>
                <p className="text-slate-400 font-sans leading-relaxed pt-1">
                  {selectedBadge.lore}
                </p>
              </div>

              {/* NASA Science Insight */}
              <div className="mt-3.5 p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-[11px] text-slate-300 font-sans space-y-1">
                <div className="text-[10px] font-mono uppercase text-cyan-400 font-bold flex items-center gap-1">
                  <BookOpen className="w-3 h-3" />
                  <span>NASA Exploration Science</span>
                </div>
                <p className="leading-relaxed">
                  {selectedBadge.educationalInsight}
                </p>
              </div>
            </div>

            {/* Action Bar */}
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
              {isSelectedUnlocked && onReplayCeremony ? (
                <button
                  onClick={() => {
                    soundEngine.playTelemetryClick();
                    onReplayCeremony(selectedBadge);
                  }}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-xs font-mono text-cyan-300 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Replay Ceremony</span>
                </button>
              ) : (
                <span className="text-[11px] font-mono text-slate-500">
                  {isSelectedUnlocked ? 'Insignia Active' : 'Locked Milestone'}
                </span>
              )}

              <button
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 transition-colors cursor-pointer"
              >
                Close Collection
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
