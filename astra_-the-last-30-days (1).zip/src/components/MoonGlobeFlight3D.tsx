/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { ArrowRight, Compass, MapPin, Rocket, SkipForward, Sparkles } from 'lucide-react';
import { RocketId } from '../types/mission';
import { getRocketSpec, MoonSpot } from '../data/rocketCatalog';
import { build3DRocketMesh, createRealisticMoonTextures } from '../services/rocket3DFactory';
import { soundEngine } from '../services/soundEngine';

interface MoonGlobeFlight3DProps {
  rocketId?: RocketId;
  fromSpot: MoonSpot;
  toSpot: MoonSpot;
  headline: string;
  subtext?: string;
  badgeText?: string;
  ctaLabel?: string;
  autoCompleteDelayMs?: number;
  onLanded?: () => void;
  onComplete: () => void;
  renderLandedOverlay?: () => React.ReactNode;
}

const MOON_RADIUS = 5.4;

// Pre-allocated scratch math helpers (zero GC inside animation loop)
const _upVec = new THREE.Vector3(0, 1, 0);
const _tangent = new THREE.Vector3();
const _rocketPos = new THREE.Vector3();
const _surfaceNormal = new THREE.Vector3();
const _desiredUp = new THREE.Vector3();
const _sideAxis = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _lookTarget = new THREE.Vector3();
const _currentLook = new THREE.Vector3(0, 0, 0);
const _qStart = new THREE.Quaternion();
const _qEnd = new THREE.Quaternion();
const _qBlend = new THREE.Quaternion();
const _dummy = new THREE.Object3D();

function latLonToLocalVector(latDeg: number, lonDeg: number, radius: number): THREE.Vector3 {
  const lat = THREE.MathUtils.degToRad(latDeg);
  const lon = THREE.MathUtils.degToRad(lonDeg);
  const cosLat = Math.cos(lat);
  return new THREE.Vector3(
    radius * cosLat * Math.sin(lon),
    radius * Math.sin(lat),
    radius * cosLat * Math.cos(lon)
  );
}

// Spherical geodesic direction slerp between two unit vectors (handles long distances around the globe cleanly)
function slerpUnitVectors(a: THREE.Vector3, b: THREE.Vector3, t: number, out: THREE.Vector3): THREE.Vector3 {
  const dot = THREE.MathUtils.clamp(a.dot(b), -0.9999, 0.9999);
  const omega = Math.acos(dot);
  if (omega < 0.001) {
    return out.copy(a).lerp(b, t).normalize();
  }
  const sinOmega = Math.sin(omega);
  const wa = Math.sin((1 - t) * omega) / sinOmega;
  const wb = Math.sin(t * omega) / sinOmega;
  return out.set(
    wa * a.x + wb * b.x,
    wa * a.y + wb * b.y,
    wa * a.z + wb * b.z
  ).normalize();
}

export const MoonGlobeFlight3D: React.FC<MoonGlobeFlight3DProps> = ({
  rocketId,
  fromSpot,
  toSpot,
  headline,
  subtext,
  badgeText = 'LUNAR GLOBE TRANSIT',
  ctaLabel = 'Continue',
  autoCompleteDelayMs,
  onLanded,
  onComplete,
  renderLandedOverlay,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;
  const onLandedRef = useRef(onLanded);
  onLandedRef.current = onLanded;
  const hasCompletedRef = useRef(false);
  const autoTimerIdRef = useRef<number | null>(null);

  const completeOnce = () => {
    if (hasCompletedRef.current) return;
    hasCompletedRef.current = true;
    if (autoTimerIdRef.current !== null) {
      clearTimeout(autoTimerIdRef.current);
      autoTimerIdRef.current = null;
    }
    soundEngine.playConfirm();
    onCompleteRef.current();
  };

  const [flightStage, setFlightStage] = useState<'takeoff' | 'cruise' | 'landing' | 'landed'>('takeoff');
  const [webGlOk, setWebGlOk] = useState(true);
  const rocketSpec = getRocketSpec(rocketId);

  useEffect(() => {
    hasCompletedRef.current = false;
  }, [fromSpot.id, toSpot.id, rocketId]);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const isSoftwareGl = (() => {
      try {
        const probe = document.createElement('canvas');
        const gl = probe.getContext('webgl2') || probe.getContext('webgl');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param) || '');
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebGlOk(false);
      return;
    }

    const disposables: Array<{ dispose: () => void }> = [];
    const track = <T extends { dispose: () => void }>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const width = mount.clientWidth || window.innerWidth;
    const height = mount.clientHeight || window.innerHeight;
    const isPortrait = width < height;

    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    mount.replaceChildren(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x03050d);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmremGenerator.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    scene.environmentIntensity = 0.45; // Subtle so Moon terminator shadows stay deep & crisp!
    roomEnv.dispose();
    pmremGenerator.dispose();
    track(envTarget);

    const camera = new THREE.PerspectiveCamera(isPortrait ? 52 : 44, width / height, 0.1, 300);

    // =========================================================================
    // 1. REALISTIC SOLAR LIGHTING RIG (Illuminates Destination Sector Obliquely)
    // =========================================================================
    const originDir = latLonToLocalVector(fromSpot.latDeg, fromSpot.lonDeg, 1).normalize();
    const destDir = latLonToLocalVector(toSpot.latDeg, toSpot.lonDeg, 1).normalize();
    const avgDir = originDir.clone().add(destDir).normalize();
    if (avgDir.lengthSq() < 0.05) avgDir.copy(destDir);

    // Subtle earthshine on night hemisphere
    scene.add(new THREE.HemisphereLight(0x94a3b8, 0x0f172a, 0.36));

    // Oblique angled white sunlight casts sharp raking shadows across craters & rims
    const sunTangent = new THREE.Vector3().crossVectors(_upVec, destDir).normalize();
    if (sunTangent.lengthSq() < 0.05) sunTangent.set(1, 0, 0);
    const sunDir = destDir
      .clone()
      .multiplyScalar(0.75)
      .addScaledVector(sunTangent, 0.65)
      .add(new THREE.Vector3(0, 0.35, 0))
      .normalize();

    const sunLight = new THREE.DirectionalLight(0xfffcf5, 3.15);
    sunLight.position.copy(sunDir).multiplyScalar(30);
    sunLight.castShadow = !isSoftwareGl;
    sunLight.shadow.mapSize.set(1024, 1024);
    scene.add(sunLight);

    // Faint blue Earth-glow bounce on dark terminator edge
    const earthRimLight = new THREE.DirectionalLight(0x38bdf8, 0.48);
    earthRimLight.position.copy(sunDir).multiplyScalar(-24);
    scene.add(earthRimLight);

    const nozzleLight = new THREE.PointLight(rocketSpec.flamePrimaryHex, 5, 14, 1.6);
    scene.add(nozzleLight);

    const maxAniso = renderer.capabilities.getMaxAnisotropy();

    // =========================================================================
    // 2. DEEP SPACE STARFIELD & DISTANT EARTH
    // =========================================================================
    const STAR_COUNT = 340;
    const starInstanced = new THREE.InstancedMesh(
      track(new THREE.OctahedronGeometry(0.08, 0)),
      track(new THREE.MeshBasicMaterial({ color: 0xf1f5f9 })),
      STAR_COUNT
    );
    starInstanced.frustumCulled = false;
    for (let i = 0; i < STAR_COUNT; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const r = 46 + Math.random() * 58;
      _dummy.position.set(
        r * Math.sin(phi) * Math.cos(theta),
        r * Math.cos(phi),
        r * Math.sin(phi) * Math.sin(theta)
      );
      _dummy.scale.setScalar(0.45 + Math.random() * 1.25);
      _dummy.updateMatrix();
      starInstanced.setMatrixAt(i, _dummy.matrix);
    }
    starInstanced.instanceMatrix.needsUpdate = true;
    scene.add(starInstanced);

    const earthMesh = new THREE.Mesh(
      track(new THREE.SphereGeometry(2.0, 28, 28)),
      track(
        new THREE.MeshStandardMaterial({
          color: 0x0369a1,
          emissive: 0x0284c7,
          emissiveIntensity: 0.25,
          roughness: 0.45,
        })
      )
    );
    earthMesh.position.set(-22, 16, -42);
    scene.add(earthMesh);

    // =========================================================================
    // 3. REALISTIC 3D MOON GLOBE (Fixed Astronomical Coordinates + Physical Relief)
    // =========================================================================
    const moonGroup = new THREE.Group();
    scene.add(moonGroup);

    const moonTextures = createRealisticMoonTextures(maxAniso);
    track(moonTextures.map);
    track(moonTextures.bumpMap);
    track(moonTextures.roughnessMap);

    const moonMesh = new THREE.Mesh(
      track(new THREE.SphereGeometry(MOON_RADIUS, 72, 72)),
      track(
        new THREE.MeshStandardMaterial({
          map: moonTextures.map,
          bumpMap: moonTextures.bumpMap,
          bumpScale: 0.24,
          roughnessMap: moonTextures.roughnessMap,
          roughness: 0.94,
          metalness: 0.02,
          envMapIntensity: 0.22,
        })
      )
    );
    moonMesh.receiveShadow = true;
    moonGroup.add(moonMesh);

    // Ultra-subtle realistic sunlit limb dust scatter (no artificial neon ring)
    const limbGlow = new THREE.Mesh(
      track(new THREE.SphereGeometry(MOON_RADIUS * 1.018, 40, 40)),
      track(
        new THREE.MeshBasicMaterial({
          color: 0xe2e8f0,
          transparent: true,
          opacity: 0.045,
          side: THREE.BackSide,
          depthWrite: false,
        })
      )
    );
    moonGroup.add(limbGlow);

    // True spherical coordinates on the Moon globe for Origin & Destination
    const pOriginLocal = latLonToLocalVector(fromSpot.latDeg, fromSpot.lonDeg, MOON_RADIUS);
    const pDestLocal = latLonToLocalVector(toSpot.latDeg, toSpot.lonDeg, MOON_RADIUS);

    // Build Surface Landing Pads / Zone Markers at Origin (Cyan) & Destination (Emerald)
    const addSpotBeacon = (localPos: THREE.Vector3, colorHex: number, isDest: boolean) => {
      const normal = localPos.clone().normalize();
      const beaconGroup = new THREE.Group();
      beaconGroup.position.copy(localPos);
      beaconGroup.quaternion.setFromUnitVectors(_upVec, normal);

      const outerRing = new THREE.Mesh(
        track(new THREE.RingGeometry(isDest ? 0.26 : 0.16, isDest ? 0.42 : 0.26, 28)),
        track(
          new THREE.MeshBasicMaterial({
            color: colorHex,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.9,
          })
        )
      );
      outerRing.rotation.x = -Math.PI / 2;
      outerRing.position.y = 0.035;

      const padDisc = new THREE.Mesh(
        track(new THREE.CylinderGeometry(isDest ? 0.24 : 0.16, isDest ? 0.30 : 0.20, 0.06, 20)),
        track(
          new THREE.MeshStandardMaterial({
            color: 0x334155,
            emissive: colorHex,
            emissiveIntensity: 0.45,
            roughness: 0.4,
            metalness: 0.8,
          })
        )
      );
      padDisc.position.y = 0.03;

      beaconGroup.add(outerRing, padDisc);

      if (isDest) {
        // Subtle vertical beacon beam at destination so the target spot stands out clearly
        const beam = new THREE.Mesh(
          track(new THREE.CylinderGeometry(0.02, 0.08, 0.85, 12, 1, true)),
          track(
            new THREE.MeshBasicMaterial({
              color: colorHex,
              transparent: true,
              opacity: 0.35,
              side: THREE.DoubleSide,
              depthWrite: false,
            })
          )
        );
        beam.position.y = 0.44;
        beaconGroup.add(beam);
      }

      moonGroup.add(beaconGroup);
      return outerRing;
    };

    const originRing = addSpotBeacon(pOriginLocal, 0x38bdf8, false);
    const destRing = addSpotBeacon(pDestLocal, 0x34d399, true);

    // Compute smooth 3D geodesic great-circle orbital flight arc around the Moon Globe
    const arcPoints: THREE.Vector3[] = [];
    const ARC_SAMPLES = 48;
    const angularDist = originDir.angleTo(destDir);
    const peakLift = THREE.MathUtils.clamp(1.6 + angularDist * 1.15, 1.8, 3.6);
    const tmpUnit = new THREE.Vector3();

    for (let i = 0; i <= ARC_SAMPLES; i++) {
      const t = i / ARC_SAMPLES;
      slerpUnitVectors(originDir, destDir, t, tmpUnit);
      const arcLift = Math.sin(t * Math.PI) * peakLift;
      arcPoints.push(tmpUnit.clone().multiplyScalar(MOON_RADIUS + 0.06 + arcLift));
    }
    const flightCurve = new THREE.CatmullRomCurve3(arcPoints);

    const arcTubeGeo = track(new THREE.TubeGeometry(flightCurve, 64, 0.038, 8, false));
    const arcTubeMat = track(
      new THREE.MeshBasicMaterial({
        color: rocketSpec.accentColorHex,
        transparent: true,
        opacity: 0.52,
      })
    );
    const arcTube = new THREE.Mesh(arcTubeGeo, arcTubeMat);
    moonGroup.add(arcTube);

    // =========================================================================
    // 4. SELECTED 3D ROCKET ASSEMBLY + THRUSTER SPARKS + LANDING DUST
    // =========================================================================
    const built = build3DRocketMesh(rocketId, maxAniso, track);
    const rocketContainer = new THREE.Group();
    built.group.scale.setScalar(0.32);
    rocketContainer.add(built.group);
    moonGroup.add(rocketContainer);

    rocketContainer.position.copy(flightCurve.getPointAt(0));
    rocketContainer.quaternion.setFromUnitVectors(_upVec, originDir);

    // Position camera directly in 3/4 view over Origin spot so we immediately see THAT lunar region
    const initSide = new THREE.Vector3().crossVectors(originDir, _upVec).normalize();
    if (initSide.lengthSq() < 0.05) initSide.set(1, 0, 0);
    const initUpCam = new THREE.Vector3().crossVectors(initSide, originDir).normalize();
    const initialCamDist = isPortrait ? 9.2 : 7.4;

    camera.position
      .copy(pOriginLocal)
      .addScaledVector(originDir, initialCamDist * 0.78)
      .addScaledVector(initSide, initialCamDist * 0.48)
      .addScaledVector(initUpCam, 1.5);
    _currentLook.copy(pOriginLocal).lerp(moonGroup.position, 0.25);
    camera.lookAt(_currentLook);

    // Thruster spark particles
    const SPARK_COUNT = 42;
    const sparkMesh = new THREE.InstancedMesh(
      track(new THREE.OctahedronGeometry(0.052, 0)),
      track(
        new THREE.MeshBasicMaterial({
          color: rocketSpec.flamePrimaryHex,
          transparent: true,
          opacity: 0.9,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })
      ),
      SPARK_COUNT
    );
    sparkMesh.frustumCulled = false;
    moonGroup.add(sparkMesh);
    const sparks = Array.from({ length: SPARK_COUNT }, () => ({
      age: Math.random(),
      offset: new THREE.Vector3((Math.random() - 0.5) * 0.22, 0, (Math.random() - 0.5) * 0.22),
    }));

    // Regolith lunar dust ring puffs emitted upon landing touchdown
    const DUST_COUNT = 26;
    const dustMesh = new THREE.InstancedMesh(
      track(new THREE.IcosahedronGeometry(0.09, 1)),
      track(
        new THREE.MeshStandardMaterial({
          color: 0xcbd5e1,
          roughness: 1.0,
          transparent: true,
          opacity: 0.55,
          depthWrite: false,
        })
      ),
      DUST_COUNT
    );
    dustMesh.frustumCulled = false;
    moonGroup.add(dustMesh);
    const dustPuffs = Array.from({ length: DUST_COUNT }, (_, idx) => {
      const a = (idx / DUST_COUNT) * Math.PI * 2;
      return { angle: a, speed: 0.5 + (idx % 4) * 0.18 };
    });

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const handleResize = () => {
      if (!mount) return;
      const w = mount.clientWidth || window.innerWidth;
      const h = mount.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.fov = w < h ? 52 : 44;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    };
    window.addEventListener('resize', handleResize);

    const clock = new THREE.Clock();
    let elapsed = 0;
    let frameId = 0;
    let isDisposed = false;
    let currentStage: 'takeoff' | 'cruise' | 'landing' | 'landed' = 'takeoff';
    let touchdownTime = -1;

    const TAKEOFF_END = 0.85;
    const LANDING_START = 3.65;
    const TOTAL_FLIGHT_SEC = 4.65;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || typeof gl.fenceSync !== 'function') {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (isDisposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (isDisposed) return;
      const delta = Math.min(clock.getDelta(), 0.08);
      elapsed += delta;

      const pct = Math.min(100, (elapsed / TOTAL_FLIGHT_SEC) * 100);
      if (progressBarRef.current) {
        progressBarRef.current.style.width = `${pct.toFixed(1)}%`;
      }

      const nextStage: typeof currentStage =
        elapsed < TAKEOFF_END
          ? 'takeoff'
          : elapsed < LANDING_START
          ? 'cruise'
          : elapsed < TOTAL_FLIGHT_SEC
          ? 'landing'
          : 'landed';

      if (nextStage !== currentStage) {
        currentStage = nextStage;
        setFlightStage(nextStage);
        if (nextStage === 'cruise') {
          soundEngine.playPromoLiftoff();
        }
        if (nextStage === 'landed') {
          touchdownTime = elapsed;
          soundEngine.playConfirm();
          onLandedRef.current?.();
          if (autoCompleteDelayMs !== undefined) {
            autoTimerIdRef.current = window.setTimeout(() => {
              if (!isDisposed) completeOnce();
            }, autoCompleteDelayMs);
          }
        }
      }

      // Pulse origin/dest landing beacons subtly
      destRing.scale.setScalar(1 + Math.sin(elapsed * 5) * 0.16);
      originRing.scale.setScalar(1 + Math.cos(elapsed * 4) * 0.08);

      // Compute smooth eased progress along the 3D Moon great-circle arc (0 -> 1)
      const rawT = THREE.MathUtils.clamp((elapsed - 0.35) / (TOTAL_FLIGHT_SEC - 0.35), 0, 1);
      const u = rawT * rawT * (3 - 2 * rawT);

      flightCurve.getPointAt(u, _rocketPos);
      flightCurve.getTangentAt(Math.min(0.999, Math.max(0.001, u)), _tangent).normalize();
      _surfaceNormal.copy(_rocketPos).normalize();

      _qStart.setFromUnitVectors(_upVec, _surfaceNormal);
      _qEnd.setFromUnitVectors(_upVec, _tangent);

      const pitchFactor = Math.sin(u * Math.PI);
      _qBlend.copy(_qStart).slerp(_qEnd, pitchFactor * 0.85);
      rocketContainer.position.copy(_rocketPos);
      rocketContainer.quaternion.copy(_qBlend);

      built.group.rotation.y = elapsed * 0.72;

      // Dynamic thruster flame plume
      const flicker = 0.9 + Math.sin(elapsed * 28) * 0.1;
      const flamePower = nextStage === 'landed' ? 0.14 : 1.0 * flicker;
      built.flameGroup.scale.set(
        0.42 + flamePower * 0.48,
        0.16 + flamePower * 1.12,
        0.42 + flamePower * 0.48
      );

      moonGroup.updateMatrixWorld(true);
      const worldRocketPos = _rocketPos.clone().applyMatrix4(moonGroup.matrixWorld);
      nozzleLight.position.copy(worldRocketPos);
      nozzleLight.intensity = nextStage === 'landed' ? 2.2 : 8.5 * flicker;

      // Thruster exhaust sparks
      _desiredUp.set(0, 1, 0).applyQuaternion(rocketContainer.quaternion).normalize();
      for (let i = 0; i < SPARK_COUNT; i++) {
        const sp = sparks[i];
        sp.age += delta * (nextStage === 'landed' ? 0.5 : 2.3);
        if (sp.age >= 1) sp.age = 0;
        const distBack = nextStage === 'landed' ? 0.14 : 0.2 + sp.age * 1.3;
        _dummy.position
          .copy(_rocketPos)
          .addScaledVector(_desiredUp, -distBack)
          .addScaledVector(sp.offset, 1 + sp.age * 1.5);
        _dummy.scale.setScalar(nextStage === 'landed' ? 0.01 : Math.max(0.05, (1 - sp.age) * 1.2));
        _dummy.updateMatrix();
        sparkMesh.setMatrixAt(i, _dummy.matrix);
      }
      sparkMesh.instanceMatrix.needsUpdate = true;

      // Touchdown lunar regolith dust ring
      const dustAge = touchdownTime >= 0 ? Math.min(1.5, elapsed - touchdownTime) : -1;
      const destBasis = new THREE.Quaternion().setFromUnitVectors(_upVec, destDir);
      const dustEast = new THREE.Vector3(1, 0, 0).applyQuaternion(destBasis);
      const dustNorth = new THREE.Vector3(0, 0, 1).applyQuaternion(destBasis);
      for (let i = 0; i < DUST_COUNT; i++) {
        if (dustAge < 0 || dustAge >= 1.45) {
          _dummy.scale.setScalar(0.0001);
        } else {
          const dp = dustPuffs[i];
          const rad = 0.25 + dustAge * dp.speed;
          _dummy.position
            .copy(pDestLocal)
            .addScaledVector(destDir, 0.08 + Math.sin(dustAge * 2.2) * 0.12)
            .addScaledVector(dustEast, Math.cos(dp.angle) * rad)
            .addScaledVector(dustNorth, Math.sin(dp.angle) * rad);
          _dummy.scale.setScalar(Math.max(0.01, (1 - dustAge / 1.45) * (0.45 + dustAge * 0.9)));
        }
        _dummy.updateMatrix();
        dustMesh.setMatrixAt(i, _dummy.matrix);
      }
      dustMesh.instanceMatrix.needsUpdate = true;

      // Dynamic Orbiting Tracking Camera that travels around the Moon Globe right with the rocket!
      const worldNormal = worldRocketPos.clone().normalize();
      _sideAxis.crossVectors(worldNormal, _upVec);
      if (_sideAxis.lengthSq() < 0.04) {
        // Fallback near North/South poles (Shackleton/Peary!)
        _sideAxis.crossVectors(worldNormal, new THREE.Vector3(0, 0, 1));
      }
      _sideAxis.normalize();
      const camNorth = new THREE.Vector3().crossVectors(_sideAxis, worldNormal).normalize();

      const camDist = isPortrait ? 8.8 : 7.0;
      const altitudeZoom = Math.sin(u * Math.PI) * 1.45; // Pull out slightly at cruise peak so whole Moon globe curves beneath!
      _camTarget
        .copy(worldRocketPos)
        .addScaledVector(worldNormal, (isPortrait ? 3.8 : 3.1) + altitudeZoom)
        .addScaledVector(_sideAxis, (isPortrait ? 4.4 : 3.8) + altitudeZoom * 0.6)
        .addScaledVector(camNorth, 1.35);

      _lookTarget.copy(worldRocketPos).lerp(moonGroup.position, 0.34);

      camera.position.x = THREE.MathUtils.damp(camera.position.x, _camTarget.x, 3.2, delta);
      camera.position.y = THREE.MathUtils.damp(camera.position.y, _camTarget.y, 3.2, delta);
      camera.position.z = THREE.MathUtils.damp(camera.position.z, _camTarget.z, 3.2, delta);

      _currentLook.x = THREE.MathUtils.damp(_currentLook.x, _lookTarget.x, 3.8, delta);
      _currentLook.y = THREE.MathUtils.damp(_currentLook.y, _lookTarget.y, 3.8, delta);
      _currentLook.z = THREE.MathUtils.damp(_currentLook.z, _lookTarget.z, 3.8, delta);
      camera.lookAt(_currentLook);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    if (isSoftwareGl) {
      afterDraw(tick);
    } else {
      frameId = requestAnimationFrame(tick);
    }

    return () => {
      isDisposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      if (autoTimerIdRef.current !== null) {
        clearTimeout(autoTimerIdRef.current);
        autoTimerIdRef.current = null;
      }
      window.removeEventListener('resize', handleResize);
      disposables.forEach((d) => {
        try {
          d.dispose();
        } catch {
          // ignore
        }
      });
      renderer.dispose();
    };
  }, [
    rocketId,
    fromSpot.id,
    fromSpot.latDeg,
    fromSpot.lonDeg,
    toSpot.id,
    toSpot.latDeg,
    toSpot.lonDeg,
    autoCompleteDelayMs,
    rocketSpec.accentColorHex,
    rocketSpec.flamePrimaryHex,
  ]);

  // Fallback timer if WebGL unavailable
  useEffect(() => {
    if (webGlOk) return;
    setFlightStage('landed');
    onLandedRef.current?.();
    if (autoCompleteDelayMs !== undefined) {
      const t = window.setTimeout(() => completeOnce(), 1200);
      return () => clearTimeout(t);
    }
  }, [webGlOk, autoCompleteDelayMs]);

  const coordTag = `${Math.abs(toSpot.latDeg)}°${toSpot.latDeg >= 0 ? 'N' : 'S'}, ${Math.abs(toSpot.lonDeg)}°${
    toSpot.lonDeg >= 0 ? 'E' : 'W'
  }`;

  return (
    <div className="fixed inset-0 z-50 bg-[#03050d] text-white select-none overflow-hidden animate-fade-in">
      {/* Dedicated WebGL 3D Canvas */}
      <div ref={mountRef} className="absolute inset-0 w-full h-full" />

      {!webGlOk && (
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-b from-[#03050d] via-[#131d4c] to-[#1e1b4b]">
          <Rocket className="w-16 h-16 text-cyan-300 animate-bounce" />
        </div>
      )}

      {/* Top Flight Route Strip (no backdrop-blur over WebGL) */}
      <div className="relative z-10 flex items-center justify-between gap-3 px-4 sm:px-8 pt-4 sm:pt-6">
        <div className="flex flex-wrap items-center gap-2">
          <div
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-cyan-400/40"
            style={{ backgroundColor: 'rgba(11, 17, 46, 0.90)' }}
          >
            <Sparkles className="w-4 h-4 text-amber-300 shrink-0" />
            <span className="font-mono text-[11px] sm:text-xs font-extrabold uppercase tracking-wider text-cyan-200 truncate">
              {badgeText} · {rocketSpec.name}
            </span>
          </div>

          <div
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-emerald-400/35 text-[11px] font-mono text-emerald-200"
            style={{ backgroundColor: 'rgba(11, 17, 46, 0.90)' }}
          >
            <Compass className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
            <span>
              {toSpot.terrainType || 'Lunar Sector'} ({coordTag})
            </span>
          </div>
        </div>

        <button
          onClick={completeOnce}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-indigo-400/40 hover:border-cyan-300 text-xs font-bold text-indigo-100 hover:text-white transition-colors cursor-pointer shrink-0"
          style={{ backgroundColor: 'rgba(11, 17, 46, 0.90)' }}
        >
          <span>Skip</span>
          <SkipForward className="w-3.5 h-3.5 text-cyan-300" />
        </button>
      </div>

      {/* Bottom Moon Route Card / Landed Overlay */}
      <div className="absolute bottom-4 sm:bottom-7 inset-x-3 sm:inset-x-auto sm:left-1/2 sm:-translate-x-1/2 sm:w-full sm:max-w-xl z-10">
        {flightStage === 'landed' && renderLandedOverlay ? (
          renderLandedOverlay()
        ) : (
          <div
            className="rounded-3xl border border-indigo-400/45 p-4 sm:p-5 shadow-2xl space-y-3"
            style={{ backgroundColor: 'rgba(12, 18, 48, 0.92)' }}
          >
            {/* Origin -> Destination Moon Spot Route */}
            <div className="flex items-center justify-between gap-2 text-[11px] sm:text-xs font-mono">
              <span className="flex items-center gap-1 text-cyan-300 font-bold truncate">
                <MapPin className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{fromSpot.name}</span>
              </span>
              <span className="text-indigo-300 shrink-0">━━ 🚀 ━━▶</span>
              <span className="flex items-center gap-1 text-emerald-300 font-bold truncate">
                <MapPin className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{toSpot.name}</span>
              </span>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="font-display text-lg sm:text-2xl font-extrabold text-white leading-tight">
                  {flightStage === 'landed' ? `Landed at ${toSpot.name}!` : headline}
                </h2>
                {subtext && <p className="text-xs sm:text-sm text-indigo-200 mt-0.5">{subtext}</p>}
              </div>

              <button
                onClick={completeOnce}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400 hover:brightness-110 text-slate-950 font-extrabold text-xs sm:text-sm shadow-lg shadow-cyan-500/25 transition-all cursor-pointer shrink-0"
              >
                <span>{ctaLabel}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Flight Progress Bar */}
            <div className="w-full h-1.5 bg-[#060a1f] rounded-full overflow-hidden border border-indigo-500/30">
              <div
                ref={progressBarRef}
                className="h-full bg-gradient-to-r from-cyan-400 via-amber-400 to-emerald-400 rounded-full"
                style={{ width: '0%' }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
