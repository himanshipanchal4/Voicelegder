/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Play,
  BookOpen,
  Orbit,
  ArrowRight,
  ShieldCheck,
  Activity,
  BatteryCharging,
  Radio,
  Award,
  Compass,
  ExternalLink,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  Trophy,
} from 'lucide-react';
import { soundEngine } from '../services/soundEngine';
import { storageService } from '../services/storageService';
import { NASA_DISCOVERIES } from '../data/discoveriesData';
import { getNextUpcomingBadge } from '../data/badgeData';
import { NasaAstronautLogo } from './NasaAstronautLogo';

interface LandingPageProps {
  onStartMission: () => void;
  onResumeMission?: () => void;
  hasSavedGame: boolean;
  onOpenHowToPlay: () => void;
  onOpenScience: () => void;
  onOpenBadges?: () => void;
  badgeCount?: number;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onStartMission,
  onResumeMission,
  hasSavedGame,
  onOpenHowToPlay,
  onOpenScience,
  onOpenBadges,
  badgeCount = 0,
}) => {
  const savedMission = useMemo(() => {
    if (!hasSavedGame) return null;
    return storageService.loadMission();
  }, [hasSavedGame]);

  const upcomingBadgeInfo = useMemo(() => {
    const currentDay = savedMission?.day || 1;
    return getNextUpcomingBadge(currentDay);
  }, [savedMission]);

  const [intelIndex, setIntelIndex] = useState<number>(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIntelIndex((prev) => (prev + 1) % NASA_DISCOVERIES.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const activeFact = NASA_DISCOVERIES[intelIndex] || NASA_DISCOVERIES[0];

  return (
    <div className="relative min-h-[calc(100dvh-54px)] flex flex-col justify-between p-3.5 sm:p-6 md:p-8 max-w-7xl mx-auto select-none overflow-hidden">
      {/* ============================================================ */}
      {/* COLORFUL COSMIC MOONBASE SCENERY BACKDROP                    */}
      {/* ============================================================ */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0b112e] via-[#151e4a] to-[#1a1544]" />
        <div className="absolute -top-24 left-1/4 w-[680px] h-[420px] bg-violet-600/25 rounded-full blur-[130px]" />
        <div className="absolute top-1/3 -right-16 w-[560px] h-[380px] bg-cyan-500/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-8 left-10 w-[500px] h-[280px] bg-amber-500/15 rounded-full blur-[110px]" />

        {/* Colorful Blue Marble Earth */}
        <div className="absolute top-8 right-10 md:right-20 w-24 h-24 md:w-32 md:h-32 opacity-90 pointer-events-none">
          <div className="relative w-full h-full">
            <div className="absolute inset-0 rounded-full bg-cyan-400/30 blur-md" />
            <div className="w-full h-full rounded-full bg-gradient-to-tr from-[#0f3460] via-[#1d6fa5] to-[#7dd3fc] border border-cyan-300/40 overflow-hidden relative shadow-2xl">
              <div className="absolute -top-3 -left-3 w-20 h-20 rounded-full bg-emerald-400/25 blur-sm" />
              <div className="absolute top-8 left-5 w-16 h-8 rounded-full bg-white/30 blur-[2px]" />
              <div className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-slate-950/75" />
            </div>
          </div>
        </div>

        {/* Moon Horizon & Base Silhouette */}
        <div className="absolute bottom-0 inset-x-0 h-56 md:h-72 pointer-events-none opacity-55">
          <svg
            viewBox="0 0 1200 320"
            preserveAspectRatio="none"
            className="w-full h-full"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="landingRidgeFar" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#312e81" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#0f172a" stopOpacity="0.95" />
              </linearGradient>
              <linearGradient id="landingRidgeNear" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#1e1b4b" stopOpacity="0.95" />
                <stop offset="100%" stopColor="#090e24" stopOpacity="1" />
              </linearGradient>
            </defs>
            <path
              d="M0,170 Q120,115 240,150 T480,120 T720,160 T960,115 T1200,145 L1200,320 L0,320 Z"
              fill="url(#landingRidgeFar)"
            />
            <path
              d="M0,205 Q160,165 320,195 T640,175 T920,210 T1200,185 L1200,320 L0,320 Z"
              fill="url(#landingRidgeNear)"
            />
            <g transform="translate(860, 160)" fill="#38bdf8" opacity="0.9">
              <line x1="120" y1="30" x2="120" y2="0" stroke="#38bdf8" strokeWidth="1.5" />
              <circle cx="120" cy="0" r="2" fill="#f472b6" />
              <path d="M112,8 Q120,4 128,8" stroke="#38bdf8" strokeWidth="1.5" fill="none" />
              <path d="M70,30 Q90,5 110,30 Z" fill="#1e1b4b" stroke="#38bdf8" strokeWidth="1.3" />
              <circle cx="90" cy="20" r="2.5" fill="#fbbf24" />
              <rect x="50" y="20" width="22" height="10" rx="2" fill="#1e1b4b" stroke="#a78bfa" strokeWidth="1.2" />
              <rect x="110" y="22" width="20" height="8" rx="2" fill="#1e1b4b" stroke="#34d399" strokeWidth="1.2" />
              <path d="M150,30 L154,12 L158,5 L162,12 L166,30 Z" fill="#1e1b4b" stroke="#fbbf24" strokeWidth="1.3" />
            </g>
          </svg>
        </div>
      </div>

      {/* ============================================================ */}
      {/* TOP BAR TAGS                                                 */}
      {/* ============================================================ */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 text-xs font-medium text-indigo-200">
          <NasaAstronautLogo size={30} className="drop-shadow-[0_0_8px_rgba(250,204,21,0.4)]" />
          <span className="font-bold tracking-wide text-cyan-300">NASA SPACE APPS</span>
        </div>

        <div className="text-xs font-semibold text-amber-300">
          30-Day Moon Mission
        </div>
      </div>

      {/* ============================================================ */}
      {/* MAIN 2-COLUMN HERO & QUICK MISSION LAUNCHPAD                 */}
      {/* ============================================================ */}
      <div className="relative z-10 my-auto py-5 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* LEFT COLUMN: Hero Title + Big Action Buttons */}
        <div className="lg:col-span-7 p-4 sm:p-8 rounded-3xl bg-[#131b3d]/90 backdrop-blur-md border border-indigo-400/35 shadow-2xl flex flex-col justify-between">
          <div>
            {/* Hero Lockup with NASA Astronaut Logo */}
            <div className="flex items-center gap-3.5 sm:gap-5 mb-4">
              <div className="shrink-0 group">
                <NasaAstronautLogo
                  size={68}
                  className="sm:w-[84px] sm:h-[84px] transition-transform duration-300 group-hover:scale-105 drop-shadow-[0_0_24px_rgba(56,189,248,0.45)]"
                />
              </div>
              <div className="min-w-0">
                <h1 className="font-display text-4xl sm:text-6xl font-black tracking-tight text-white leading-none">
                  ASTRA
                </h1>
                <span className="block font-display text-base sm:text-2xl md:text-3xl font-extrabold bg-gradient-to-r from-cyan-300 via-sky-300 to-fuchsia-300 bg-clip-text text-transparent mt-1">
                  THE LAST 30 DAYS
                </span>
              </div>
            </div>

            <p className="text-sm sm:text-lg font-semibold text-indigo-100 leading-snug mb-5 sm:mb-6 max-w-xl">
              Command a Moon base, protect 4 astronauts, and earn 6 NASA badges.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:flex-wrap items-stretch sm:items-center gap-2.5 sm:gap-3">
              {hasSavedGame && onResumeMission ? (
                <>
                  <button
                    onClick={() => {
                      soundEngine.playConfirm();
                      onResumeMission();
                    }}
                    className="w-full sm:w-auto flex items-center justify-center gap-2.5 px-6 py-3.5 bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400 hover:from-emerald-300 hover:to-sky-300 text-slate-950 font-extrabold text-sm sm:text-base rounded-2xl shadow-lg shadow-cyan-500/30 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer whitespace-nowrap"
                  >
                    <ArrowRight className="w-5 h-5" />
                    <span>Continue (Day {savedMission?.day || 1})</span>
                  </button>

                  <button
                    onClick={() => {
                      soundEngine.playTelemetryClick();
                      onStartMission();
                    }}
                    className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-3.5 bg-indigo-900/80 hover:bg-indigo-800 text-white font-bold text-sm rounded-2xl border border-amber-400/50 transition-all hover:scale-[1.01] cursor-pointer whitespace-nowrap"
                  >
                    <Play className="w-4 h-4 text-amber-300 fill-amber-300" />
                    <span>New Game</span>
                  </button>
                </>
              ) : (
                <button
                  onClick={() => {
                    soundEngine.playConfirm();
                    onStartMission();
                  }}
                  className="w-full sm:w-auto flex items-center justify-center gap-3 px-7 py-4 bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400 hover:from-emerald-300 hover:to-sky-300 text-slate-950 font-extrabold text-base rounded-2xl shadow-xl shadow-cyan-500/30 transition-all hover:scale-[1.03] active:scale-[0.98] cursor-pointer whitespace-nowrap"
                >
                  <Play className="w-5 h-5 fill-slate-950" />
                  <span>Start Mission</span>
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2.5 pt-1">
              <button
                onClick={() => {
                  soundEngine.playTelemetryClick();
                  onOpenHowToPlay();
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-[#1c2654] hover:bg-[#25326c] text-indigo-100 font-semibold text-xs sm:text-sm rounded-xl border border-indigo-400/30 transition-colors cursor-pointer whitespace-nowrap"
              >
                <BookOpen className="w-4 h-4 text-amber-300" />
                <span>How to Play</span>
              </button>

              <button
                onClick={() => {
                  soundEngine.playTelemetryClick();
                  onOpenScience();
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-[#1c2654] hover:bg-[#25326c] text-indigo-100 font-semibold text-xs sm:text-sm rounded-xl border border-indigo-400/30 transition-colors cursor-pointer whitespace-nowrap"
              >
                <Orbit className="w-4 h-4 text-cyan-300" />
                <span>Science</span>
              </button>

              {onOpenBadges && (
                <button
                  onClick={() => {
                    soundEngine.playTelemetryClick();
                    onOpenBadges();
                  }}
                  className="flex items-center gap-2 px-4 py-2.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 font-bold text-xs sm:text-sm rounded-xl border border-amber-400/50 transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Award className="w-4 h-4 text-amber-300" />
                  <span>Badges ({badgeCount}/6)</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Simple 3-Step Roadmap + Space Fact Explorer */}
        <div className="lg:col-span-5 flex flex-col gap-4 justify-between">
          {/* 3 Simple Steps Card */}
          <div className="p-5 rounded-3xl bg-[#161f47]/90 backdrop-blur-md border border-violet-400/35 shadow-xl space-y-2.5">
            <h2 className="font-display text-base font-extrabold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-fuchsia-300" />
              <span>3 Easy Steps</span>
            </h2>

            <div className="space-y-2 text-xs sm:text-sm">
              <div className="flex items-center gap-3 p-2.5 rounded-2xl bg-cyan-500/15 border border-cyan-400/30">
                <span className="w-6 h-6 rounded-lg bg-cyan-400 text-slate-950 font-black flex items-center justify-center shrink-0 text-xs">
                  1
                </span>
                <span className="font-bold text-cyan-100">Pick 4 astronauts</span>
              </div>

              <div className="flex items-center gap-3 p-2.5 rounded-2xl bg-emerald-500/15 border border-emerald-400/30">
                <span className="w-6 h-6 rounded-lg bg-emerald-400 text-slate-950 font-black flex items-center justify-center shrink-0 text-xs">
                  2
                </span>
                <span className="font-bold text-emerald-100">Keep Air, Water, Food & Power up</span>
              </div>

              <div className="flex items-center gap-3 p-2.5 rounded-2xl bg-amber-500/15 border border-amber-400/30">
                <span className="w-6 h-6 rounded-lg bg-amber-400 text-slate-950 font-black flex items-center justify-center shrink-0 text-xs">
                  3
                </span>
                <span className="font-bold text-amber-100">Unlock a badge every 5 days!</span>
              </div>
            </div>

            {upcomingBadgeInfo.badge && (
              <div className="pt-2 border-t border-indigo-400/20 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-amber-200 font-semibold">
                  <Trophy className="w-3.5 h-3.5 text-amber-300" />
                  <span>{upcomingBadgeInfo.badge.title}</span>
                </div>
                <span className="font-mono text-amber-300 font-bold">Day {upcomingBadgeInfo.badge.requiredDay}</span>
              </div>
            )}
          </div>

          {/* Interactive Cool Space Fact Switcher */}
          <div className="p-5 rounded-3xl bg-[#161f47]/90 backdrop-blur-md border border-cyan-400/35 shadow-xl flex flex-col justify-between flex-1">
            <div>
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-cyan-300">
                  <Compass className="w-4 h-4" />
                  <span>NASA Fact #{intelIndex + 1}</span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      soundEngine.playTelemetryClick();
                      setIntelIndex((prev) => (prev - 1 + NASA_DISCOVERIES.length) % NASA_DISCOVERIES.length);
                    }}
                    className="p-1 rounded-lg bg-[#0d1433] hover:bg-indigo-800 text-cyan-200 border border-indigo-400/30 transition-colors cursor-pointer"
                    title="Previous Space Fact"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      soundEngine.playTelemetryClick();
                      setIntelIndex((prev) => (prev + 1) % NASA_DISCOVERIES.length);
                    }}
                    className="p-1 rounded-lg bg-[#0d1433] hover:bg-indigo-800 text-cyan-200 border border-indigo-400/30 transition-colors cursor-pointer"
                    title="Next Space Fact"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <h3 className="font-display font-bold text-sm sm:text-base text-white mb-1">{activeFact.factTitle}</h3>
              <p className="text-xs text-indigo-100/90 leading-relaxed line-clamp-2">
                {activeFact.conciseExplanation}
              </p>
            </div>

            <div className="mt-2.5 pt-2 border-t border-indigo-400/20 flex items-center justify-between">
              <span className="text-[11px] text-indigo-300 truncate">{activeFact.sourceOrg}</span>
              <a
                href={activeFact.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-bold text-cyan-300 hover:text-cyan-200 flex items-center gap-1 shrink-0"
              >
                <span>More</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 4 COLORFUL GAME PILLAR CARDS (COMPACT)                       */}
      {/* ============================================================ */}
      <div className="relative z-10 grid grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
        <div className="p-3.5 rounded-2xl bg-[#131c42]/90 backdrop-blur-md border border-cyan-400/40 shadow-lg flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-cyan-400/20 border border-cyan-400/50 flex items-center justify-center text-cyan-300 shrink-0">
            <Activity className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h3 className="font-display text-xs sm:text-sm font-extrabold text-white truncate">Air & Water</h3>
            <p className="text-[11px] text-cyan-300 font-semibold truncate">98% Recycled</p>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-[#131c42]/90 backdrop-blur-md border border-amber-400/40 shadow-lg flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-400/20 border border-amber-400/50 flex items-center justify-center text-amber-300 shrink-0">
            <BatteryCharging className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h3 className="font-display text-xs sm:text-sm font-extrabold text-white truncate">Solar Power</h3>
            <p className="text-[11px] text-amber-300 font-semibold truncate">Sunlight + Batteries</p>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-[#131c42]/90 backdrop-blur-md border border-violet-400/40 shadow-lg flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-violet-400/20 border border-violet-400/50 flex items-center justify-center text-violet-300 shrink-0">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h3 className="font-display text-xs sm:text-sm font-extrabold text-white truncate">4 Astronauts</h3>
            <p className="text-[11px] text-violet-300 font-semibold truncate">Team Health & Mood</p>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-[#131c42]/90 backdrop-blur-md border border-rose-400/40 shadow-lg flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-rose-400/20 border border-rose-400/50 flex items-center justify-center text-rose-300 shrink-0">
            <Radio className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h3 className="font-display text-xs sm:text-sm font-extrabold text-white truncate">Space Events</h3>
            <p className="text-[11px] text-rose-300 font-semibold truncate">Quick Fixes & Quizzes</p>
          </div>
        </div>
      </div>
    </div>
  );
};
