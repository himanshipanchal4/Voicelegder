/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  MissionState,
  DailySnapshot,
  DailyResourceDeltas,
  DecisionChoice,
  EmergencyOption,
  DifficultyLevel,
  OutpostModuleAction
} from '../types/mission';
import {
  INITIAL_RESOURCES,
  INITIAL_CREW,
  INITIAL_MODULES,
  DAILY_DECISIONS,
  EMERGENCY_INCIDENTS
} from '../data/missionContent';

export const simulationEngine = {
  createInitialMission(difficulty: DifficultyLevel = 'beginner'): MissionState {
    const resources = JSON.parse(JSON.stringify(INITIAL_RESOURCES));

    // Apply difficulty modifiers
    if (difficulty === 'beginner') {
      resources.oxygenKg = 180;
      resources.waterLiters = 230;
      resources.foodPacks = 200;
      resources.powerKwh = 270;
      resources.baseIntegrity = 100;
    } else if (difficulty === 'expert') {
      resources.oxygenKg = 110;
      resources.waterLiters = 140;
      resources.foodPacks = 125;
      resources.powerKwh = 180;
      resources.baseIntegrity = 90;
    }

    const initialState: MissionState = {
      day: 1,
      phase: 'landing',
      difficulty,
      solarAngleDeg: 18.5,
      solarEfficiency: 1.0,
      isLunarNight: false,
      surfaceTempC: 32,
      resources,
      crew: JSON.parse(JSON.stringify(INITIAL_CREW)),
      selectedRocketId: 'nova-mk1',
      modules: JSON.parse(JSON.stringify(INITIAL_MODULES)),
      history: [
        {
          day: 1,
          oxygen: resources.oxygenKg,
          water: resources.waterLiters,
          food: resources.foodPacks,
          power: resources.powerKwh,
          crewHealthAvg: 98,
          crewMoraleAvg: 94,
          baseIntegrity: resources.baseIntegrity,
          solarEfficiency: 1.0,
        },
      ],
      logs: [
        {
          id: 'log-0',
          day: 1,
          timestamp: '00:00 UTC',
          message: `Touchdown on the Moon! Mode: ${difficulty === 'beginner' ? 'CADET (EASY)' : difficulty.toUpperCase()}. All base systems ready.`,
          type: 'info',
        },
      ],
      activeDecision: JSON.parse(JSON.stringify(DAILY_DECISIONS[0])),
      activeEmergency: undefined,
      stats: {
        emergenciesFaced: 0,
        emergenciesResolved: 0,
        decisionsMade: 0,
        scienceDiscoveries: 0,
        peakPowerDeficit: 0,
        totalWaterRecycled: 0,
        totalOxygenRecovered: 0,
        finalScore: 0,
      },
      soundEnabled: true,
      tutorialCompleted: false,
      unlockedDiscoveries: [1],
      unlockedBadges: [],
      viewedBadgeCeremonies: [],
    };

    return initialState;
  },

  calculateSolarConditions(day: number): {
    solarAngleDeg: number;
    solarEfficiency: number;
    isLunarNight: boolean;
    surfaceTempC: number;
  } {
    let solarAngleDeg = 20;
    let solarEfficiency = 1.0;
    let isLunarNight = false;
    let surfaceTempC = 25;

    if (day <= 13) {
      solarAngleDeg = 15 + Math.sin((day / 13) * Math.PI) * 12;
      solarEfficiency = 0.95 + Math.sin((day / 13) * Math.PI) * 0.15;
      isLunarNight = false;
      surfaceTempC = 15 + day * 2;
    } else if (day === 14 || day === 15) {
      solarAngleDeg = 2.1;
      solarEfficiency = 0.28;
      isLunarNight = true;
      surfaceTempC = -135;
    } else if (day >= 16 && day <= 27) {
      solarAngleDeg = 5.5 + Math.sin(((day - 15) / 12) * Math.PI) * 6;
      solarEfficiency = 0.45 + Math.sin(((day - 15) / 12) * Math.PI) * 0.2;
      isLunarNight = false;
      surfaceTempC = -70;
    } else {
      solarAngleDeg = 22 + (day - 28) * 4;
      solarEfficiency = 1.08;
      isLunarNight = false;
      surfaceTempC = 45;
    }

    return {
      solarAngleDeg: Number(solarAngleDeg.toFixed(1)),
      solarEfficiency: Number(solarEfficiency.toFixed(2)),
      isLunarNight,
      surfaceTempC: Math.round(surfaceTempC),
    };
  },

  calculateDailyBaselineDeltas(state: MissionState): DailyResourceDeltas {
    const { resources, modules, difficulty } = state;
    const solar = this.calculateSolarConditions(state.day);

    const eclssMod = modules.find((m) => m.id === 'life-support');
    const greenMod = modules.find((m) => m.id === 'greenhouse');
    const powerMod = modules.find((m) => m.id === 'solar-power');

    const eclssEff = (eclssMod?.efficiency ?? 95) / 100;
    const greenEff = (greenMod?.efficiency ?? 90) / 100;
    const powerEff = (powerMod?.efficiency ?? 100) / 100;

    // Difficulty rate modifiers (Cadet/Beginner mode uses gentler burn rates)
    const diffFactor = difficulty === 'beginner' ? 0.72 : difficulty === 'expert' ? 1.15 : 1.0;

    const rawO2Burn = 3.36 * diffFactor;
    const o2Recovered = (1.6 * eclssEff) + (0.4 * greenEff);
    const netOxygen = -(rawO2Burn - o2Recovered);

    const rawWaterBurn = 10.0 * diffFactor;
    const waterRecovered = rawWaterBurn * resources.eclssWaterRecycleRate * eclssEff;
    const netWater = -(rawWaterBurn - waterRecovered);

    const rawFoodBurn = difficulty === 'beginner' ? 3.2 : 4.0;
    const foodProduced = 0.5 * greenEff;
    const netFood = -(rawFoodBurn - foodProduced);

    const baseLoadKw = modules.reduce((acc, m) => acc + (m.status !== 'offline' ? m.powerDrawKw : 0), 0.5);
    const dailyKwhConsumed = baseLoadKw * 10 * diffFactor;
    const effectiveSolarEfficiency = state.solarEfficiency || solar.solarEfficiency;
    const dailyKwhGenerated = 60 * effectiveSolarEfficiency * powerEff;
    const netPower = dailyKwhGenerated - dailyKwhConsumed;

    const netIntegrity = difficulty === 'beginner' ? -0.1 : difficulty === 'expert' ? -0.6 : -0.4;

    return {
      netOxygen: Number(netOxygen.toFixed(2)),
      netWater: Number(netWater.toFixed(2)),
      netFood: Number(netFood.toFixed(2)),
      netPower: Number(netPower.toFixed(1)),
      netIntegrity,
      crewHealthDelta: 0,
      crewMoraleDelta: 0,
    };
  },

  applyChoiceToState(state: MissionState, choice: DecisionChoice): MissionState {
    const next = JSON.parse(JSON.stringify(state)) as MissionState;
    const deltas = choice.deltas;

    if (deltas.netOxygen) next.resources.oxygenKg += deltas.netOxygen;
    if (deltas.netWater) next.resources.waterLiters += deltas.netWater;
    if (deltas.netFood) next.resources.foodPacks += deltas.netFood;
    if (deltas.netPower) next.resources.powerKwh += deltas.netPower;
    if (deltas.netIntegrity) next.resources.baseIntegrity += deltas.netIntegrity;

    if (deltas.crewHealthDelta) {
      next.crew.forEach((c) => {
        c.health = Math.min(100, Math.max(0, c.health + (deltas.crewHealthDelta ?? 0)));
      });
    }
    if (deltas.crewMoraleDelta) {
      next.crew.forEach((c) => {
        c.morale = Math.min(100, Math.max(0, c.morale + (deltas.crewMoraleDelta ?? 0)));
      });
    }

    next.stats.decisionsMade += 1;
    if (choice.impactDesc.includes('Science Discovery')) {
      next.stats.scienceDiscoveries += 1;
    }

    next.logs.unshift({
      id: `log-dec-${Date.now()}`,
      day: next.day,
      timestamp: '14:00 UTC',
      message: `Directive executed: ${choice.title}. ${choice.impactDesc}`,
      type: 'info',
    });

    next.activeDecision = undefined;
    return this.clampResources(next);
  },

  applyEmergencyResolution(state: MissionState, option: EmergencyOption): MissionState {
    const next = JSON.parse(JSON.stringify(state)) as MissionState;
    
    // In Cadet (beginner) mode, grant a +20% bonus to success
    const bonusRate = next.difficulty === 'beginner' ? 20 : 0;
    const isSuccess = Math.random() * 100 <= Math.min(99, option.successRatePercent + bonusRate);

    const outcomeText = isSuccess ? option.successOutcome : option.failureOutcome;
    const outcomeType = isSuccess ? 'success' : 'warn';

    const cost = option.resourceCost;
    if (cost.netOxygen) next.resources.oxygenKg += cost.netOxygen;
    if (cost.netWater) next.resources.waterLiters += cost.netWater;
    if (cost.netFood) next.resources.foodPacks += cost.netFood;
    if (cost.netPower) next.resources.powerKwh += cost.netPower;
    if (cost.netIntegrity) next.resources.baseIntegrity += cost.netIntegrity;

    if (!isSuccess) {
      const penalty = next.difficulty === 'beginner' ? 2 : next.difficulty === 'expert' ? 12 : 8;
      next.resources.baseIntegrity = Math.max(10, next.resources.baseIntegrity - penalty);
      next.crew.forEach((c) => {
        c.health = Math.max(10, c.health - penalty);
        c.morale = Math.max(10, c.morale - penalty);
      });
    } else {
      next.stats.emergenciesResolved += 1;
    }

    next.logs.unshift({
      id: `log-em-${Date.now()}`,
      day: next.day,
      timestamp: '18:30 UTC',
      message: `Alert handled (${option.label}): ${outcomeText}`,
      type: outcomeType,
    });

    next.activeEmergency = undefined;
    return this.clampResources(next);
  },

  applyModuleAction(state: MissionState, moduleId: string, action: OutpostModuleAction): MissionState {
    const next = JSON.parse(JSON.stringify(state)) as MissionState;
    const mod = next.modules.find((m) => m.id === moduleId);
    if (!mod) return next;

    const targetAct = mod.actions.find((a) => a.id === action.id);
    if (!targetAct) return next;

    // Guard against cooldown abuse
    if (targetAct.lastUsedDay && next.day - targetAct.lastUsedDay < targetAct.cooldownDays) {
      return next;
    }

    // Check power cost
    const requiredPower = targetAct.powerCostKw * 2;
    if (next.resources.powerKwh < requiredPower) {
      next.logs.unshift({
        id: `log-act-lowpwr-${Date.now()}`,
        day: next.day,
        timestamp: '11:00 UTC',
        message: `Not enough battery power for ${targetAct.label} (needs ${requiredPower} kWh).`,
        type: 'warn',
      });
      return next;
    }
    next.resources.powerKwh = Math.max(0, next.resources.powerKwh - requiredPower);

    // Apply action specific yields
    if (targetAct.id === 'hab-airlock-clean') {
      next.resources.baseIntegrity = Math.min(100, next.resources.baseIntegrity + 5);
    } else if (targetAct.id === 'hab-exercise-boost') {
      next.crew.forEach((c) => (c.health = Math.min(100, c.health + 4)));
    } else if (targetAct.id === 'power-clean-arrays') {
      next.solarEfficiency = Math.min(1.25, next.solarEfficiency + 0.08);
    } else if (targetAct.id === 'eclss-flush-filters') {
      next.resources.eclssWaterRecycleRate = Math.min(0.95, next.resources.eclssWaterRecycleRate + 0.05);
    } else if (targetAct.id === 'eclss-boost-o2') {
      next.resources.oxygenKg = Math.min(200, next.resources.oxygenKg + 2.0);
    } else if (targetAct.id === 'greenhouse-nutrient-cycle') {
      next.resources.foodPacks = Math.min(200, next.resources.foodPacks + 1);
      next.crew.forEach((c) => (c.morale = Math.min(100, c.morale + 5)));
    } else if (targetAct.id === 'greenhouse-o2-scrub') {
      next.resources.oxygenKg = Math.min(200, next.resources.oxygenKg + 0.8);
    } else if (targetAct.id === 'lab-analyze-sample') {
      next.stats.scienceDiscoveries += 1;
    } else if (targetAct.id === 'comm-sync-earth') {
      next.crew.forEach((c) => (c.morale = Math.min(100, c.morale + 6)));
    }

    targetAct.lastUsedDay = next.day;
    next.logs.unshift({
      id: `log-act-${Date.now()}`,
      day: next.day,
      timestamp: '11:00 UTC',
      message: `Facility maintenance in ${mod.shortName}: ${targetAct.label}.`,
      type: 'info',
    });

    return this.clampResources(next);
  },

  advanceDay(currentState: MissionState): MissionState {
    const next = JSON.parse(JSON.stringify(currentState)) as MissionState;
    const currentDay = next.day;

    const baseDeltas = this.calculateDailyBaselineDeltas(next);
    next.resources.oxygenKg += baseDeltas.netOxygen;
    next.resources.waterLiters += baseDeltas.netWater;
    next.resources.foodPacks += baseDeltas.netFood;
    next.resources.powerKwh += baseDeltas.netPower;
    next.resources.baseIntegrity += baseDeltas.netIntegrity;

    next.stats.totalWaterRecycled += 8.5;
    next.stats.totalOxygenRecovered += 2.0;

    const avgHealth = next.crew.reduce((acc, c) => acc + c.health, 0) / next.crew.length;
    const avgMorale = next.crew.reduce((acc, c) => acc + c.morale, 0) / next.crew.length;

    const isCadet = next.difficulty === 'beginner';

    if (next.resources.oxygenKg <= 0) {
      next.phase = 'failed';
      next.failureReason = 'We ran out of Oxygen! Try fixing air systems or picking Oxygen-saving choices next time.';
      next.stats.finalScore = this.calculateFailedScore(next);
      return this.clampResources(next);
    }
    if (next.resources.baseIntegrity <= 0) {
      next.phase = 'failed';
      next.failureReason = 'Base Shield Integrity hit 0%! Airlock wear and space debris breached the outpost.';
      next.stats.finalScore = this.calculateFailedScore(next);
      return this.clampResources(next);
    }
    if (next.resources.waterLiters <= 0) {
      const waterHealthHit = isCadet ? 8 : 25;
      next.crew.forEach((c) => (c.health = Math.max(0, c.health - waterHealthHit)));
      next.logs.unshift({
        id: `log-h2o-warn-${Date.now()}`,
        day: currentDay,
        timestamp: 'CRIT',
        message: 'Water tank is empty! Crew needs water soon.',
        type: 'crit',
      });
    }
    if (next.resources.foodPacks <= 0) {
      const foodHealthHit = isCadet ? 4 : 10;
      const foodMoraleHit = isCadet ? 8 : 20;
      next.crew.forEach((c) => {
        c.health = Math.max(0, c.health - foodHealthHit);
        c.morale = Math.max(0, c.morale - foodMoraleHit);
      });
      next.logs.unshift({
        id: `log-food-warn-${Date.now()}`,
        day: currentDay,
        timestamp: 'WARN',
        message: 'Food supplies are empty! Harvest Greenhouse food or save rations.',
        type: 'warn',
      });
    }
    if (next.resources.powerKwh <= 0) {
      next.stats.peakPowerDeficit += 1;
      const integrityHit = isCadet ? 2 : 5;
      const powerHealthHit = isCadet ? 3 : 8;
      next.resources.baseIntegrity = Math.max(0, next.resources.baseIntegrity - integrityHit);
      next.crew.forEach((c) => (c.health = Math.max(0, c.health - powerHealthHit)));
      next.logs.unshift({
        id: `log-pwr-warn-${Date.now()}`,
        day: currentDay,
        timestamp: 'CRIT',
        message: 'Power ran out! Base heaters are off until solar power recharges.',
        type: 'crit',
      });
    }

    const livingCrew = next.crew.filter((c) => c.health > 0);
    if (livingCrew.length === 0) {
      next.phase = 'failed';
      next.failureReason = 'All 4 expedition crew members incapacitated. Base evacuation initiated.';
      next.stats.finalScore = this.calculateFailedScore(next);
      return this.clampResources(next);
    }

    next.day = currentDay + 1;

    // Award badge milestone after successfully completing Day 5, 10, 15, 20, 25, 30
    if (!next.unlockedBadges) next.unlockedBadges = [];
    const badgeMilestones: Record<number, string> = {
      5: 'badge-level-1',
      10: 'badge-level-2',
      15: 'badge-level-3',
      20: 'badge-level-4',
      25: 'badge-level-5',
      30: 'badge-level-6',
    };
    const earnedBadgeId = badgeMilestones[currentDay];
    if (earnedBadgeId && !next.unlockedBadges.includes(earnedBadgeId)) {
      next.unlockedBadges.push(earnedBadgeId);
      next.logs.unshift({
        id: `log-badge-${Date.now()}`,
        day: currentDay,
        timestamp: '12:00 UTC',
        message: `ASTRA Training Insignia Awarded: Level ${currentDay / 5} unlocked for completing Day ${currentDay}!`,
        type: 'success',
      });
    }

    const solar = this.calculateSolarConditions(next.day);
    next.solarAngleDeg = solar.solarAngleDeg;
    next.solarEfficiency = solar.solarEfficiency;
    next.isLunarNight = solar.isLunarNight;
    next.surfaceTempC = solar.surfaceTempC;

    if (next.day > 30) {
      next.phase = 'victory';
      next.day = 30;
      next.stats.finalScore = this.calculateFinalScore(next);
      next.logs.unshift({
        id: `log-vic-${Date.now()}`,
        day: 30,
        timestamp: '23:59 UTC',
        message: 'MISSION ACCOMPLISHED: All 30 lunar days successfully completed. Crew is safe!',
        type: 'success',
      });
      return this.clampResources(next);
    }

    const nextDecision = DAILY_DECISIONS[next.day - 1];
    next.activeDecision = nextDecision;

    // Scheduled emergencies
    if (next.day === 7) {
      next.activeEmergency = EMERGENCY_INCIDENTS[0];
      next.stats.emergenciesFaced += 1;
    } else if (next.day === 13) {
      next.activeEmergency = EMERGENCY_INCIDENTS[1];
      next.stats.emergenciesFaced += 1;
    } else if (next.day === 17) {
      next.activeEmergency = EMERGENCY_INCIDENTS[2];
      next.stats.emergenciesFaced += 1;
    } else if (next.day === 24) {
      next.activeEmergency = EMERGENCY_INCIDENTS[3];
      next.stats.emergenciesFaced += 1;
    }

    next.history.push({
      day: next.day,
      oxygen: Number(next.resources.oxygenKg.toFixed(1)),
      water: Number(next.resources.waterLiters.toFixed(1)),
      food: Number(next.resources.foodPacks.toFixed(1)),
      power: Number(next.resources.powerKwh.toFixed(1)),
      crewHealthAvg: Math.round(avgHealth),
      crewMoraleAvg: Math.round(avgMorale),
      baseIntegrity: Math.round(next.resources.baseIntegrity),
      solarEfficiency: next.solarEfficiency,
    });

    if (!next.unlockedDiscoveries) next.unlockedDiscoveries = [1];

    next.logs.unshift({
      id: `log-day-${next.day}-${Date.now()}`,
      day: next.day,
      timestamp: '06:00 UTC',
      message: `Day ${next.day} commenced. Sun elevation: ${solar.solarAngleDeg}°. Surface temp: ${solar.surfaceTempC}°C.`,
      type: 'info',
    });

    return this.clampResources(next);
  },

  clampResources(state: MissionState): MissionState {
    state.resources.oxygenKg = Math.max(0, Math.min(200, state.resources.oxygenKg));
    state.resources.waterLiters = Math.max(0, Math.min(250, state.resources.waterLiters));
    state.resources.foodPacks = Math.max(0, Math.min(200, state.resources.foodPacks));
    state.resources.powerKwh = Math.max(0, Math.min(state.resources.maxPowerKwh, state.resources.powerKwh));
    state.resources.baseIntegrity = Math.max(0, Math.min(100, state.resources.baseIntegrity));

    state.crew.forEach((c) => {
      c.health = Math.max(0, Math.min(100, Math.round(c.health)));
      c.morale = Math.max(0, Math.min(100, Math.round(c.morale)));
      c.fatigue = Math.max(0, Math.min(100, Math.round(c.fatigue)));
      if (c.health === 0) c.status = 'critical';
      else if (c.health < 40) c.status = 'injured';
      else if (c.fatigue > 60) c.status = 'fatigued';
      else c.status = 'nominal';
    });

    return state;
  },

  calculateFinalScore(state: MissionState): number {
    const r = state.resources;
    const avgHealth = state.crew.reduce((acc, c) => acc + c.health, 0) / state.crew.length;
    const avgMorale = state.crew.reduce((acc, c) => acc + c.morale, 0) / state.crew.length;

    let score = 5000;
    score += avgHealth * 20;
    score += avgMorale * 15;
    score += r.baseIntegrity * 10;
    score += r.oxygenKg * 10;
    score += r.waterLiters * 8;
    score += r.foodPacks * 6;
    score += r.powerKwh * 5;
    score += state.stats.emergenciesResolved * 250;
    score += Math.max(state.stats.scienceDiscoveries, state.unlockedDiscoveries?.length || 1) * 300;
    score += Math.max(0, (state.unlockedDiscoveries?.length || 1) - 1) * 50;
    score -= state.stats.peakPowerDeficit * 150;

    // Difficulty score multiplier
    const diffMult = state.difficulty === 'beginner' ? 0.8 : state.difficulty === 'expert' ? 1.4 : 1.0;
    return Math.max(0, Math.round(score * diffMult));
  },

  calculateFailedScore(state: MissionState): number {
    const daysSurvived = Math.max(0, state.day - 1);
    const quizCount = Math.max(0, (state.unlockedDiscoveries?.length || 1) - 1);
    const rawScore =
      daysSurvived * 180 +
      state.stats.decisionsMade * 40 +
      state.stats.emergenciesResolved * 200 +
      quizCount * 50;
    const diffMult = state.difficulty === 'beginner' ? 0.8 : state.difficulty === 'expert' ? 1.4 : 1.0;
    return Math.max(0, Math.round(rawScore * diffMult));
  },
};
