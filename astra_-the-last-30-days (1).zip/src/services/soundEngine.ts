/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private musicMasterGain: GainNode | null = null;
  private isAmbientPlaying: boolean = false;
  private musicIntervalId: number | null = null;
  private stepIndex: number = 0;

  constructor() {
    // AudioContext initializes on first user interaction per browser autoplay policy
  }

  private initContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
    if (!muted) {
      const ctx = this.initContext();
      if (ctx && !this.isAmbientPlaying) {
        this.startAmbientDrone();
      }
    }
    if (this.musicMasterGain && this.ctx) {
      this.musicMasterGain.gain.setTargetAtTime(
        this.isMuted ? 0 : 0.16,
        this.ctx.currentTime,
        0.08
      );
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public toggleMute(): boolean {
    this.setMuted(!this.isMuted);
    return this.isMuted;
  }

  public playTelemetryClick(): void {
    if (this.isMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(920, now);
      osc.frequency.exponentialRampToValueAtTime(1380, now + 0.045);

      gain.gain.setValueAtTime(0.055, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.055);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.06);
    } catch {
      // Non-fatal
    }
  }

  public playConfirm(): void {
    if (this.isMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      // Playful cheerful 2-note chime (C5 -> G5)
      [523.25, 783.99].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const t = now + idx * 0.065;

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, t);

        gain.gain.setValueAtTime(0.075, t);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 0.17);
      });
    } catch {
      // Non-fatal
    }
  }

  public playWarning(): void {
    if (this.isMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(480, now);
      osc.frequency.setValueAtTime(340, now + 0.09);

      gain.gain.setValueAtTime(0.075, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.25);
    } catch {
      // Non-fatal
    }
  }

  public playDayAdvance(): void {
    if (this.isMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const notes = [523.25, 659.25, 783.99, 1046.5]; // Bright C major rocket launch arpeggio
      const now = ctx.currentTime;

      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const startTime = now + idx * 0.065;

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, startTime);

        gain.gain.setValueAtTime(0.065, startTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.34);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + 0.36);
      });
    } catch {
      // Non-fatal
    }
  }

  public playPromoLiftoff(): void {
    if (this.isMuted) return;
    const ctx = this.initContext();
    if (!ctx || ctx.state !== 'running') return;

    try {
      const now = ctx.currentTime;
      // Warm ascending rocket thruster whoosh
      const rumbleOsc = ctx.createOscillator();
      const rumbleGain = ctx.createGain();
      rumbleOsc.type = 'sawtooth';
      rumbleOsc.frequency.setValueAtTime(62, now);
      rumbleOsc.frequency.exponentialRampToValueAtTime(165, now + 1.4);

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(220, now);
      filter.frequency.exponentialRampToValueAtTime(900, now + 1.2);

      rumbleGain.gain.setValueAtTime(0.001, now);
      rumbleGain.gain.linearRampToValueAtTime(0.09, now + 0.25);
      rumbleGain.gain.exponentialRampToValueAtTime(0.0001, now + 1.8);

      rumbleOsc.connect(filter);
      filter.connect(rumbleGain);
      rumbleGain.connect(ctx.destination);
      rumbleOsc.start(now);
      rumbleOsc.stop(now + 1.85);

      // Exciting cosmic launch chime (C5 -> E5 -> G5 -> C6)
      [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const t = now + 0.1 + idx * 0.08;
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, t);
        gain.gain.setValueAtTime(0.06, t);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.45);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 0.48);
      });
    } catch {
      // Non-fatal
    }
  }

  public playDiscoveryReveal(): void {
    if (this.isMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      // Sparkly arcade achievement fanfare (C5 -> E5 -> G5 -> A5 -> C6)
      const notes = [523.25, 659.25, 783.99, 880.0, 1046.5];
      const now = ctx.currentTime;

      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const startTime = now + idx * 0.09;

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, startTime);

        const duration = idx === notes.length - 1 ? 0.7 : 0.22;
        gain.gain.setValueAtTime(0.085, startTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + duration + 0.02);
      });
    } catch {
      // Non-fatal
    }
  }

  /**
   * Starts a playful, upbeat, teen-friendly Cosmic Adventure Synth Loop!
   * Features an 8-bar (64 eighth-note steps @ ~128 BPM) cheerful melody,
   * bouncy octave bassline, warm shimmer chords, and crisp soft electronic beat.
   */
  public startAmbientDrone(): void {
    if (this.isAmbientPlaying) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const master = ctx.createGain();
      master.gain.setValueAtTime(this.isMuted ? 0 : 0.16, ctx.currentTime);

      const masterFilter = ctx.createBiquadFilter();
      masterFilter.type = 'lowpass';
      masterFilter.frequency.setValueAtTime(3400, ctx.currentTime);
      masterFilter.Q.setValueAtTime(0.6, ctx.currentTime);

      master.connect(masterFilter);
      masterFilter.connect(ctx.destination);

      this.musicMasterGain = master;
      this.isAmbientPlaying = true;
      this.stepIndex = 0;

      // 8-bar playful cosmic adventure progression (8 steps per bar = 64 steps total)
      // Section A: C -> G -> Am -> F (bright, hopeful, catchy)
      // Section B: Dm7 -> Em7 -> Fmaj7 -> G7sus4 (uplifting adventure turnaround)
      // 0 = rest in melody so it breathes musically and sounds groovy
      const bars = [
        // Bar 1: C major
        {
          bass: 130.81, // C3
          pad: [261.63, 329.63, 392.0],
          melody: [523.25, 0, 659.25, 783.99, 0, 659.25, 880.0, 783.99],
        },
        // Bar 2: G major
        {
          bass: 98.0, // G2
          pad: [246.94, 293.66, 392.0],
          melody: [783.99, 0, 659.25, 587.33, 0, 587.33, 659.25, 783.99],
        },
        // Bar 3: A minor 7
        {
          bass: 110.0, // A2
          pad: [261.63, 329.63, 440.0],
          melody: [880.0, 0, 783.99, 659.25, 0, 523.25, 659.25, 783.99],
        },
        // Bar 4: F major 7
        {
          bass: 87.31, // F2
          pad: [261.63, 349.23, 440.0],
          melody: [698.46, 0, 659.25, 523.25, 587.33, 659.25, 523.25, 0],
        },
        // Bar 5: D minor 7
        {
          bass: 146.83, // D3
          pad: [261.63, 349.23, 440.0],
          melody: [587.33, 659.25, 698.46, 0, 880.0, 0, 783.99, 698.46],
        },
        // Bar 6: E minor 7
        {
          bass: 164.81, // E3
          pad: [246.94, 329.63, 392.0],
          melody: [659.25, 783.99, 987.77, 0, 783.99, 0, 659.25, 587.33],
        },
        // Bar 7: F major 9
        {
          bass: 87.31, // F2
          pad: [261.63, 349.23, 440.0],
          melody: [523.25, 587.33, 659.25, 783.99, 880.0, 783.99, 659.25, 587.33],
        },
        // Bar 8: G6 turnaround
        {
          bass: 98.0, // G2
          pad: [293.66, 392.0, 493.88],
          melody: [783.99, 0, 880.0, 987.77, 1046.5, 0, 987.77, 783.99],
        },
      ];

      const stepMs = 232; // ~129 BPM upbeat playful eighth-note pulse

      const playMusicStep = () => {
        if (!this.ctx || !this.musicMasterGain || !this.isAmbientPlaying) return;
        if (
          this.isMuted ||
          this.ctx.state !== 'running' ||
          (typeof document !== 'undefined' && document.hidden)
        ) {
          this.stepIndex = (this.stepIndex + 1) % 64;
          return;
        }

        const now = this.ctx.currentTime;
        const barIdx = Math.floor(this.stepIndex / 8);
        const stepInBar = this.stepIndex % 8;
        const bar = bars[barIdx];

        // 1. Warm bouncy chord shimmer on beat 1 (step 0) and light staccato stab on beat 3 (step 4)
        if (stepInBar === 0 || stepInBar === 4) {
          const isDownbeat = stepInBar === 0;
          bar.pad.forEach((freq) => {
            if (!this.ctx || !this.musicMasterGain) return;
            const osc = this.ctx.createOscillator();
            const g = this.ctx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq, now);

            const peak = isDownbeat ? 0.052 : 0.032;
            const dur = isDownbeat ? 0.85 : 0.36;
            g.gain.setValueAtTime(0.0001, now);
            g.gain.linearRampToValueAtTime(peak, now + 0.04);
            g.gain.exponentialRampToValueAtTime(0.001, now + dur);

            osc.connect(g);
            g.connect(this.musicMasterGain);
            osc.start(now);
            osc.stop(now + dur + 0.03);
          });
        }

        // 2. Bouncy octave-jumping synth bassline (disco/arcade space groove!)
        // Plays root on 0, 2, 4, 6 and octave-up bounce on 3 & 7
        if (stepInBar === 0 || stepInBar === 2 || stepInBar === 3 || stepInBar === 4 || stepInBar === 6 || stepInBar === 7) {
          const isOctaveBounce = stepInBar === 3 || stepInBar === 7;
          const bassOsc = this.ctx.createOscillator();
          const bassFilter = this.ctx.createBiquadFilter();
          const bassGain = this.ctx.createGain();

          bassOsc.type = 'sawtooth';
          bassOsc.frequency.setValueAtTime(isOctaveBounce ? bar.bass * 2 : bar.bass, now);

          bassFilter.type = 'lowpass';
          bassFilter.frequency.setValueAtTime(isOctaveBounce ? 680 : 480, now);
          bassFilter.frequency.exponentialRampToValueAtTime(220, now + 0.16);

          bassGain.gain.setValueAtTime(0.001, now);
          bassGain.gain.linearRampToValueAtTime(isOctaveBounce ? 0.075 : 0.11, now + 0.015);
          bassGain.gain.exponentialRampToValueAtTime(0.001, now + 0.19);

          bassOsc.connect(bassFilter);
          bassFilter.connect(bassGain);
          bassGain.connect(this.musicMasterGain);
          bassOsc.start(now);
          bassOsc.stop(now + 0.21);
        }

        // 3. Playful bouncy cosmic lead melody (warm triangle + soft octave sparkle)
        const melodyFreq = bar.melody[stepInBar];
        if (melodyFreq > 0) {
          const leadOsc = this.ctx.createOscillator();
          const sparkleOsc = this.ctx.createOscillator();
          const leadFilter = this.ctx.createBiquadFilter();
          const leadGain = this.ctx.createGain();

          leadOsc.type = 'triangle';
          leadOsc.frequency.setValueAtTime(melodyFreq, now);

          // Soft playful 2nd harmonic square layer for arcade charm
          sparkleOsc.type = 'square';
          sparkleOsc.frequency.setValueAtTime(melodyFreq, now);

          leadFilter.type = 'lowpass';
          leadFilter.frequency.setValueAtTime(2400, now);
          leadFilter.frequency.exponentialRampToValueAtTime(900, now + 0.18);

          const isAccent = stepInBar === 0 || stepInBar === 4 || stepInBar === 6;
          const leadPeak = isAccent ? 0.088 : 0.064;
          leadGain.gain.setValueAtTime(0.0001, now);
          leadGain.gain.linearRampToValueAtTime(leadPeak, now + 0.012);
          leadGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.2);

          const sparkleGain = this.ctx.createGain();
          sparkleGain.gain.setValueAtTime(0.18, now); // subtle square mix

          leadOsc.connect(leadFilter);
          sparkleOsc.connect(sparkleGain);
          sparkleGain.connect(leadFilter);
          leadFilter.connect(leadGain);
          leadGain.connect(this.musicMasterGain);

          leadOsc.start(now);
          sparkleOsc.start(now);
          leadOsc.stop(now + 0.22);
          sparkleOsc.stop(now + 0.22);
        }

        // 4. Soft punchy electronic kick on beats 1 & 3 (steps 0 and 4)
        if (stepInBar === 0 || stepInBar === 4) {
          const kickOsc = this.ctx.createOscillator();
          const kickGain = this.ctx.createGain();
          kickOsc.type = 'sine';
          kickOsc.frequency.setValueAtTime(135, now);
          kickOsc.frequency.exponentialRampToValueAtTime(48, now + 0.08);

          kickGain.gain.setValueAtTime(0.15, now);
          kickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);

          kickOsc.connect(kickGain);
          kickGain.connect(this.musicMasterGain);
          kickOsc.start(now);
          kickOsc.stop(now + 0.12);
        }

        // 5. Crisp soft snare-pop on beat 2 & 4 (steps 2 and 6) + light offbeat hi-hat
        if (stepInBar === 2 || stepInBar === 6) {
          const popOsc = this.ctx.createOscillator();
          const popGain = this.ctx.createGain();
          popOsc.type = 'triangle';
          popOsc.frequency.setValueAtTime(340, now);
          popOsc.frequency.exponentialRampToValueAtTime(140, now + 0.05);

          popGain.gain.setValueAtTime(0.04, now);
          popGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.06);

          popOsc.connect(popGain);
          popGain.connect(this.musicMasterGain);
          popOsc.start(now);
          popOsc.stop(now + 0.07);
        } else if (stepInBar % 2 === 1) {
          // Gentle hi-hat tick on off-beats
          const hatOsc = this.ctx.createOscillator();
          const hatGain = this.ctx.createGain();
          hatOsc.type = 'square';
          hatOsc.frequency.setValueAtTime(2200, now);
          hatOsc.frequency.exponentialRampToValueAtTime(950, now + 0.02);

          hatGain.gain.setValueAtTime(0.015, now);
          hatGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.025);

          hatOsc.connect(hatGain);
          hatGain.connect(this.musicMasterGain);
          hatOsc.start(now);
          hatOsc.stop(now + 0.03);
        }

        this.stepIndex = (this.stepIndex + 1) % 64;
      };

      playMusicStep();
      this.musicIntervalId = window.setInterval(playMusicStep, stepMs);
    } catch {
      // Non-fatal
    }
  }

  public stopAmbientDrone(): void {
    this.isAmbientPlaying = false;
    if (this.musicIntervalId !== null) {
      window.clearInterval(this.musicIntervalId);
      this.musicIntervalId = null;
    }
  }
}

export const soundEngine = new SoundEngine();
