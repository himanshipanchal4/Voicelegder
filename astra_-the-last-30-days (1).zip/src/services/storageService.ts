/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MissionState } from '../types/mission';

const STORAGE_KEY = 'astra_lunar_mission_save_v1';
const PREFERENCES_KEY = 'astra_user_preferences_v1';

export interface UserPreferences {
  soundEnabled: boolean;
}

let inMemoryMissionSave: string | null = null;
let inMemoryPreferences: string | null = null;

export const storageService = {
  saveMission(state: MissionState): boolean {
    try {
      const serialized = JSON.stringify(state);
      inMemoryMissionSave = serialized;
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(STORAGE_KEY, serialized);
      }
      return true;
    } catch (e) {
      console.warn('ASTRA: Unable to save mission to localStorage:', e);
      return inMemoryMissionSave !== null;
    }
  },

  loadMission(): MissionState | null {
    try {
      let data: string | null = null;
      if (typeof window !== 'undefined' && window.localStorage) {
        data = window.localStorage.getItem(STORAGE_KEY);
      }
      if (!data) {
        data = inMemoryMissionSave;
      }
      if (!data) return null;
      const parsed = JSON.parse(data) as MissionState;
      // Basic sanity validation
      if (
        parsed &&
        typeof parsed.day === 'number' &&
        parsed.resources &&
        typeof parsed.resources.oxygenKg === 'number' &&
        Array.isArray(parsed.crew)
      ) {
        parsed.crew = parsed.crew.map((member) => {
          if (member.name === 'Himanshi Panchal') {
            return { ...member, name: 'Dr. Himanshi Panchal' };
          }
          if (member.name === 'Prisha Mishra') {
            return { ...member, name: 'Dr. Prisha Mishra' };
          }
          return member;
        });
        return parsed;
      }
      return null;
    } catch (e) {
      console.warn('ASTRA: Failed to parse mission save:', e);
      return null;
    }
  },

  clearMission(): void {
    try {
      inMemoryMissionSave = null;
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.removeItem(STORAGE_KEY);
      }
    } catch (e) {
      console.warn('ASTRA: Failed to clear mission save:', e);
    }
  },

  hasSave(): boolean {
    try {
      let data: string | null = null;
      if (typeof window !== 'undefined' && window.localStorage) {
        data = window.localStorage.getItem(STORAGE_KEY);
      }
      if (!data) {
        data = inMemoryMissionSave;
      }
      if (!data) return false;
      const parsed = JSON.parse(data) as MissionState;
      return !!(parsed && typeof parsed.day === 'number' && parsed.resources);
    } catch {
      return false;
    }
  },

  exportMissionBackup(state: MissionState): boolean {
    try {
      if (typeof window === 'undefined') return false;
      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(state, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', dataStr);
      downloadAnchor.setAttribute('download', `astra-mission-day-${state.day}-backup.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      return true;
    } catch (e) {
      console.warn('ASTRA: Failed to export mission backup:', e);
      return false;
    }
  },

  savePreferences(prefs: UserPreferences): void {
    try {
      const serialized = JSON.stringify(prefs);
      inMemoryPreferences = serialized;
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(PREFERENCES_KEY, serialized);
      }
    } catch (e) {
      console.warn('ASTRA: Failed to save preferences:', e);
    }
  },

  loadPreferences(): UserPreferences {
    try {
      let data: string | null = null;
      if (typeof window !== 'undefined' && window.localStorage) {
        data = window.localStorage.getItem(PREFERENCES_KEY);
      }
      if (!data) {
        data = inMemoryPreferences;
      }
      if (!data) return { soundEnabled: true };
      return JSON.parse(data) as UserPreferences;
    } catch {
      return { soundEnabled: true };
    }
  },
};
