/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { RocketId } from '../types/mission';
import { getRocketSpec, RocketSpec } from '../data/rocketCatalog';

type TrackFn = <T extends { dispose: () => void }>(res: T) => T;

export function createRocketHullCanvasTexture(spec: RocketSpec, maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const baseColor = '#' + new THREE.Color(spec.hullColorHex).getHexString();
    const accentColor = '#' + new THREE.Color(spec.accentColorHex).getHexString();
    const noseColor = '#' + new THREE.Color(spec.noseColorHex).getHexString();
    const isDarkHull = new THREE.Color(spec.hullColorHex).getHSL({ h: 0, s: 0, l: 0 }).l < 0.45;

    ctx.fillStyle = baseColor;
    ctx.fillRect(0, 0, 512, 512);

    // Subtle panel shading gradient
    const shade = ctx.createLinearGradient(0, 0, 512, 0);
    shade.addColorStop(0, 'rgba(0,0,0,0.18)');
    shade.addColorStop(0.5, 'rgba(255,255,255,0.14)');
    shade.addColorStop(1, 'rgba(0,0,0,0.2)');
    ctx.fillStyle = shade;
    ctx.fillRect(0, 0, 512, 512);

    // Horizontal panel seams
    ctx.strokeStyle = isDarkHull ? 'rgba(255,255,255,0.14)' : 'rgba(15,23,42,0.18)';
    ctx.lineWidth = 2;
    for (let y = 72; y < 512; y += 92) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(512, y);
      ctx.stroke();
    }

    // Racing & accent stripes
    ctx.fillStyle = noseColor;
    ctx.fillRect(0, 66, 512, 24);
    ctx.fillStyle = accentColor;
    ctx.fillRect(0, 96, 512, 12);

    ctx.fillStyle = isDarkHull ? '#1e293b' : '#0f172a';
    ctx.fillRect(0, 412, 512, 22);
    ctx.fillStyle = accentColor;
    ctx.fillRect(0, 438, 512, 10);

    // Bold ASTRA wordmark on both sides
    const drawWordmark = (cx: number) => {
      ctx.save();
      ctx.translate(cx, 268);
      ctx.fillStyle = isDarkHull ? '#ffffff' : '#0f172a';
      ctx.font = '900 44px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('ASTRA', 0, 0);
      ctx.fillStyle = isDarkHull ? accentColor : noseColor;
      ctx.font = '800 18px monospace';
      ctx.fillText(spec.nickname.toUpperCase(), 0, 26);
      ctx.restore();
    };
    drawWordmark(128);
    drawWordmark(384);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export interface RealisticMoonTextures {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
  roughnessMap: THREE.CanvasTexture;
}

// Deterministic PRNG for consistent crater/regolith placement
function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Convert lunar (latDeg, lonDeg) to equirectangular canvas pixels aligned with SphereGeometry + latLonToLocalVector
function moonLatLonToPx(latDeg: number, lonDeg: number, w: number, h: number): [number, number] {
  let u = 0.25 + lonDeg / 360;
  u = ((u % 1) + 1) % 1;
  const v = (90 - latDeg) / 180;
  return [u * w, v * h];
}

export function createRealisticMoonTextures(maxAnisotropy: number): RealisticMoonTextures {
  const W = 2048;
  const H = 1024;
  const rand = mulberry32(19690720);

  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = W;
  colorCanvas.height = H;
  const cCtx = colorCanvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = W;
  bumpCanvas.height = H;
  const bCtx = bumpCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = W;
  roughCanvas.height = H;
  const rCtx = roughCanvas.getContext('2d')!;

  // 1. Base highland anorthosite regolith (neutral warm-silver grey, slightly brighter near poles)
  const baseGrad = cCtx.createLinearGradient(0, 0, 0, H);
  baseGrad.addColorStop(0, '#c8c6c0');
  baseGrad.addColorStop(0.25, '#a8a69f');
  baseGrad.addColorStop(0.5, '#9d9b95');
  baseGrad.addColorStop(0.75, '#a7a49d');
  baseGrad.addColorStop(1, '#c4c2bc');
  cCtx.fillStyle = baseGrad;
  cCtx.fillRect(0, 0, W, H);

  // Neutral mid-high elevation base for bump; high roughness for dusty highlands
  bCtx.fillStyle = '#8e8e8e';
  bCtx.fillRect(0, 0, W, H);
  rCtx.fillStyle = '#ececec';
  rCtx.fillRect(0, 0, W, H);

  // Helper to paint wrapped across seam x=0 / x=W
  const drawWrapped = (ctx: CanvasRenderingContext2D, cx: number, cy: number, radiusX: number, fn: (ox: number) => void) => {
    fn(cx);
    if (cx - radiusX < 0) fn(cx + W);
    if (cx + radiusX > W) fn(cx - W);
  };

  // 2. Patchy mottled highland terrain albedo variation
  for (let i = 0; i < 420; i++) {
    const cx = rand() * W;
    const cy = rand() * H;
    const rx = 25 + rand() * 90;
    const ry = rx * (0.4 + rand() * 0.5);
    const bright = rand() > 0.45;
    drawWrapped(cCtx, cx, cy, rx, (ox) => {
      const g = cCtx.createRadialGradient(ox, cy, 2, ox, cy, rx);
      g.addColorStop(0, bright ? 'rgba(218, 215, 208, 0.16)' : 'rgba(92, 90, 86, 0.18)');
      g.addColorStop(1, 'rgba(0,0,0,0)');
      cCtx.fillStyle = g;
      cCtx.beginPath();
      cCtx.ellipse(ox, cy, rx, ry, rand() * Math.PI, 0, Math.PI * 2);
      cCtx.fill();

      const bg = bCtx.createRadialGradient(ox, cy, 2, ox, cy, rx);
      bg.addColorStop(0, bright ? 'rgba(225,225,225,0.14)' : 'rgba(65,65,65,0.16)');
      bg.addColorStop(1, 'rgba(0,0,0,0)');
      bCtx.fillStyle = bg;
      bCtx.beginPath();
      bCtx.ellipse(ox, cy, rx, ry, 0, 0, Math.PI * 2);
      bCtx.fill();
    });
  }

  // 3. Authentic Lunar Maria (Dark Basalt Volcanic Seas aligned at real coordinates)
  const lunarMaria = [
    { lat: 33, lon: -16, rx: 195, ry: 135, tint: 'rgba(54, 56, 62, 0.85)' },   // Mare Imbrium
    { lat: 18, lon: -57, rx: 225, ry: 170, tint: 'rgba(58, 61, 68, 0.78)' },   // Oceanus Procellarum
    { lat: 28, lon: 18, rx: 115, ry: 95, tint: 'rgba(52, 54, 60, 0.84)' },     // Mare Serenitatis
    { lat: 8, lon: 31, rx: 120, ry: 92, tint: 'rgba(48, 52, 59, 0.88)' },      // Mare Tranquillitatis
    { lat: -7, lon: 51, rx: 95, ry: 85, tint: 'rgba(56, 58, 62, 0.82)' },      // Mare Fecunditatis
    { lat: 17, lon: 59, rx: 72, ry: 55, tint: 'rgba(46, 48, 53, 0.90)' },      // Mare Crisium
    { lat: -15, lon: 35, rx: 78, ry: 68, tint: 'rgba(54, 56, 60, 0.82)' },     // Mare Nectaris
    { lat: -24, lon: -39, rx: 82, ry: 68, tint: 'rgba(52, 54, 58, 0.82)' },    // Mare Humorum
    { lat: -19, lon: -93, rx: 105, ry: 90, tint: 'rgba(49, 50, 54, 0.84)' },   // Mare Orientale
    { lat: 27, lon: 147, rx: 85, ry: 72, tint: 'rgba(50, 51, 56, 0.85)' },     // Mare Moscoviense (far side)
    { lat: -52, lon: -160, rx: 210, ry: 140, tint: 'rgba(62, 62, 66, 0.72)' }, // South Pole-Aitken Basin
  ];

  lunarMaria.forEach((m) => {
    const [mx, my] = moonLatLonToPx(m.lat, m.lon, W, H);
    const blobs = 5;
    for (let k = 0; k < blobs; k++) {
      const bx = mx + (k === 0 ? 0 : (rand() - 0.5) * m.rx * 0.75);
      const by = my + (k === 0 ? 0 : (rand() - 0.5) * m.ry * 0.75);
      const brx = m.rx * (k === 0 ? 1 : 0.45 + rand() * 0.4);
      const bry = m.ry * (k === 0 ? 1 : 0.45 + rand() * 0.4);
      drawWrapped(cCtx, bx, by, brx, (ox) => {
        // Basalt fill
        const cg = cCtx.createRadialGradient(ox, by, brx * 0.12, ox, by, brx);
        cg.addColorStop(0, m.tint);
        cg.addColorStop(0.65, m.tint.replace(/[\d.]+\)$/, '0.52)'));
        cg.addColorStop(1, 'rgba(50, 52, 56, 0)');
        cCtx.fillStyle = cg;
        cCtx.beginPath();
        cCtx.ellipse(ox, by, brx, bry, rand() * 0.6, 0, Math.PI * 2);
        cCtx.fill();

        // Lower basin depth in bumpMap
        const bg = bCtx.createRadialGradient(ox, by, brx * 0.15, ox, by, brx);
        bg.addColorStop(0, 'rgba(38, 38, 38, 0.7)');
        bg.addColorStop(0.8, 'rgba(64, 64, 64, 0.35)');
        bg.addColorStop(1, 'rgba(0,0,0,0)');
        bCtx.fillStyle = bg;
        bCtx.beginPath();
        bCtx.ellipse(ox, by, brx, bry, 0, 0, Math.PI * 2);
        bCtx.fill();

        // Slightly smoother basalt in roughnessMap
        const rg = rCtx.createRadialGradient(ox, by, brx * 0.15, ox, by, brx);
        rg.addColorStop(0, 'rgba(175, 175, 175, 0.55)');
        rg.addColorStop(1, 'rgba(0,0,0,0)');
        rCtx.fillStyle = rg;
        rCtx.beginPath();
        rCtx.ellipse(ox, by, brx, bry, 0, 0, Math.PI * 2);
        rCtx.fill();
      });
    }
  });

  // 4. Helper for realistic multi-ring craters (ejecta halo, raised rim, shaded bowl, central peak)
  const paintCrater = (
    cx: number,
    cy: number,
    r: number,
    options?: { darkFloor?: boolean; rays?: number; centralPeak?: boolean }
  ) => {
    const latScale = Math.max(0.32, Math.sin((cy / H) * Math.PI));
    const rx = r / latScale;
    const ry = r;

    drawWrapped(cCtx, cx, cy, rx * 2.5, (ox) => {
      // Optional bright ejecta rays (Tycho / Copernicus / Kepler / Aristarchus)
      if (options?.rays && options.rays > 0) {
        cCtx.save();
        for (let ray = 0; ray < options.rays; ray++) {
          const ang = (ray / options.rays) * Math.PI * 2 + (rand() - 0.5) * 0.25;
          const len = r * (3.2 + rand() * 5.2);
          const endX = ox + Math.cos(ang) * (len / latScale);
          const endY = cy + Math.sin(ang) * len;
          const rg = cCtx.createLinearGradient(ox, cy, endX, endY);
          rg.addColorStop(0, 'rgba(242, 240, 234, 0.52)');
          rg.addColorStop(0.45, 'rgba(225, 223, 216, 0.2)');
          rg.addColorStop(1, 'rgba(225, 223, 216, 0)');
          cCtx.strokeStyle = rg;
          cCtx.lineWidth = Math.max(1.2, r * (0.14 + rand() * 0.18));
          cCtx.beginPath();
          cCtx.moveTo(ox, cy);
          cCtx.lineTo(endX, endY);
          cCtx.stroke();
        }
        cCtx.restore();
      }

      // Outer dust ejecta collar
      const halo = cCtx.createRadialGradient(ox, cy, rx * 0.8, ox, cy, rx * 1.55);
      halo.addColorStop(0, 'rgba(220, 218, 212, 0.34)');
      halo.addColorStop(1, 'rgba(220, 218, 212, 0)');
      cCtx.fillStyle = halo;
      cCtx.beginPath();
      cCtx.ellipse(ox, cy, rx * 1.55, ry * 1.55, 0, 0, Math.PI * 2);
      cCtx.fill();

      // Crater depressed floor
      const floorGrad = cCtx.createRadialGradient(ox + rx * 0.15, cy + ry * 0.15, rx * 0.08, ox, cy, rx);
      floorGrad.addColorStop(0, options?.darkFloor ? 'rgba(38, 40, 46, 0.85)' : 'rgba(84, 83, 79, 0.58)');
      floorGrad.addColorStop(0.75, 'rgba(110, 108, 102, 0.42)');
      floorGrad.addColorStop(0.95, 'rgba(222, 220, 214, 0.48)');
      floorGrad.addColorStop(1, 'rgba(222, 220, 214, 0)');
      cCtx.fillStyle = floorGrad;
      cCtx.beginPath();
      cCtx.ellipse(ox, cy, rx, ry, 0, 0, Math.PI * 2);
      cCtx.fill();

      // Bump Map crater profile (deep bowl -> crisp bright raised rim -> ambient)
      const bGrad = bCtx.createRadialGradient(ox, cy, rx * 0.1, ox, cy, rx * 1.18);
      bGrad.addColorStop(0, 'rgba(20, 20, 20, 0.82)');
      bGrad.addColorStop(0.65, 'rgba(55, 55, 55, 0.65)');
      bGrad.addColorStop(0.86, 'rgba(248, 248, 248, 0.82)');
      bGrad.addColorStop(0.96, 'rgba(195, 195, 195, 0.4)');
      bGrad.addColorStop(1, 'rgba(142, 142, 142, 0)');
      bCtx.fillStyle = bGrad;
      bCtx.beginPath();
      bCtx.ellipse(ox, cy, rx * 1.18, ry * 1.18, 0, 0, Math.PI * 2);
      bCtx.fill();

      // Optional central uplift peak
      if (options?.centralPeak) {
        const pGrad = bCtx.createRadialGradient(ox, cy, 0.5, ox, cy, rx * 0.22);
        pGrad.addColorStop(0, 'rgba(245, 245, 245, 0.9)');
        pGrad.addColorStop(1, 'rgba(20, 20, 20, 0)');
        bCtx.fillStyle = pGrad;
        bCtx.beginPath();
        bCtx.ellipse(ox, cy, rx * 0.22, ry * 0.22, 0, 0, Math.PI * 2);
        bCtx.fill();

        cCtx.fillStyle = 'rgba(218, 216, 210, 0.6)';
        cCtx.beginPath();
        cCtx.ellipse(ox, cy, Math.max(1.5, rx * 0.12), Math.max(1.5, ry * 0.12), 0, 0, Math.PI * 2);
        cCtx.fill();
      }
    });
  };

  // 5. Landmark Iconic Craters (aligned to DAY_SECTORS & MOON_SPOTS)
  const landmarks: Array<{ lat: number; lon: number; r: number; darkFloor?: boolean; rays?: number; peak?: boolean }> = [
    { lat: -43, lon: -11, r: 24, rays: 18, peak: true },  // Tycho
    { lat: 10, lon: -20, r: 26, rays: 14, peak: true },   // Copernicus
    { lat: 24, lon: -47, r: 16, rays: 10, peak: true },   // Aristarchus
    { lat: 8, lon: -38, r: 14, rays: 9 },                 // Kepler
    { lat: 51, lon: -9, r: 24, darkFloor: true },         // Plato
    { lat: -58, lon: -14, r: 44, peak: true },            // Clavius
    { lat: -82, lon: 18, r: 18, darkFloor: true },        // Shackleton South Pole
    { lat: -20, lon: 129, r: 34, darkFloor: true, peak: true }, // Tsiolkovskiy
    { lat: -4, lon: -157, r: 38, peak: true },            // Korolev
    { lat: -25, lon: 60, r: 28, peak: true },             // Petavius
    { lat: -66, lon: -69, r: 42 },                        // Bailly
    { lat: 2, lon: -129, r: 48 },                         // Hertzsprung
  ];
  landmarks.forEach((lm) => {
    const [lx, ly] = moonLatLonToPx(lm.lat, lm.lon, W, H);
    paintCrater(lx, ly, lm.r, {
      darkFloor: lm.darkFloor,
      rays: lm.rays,
      centralPeak: lm.peak,
    });
  });

  // 6. Scatter 380 realistic varied craters across all scales
  for (let i = 0; i < 380; i++) {
    const cx = rand() * W;
    const cy = 28 + rand() * (H - 56);
    const tier = rand();
    const r = tier < 0.65 ? 2.5 + rand() * 5.5 : tier < 0.92 ? 7 + rand() * 14 : 20 + rand() * 20;
    paintCrater(cx, cy, r, { centralPeak: r > 18 && rand() > 0.5 });
  }

  // 7. Fine micro-regolith mineral speckle across albedo & bump pixels
  const cImg = cCtx.getImageData(0, 0, W, H);
  const bImg = bCtx.getImageData(0, 0, W, H);
  const cd = cImg.data;
  const bd = bImg.data;
  for (let p = 0; p < cd.length; p += 4) {
    const n = (rand() - 0.5) * 18;
    cd[p] = Math.max(0, Math.min(255, cd[p] + n));
    cd[p + 1] = Math.max(0, Math.min(255, cd[p + 1] + n));
    cd[p + 2] = Math.max(0, Math.min(255, cd[p + 2] + n));

    const bn = (rand() - 0.5) * 24;
    const bv = Math.max(0, Math.min(255, bd[p] + bn));
    bd[p] = bv;
    bd[p + 1] = bv;
    bd[p + 2] = bv;
  }
  cCtx.putImageData(cImg, 0, 0);
  bCtx.putImageData(bImg, 0, 0);

  const map = new THREE.CanvasTexture(colorCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.anisotropy = maxAnisotropy;

  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  bumpMap.colorSpace = THREE.NoColorSpace;
  bumpMap.anisotropy = maxAnisotropy;

  const roughnessMap = new THREE.CanvasTexture(roughCanvas);
  roughnessMap.colorSpace = THREE.NoColorSpace;
  roughnessMap.anisotropy = maxAnisotropy;

  return { map, bumpMap, roughnessMap };
}

export function createMoonGlobeCanvasTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const { map, bumpMap, roughnessMap } = createRealisticMoonTextures(maxAnisotropy);
  bumpMap.dispose();
  roughnessMap.dispose();
  return map;
}

export interface BuiltRocket3D {
  group: THREE.Group;
  flameGroup: THREE.Group;
}

/**
 * Builds a composite 10-part PBR 3D rocket centered at bottom-center (y = 0 at nozzle exit).
 * Distinct silhouette features vary by RocketId so each selected rocket looks unique!
 */
export function build3DRocketMesh(
  rocketId: RocketId | undefined,
  maxAnisotropy: number,
  track: TrackFn
): BuiltRocket3D {
  const spec = getRocketSpec(rocketId);
  const group = new THREE.Group();

  const hullTex = track(createRocketHullCanvasTexture(spec, maxAnisotropy));
  const hullMat = track(
    new THREE.MeshStandardMaterial({
      map: hullTex,
      roughness: 0.24,
      metalness: spec.id === 'apollo-gold' ? 0.65 : 0.18,
    })
  );
  const noseMat = track(
    new THREE.MeshStandardMaterial({
      color: spec.noseColorHex,
      roughness: 0.26,
      metalness: 0.42,
    })
  );
  const finMat = track(
    new THREE.MeshStandardMaterial({
      color: spec.finColorHex,
      roughness: 0.3,
      metalness: 0.38,
    })
  );
  const chromeMat = track(
    new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.16,
      metalness: 0.92,
    })
  );
  const accentMat = track(
    new THREE.MeshStandardMaterial({
      color: spec.accentColorHex,
      roughness: 0.22,
      metalness: 0.82,
    })
  );
  const darkNozzleMat = track(
    new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.38,
      metalness: 0.85,
    })
  );
  const glassMat = track(
    new THREE.MeshStandardMaterial({
      color: spec.accentColorHex,
      emissive: spec.flamePrimaryHex,
      emissiveIntensity: 1.35,
      roughness: 0.12,
      metalness: 0.2,
    })
  );

  // 1. Engine Nozzle Bell
  const nozzleProfile = [
    new THREE.Vector2(0.46, 0.0),
    new THREE.Vector2(0.41, 0.18),
    new THREE.Vector2(0.28, 0.42),
    new THREE.Vector2(0.36, 0.56),
  ];
  const nozzle = new THREE.Mesh(track(new THREE.LatheGeometry(nozzleProfile, 24)), darkNozzleMat);
  nozzle.castShadow = true;
  group.add(nozzle);

  // 2. Thruster Inner Core
  const thrusterCore = new THREE.Mesh(
    track(new THREE.CircleGeometry(0.38, 20)),
    track(new THREE.MeshBasicMaterial({ color: spec.flamePrimaryHex }))
  );
  thrusterCore.rotation.x = Math.PI / 2;
  thrusterCore.position.y = 0.04;
  group.add(thrusterCore);

  // 3. Lower Engine Collar
  const lowerCollar = new THREE.Mesh(
    track(new THREE.CylinderGeometry(0.76, 0.6, 0.35, 28)),
    darkNozzleMat
  );
  lowerCollar.position.y = 0.72;
  lowerCollar.castShadow = true;
  group.add(lowerCollar);

  // 4. Main Cylindrical Hull
  const bodyRadiusTop = spec.id === 'falcon-cyan' ? 0.68 : 0.76;
  const bodyRadiusBot = spec.id === 'apollo-gold' ? 0.84 : 0.76;
  const mainBody = new THREE.Mesh(
    track(new THREE.CylinderGeometry(bodyRadiusTop, bodyRadiusBot, 2.75, 32)),
    hullMat
  );
  mainBody.position.y = 2.27;
  mainBody.rotation.y = -Math.PI / 2;
  mainBody.castShadow = true;
  group.add(mainBody);

  // 5. Accent Rings
  const upperRing = new THREE.Mesh(
    track(new THREE.TorusGeometry(bodyRadiusTop + 0.01, 0.045, 10, 32)),
    accentMat
  );
  upperRing.rotation.x = Math.PI / 2;
  upperRing.position.y = 3.63;
  group.add(upperRing);

  const lowerRing = new THREE.Mesh(
    track(new THREE.TorusGeometry(bodyRadiusBot + 0.01, 0.045, 10, 32)),
    chromeMat
  );
  lowerRing.rotation.x = Math.PI / 2;
  lowerRing.position.y = 0.92;
  group.add(lowerRing);

  // 6. Aerodynamic Nose Cone
  const noseHeight = spec.id === 'falcon-cyan' ? 1.75 : 1.48;
  const nosePts: THREE.Vector2[] = [];
  for (let i = 0; i <= 14; i++) {
    const t = i / 14;
    const r = bodyRadiusTop * Math.pow(1 - t, spec.id === 'apollo-gold' ? 0.56 : 0.68);
    nosePts.push(new THREE.Vector2(Math.max(0.03, r), t * noseHeight));
  }
  const noseCone = new THREE.Mesh(track(new THREE.LatheGeometry(nosePts, 28)), noseMat);
  noseCone.position.y = 3.65;
  noseCone.castShadow = true;
  group.add(noseCone);

  // 7. Chrome Spire
  const tipSpire = new THREE.Mesh(track(new THREE.CylinderGeometry(0.015, 0.055, 0.34, 14)), chromeMat);
  tipSpire.position.y = 3.65 + noseHeight + 0.14;
  group.add(tipSpire);

  // 8. Cockpit Porthole Window
  const portholeGroup = new THREE.Group();
  portholeGroup.position.set(0.32, 2.95, bodyRadiusTop - 0.08);
  portholeGroup.lookAt(0.65, 2.95, 1.4);
  const bezel = new THREE.Mesh(track(new THREE.TorusGeometry(0.24, 0.05, 12, 24)), chromeMat);
  const glass = new THREE.Mesh(track(new THREE.SphereGeometry(0.22, 18, 14)), glassMat);
  glass.scale.z = 0.45;
  portholeGroup.add(bezel, glass);
  group.add(portholeGroup);

  // 9. Beveled Tail Fins (3 or 4 fins depending on ship)
  const finCount = spec.id === 'falcon-cyan' || spec.id === 'apollo-gold' ? 4 : 3;
  const finShape = new THREE.Shape();
  finShape.moveTo(0, 0);
  finShape.lineTo(spec.id === 'falcon-cyan' ? 0.92 : 0.75, -0.35);
  finShape.lineTo(spec.id === 'falcon-cyan' ? 0.92 : 0.75, 0.35);
  finShape.lineTo(0.06, 1.15);
  finShape.lineTo(0, 1.15);
  finShape.closePath();

  const finGeo = track(
    new THREE.ExtrudeGeometry(finShape, {
      depth: 0.08,
      bevelEnabled: true,
      bevelThickness: 0.02,
      bevelSize: 0.02,
      bevelSegments: 2,
    })
  );
  finGeo.translate(0, 0, -0.04);

  for (let i = 0; i < finCount; i++) {
    const finHolder = new THREE.Group();
    finHolder.rotation.y = (i / finCount) * Math.PI * 2 + 0.4;
    const finMesh = new THREE.Mesh(finGeo, finMat);
    finMesh.position.set(bodyRadiusBot - 0.04, 0.78, 0);
    finMesh.castShadow = true;
    finHolder.add(finMesh);
    group.add(finHolder);
  }

  // 10. Side Mini-Boosters / Pods
  const boosterBodyGeo = track(new THREE.CylinderGeometry(0.24, 0.24, 1.75, 18));
  const boosterConeGeo = track(new THREE.ConeGeometry(0.24, 0.55, 18));
  const boosterNozzleGeo = track(new THREE.CylinderGeometry(0.14, 0.22, 0.28, 14));
  const podOffset = bodyRadiusBot + 0.19;
  [-podOffset, podOffset].forEach((bx) => {
    const bGroup = new THREE.Group();
    bGroup.position.set(bx, 0.3, 0);
    const bBody = new THREE.Mesh(
      boosterBodyGeo,
      spec.id === 'comet-emerald' ? finMat : chromeMat
    );
    bBody.position.y = 1.05;
    bBody.castShadow = true;
    const bCone = new THREE.Mesh(boosterConeGeo, noseMat);
    bCone.position.y = 2.2;
    const bNoz = new THREE.Mesh(boosterNozzleGeo, darkNozzleMat);
    bNoz.position.y = 0.04;
    bGroup.add(bBody, bCone, bNoz);
    group.add(bGroup);
  });

  // 11. Multi-Layer Additive Thruster Flame Plume
  const flameGroup = new THREE.Group();
  flameGroup.position.set(0, 0.02, 0);
  group.add(flameGroup);

  const innerMat = track(
    new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.95,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  const midMat = track(
    new THREE.MeshBasicMaterial({
      color: spec.flamePrimaryHex,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  const outerMat = track(
    new THREE.MeshBasicMaterial({
      color: spec.flameSecondaryHex,
      transparent: true,
      opacity: 0.6,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );

  const makeFlameCone = (radius: number, len: number, mat: THREE.Material) => {
    const geo = track(new THREE.ConeGeometry(radius, len, 18));
    geo.rotateX(Math.PI);
    geo.translate(0, -len / 2, 0);
    return new THREE.Mesh(geo, mat);
  };

  flameGroup.add(
    makeFlameCone(0.68, 3.6, outerMat),
    makeFlameCone(0.45, 2.5, midMat),
    makeFlameCone(0.28, 1.5, innerMat)
  );
  flameGroup.scale.set(0.6, 0.4, 0.6);

  return { group, flameGroup };
}
