# ASTRA: The Last 30 Days – Lunar Survival Simulation (Refined)

An interactive, scientifically informed educational lunar survival web simulation built for the NASA Space Apps Challenge. The player acts as Expedition Commander of the lunar research base **ASTRA**, guiding a 4-person crew through 30 mission days by managing life-support systems, balancing energy generation, addressing mechanical and environmental emergencies, and exploring the lunar outpost.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following revisions and specifications are locked into this plan:
> - **Scientific Rigor & Education**: Clear distinction between simplified educational game mechanics and real-world NASA flight rules. Real NASA data (Artemis Program, LRO polar illumination studies, ISS/Gateway ECLSS water recovery) is cited with verified sources in an in-app "NASA Science & Sources" panel. The simulation explicitly explains that while equatorial regions endure a strict 14-day night, polar crater rims (such as Shackleton) experience grazing, near-permanent sunlight on elevated peaks, contrasting with Permanently Shadowed Regions (PSRs).
> - **Balanced Survival Math**: Initial reserves and daily consumption calibrated to provide an achievable 30-day mission for prudent commanders (including a 25% safety reserve margin). Decisions provide explicit resource impact previews, avoiding unfair instantaneous game-overs.
> - **3D Architecture with Resilient Fallback**: Procedural Three.js 3D base with 6 distinct composite modules, raycasting inspection, orbit camera, and an automatic 2D/2.5D schematic tactical fallback if WebGL fails or hardware acceleration is absent.
> - **Decoupled Optional Audio**: Procedural Web Audio space synthesizer with prominent top-bar mute control, completely isolated from gameplay logic so audio never impedes simulation flow.
> - **Structured Verification & Test Matrix**: Step-by-step verification covering day 1 through day 30, crisis resolution branches, win/loss states, and localStorage persistence.

---

### 1. Overview & Core Concept

- **What It Does**: A complete, responsive mission-control web simulation where players take the helm of Lunar Outpost ASTRA for 30 consecutive mission days. Players monitor real-time resource meters, inspect 3D outpost modules, balance power generation across lunar day/night transitions, assign crew duties, resolve unpredictable lunar crises (solar radiation flares, micrometeorite strikes, ECLSS leaks, power distributor failures), and receive a comprehensive end-of-mission NASA debriefing report.
- **Target Audience / Persona**: Space enthusiasts, science students, Space Apps Challenge participants, and strategy gamers interested in realistic astronautics and life-support engineering.
- **Key Value**: Delivers an engaging, scientifically grounded experience showing the genuine challenges of sustainable human presence on the Moon without artificial complexity or external API paywalls.

---

### 2. Scientific Accuracy & Educational Transparency

To satisfy NASA Space Apps Challenge educational standards, the simulation incorporates dedicated scientific disclosures:

1. **Lunar Polar Illumination vs. Equatorial Simplification**:
   - *Game Mechanic*: The outpost models a dynamic illumination cycle (high-power daylight phase transitioning to a low-solar twilight/storage phase) to teach energy storage trade-offs and battery bank sizing.
   - *Scientific Reality (Clarified in-app)*: In real lunar South Pole sites (e.g., Shackleton rim, Connecting Ridge, Malapert Mountain), the low solar elevation angle (~1.5° above the horizon) produces grazing sunlight on elevated ridges for over 70–86% of the year, while crater floors remain in permanent shadow (holding cryogenic water ice). The simulation features an educational note explaining this exact orbital mechanics distinction.
2. **ECLSS Life Support Baselines (NASA Standards)**:
   - Human consumption baselines calibrated using NASA Life Support Baseline Values and Assumptions Document (BVAD):
     - Metabolic O₂ consumption: ~0.84 kg / astronaut / day (crew of 4 = ~3.36 kg / day).
     - Hydration & food preparation: ~2.5 L / astronaut / day (crew of 4 = ~10 L / day).
     - Water recovery efficiency: Realistic closed-loop urine/condensate distillation recovering ~85%–90% of water under nominal operations.
     - Food rations: 3 nutritionally balanced freeze-dried / rehydrated meals per day per astronaut.
3. **Dedicated In-App Educational Reference Drawer**:
   - Accessible via the top bar and debrief screen, listing authentic NASA research citations:
     - NASA Artemis Program Lunar Exploration Plan
     - NASA Lunar Reconnaissance Orbiter (LRO) Polar Illumination & Ice Detection data
     - NASA Technical Reports Server (NTRS) – ECLSS Advanced Water Recovery & Sabatier CO₂ Reduction
     - NASA Space Radiation Analysis Group (SRAG) – Solar Particle Event (SPE) shielding protocols using lunar regolith (minimum 2–3 meters regolith overburden).

---

### 3. Balanced Gameplay & Resource Mechanics

The simulation parameters are balanced so that players who make sensible decisions can consistently complete all 30 days while still experiencing realistic operational tension:

| Resource | Initial Reserve | Daily Crew Consumption (Base 4 Crew) | Daily Base Production / Recovery | Net Daily Delta (Nominal) | Safety Days Margin |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Oxygen (kg)** | 140 kg | 3.36 kg / day | +2.0 kg / day (ECLSS Sabatier + Hydroponics) | -1.36 kg / day | ~100 days (Plenty of reserve for crisis events) |
| **Water (L)** | 180 L | 10.0 L / day | +8.5 L / day (85% recovery recycling) | -1.5 L / day | ~120 days nominal safety margin |
| **Food (Rations)** | 160 packs | 4.0 packs / day | +0.5 pack / day (Hydroponic fresh supplements) | -3.5 packs / day | ~45 days (Achievable 30-day baseline) |
| **Power (kWh)** | 220 kWh (Cap: 300) | 45 kWh / day (Life support, heaters, comms, lights) | Variable: +65 kWh (Sun) / +15 kWh (Storage/Fuel cell) | +20 kWh (Sun) / -30 kWh (Night) | Requires active battery management & panel dusting |

- **Transparent Decision Impact**: Every daily decision card displays exact resource impact deltas (e.g., `+15 kWh power, -2.5 kg O₂, +5% crew fatigue`) before the player confirms.
- **Fail-Safe Warnings**: When any vital resource drops below 20%, an immediate amber caution banner warns the player with recommended countermeasures. Mission failure only triggers if O₂, H₂O, or Power remains at 0 for more than 24 hours, or if crew health averages 0%.

---

### 4. Technical Architecture & Phased Implementation

```
┌────────────────────────────────────────────────────────────────────────┐
│                        ASTRA LUNAR MISSION SHELL                       │
│ ┌────────────────────────────────────────────────────────────────────┐ │
│ │ Top Bar: Day X/30 · Illumination · Crew Vitals · Audio Mute · Help │ │
│ └────────────────────────────────────────────────────────────────────┘ │
│ ┌──────────────────────────────────┬─────────────────────────────────┐ │
│ │      PRIMARY VIEWPORT STAGE      │       TELEMETRY SIDEBAR         │ │
│ │                                  │                                 │ │
│ │  [A] Mission Control Dashboard   │  - Consumables Meters (O2, H2O, │ │
│ │  [B] 3D Lunar Base Exploration   │    Power, Food) with trends     │ │
│ │      (With 2D Schematic Fallback)│  - 4-Astronaut Crew Roster      │ │
│ │  [C] Daily Tactical Decisions    │  - Subsystem Operational Health │ │
│ │  [D] Emergency Response Center   │  - Real-Time Activity Log       │ │
│ │  [E] Final Debrief & NASA Report │  - [Advance to Next Day] CTA    │ │
│ └──────────────────────────────────┴─────────────────────────────────┘ │
│ ┌────────────────────────────────────────────────────────────────────┐ │
│ │ Collapsible Bottom Dock: View Switcher · Science Notes · Reset Save │ │
└─┴────────────────────────────────────────────────────────────────────┴─┘
```

#### Development Priorities & Execution Phases:

- **Phase 1: Core Engine & Data Structures (Immediate)**
  - `src/types/mission.ts`: Strict TypeScript definitions for resources, crew, modules, daily scenarios, emergencies, and history logs.
  - `src/services/simulationEngine.ts`: Deterministic calculation of consumption, recycling, lunar solar angles, day progression, and win/fail condition checks.
  - `src/services/storageService.ts`: Safe `localStorage` persistence with versioning, auto-save on every day advance, and clean reset functionality.
  - `src/data/missionContent.ts`: 30 authentic daily operational scenarios, 10 crisis events, module definitions, and NASA educational citations.

- **Phase 2: Core Views & Gameplay Loop**
  - `LandingPage.tsx`: Atmospheric cinematic hero, mission summary, "Start Mission" and "How to Play" guide.
  - `MissionBriefing.tsx`: Day 0 crew profiles, resource allowances, Shackleton landing coordinates, and mission launch action.
  - `DashboardView.tsx`: Comprehensive mission control telemetry, dynamic resource dials, consumption rates, crew vitals, and activity log.
  - `DailyDecisionModal.tsx` & `EmergencyModal.tsx`: High-stakes decision cards with trade-off previews and action confirmations.
  - `FinalReportView.tsx`: NASA Space Apps Challenge debrief with performance scoring, survival statistics, key decisions recap, and restart action.

- **Phase 3: 3D Lunar Base & Resilient Fallback**
  - `LunarBase3D.tsx`: Three.js procedural environment (lunar crater mesh, high-contrast sunlight, Earth in the sky, starfield) and 6 composite modules:
    1. *Living Habitat*: Beveled cylindrical pressurized module with airlock port and viewing cupola.
    2. *Solar Power Array*: Dual photovoltaic tracker panels with metallic truss mounts.
    3. *Life Support (ECLSS)*: Pressurized oxygen/water scrubber tanks, radiator fins, and piping.
    4. *Hydroponic Greenhouse*: Geodesic biometallurgic dome with interior green grow-lights.
    5. *Research Laboratory*: Hexagonal science module with sensory masts and spectrometer dish.
    6. *Deep-Space Comm Station*: High-gain parabolic antenna reflector with gimbal mount.
  - Interactive module raycasting/selection smoothly transitions camera and opens module diagnostics.
  - *Fallback*: Automatic detection of WebGL context creation failure; smoothly renders an interactive SVG tactical blueprint if 3D is unsupported.

- **Phase 4: Optional Audio & Educational Polish**
  - `src/services/soundEngine.ts`: Web Audio procedural synthesizer (radio telemetry chirp, ambient spacecraft hum, alert Klaxon, button clicks) with a prominent top-bar mute button, defaulted to respectful volume and completely isolated from game state execution.
  - `ScienceModal.tsx`: NASA references, Artemis Program links, and educational disclosures.
  - Help / Survival Handbook modal explaining ECLSS mechanics and lunar survival tips.

- **Phase 5: Comprehensive Verification & Testing**
  - Run full simulation sweeps through Day 30 to verify resource mathematical stability, emergency triggers, local storage persistence, and victory/defeat boundaries.
  - Ensure zero compilation errors via `compile_applet`.
